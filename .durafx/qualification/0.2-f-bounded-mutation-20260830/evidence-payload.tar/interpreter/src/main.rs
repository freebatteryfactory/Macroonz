//! Disposable typed custody crossing for the accepted Wave F bounded-verification subject.

use std::io::{self, Write};

use macroonz_harness::descriptor::ClaimRef;
use macroonz_harness::muterprater::wrap::read_artifact;
use macroonz_harness::muterprater::{
    AdapterQualification, AnnouncedRoster, BackendCommand, BackendVersion, ClaimCeiling,
    CompiledSuiteArtifactCustody, CompiledSuiteArtifactStanding, CompiledSuitePressure,
    ExecutionAxis, GrammarStanding, MaterializationAxis, MutationBackendInvocation,
    MutationSourceRevision, MutationVerdict, OperatorFamilyRef, SourceCoordinate, WrappedBackend,
};
use macroonz_harness::report::{TargetBinding, TargetTriple, ToolchainIdentity};

const BACKEND_OUTPUT: &str = include_str!("../../authoritative.stdout.txt");
const SOURCE: &[u8] = include_bytes!("../../../src/lib.rs");
const SOURCE_FILE: &str = "src/lib.rs";
const BACKEND_VERSION: &str = "27.0.0";
const BACKEND_TARGET: &str = "x86_64-pc-windows-msvc";
const BACKEND_TOOLCHAIN: &str =
    "cargo 1.98.0 (797e8a9bc 2026-08-05); rustc 1.98.0 (88d9e12ae 2026-08-18)";
const SELECTOR: &str = "(Qualification::rendered|qualify|complete_u8_domain|derived_u8_denominator|complete_reading|temporal_reading|inspect_complete|inspect_generated_domain|source_incomplete|resource_incomplete|incomplete_reading|counterexample|report_reduce_replay|refused_fingerprint|hostile_binding|invocation|hostile_probe|hostile_check|decode_member|opening_state|apply_rotate_xor|apply_invert|apply_hostile|roundtrip_holds)";
const COMMAND: &[&str] = &[
    "+1.98.0",
    "mutants",
    "--no-config",
    "--in-place",
    "--file",
    SOURCE_FILE,
    "--re",
    SELECTOR,
    "--cap-lints",
    "false",
    "--test-tool",
    "cargo",
    "--baseline",
    "run",
    "--jobserver-tasks",
    "1",
    "--no-shuffle",
    "--caught",
    "--unviable",
    "--no-times",
    "--colors",
    "never",
    "--annotations",
    "none",
    "--timeout",
    "300",
    "--build-timeout",
    "300",
    "--output",
    "custody/authoritative",
    "--cargo-arg=--locked",
    "--cargo-arg=--offline",
    "--cargo-arg=--target",
    "--cargo-arg=x86_64-pc-windows-msvc",
    "--cargo-arg=--jobs",
    "--cargo-arg=1",
    "--",
    "--test",
    "bounded",
    "--",
    "--test-threads=1",
];

#[derive(Default)]
struct OutcomeCounts {
    caught: u32,
    missed: u32,
    unviable: u32,
    timed_out: u32,
    tool_failed: u32,
}

fn owner(coordinate: &SourceCoordinate) -> Option<ClaimRef> {
    (coordinate.file() == SOURCE_FILE)
        .then(|| ClaimRef::named("wave-f-bounded-verification", "finite-domain-sensitivity"))
        .and_then(Result::ok)
}

const fn family(_: &SourceCoordinate, _: &[u8]) -> Option<OperatorFamilyRef> {
    None
}

macro_rules! require {
    ($condition:expr, $message:literal) => {
        if !$condition {
            return Err($message.to_owned());
        }
    };
}

fn classify(
    reports: &[macroonz_harness::muterprater::MutationReport],
) -> Result<OutcomeCounts, String> {
    let mut counts = OutcomeCounts::default();
    for report in reports {
        match (
            report.verdict(),
            report.materialization(),
            report.execution(),
        ) {
            (MutationVerdict::Killed, MaterializationAxis::Built, ExecutionAxis::Completed) => {
                counts.caught = counts.caught.saturating_add(1);
            }
            (
                MutationVerdict::Inconclusive,
                MaterializationAxis::Built,
                ExecutionAxis::Completed,
            ) => {
                counts.missed = counts.missed.saturating_add(1);
            }
            (MutationVerdict::Inconclusive, MaterializationAxis::Unviable, _) => {
                counts.unviable = counts.unviable.saturating_add(1);
            }
            (MutationVerdict::Inconclusive, _, ExecutionAxis::TimedOut) => {
                counts.timed_out = counts.timed_out.saturating_add(1);
            }
            (MutationVerdict::Inconclusive, MaterializationAxis::ToolFailed, _) => {
                counts.tool_failed = counts.tool_failed.saturating_add(1);
            }
            _ => {
                return Err("the parsed report carries an outcome outside this campaign".to_owned());
            }
        }
    }
    Ok(counts)
}

fn execute() -> Result<String, String> {
    let version = BackendVersion::stated(BACKEND_VERSION).map_err(|error| format!("{error:?}"))?;
    let command =
        BackendCommand::declared("cargo", COMMAND).map_err(|error| format!("{error:?}"))?;
    let invocation = MutationBackendInvocation::declared(
        WrappedBackend::CargoMutants,
        version.clone(),
        command,
        TargetBinding::bound(
            TargetTriple::declared(BACKEND_TARGET),
            ToolchainIdentity::declared(BACKEND_TOOLCHAIN),
        ),
    );
    let source = MutationSourceRevision::from_content(SOURCE_FILE, SOURCE)
        .map_err(|error| format!("{error:?}"))?;
    let manifest = read_artifact(
        BACKEND_OUTPUT,
        invocation,
        vec![source.clone()],
        owner,
        family,
    )
    .map_err(|error| format!("{error:?}"))?;
    require!(
        manifest.reading().announced() == AnnouncedRoster::Stated(42),
        "the announced roster is not exactly 42"
    );
    let reports = manifest.reading().run().reports();
    require!(reports.len() == 42, "the parsed roster is not exactly 42");
    require!(
        reports
            .iter()
            .all(|report| report.target().owning_claim().is_some()),
        "a selected target lacks the Wave F claim owner"
    );
    let counts = classify(reports)?;
    require!(
        counts.caught == 16,
        "the caught denominator is not exactly 16"
    );
    require!(counts.missed == 0, "a viable mutant was missed");
    require!(
        counts.unviable == 26,
        "the unviable denominator is not exactly 26"
    );
    require!(counts.timed_out == 0, "a selected mutant timed out");
    require!(counts.tool_failed == 0, "the mutation tool failed");
    let [summary] = manifest.reading().unparsed() else {
        return Err("the backend summary is not the sole unparsed line".to_owned());
    };
    require!(
        summary.text().bytes() == b"42 mutants tested: 16 caught, 26 unviable",
        "the backend summary moved"
    );
    require!(
        manifest.sources() == [source.clone()],
        "the manifest source roster is not exact"
    );
    let qualification =
        AdapterQualification::of(manifest.reading(), GrammarStanding::Checked(version))
            .map_err(|error| format!("{error:?}"))?;
    require!(
        qualification.ceiling() == ClaimCeiling::WitnessRejection,
        "the adapter ceiling moved"
    );
    let custody = CompiledSuiteArtifactCustody::current(manifest, vec![source])
        .map_err(|error| format!("{error:?}"))?;
    let pressure = CompiledSuitePressure::demonstrated(
        CompiledSuiteArtifactStanding::Reported(&custody),
        &qualification,
    )
    .map_err(|error| format!("{error:?}"))?;
    require!(
        pressure.kill().verdict() == MutationVerdict::Killed,
        "the typed pressure carries no lawful kill"
    );
    Ok(format!(
        "WAVE_F_MUTATION=qualified-local-sensitivity\nBACKEND=cargo-mutants;VERSION={BACKEND_VERSION}\nTARGET={BACKEND_TARGET}\nROSTER=42;CAUGHT={};MISSED={};UNVIABLE={};TIMED_OUT={};TOOL_FAILED={}\nSOURCE={SOURCE_FILE};CURRENT=true\nCLAIM=wave-f-bounded-verification::finite-domain-sensitivity\nCEILING=witness-rejection;ACTIVATION=unobservable-under-backend\nPRESSURE=demonstrated-current-source\nDISPOSITION=existing-Muterprater-custody-composes;no-product-seam\n",
        counts.caught, counts.missed, counts.unviable, counts.timed_out, counts.tool_failed,
    ))
}

fn main() -> Result<(), String> {
    let output = execute()?;
    io::stdout()
        .lock()
        .write_all(output.as_bytes())
        .map_err(|error| error.to_string())
}
