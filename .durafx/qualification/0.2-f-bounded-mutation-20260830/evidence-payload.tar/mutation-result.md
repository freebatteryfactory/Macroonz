# Wave F bounded mutation result

## Standing

This local Windows x64 sublot pressed the complete one-file Cargo Mutants roster visible in the accepted Wave F `src/lib.rs` source at commit `2828e7de9652db5de8ac5fd8a555428a4b059bed`.

The authoritative run tested 42 selected mutants and reported 16 caught, 26 compile-unviable, zero missed, zero timed out, and zero tool-failed.

Compile-unviable rows are retained as inconclusive under the existing Muterprater materialization axis and are never counted as kills.

The run establishes local stable-Rust Windows witness-rejection sensitivity over the selected source and external tests.

It does not establish activation, equivalence, another host, another target, general mutation adequacy, or Wave F acceptance.

## Accepted source custody

The source payload was extracted from `.durafx/qualification/0.2-f-bounded-verification-20260830/source-payload.tar` into this disposable directory.

Every retained source hash matched before enumeration and matched again after the in-place mutation run restored the source.

| Source | SHA-256 |
| --- | --- |
| `Cargo.lock` | `294ECCD45C08EED79D6E7D447DDD0BAD37708F090097D9D4AC3922AE0777F6D1` |
| `Cargo.toml` | `65088A5FE5DCA9F30ABE5F110598A8C8A45F8721B06D7D4A46E170DC227EC24F` |
| `rust-toolchain.toml` | `E879701472A698533F43F54989BBF5F3101EB0503472159D32633F3BB8A13FDF` |
| `src/lib.rs` | `3A22884F05427B354E3A242A1E4C3C57FE98C0354B809D71D84B96BF22A40F5E` |
| `src/main.rs` | `9075948EAE5D9A2E33EFF9D1195B3C96D8EF03A55F54D3ECF6ACD4F87610511A` |
| `tests/bounded.rs` | `2DDD9C336A69992C09ECE5315763CE430913773EC62ED76CB35E6C3EA342C869` |
| `result.md` | `AEC8F50C7105610BCEA5D1C2B29ACDC4A5C4BAF439065AD33F8FE0CB10D6A994` |

## Tool and command

The backend was `cargo-mutants 27.0.0` under `rustc 1.98.0 (88d9e12ae 2026-08-18)` and `cargo 1.98.0 (797e8a9bc 2026-08-05)` for `x86_64-pc-windows-msvc`.

The ordinary extracted scratch library and its external `bounded` test were the actual subject and witness executed by Cargo Mutants.

The unchanged baseline passed both external tests under this command:

```text
cargo +1.98.0 test --locked --offline --test bounded --target x86_64-pc-windows-msvc --jobs 1 --color never -- --test-threads=1
```

The authoritative mutation command was:

```text
cargo +1.98.0 mutants --no-config --in-place --file src/lib.rs --re (Qualification::rendered|qualify|complete_u8_domain|derived_u8_denominator|complete_reading|temporal_reading|inspect_complete|inspect_generated_domain|source_incomplete|resource_incomplete|incomplete_reading|counterexample|report_reduce_replay|refused_fingerprint|hostile_binding|invocation|hostile_probe|hostile_check|decode_member|opening_state|apply_rotate_xor|apply_invert|apply_hostile|roundtrip_holds) --cap-lints false --test-tool cargo --baseline run --jobserver-tasks 1 --no-shuffle --caught --unviable --no-times --colors never --annotations none --timeout 300 --build-timeout 300 --output custody/authoritative --cargo-arg=--locked --cargo-arg=--offline --cargo-arg=--target --cargo-arg=x86_64-pc-windows-msvc --cargo-arg=--jobs --cargo-arg=1 -- --test bounded -- --test-threads=1
```

One preliminary command combined Cargo Mutants `--in-place` with its own `--jobs 1`, which version 27 refuses before baseline or mutation execution.

The authoritative command removed that incompatible backend flag while retaining one Cargo-heavy task through `--jobserver-tasks 1` and the inner Cargo `--jobs 1`.

## Selected denominator

The selector retained all 42 mutants listed for `src/lib.rs` and no other source file.

The selected functions and counts were:

| Function | Mutants |
| --- | ---: |
| `Qualification::rendered` | 2 |
| `qualify` | 1 |
| `complete_u8_domain` | 3 |
| `derived_u8_denominator` | 2 |
| `complete_reading` | 1 |
| `temporal_reading` | 4 |
| `inspect_complete` | 1 |
| `inspect_generated_domain` | 1 |
| `source_incomplete` | 1 |
| `resource_incomplete` | 1 |
| `incomplete_reading` | 1 |
| `counterexample` | 1 |
| `report_reduce_replay` | 1 |
| `refused_fingerprint` | 1 |
| `hostile_binding` | 1 |
| `invocation` | 1 |
| `hostile_probe` | 2 |
| `hostile_check` | 1 |
| `decode_member` | 1 |
| `opening_state` | 1 |
| `apply_rotate_xor` | 5 |
| `apply_invert` | 3 |
| `apply_hostile` | 2 |
| `roundtrip_holds` | 4 |

This denominator crosses denominator derivation and completeness, the lawful property, order variation, source exhaustion versus byte-budget exhaustion, vacuity, the exact `0xA5` counterexample, report joining, reduction census, and replay posture.

The complete selected roster is retained in `custody/selected-mutant-list.json` and the backend outcome roster is retained in `custody/authoritative/mutants.out/outcomes.json`.

## Typed custody crossing

The disposable `custody/interpreter` package consumed the exact backend console and exact current `src/lib.rs` bytes through the existing public Muterprater road.

That road was `read_artifact` to `AdapterQualification` to `CompiledSuiteArtifactCustody::current` to `CompiledSuitePressure::demonstrated`.

Every source coordinate was mapped to `wave-f-bounded-verification::finite-domain-sensitivity`, while every mutation remained outside the operator bank because this sublot did not claim a Macroonz operator-family attribution.

The interpreter asserted an announced and parsed roster of 42, the exact five outcome counts, the sole unparsed summary, complete current-source custody, the witness-rejection ceiling, and at least one lawful compiled-suite kill.

It passed formatting, checking, strict Clippy, and two identical locked-offline executions under stable Rust 1.98.

The exact repeated account is retained in `custody/typed-current-source-account.txt`.

No product schema seam, new reusable infrastructure, or tracked architecture was required.

## Key custody hashes

| Artifact | SHA-256 |
| --- | --- |
| `custody/selected-mutant-list.json` | `DCB367084CC297EEACDB342B9CC31EB2039957862AA15F874DA6CD2C5E21BF38` |
| `custody/authoritative.stdout.txt` | `2AAE98381100872B5B2D63A3674D380632638279A00BB9EB3E4F27A780ABFE85` |
| `custody/authoritative.stderr.txt` | `E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855` |
| `custody/authoritative-exit-code.txt` | `5FECEB66FFC86F38D952786C6D696C79C2DBC239DD4E91B46729D73A27FB57E9` |
| `custody/authoritative/mutants.out/mutants.json` | `DCB367084CC297EEACDB342B9CC31EB2039957862AA15F874DA6CD2C5E21BF38` |
| `custody/authoritative/mutants.out/outcomes.json` | `CBC8F47B6D4FC23B2C59279A0AC637586C669B251FA478DF583940B023BFE0A2` |
| `custody/authoritative/mutants.out/caught.txt` | `01FC157BC66094060AC5BAE295DB7F23ED44127A610AD937EBE961357CEECD47` |
| `custody/authoritative/mutants.out/missed.txt` | `E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855` |
| `custody/authoritative/mutants.out/unviable.txt` | `36DC1F9CA3CA1FB871E84ABBB48D6CB7A8615C9532D77BCFC76E897AAC264C32` |
| `custody/authoritative/mutants.out/timeout.txt` | `E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855` |

The complete Cargo Mutants output directory remains present and unsealed in disposable scratch for parent QA.
