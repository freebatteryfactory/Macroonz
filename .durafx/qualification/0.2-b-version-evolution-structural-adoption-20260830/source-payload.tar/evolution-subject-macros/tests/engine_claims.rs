//! External claims over the private subject engine source.

#![forbid(unsafe_code)]
#![deny(warnings)]

#[path = "../src/engine.rs"]
mod engine;

use bakery::compiler::request::committed;
use bakery::compiler::{
    CanonicalContent, Closure, ClosureIssue, GeneratedDelimiter, GeneratedToken, GeneratedTree,
    PlannedMember, RenderedProjection, RenderedUnit, TextCapture,
};
use engine::{
    EdgeSpec, EvolutionDeclaration, EvolutionRole, GrammarIssue, RenderStyle, read_declaration,
};

const BASELINE: &str = r"
versions { V1, V2, V3, }
edges { V1 -> V2, V2 -> V3, }
adapters {
    V1 -> V2 = V1ToV2 add(5),
    V2 -> V3 = V2ToV3 add(7),
}
";

const PERMUTED: &str = r"
versions { V1, V2, V3, }
edges { V2 -> V3, V1 -> V2, }
adapters {
    V2 -> V3 = V2ToV3 add(7),
    V1 -> V2 = V1ToV2 add(5),
}
";

const DIRECT_ADDED: &str = r"
versions { V1, V2, V3, }
edges { V1 -> V2, V2 -> V3, V1 -> V3, }
adapters {
    V1 -> V2 = V1ToV2 add(5),
    V2 -> V3 = V2ToV3 add(7),
    V1 -> V3 = V1ToV3 add(12),
}
";

fn read(source: &str) -> Result<bakery::compiler::CapturedInput, String> {
    TextCapture::read(source)
        .map(|capture| capture.input().clone())
        .map_err(|error| error.to_string())
}

fn parsed(source: &str) -> Result<EvolutionDeclaration, String> {
    read_declaration(&read(source)?)
        .map_err(|refusal| format!("declaration refused as {:?}", refusal.issue()))
}

fn require_refusal(source: &str) -> Result<engine::GrammarRefusal, String> {
    match read_declaration(&read(source)?) {
        Ok(_) => Err("hostile declaration unexpectedly informed a version graph".to_owned()),
        Err(refusal) => Ok(refusal),
    }
}

fn content_bytes(declaration: &EvolutionDeclaration) -> Vec<u8> {
    let mut bytes = Vec::new();
    declaration.encode_content_into(&mut bytes);
    bytes
}

fn expansion(
    source: &str,
    style: RenderStyle,
) -> Result<bakery::compiler::Expansion<engine::EvolutionProjection>, String> {
    let capture = read(source)?;
    let result = match style {
        RenderStyle::Direct => engine::compile(capture),
        RenderStyle::Refactored => engine::compile_refactored(capture),
    };
    result.map_err(|diagnostic| diagnostic.summary().to_owned())
}

#[test]
fn baseline_declares_complete_version_edge_and_adapter_rosters() -> Result<(), String> {
    let declaration = parsed(BASELINE)?;
    let versions: Vec<&str> = declaration
        .versions
        .members()
        .map(|version| version.name.as_str())
        .collect();
    assert_eq!(versions, ["V1", "V2", "V3"]);
    let edges: Vec<(&str, &str, &str, u64)> = declaration
        .adapters
        .indexed()
        .map(|(_index, _edge_key, _edge, _seat, adapter)| {
            (
                adapter.edge.from.as_str(),
                adapter.edge.to.as_str(),
                adapter.seat.as_str(),
                adapter.added,
            )
        })
        .collect();
    assert_eq!(
        edges,
        [("V1", "V2", "V1ToV2", 5), ("V2", "V3", "V2ToV3", 7),]
    );
    assert!(
        !declaration
            .adapters
            .denominator()
            .members()
            .any(|edge| edge.from == "V1" && edge.to == "V3")
    );
    Ok(())
}

#[test]
fn version_roster_refuses_empty_duplicate_and_overbound_material() -> Result<(), String> {
    let empty = require_refusal("versions { } edges { V1 -> V2, } adapters { }")?;
    assert_eq!(empty.issue(), &GrammarIssue::VersionsAbsent);

    let duplicate = require_refusal(
        "versions { V1, V1, } edges { V1 -> V1, } adapters { V1 -> V1 = V1ToV1 add(0), }",
    )?;
    assert_eq!(
        duplicate.issue(),
        &GrammarIssue::DuplicateVersion("V1".to_owned())
    );

    let overbound = require_refusal(
        "versions { V1, V2, V3, V4, V5, V6, V7, V8, V9, } edges { V1 -> V2, } adapters { V1 -> V2 = V1ToV2 add(1), }",
    )?;
    assert_eq!(overbound.issue(), &GrammarIssue::VersionsUnbounded);
    Ok(())
}

#[test]
fn edge_law_refuses_foreign_duplicate_self_and_backward_rows() -> Result<(), String> {
    let foreign = require_refusal(
        "versions { V1, V2, } edges { V1 -> V3, } adapters { V1 -> V3 = V1ToV3 add(1), }",
    )?;
    assert_eq!(
        foreign.issue(),
        &GrammarIssue::ForeignEdge(EdgeSpec {
            from: "V1".to_owned(),
            to: "V3".to_owned(),
        })
    );

    let duplicate = require_refusal(
        "versions { V1, V2, } edges { V1 -> V2, V1 -> V2, } adapters { V1 -> V2 = V1ToV2 add(1), }",
    )?;
    assert_eq!(
        duplicate.issue(),
        &GrammarIssue::DuplicateEdge(EdgeSpec {
            from: "V1".to_owned(),
            to: "V2".to_owned(),
        })
    );

    let self_edge = require_refusal(
        "versions { V1, V2, } edges { V1 -> V1, } adapters { V1 -> V1 = V1ToV1 add(1), }",
    )?;
    assert_eq!(
        self_edge.issue(),
        &GrammarIssue::SelfEdge(EdgeSpec {
            from: "V1".to_owned(),
            to: "V1".to_owned(),
        })
    );

    let backward = require_refusal(
        "versions { V1, V2, } edges { V2 -> V1, } adapters { V2 -> V1 = V2ToV1 add(1), }",
    )?;
    assert_eq!(
        backward.issue(),
        &GrammarIssue::BackwardEdge(EdgeSpec {
            from: "V2".to_owned(),
            to: "V1".to_owned(),
        })
    );
    Ok(())
}

#[test]
fn adapter_accounting_refuses_missing_doubled_foreign_and_reused_seats() -> Result<(), String> {
    let missing = require_refusal(
        "versions { V1, V2, V3, } edges { V1 -> V2, V2 -> V3, } adapters { V1 -> V2 = V1ToV2 add(1), }",
    )?;
    assert_eq!(
        missing.issue(),
        &GrammarIssue::MissingAdapter(EdgeSpec {
            from: "V2".to_owned(),
            to: "V3".to_owned(),
        })
    );

    let doubled = require_refusal(
        "versions { V1, V2, } edges { V1 -> V2, } adapters { V1 -> V2 = First add(1), V1 -> V2 = Second add(1), }",
    )?;
    assert_eq!(
        doubled.issue(),
        &GrammarIssue::DuplicateAdapter(EdgeSpec {
            from: "V1".to_owned(),
            to: "V2".to_owned(),
        })
    );

    let foreign = require_refusal(
        "versions { V1, V2, V3, } edges { V1 -> V2, } adapters { V1 -> V3 = V1ToV3 add(1), }",
    )?;
    assert_eq!(
        foreign.issue(),
        &GrammarIssue::ForeignAdapter(EdgeSpec {
            from: "V1".to_owned(),
            to: "V3".to_owned(),
        })
    );

    let reused = require_refusal(
        "versions { V1, V2, V3, } edges { V1 -> V2, V2 -> V3, } adapters { V1 -> V2 = Shared add(1), V2 -> V3 = Shared add(1), }",
    )?;
    assert_eq!(
        reused.issue(),
        &GrammarIssue::DuplicateAdapterSeat("Shared".to_owned())
    );
    Ok(())
}

#[test]
fn version_mixed_hostiles_preserve_legacy_fail_fast_diagnostic() -> Result<(), String> {
    let capture =
        read("versions { V1, V1, 1, } edges { V1 -> V1, } adapters { V1 -> V1 = V1ToV1 add(0), }")?;
    let [_, version_group, _, _, _, _] = capture.trees() else {
        return Err("the version mixed-hostile control lost its declaration grammar".to_owned());
    };
    let Some((_, [_, _, repeated_version, _, _, _])) = version_group.group() else {
        return Err("the version mixed-hostile control lost its version rows".to_owned());
    };
    let Err(refusal) = read_declaration(&capture) else {
        return Err("the version mixed-hostile control unexpectedly informed".to_owned());
    };
    assert_eq!(
        refusal.issue(),
        &GrammarIssue::DuplicateVersion("V1".to_owned())
    );
    assert_eq!(refusal.token(), Some(repeated_version.span()));
    Ok(())
}

#[test]
fn edge_mixed_hostiles_preserve_legacy_fail_fast_diagnostic() -> Result<(), String> {
    let edge_capture = read(
        "versions { V1, V2, } edges { V1 -> V2, V1 -> V2, V1 => V2, } adapters { V1 -> V2 = V1ToV2 add(1), }",
    )?;
    let [_, _, _, edge_group, _, _] = edge_capture.trees() else {
        return Err("the edge mixed-hostile control lost its declaration grammar".to_owned());
    };
    let Some((_, edge_tokens)) = edge_group.group() else {
        return Err("the edge mixed-hostile control lost its edge rows".to_owned());
    };
    let (edge_rows, edge_remainder) = edge_tokens.as_chunks::<5>();
    let [_, repeated_edge, _] = edge_rows else {
        return Err("the edge mixed-hostile control lost its three rows".to_owned());
    };
    assert!(edge_remainder.is_empty());
    let [repeated_from, _, _, _, _] = repeated_edge;
    let Err(edge_refusal) = read_declaration(&edge_capture) else {
        return Err("the edge mixed-hostile control unexpectedly informed".to_owned());
    };
    assert_eq!(
        edge_refusal.issue(),
        &GrammarIssue::DuplicateEdge(EdgeSpec {
            from: "V1".to_owned(),
            to: "V2".to_owned(),
        })
    );
    assert_eq!(edge_refusal.token(), Some(repeated_from.span()));
    Ok(())
}

#[test]
fn adapter_mixed_hostiles_preserve_legacy_fail_fast_diagnostic() -> Result<(), String> {
    let adapter_capture = read(
        "versions { V1, V2, V3, } edges { V1 -> V2, V2 -> V3, } adapters { V1 -> V2 = Shared add(1), V2 -> V3 = Shared add(2), V1 -> V3 = Foreign add(3), }",
    )?;
    let [_, _, _, _, _, adapter_group] = adapter_capture.trees() else {
        return Err("the adapter mixed-hostile control lost its declaration grammar".to_owned());
    };
    let Some((_, adapter_tokens)) = adapter_group.group() else {
        return Err("the adapter mixed-hostile control lost its adapter rows".to_owned());
    };
    let (adapter_rows, adapter_remainder) = adapter_tokens.as_chunks::<9>();
    let [_, repeated_seat_adapter, _] = adapter_rows else {
        return Err("the adapter mixed-hostile control lost its three rows".to_owned());
    };
    assert!(adapter_remainder.is_empty());
    let [_, _, _, _, _, repeated_seat, _, _, _] = repeated_seat_adapter;
    let Err(adapter_refusal) = read_declaration(&adapter_capture) else {
        return Err("the adapter mixed-hostile control unexpectedly informed".to_owned());
    };
    assert_eq!(
        adapter_refusal.issue(),
        &GrammarIssue::DuplicateAdapterSeat("Shared".to_owned())
    );
    assert_eq!(adapter_refusal.token(), Some(repeated_seat.span()));
    Ok(())
}

#[test]
fn authored_edge_order_still_selects_the_first_missing_adapter() -> Result<(), String> {
    let refusal =
        require_refusal("versions { V1, V2, V3, } edges { V2 -> V3, V1 -> V2, } adapters { }")?;
    assert_eq!(
        refusal.issue(),
        &GrammarIssue::MissingAdapter(EdgeSpec {
            from: "V2".to_owned(),
            to: "V3".to_owned(),
        })
    );
    assert_eq!(refusal.token(), None);
    Ok(())
}

#[test]
fn duplicate_precedence_survives_an_overbound_prefix() -> Result<(), String> {
    let version_refusal = require_refusal(
        "versions { V1, V2, V3, V4, V5, V6, V7, V8, V9, V1, } edges { V1 -> V2, } adapters { V1 -> V2 = V1ToV2 add(1), }",
    )?;
    assert_eq!(
        version_refusal.issue(),
        &GrammarIssue::DuplicateVersion("V1".to_owned())
    );

    let edge_refusal = require_refusal(
        "versions { V1, V2, V3, V4, V5, V6, V7, V8, } edges { V1 -> V2, V1 -> V3, V1 -> V4, V1 -> V5, V1 -> V6, V1 -> V7, V1 -> V8, V2 -> V3, V2 -> V4, V2 -> V5, V2 -> V6, V2 -> V7, V2 -> V8, V3 -> V4, V3 -> V5, V3 -> V6, V3 -> V7, V1 -> V2, } adapters { }",
    )?;
    assert_eq!(
        edge_refusal.issue(),
        &GrammarIssue::DuplicateEdge(EdgeSpec {
            from: "V1".to_owned(),
            to: "V2".to_owned(),
        })
    );
    Ok(())
}

#[test]
fn malformed_arrow_is_typed_and_placed_at_the_wrong_token() -> Result<(), String> {
    let capture =
        read("versions { V1, V2, } edges { V1 => V2, } adapters { V1 -> V2 = V1ToV2 add(1), }")?;
    let [_, _, _, edge_group, _, _] = capture.trees() else {
        return Err("malformed control lost its top-level grammar".to_owned());
    };
    let Some((_, edge_tokens)) = edge_group.group() else {
        return Err("malformed control lost its edge group".to_owned());
    };
    let [_, wrong_dash, wrong_arrow, _, _] = edge_tokens else {
        return Err("malformed control lost its five-token edge row".to_owned());
    };
    let Err(refusal) = read_declaration(&capture) else {
        return Err("malformed arrow unexpectedly informed a graph".to_owned());
    };
    assert_eq!(refusal.issue(), &GrammarIssue::MalformedEdge);
    assert_eq!(refusal.token(), Some(wrong_dash.span()));
    assert_ne!(refusal.token(), Some(wrong_arrow.span()));
    Ok(())
}

#[test]
fn adding_direct_edge_moves_every_semantic_compiler_reading() -> Result<(), String> {
    let baseline_capture = read(BASELINE)?;
    let changed_capture = read(DIRECT_ADDED)?;
    assert_ne!(committed(&baseline_capture), committed(&changed_capture));
    let baseline_declaration = read_declaration(&baseline_capture)
        .map_err(|refusal| format!("baseline refused as {:?}", refusal.issue()))?;
    let changed_declaration = read_declaration(&changed_capture)
        .map_err(|refusal| format!("changed refused as {:?}", refusal.issue()))?;
    assert_ne!(
        content_bytes(&baseline_declaration),
        content_bytes(&changed_declaration)
    );

    let baseline = expansion(BASELINE, RenderStyle::Direct)?;
    let changed = expansion(DIRECT_ADDED, RenderStyle::Direct)?;
    assert_ne!(
        baseline.plan().account().content_commitment(),
        changed.plan().account().content_commitment()
    );
    assert_ne!(baseline.plan().identity(), changed.plan().identity());
    let baseline_member = baseline
        .plan()
        .membership()
        .under(EvolutionRole::Graph)
        .ok_or_else(|| "baseline graph plan member absent".to_owned())?;
    let changed_member = changed
        .plan()
        .membership()
        .under(EvolutionRole::Graph)
        .ok_or_else(|| "changed graph plan member absent".to_owned())?;
    assert_ne!(
        baseline_member.output.semantic_key,
        changed_member.output.semantic_key
    );
    let baseline_unit = baseline
        .closure()
        .rendered()
        .under(EvolutionRole::Graph)
        .ok_or_else(|| "baseline rendered graph absent".to_owned())?;
    let changed_unit = changed
        .closure()
        .rendered()
        .under(EvolutionRole::Graph)
        .ok_or_else(|| "changed rendered graph absent".to_owned())?;
    assert_ne!(baseline_unit.bytes(), changed_unit.bytes());
    assert_ne!(baseline.closure().identity(), changed.closure().identity());
    assert_ne!(baseline.explain().identity(), changed.explain().identity());
    assert_ne!(baseline.identity(), changed.identity());
    assert_eq!(baseline_declaration.versions, changed_declaration.versions);
    assert_eq!(baseline_declaration.adapters.denominator().count(), 2);
    assert_eq!(changed_declaration.adapters.denominator().count(), 3);
    assert!(
        changed_declaration
            .adapters
            .denominator()
            .members()
            .any(|edge| edge.from == "V1" && edge.to == "V3")
    );
    Ok(())
}

#[test]
fn edge_permutation_preserves_semantic_output_but_not_raw_capture_identity() -> Result<(), String> {
    let baseline_capture = read(BASELINE)?;
    let permuted_capture = read(PERMUTED)?;
    assert_ne!(committed(&baseline_capture), committed(&permuted_capture));
    assert_eq!(
        content_bytes(&parsed(BASELINE)?),
        content_bytes(&parsed(PERMUTED)?)
    );
    let baseline = expansion(BASELINE, RenderStyle::Direct)?;
    let permuted = expansion(PERMUTED, RenderStyle::Direct)?;
    let baseline_bytes = baseline
        .closure()
        .rendered()
        .under(EvolutionRole::Graph)
        .ok_or_else(|| "baseline rendered graph absent".to_owned())?
        .bytes();
    let permuted_bytes = permuted
        .closure()
        .rendered()
        .under(EvolutionRole::Graph)
        .ok_or_else(|| "permuted rendered graph absent".to_owned())?
        .bytes();
    assert_eq!(baseline_bytes, permuted_bytes);
    assert_ne!(baseline.plan().identity(), permuted.plan().identity());
    assert_ne!(baseline.identity(), permuted.identity());
    Ok(())
}

#[test]
fn private_renderer_refactor_preserves_the_exact_expansion() -> Result<(), String> {
    let direct = expansion(BASELINE, RenderStyle::Direct)?;
    let refactored = expansion(BASELINE, RenderStyle::Refactored)?;
    assert_eq!(direct.plan().identity(), refactored.plan().identity());
    assert_eq!(direct.closure().identity(), refactored.closure().identity());
    assert_eq!(direct.explain().identity(), refactored.explain().identity());
    assert_eq!(direct.identity(), refactored.identity());
    assert_eq!(direct, refactored);
    Ok(())
}

fn raw_path(root: &str, member: &str) -> Vec<GeneratedToken> {
    vec![
        GeneratedToken::word(root),
        GeneratedToken::joint(':'),
        GeneratedToken::alone(':'),
        GeneratedToken::word(member),
    ]
}

fn raw_roster_tokens(declaration: &EvolutionDeclaration) -> Result<Vec<GeneratedToken>, String> {
    let mut versions = Vec::new();
    for version in declaration.versions.members() {
        versions.extend(raw_path("crate", "Version"));
        versions.extend([
            GeneratedToken::joint(':'),
            GeneratedToken::alone(':'),
            GeneratedToken::word(&version.name),
            GeneratedToken::alone(','),
        ]);
    }
    let mut edges = Vec::new();
    for (_index, _edge_key, _edge, _seat, adapter) in declaration.adapters.indexed() {
        let mut row = raw_path("crate", "Edge");
        row.extend([
            GeneratedToken::joint(':'),
            GeneratedToken::alone(':'),
            GeneratedToken::word("declared"),
        ]);
        let mut arguments = raw_path("crate", "Version");
        arguments.extend([
            GeneratedToken::joint(':'),
            GeneratedToken::alone(':'),
            GeneratedToken::word(&adapter.edge.from),
            GeneratedToken::alone(','),
        ]);
        arguments.extend(raw_path("crate", "Version"));
        arguments.extend([
            GeneratedToken::joint(':'),
            GeneratedToken::alone(':'),
            GeneratedToken::word(&adapter.edge.to),
            GeneratedToken::alone(','),
        ]);
        arguments.extend(raw_path("crate", "AdapterSeat"));
        arguments.extend([
            GeneratedToken::joint(':'),
            GeneratedToken::alone(':'),
            GeneratedToken::word(&adapter.seat),
        ]);
        row.push(
            bakery::compiler::group(GeneratedDelimiter::Parenthesis, arguments)
                .map_err(|error| error.to_string())?,
        );
        row.push(GeneratedToken::alone(','));
        edges.extend(row);
    }
    let mut tokens = bakery::compiler::documentation("The complete generated version roster.")
        .map_err(|error| error.to_string())?;
    tokens.extend([
        GeneratedToken::word("pub"),
        GeneratedToken::word("const"),
        GeneratedToken::word("VERSIONS"),
        GeneratedToken::alone(':'),
        GeneratedToken::alone('&'),
    ]);
    tokens.push(
        bakery::compiler::group(GeneratedDelimiter::Bracket, raw_path("crate", "Version"))
            .map_err(|error| error.to_string())?,
    );
    tokens.extend([
        GeneratedToken::alone('='),
        GeneratedToken::alone('&'),
        bakery::compiler::group(GeneratedDelimiter::Bracket, versions)
            .map_err(|error| error.to_string())?,
        GeneratedToken::alone(';'),
    ]);
    tokens.extend(
        bakery::compiler::documentation("The complete generated edge and adapter roster.")
            .map_err(|error| error.to_string())?,
    );
    tokens.extend([
        GeneratedToken::word("pub"),
        GeneratedToken::word("const"),
        GeneratedToken::word("EDGES"),
        GeneratedToken::alone(':'),
        GeneratedToken::alone('&'),
    ]);
    tokens.push(
        bakery::compiler::group(GeneratedDelimiter::Bracket, raw_path("crate", "Edge"))
            .map_err(|error| error.to_string())?,
    );
    tokens.extend([
        GeneratedToken::alone('='),
        GeneratedToken::alone('&'),
        bakery::compiler::group(GeneratedDelimiter::Bracket, edges)
            .map_err(|error| error.to_string())?,
        GeneratedToken::alone(';'),
    ]);
    Ok(tokens)
}

fn generated_bytes(tokens: Vec<GeneratedToken>) -> Result<Vec<u8>, String> {
    GeneratedTree::assembled(tokens)
        .map(|tree| tree.canonical_bytes())
        .map_err(|error| error.to_string())
}

#[test]
fn paved_rosters_preserve_independently_written_legacy_bytes() -> Result<(), String> {
    for source in [BASELINE, DIRECT_ADDED] {
        let declaration = parsed(source)?;
        let paved = engine::roster_tokens(&declaration).map_err(|error| error.to_string())?;
        let raw = raw_roster_tokens(&declaration)?;
        assert_eq!(generated_bytes(paved)?, generated_bytes(raw)?);
    }
    Ok(())
}

#[test]
fn closure_refuses_omitted_and_doubled_graph_units() -> Result<(), String> {
    let baseline = expansion(BASELINE, RenderStyle::Direct)?;
    let planned = baseline
        .plan()
        .membership()
        .under(EvolutionRole::Graph)
        .ok_or_else(|| "baseline graph plan member absent".to_owned())?;
    let foreign = PlannedMember {
        role: EvolutionRole::HostileForeign,
        output: planned.output.clone(),
    };
    let foreign_tree = GeneratedTree::assembled(vec![
        GeneratedToken::word("struct"),
        GeneratedToken::word("Foreign"),
        GeneratedToken::alone(';'),
    ])
    .map_err(|error| error.to_string())?;
    let foreign_unit =
        RenderedUnit::materialized(&foreign, foreign_tree).map_err(|error| error.to_string())?;
    let omitted = Closure::proved(baseline.plan(), RenderedProjection::of_one(foreign_unit))
        .err()
        .ok_or_else(|| "a rendering omitting the graph unexpectedly closed".to_owned())?;
    assert!(omitted.issues().iter().any(|issue| {
        issue
            == &ClosureIssue::MemberMissing {
                role: EvolutionRole::Graph,
            }
    }));

    let graph = baseline
        .closure()
        .rendered()
        .under(EvolutionRole::Graph)
        .ok_or_else(|| "baseline rendered graph absent".to_owned())?
        .clone();
    let doubled = RenderedProjection::materialized(vec![graph.clone(), graph])
        .map_err(|error| error.to_string())?;
    let duplicated = Closure::proved(baseline.plan(), doubled)
        .err()
        .ok_or_else(|| "a doubled graph rendering unexpectedly closed".to_owned())?;
    assert!(duplicated.issues().iter().any(|issue| {
        issue
            == &ClosureIssue::MemberDuplicated {
                role: EvolutionRole::Graph,
                observed: 2,
            }
    }));
    Ok(())
}
