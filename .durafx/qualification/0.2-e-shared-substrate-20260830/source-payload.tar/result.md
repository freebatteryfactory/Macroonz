# Wave E shared-substrate falsification result

This scratch-only result records one bounded local Windows observation and does not accept or seal Wave E.

## Authority and fence

- Repository baseline and current HEAD: `2f03aa2ed103dd4f3b6e70f36f8b35b05ab69be4`.
- Scratch home: `target/qualification/0.2-wave-e-shared-substrate-20260830`.
- Toolchain: stable Rust 1.98.0 only.
- Target and host: `x86_64-pc-windows-msvc` on Microsoft Windows 11 Home `10.0.26200`, build `26200`, AMD64.
- Cargo identity: `cargo 1.98.0 (797e8a9bc 2026-08-05)`.
- Rustc identity: `rustc 1.98.0 (88d9e12ae 2026-08-18)` with LLVM `22.1.8`.
- Cargo ran locked and offline after scratch-only lock preparation, with one build job.
- No product source, tracked file, `.durafx`, portable context, manifest, documentation, Git ref, or repository Cargo architecture was changed.
- No network, installation, nightly toolchain, Python, commit, seal, cleanup, push, or merge was used.

## Question

Can the existing exact compile-contract method and temporal-drive method share the current lower runner and report substrate while retaining method-specific observations and ceilings?

## Reused evidence and current observations

The exact compilation facts are not claimed as fresh rustc executions by this scratch process.

- The lawful compilation and exact E0308 refusal reuse the accepted external-process holder at `.durafx/qualification/0.2-a-compile-contract-holder-20260829/receipt.md`.
- That holder receipt has SHA-256 `B906A55CF527D6A360B81AE49418BDBDA63F5153DA726F07F9E31575A73F5A8C`.
- The reused hostile anchor is `src/bin/generated-hostile.rs:14:13..14:21` with error code E0308.
- The holder states that its external host constructed the `ObservedCompilation` value after real stable-rustc execution and carried its conclusions through `HostTrialRecord`, `record_one`, and `record_all`.
- The prior direct-harness receipt at `.durafx/qualification/0.2-q1-direct-harness-20260829/receipt.md` has SHA-256 `06B93A748E43880B10D2170EED3F3C63CE6E16FBF05FD5AE1D1803660A810E30` and establishes the already-accepted handwritten temporal composition precedent.
- This scratch freshly executed the current `holds_over_drive` API for one complete lawful drive, one incomplete drive, and one hostile counterexample drive.
- This scratch freshly exercised current runner and report admission for every record it truthfully constructed.

The planted controls are explicit and carry no observed-process claim.

- The compile hostile control declares `src/bin/generated-hostile.rs:14:14..14:22` against the reused exact observed anchor and refuses with `FailureClass::OracleDisagreement` and cause `compiled-diagnostic-primary-span`.
- The unavailable compile posture carries the local prerequisite name `stable-rustc-host` and maps only to `SkippedWithReason(PrerequisiteAbsent)`.
- The temporal hostile input `[4]` produces `FailureClass::PropertyDisagreement` and cause `("wave-e-shared-substrate", "state-remains-bounded")`.

## Authored denominator

The witness authors seven rows before selection and retains all seven in the final report census.

| Row | Method-specific fact | Report disposition |
| --- | --- | --- |
| compile-lawful | Reused accepted `ObservedCompilation::compiled()` matches `DeclaredCompilation::compiles()` | `Passed` |
| compile-exact-refusal | Reused accepted exact E0308 anchor matches the declaration | `Passed` |
| compile-unavailable | Required compiler prerequisite is absent | `Skipped(PrerequisiteAbsent)` |
| temporal-complete | Two cases are evaluated and generation halts at `CaseBudgetMet` | `Passed` |
| temporal-incomplete | One case is evaluated and generation halts at `SourceExhausted` before the case budget | `NotSelected(OutsideSelection)` |
| compile-wrong-span | Planted declared span differs from the reused observed span | `Refused(OracleDisagreement)` |
| temporal-counterexample | The hostile drive crosses the declared state bound | `Refused(PropertyDisagreement)` |

Six rows have truthful `RunAttempt` values and enter `HostTrialRecord`, `record_one`, and `record_all`.

The incomplete temporal row remains visibly authored and typed as `TemporalDriveStanding::Incomplete`.

Selecting all seven rows while supplying only the six truthful host records refuses exactly as `ReportRecordingRefusal::MissingSelectedRecord(incomplete_trial)`.

That control proves the complete denominator cannot silently omit the incomplete method result.

## Shared rail and preserved method distinctions

The lowest truthful reuse disposition is method-specific adapters over the existing runner and report rail.

- `TrialBinding` carries the declared method identity through `CheckRef` and its version through the derived check revision.
- `TrialBinding` independently carries subject identity and derived subject revision.
- `Invocation` carries the common declared bounds, exact target, and exact Cargo-plus-rustc toolchain spelling.
- `HostTrialRecord` carries only the bound trial identity, truthful attempt, method conclusion where one exists, and measurement posture.
- `record_one` derives and verifies the admitted execution key and standing from the binding, invocation, and host record.
- `record_all` owns the complete seven-row census, selection accounting, conclusions, and report-level custody.

The compiler diagnostic code and primary span remain inside `DeclaredCompilation`, `ObservedCompilation`, and their comparison result.

They never become temporal generation, census, halt, or counterexample facts.

The temporal generated census, `GenerationHalt`, evaluated count, and counterexample remain inside `TemporalDriveReading` and its standing.

They never become compilation observations or diagnostic anchors.

No cross-method observation union, generic analysis owner, public type, product adapter, dependency, feature, or package was introduced.

## Exact seam

`RunAttempt` can truthfully carry an executed `TrialConclusion`, a stated skip, a timeout, or an infrastructure failure.

`TemporalDriveStanding::Incomplete` means the method ran and evaluated a prefix, but generation stopped before its declared case budget and therefore produced no conclusion.

Mapping that value to `SkippedWithReason` would falsely state that it did not run.

Mapping it to `TimedOut`, `InfrastructureFailed`, `Passed`, or `Refused` would also flatten or fabricate its method-specific meaning.

The current public report rail therefore cannot admit a selected incomplete temporal drive without caller-forged coherence.

This is the first exact seam and is retained as a truthful ceiling rather than patched in product source.

## Stable qualification

The scratch lock was prepared with:

```text
cargo +1.98.0 generate-lockfile --offline
```

The final source passed:

```text
cargo +1.98.0 fmt --all -- --check
$env:CARGO_BUILD_JOBS='1'; cargo +1.98.0 check --locked --offline --target x86_64-pc-windows-msvc
$env:CARGO_BUILD_JOBS='1'; cargo +1.98.0 clippy --locked --offline --target x86_64-pc-windows-msvc -- -D warnings
```

Two independent executions used:

```text
$env:CARGO_BUILD_JOBS='1'; cargo +1.98.0 run --locked --offline --target x86_64-pc-windows-msvc --quiet
```

Their normalized-LF stdout was byte-identical with SHA-256 `3BB3CEF2DC90F1FDB32C93C4E060E85F493FF71AB0747278E3274F34F6E64D86`.

```text
WAVE_E_SHARED_SUBSTRATE=qualified
METHODS=exact-compilation,temporal-drive
DENOMINATOR=7
SELECTED_RECORDS=6
TEMPORAL_INCOMPLETE=typed-and-unselected
ALL_SELECTED_REFUSAL=missing-selected-record
COMPILE_PROVENANCE=reused-accepted-holder-and-planted-mismatch
COMPILE_HOLDER=.durafx/qualification/0.2-a-compile-contract-holder-20260829/receipt.md
COMPILE_HOLDER_SHA256=B906A55CF527D6A360B81AE49418BDBDA63F5153DA726F07F9E31575A73F5A8C
TARGET=x86_64-pc-windows-msvc
TOOLCHAIN=cargo 1.98.0 (797e8a9bc 2026-08-05); rustc 1.98.0 (88d9e12ae 2026-08-18)
OUTCOMES=[Passed, Passed, Skipped(PrerequisiteAbsent), Passed, NotSelected(OutsideSelection), Refused(OracleDisagreement), Refused(PropertyDisagreement)]
DISPOSITION=method-specific-adapters-over-existing-report-rail
CEILING=no-current-rustc-process-claim;temporal-incomplete-is-not-an-attempt
```

## Source custody

- `Cargo.toml`: `CF4F5A2DC91D3868B45428E2D1D2CC8BA11A835911FCF68ADC88D602A76E1D43`.
- `Cargo.lock`: `501F0D8FBD90A392705B1AFCED31347CDE539EAB9C474509F35070603A01970F`.
- `rust-toolchain.toml`: `3EBDB2005CC3A5B3558C25ABA129043FE701ECCE1F2360B8B6672A97B55E810E`.
- `src/main.rs`: `81340AD3471D7EC9F0D3588BB5B966DFC4F1A41B469F630600382CD5C9B3A431`.

All scratch files and build output remain intact for coordinator QA.

## Ceilings

This result establishes one local Windows x64 scratch composition against the live path dependency at baseline `2f03aa2ed103dd4f3b6e70f36f8b35b05ab69be4`.

It does not establish a fresh compile-contract rustc execution, package or registry delivery, Linux, macOS, hosted, Wasm, performance, public-API necessity, product integration, Wave E closure, or human acceptance.

The selected conclusion-bearing rail is reusable as-is.

The incomplete temporal standing remains method-specific and cannot currently join the selected report rail truthfully.
