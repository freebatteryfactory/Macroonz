//! Scratch-only Wave E falsification over two method-specific result families and one report rail.

use arbitrary::{Arbitrary, Unstructured};
use macroonz_harness::clock::{HarnessClock, MeasurementReading};
use macroonz_harness::descriptor::{
    AuthoredTableName, Binding, CheckRef, ClaimRef, Classification, DerivedRevision,
    ExecutableAttachment, ExecutionSuite, Origin, PopulationRef, Provenance, RevisionBinding, Role,
    Row, SubjectRoute, Tag,
};
use macroonz_harness::generate::{
    ByteSource, CaseWidth, GenerationHalt, GenerationPlan, InputOrigin, RejectionAllowance,
    SizeProgression, admit_every_sequence,
};
use macroonz_harness::oracle::{
    DeclaredCompilation, DiagnosticAnchor, ObservedCompilation, PrimarySourceSpan,
    RelativeSourcePath, RustcErrorCode, SourcePosition,
};
use macroonz_harness::properties::{
    Holding, TemporalClaim, TemporalDemand, TemporalDriveReading, TemporalDriveStanding,
    TransitionContract, holds_over_drive,
};
use macroonz_harness::report::{
    ByteBudget, CaseBudget, FailureClass, FindingCause, FindingLocation, GenerationProfile,
    HostTrialRecord, InvocationProfile, NotSelectedReason, OutcomeClass, RunAttempt,
    SelectionDisposition, SkipReason, TargetBinding, TargetTriple, TimeBudget, ToolchainIdentity,
    TrialConclusion, TrialSite,
};
use macroonz_harness::runner::{
    Invocation, ReportRecordingRefusal, Selection, SelectionPlan, TrialBinding, TrialTable,
    record_all, record_one, trial_identity,
};
use std::collections::BTreeSet;

const OWNER: &str = "wave-e-shared-substrate";
const HOLDER_RECEIPT: &str =
    ".durafx/qualification/0.2-a-compile-contract-holder-20260829/receipt.md";
const HOLDER_RECEIPT_SHA256: &str =
    "B906A55CF527D6A360B81AE49418BDBDA63F5153DA726F07F9E31575A73F5A8C";
const COMPILE_METHOD_VERSION: &[u8] = b"macroonz.oracle.compiled/exact-anchor/v1";
const TEMPORAL_METHOD_VERSION: &[u8] = b"macroonz.properties/temporal-drive/v1";
const TEMPORAL_CAUSE: FindingCause = FindingCause::named(OWNER, "state-remains-bounded");
const TARGET: &str = "x86_64-pc-windows-msvc";
const TOOLCHAIN: &str = "cargo 1.98.0 (797e8a9bc 2026-08-05); rustc 1.98.0 (88d9e12ae 2026-08-18)";

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum CompilationProvenance {
    ReusedAcceptedHolder,
    PlantedMismatchControl,
}

#[derive(Debug, Clone, PartialEq, Eq)]
enum CompilationReading {
    Established {
        declared: DeclaredCompilation,
        observed: ObservedCompilation,
        provenance: CompilationProvenance,
    },
    Unavailable {
        prerequisite: &'static str,
    },
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum TemporalRailRefusal {
    Incomplete,
}

#[derive(Debug, Clone, PartialEq, Eq)]
struct State(u8);

#[derive(Debug, Clone, PartialEq, Eq)]
struct Command(u8);

struct RowSpec {
    stem: &'static str,
    claim: &'static str,
    subject: &'static str,
    check: &'static str,
    subject_material: &'static [u8],
    check_material: &'static [u8],
}

fn main() -> Result<(), String> {
    let compile_lawful = CompilationReading::Established {
        declared: DeclaredCompilation::compiles(),
        observed: ObservedCompilation::compiled(),
        provenance: CompilationProvenance::ReusedAcceptedHolder,
    };
    let exact_anchor = exact_refusal_anchor()?;
    let compile_exact_refusal = CompilationReading::Established {
        declared: DeclaredCompilation::refuses(exact_anchor.clone()),
        observed: ObservedCompilation::refused(exact_anchor.clone()),
        provenance: CompilationProvenance::ReusedAcceptedHolder,
    };
    let compile_unavailable = CompilationReading::Unavailable {
        prerequisite: "stable-rustc-host",
    };
    let wrong_span = DiagnosticAnchor::at(
        exact_anchor.code().clone(),
        primary_span("src/bin/generated-hostile.rs", 14, 14, 14, 22)?,
    );
    let compile_hostile = CompilationReading::Established {
        declared: DeclaredCompilation::refuses(wrong_span),
        observed: ObservedCompilation::refused(exact_anchor),
        provenance: CompilationProvenance::PlantedMismatchControl,
    };

    assert_compile_provenance(&compile_lawful, CompilationProvenance::ReusedAcceptedHolder)?;
    assert_compile_provenance(
        &compile_exact_refusal,
        CompilationProvenance::ReusedAcceptedHolder,
    )?;
    assert_compile_provenance(
        &compile_hostile,
        CompilationProvenance::PlantedMismatchControl,
    )?;
    if let CompilationReading::Unavailable { prerequisite } = &compile_unavailable {
        assert_eq!(*prerequisite, "stable-rustc-host");
    } else {
        return Err("the compile-unavailable control became an observation".to_owned());
    }

    let complete_temporal = temporal_reading("complete", &[1, 2], 2, 2, at_most_three)?;
    let incomplete_temporal = temporal_reading("incomplete", &[1], 2, 2, at_most_three)?;
    let hostile_temporal = temporal_reading("counterexample", &[4], 1, 1, at_most_three)?;

    assert_eq!(
        complete_temporal.generated().halt(),
        GenerationHalt::CaseBudgetMet
    );
    assert_eq!(complete_temporal.evaluated(), 2);
    assert_eq!(
        complete_temporal.standing(),
        &TemporalDriveStanding::Concluded(TrialConclusion::Passed)
    );
    assert_eq!(
        incomplete_temporal.generated().halt(),
        GenerationHalt::SourceExhausted
    );
    assert_eq!(incomplete_temporal.evaluated(), 1);
    assert_eq!(
        incomplete_temporal.standing(),
        &TemporalDriveStanding::Incomplete
    );
    let TemporalDriveStanding::Concluded(TrialConclusion::Refused(temporal_finding)) =
        hostile_temporal.standing()
    else {
        return Err("the hostile temporal drive did not retain its counterexample".to_owned());
    };
    assert_eq!(temporal_finding.class(), FailureClass::PropertyDisagreement);
    assert_eq!(temporal_finding.cause(), TEMPORAL_CAUSE);

    let compile_lawful_attempt = compilation_attempt(&compile_lawful);
    assert_eq!(
        compile_lawful_attempt,
        RunAttempt::Executed(TrialConclusion::Passed)
    );
    let compile_exact_refusal_attempt = compilation_attempt(&compile_exact_refusal);
    assert_eq!(
        compile_exact_refusal_attempt,
        RunAttempt::Executed(TrialConclusion::Passed)
    );
    let compile_unavailable_attempt = compilation_attempt(&compile_unavailable);
    assert_eq!(
        compile_unavailable_attempt,
        RunAttempt::SkippedWithReason(SkipReason::PrerequisiteAbsent)
    );
    let compile_hostile_attempt = compilation_attempt(&compile_hostile);
    let RunAttempt::Executed(TrialConclusion::Refused(compile_finding)) = &compile_hostile_attempt
    else {
        return Err("the wrong-span compile control did not refuse".to_owned());
    };
    assert_eq!(compile_finding.class(), FailureClass::OracleDisagreement);
    assert_eq!(
        compile_finding.cause().local(),
        "compiled-diagnostic-primary-span"
    );

    let specs = row_specs();
    let bindings = specs.iter().map(binding).collect::<Result<Vec<_>, _>>()?;
    let (incomplete_trial, records) = {
        let [
            compile_lawful_binding,
            compile_refusal_binding,
            compile_unavailable_binding,
            temporal_complete_binding,
            temporal_incomplete_binding,
            compile_hostile_binding,
            temporal_hostile_binding,
        ] = bindings.as_slice()
        else {
            return Err("the fixed Wave E denominator did not contain seven rows".to_owned());
        };
        let incomplete_trial = trial_identity(temporal_incomplete_binding.row());
        let records = vec![
            record_for(compile_lawful_binding, compile_lawful_attempt),
            record_for(compile_refusal_binding, compile_exact_refusal_attempt),
            record_for(compile_unavailable_binding, compile_unavailable_attempt),
            record_for(
                temporal_complete_binding,
                temporal_attempt(&complete_temporal).map_err(|refusal| {
                    format!("complete temporal admission refused: {refusal:?}")
                })?,
            ),
            record_for(compile_hostile_binding, compile_hostile_attempt),
            record_for(
                temporal_hostile_binding,
                temporal_attempt(&hostile_temporal).map_err(|refusal| {
                    format!("hostile temporal admission refused: {refusal:?}")
                })?,
            ),
        ];
        (incomplete_trial, records)
    };

    let invocation = invocation();
    for record in &records {
        let binding = bindings
            .iter()
            .find(|candidate| trial_identity(candidate.row()) == record.trial())
            .ok_or_else(|| "one host record named no bound row".to_owned())?;
        let admitted = record_one(binding, &invocation, record.clone())
            .map_err(|refusal| format!("record_one refused shared-rail input: {refusal:?}"))?;
        assert_eq!(
            admitted.standing().key().target().target().spelling(),
            TARGET
        );
        assert_eq!(
            admitted.standing().key().target().toolchain().spelling(),
            TOOLCHAIN
        );
    }

    let table = TrialTable::authored(
        AuthoredTableName::named(OWNER, "compile-and-temporal-methods")
            .map_err(|refusal| format!("table name refused: {refusal:?}"))?,
        Provenance::Unproduced,
        bindings,
    )
    .map_err(|refusal| format!("table refused: {refusal:?}"))?;

    let selected_ids = records
        .iter()
        .map(HostTrialRecord::trial)
        .collect::<BTreeSet<_>>();
    let report = record_all(
        &table.view(),
        &SelectionPlan::of(Selection::ByTrialIds(selected_ids)),
        &invocation,
        records.clone(),
    )
    .map_err(|refusal| format!("conclusion-bearing report refused: {refusal:?}"))?;
    assert_eq!(report.denominator(), 7);
    assert_eq!(report.census().len(), 7);

    let incomplete_accounting = report
        .census()
        .iter()
        .find(|accounting| accounting.trial() == incomplete_trial)
        .ok_or_else(|| "the temporal-incomplete row disappeared from the census".to_owned())?;
    assert!(matches!(
        incomplete_accounting.disposition(),
        SelectionDisposition::NotSelected {
            trial,
            reason: NotSelectedReason::OutsideSelection,
        } if *trial == incomplete_trial
    ));
    assert_eq!(
        temporal_attempt(&incomplete_temporal),
        Err(TemporalRailRefusal::Incomplete)
    );

    let all_selected = record_all(
        &table.view(),
        &SelectionPlan::of(Selection::All),
        &invocation,
        records,
    );
    assert_eq!(
        all_selected,
        Err(ReportRecordingRefusal::MissingSelectedRecord(
            incomplete_trial
        ))
    );

    let outcomes = report
        .census()
        .iter()
        .map(|accounting| accounting.disposition().outcome())
        .collect::<Vec<_>>();
    assert_eq!(
        outcomes,
        vec![
            OutcomeClass::Passed,
            OutcomeClass::Passed,
            OutcomeClass::Skipped(SkipReason::PrerequisiteAbsent),
            OutcomeClass::Passed,
            OutcomeClass::NotSelected(NotSelectedReason::OutsideSelection),
            OutcomeClass::Refused(FailureClass::OracleDisagreement),
            OutcomeClass::Refused(FailureClass::PropertyDisagreement),
        ]
    );
    println!("WAVE_E_SHARED_SUBSTRATE=qualified");
    println!("METHODS=exact-compilation,temporal-drive");
    println!("DENOMINATOR={}", report.denominator());
    println!("SELECTED_RECORDS=6");
    println!("TEMPORAL_INCOMPLETE=typed-and-unselected");
    println!("ALL_SELECTED_REFUSAL=missing-selected-record");
    println!("COMPILE_PROVENANCE=reused-accepted-holder-and-planted-mismatch");
    println!("COMPILE_HOLDER={HOLDER_RECEIPT}");
    println!("COMPILE_HOLDER_SHA256={HOLDER_RECEIPT_SHA256}");
    println!("TARGET={TARGET}");
    println!("TOOLCHAIN={TOOLCHAIN}");
    println!("OUTCOMES={outcomes:?}");
    println!("DISPOSITION=method-specific-adapters-over-existing-report-rail");
    println!("CEILING=no-current-rustc-process-claim;temporal-incomplete-is-not-an-attempt");
    Ok(())
}

fn assert_compile_provenance(
    reading: &CompilationReading,
    expected: CompilationProvenance,
) -> Result<(), String> {
    match reading {
        CompilationReading::Established { provenance, .. } if *provenance == expected => Ok(()),
        CompilationReading::Established { provenance, .. } => Err(format!(
            "compilation provenance differed: expected {expected:?}, found {provenance:?}"
        )),
        CompilationReading::Unavailable { .. } => {
            Err("an unavailable compilation was treated as established".to_owned())
        }
    }
}

fn compilation_attempt(reading: &CompilationReading) -> RunAttempt {
    match reading {
        CompilationReading::Established {
            declared,
            observed,
            provenance: _,
        } => {
            let verdict =
                macroonz_harness::oracle::compiled::compared_compilation(observed, declared);
            RunAttempt::Executed(verdict.concluded(FindingLocation::at(file!(), line!())))
        }
        CompilationReading::Unavailable { prerequisite: _ } => {
            RunAttempt::SkippedWithReason(SkipReason::PrerequisiteAbsent)
        }
    }
}

fn temporal_attempt(
    reading: &TemporalDriveReading<Command>,
) -> Result<RunAttempt, TemporalRailRefusal> {
    match reading.standing() {
        TemporalDriveStanding::Concluded(conclusion) => {
            Ok(RunAttempt::Executed(conclusion.clone()))
        }
        TemporalDriveStanding::Incomplete => Err(TemporalRailRefusal::Incomplete),
    }
}

fn exact_refusal_anchor() -> Result<DiagnosticAnchor, String> {
    let code = RustcErrorCode::informed("E0308")
        .map_err(|refusal| format!("rustc code refused: {refusal:?}"))?;
    let span = primary_span("src/bin/generated-hostile.rs", 14, 13, 14, 21)?;
    Ok(DiagnosticAnchor::at(code, span))
}

fn primary_span(
    source: &str,
    start_line: u64,
    start_column: u64,
    end_line: u64,
    end_column: u64,
) -> Result<PrimarySourceSpan, String> {
    let source = RelativeSourcePath::informed(source)
        .map_err(|refusal| format!("source path refused: {refusal:?}"))?;
    let start = SourcePosition::informed(start_line, start_column)
        .map_err(|refusal| format!("source start refused: {refusal:?}"))?;
    let end = SourcePosition::informed(end_line, end_column)
        .map_err(|refusal| format!("source end refused: {refusal:?}"))?;
    PrimarySourceSpan::informed(source, start, end)
        .map_err(|refusal| format!("source span refused: {refusal:?}"))
}

fn temporal_reading(
    stem: &'static str,
    supplied: &[u8],
    cases: u32,
    bytes: u64,
    predicate: fn(&State) -> Holding,
) -> Result<TemporalDriveReading<Command>, String> {
    let plan = GenerationPlan::declared(
        PopulationRef::named(OWNER, stem)
            .map_err(|refusal| format!("population refused: {refusal:?}"))?,
        GenerationProfile::declared(stem, 1),
        InputOrigin::Supplied(supplied.to_vec()),
        CaseBudget::declared(cases),
        ByteBudget::declared(bytes),
        RejectionAllowance::declared(2),
        SizeProgression::Constant {
            width: CaseWidth::declared(1)
                .map_err(|refusal| format!("case width refused: {refusal:?}"))?,
        },
    )
    .map_err(|refusal| format!("generation plan refused: {refusal:?}"))?;
    let source = ByteSource::of_plan(&plan);
    let contract = TransitionContract::declared(
        opening_state,
        apply_command,
        vec![TemporalClaim::declared(
            TEMPORAL_CAUSE,
            TemporalDemand::Always(predicate),
        )],
    )
    .map_err(|refusal| format!("temporal contract refused: {refusal:?}"))?;
    Ok(holds_over_drive(
        &contract,
        &plan,
        &source,
        decode_command,
        admit_every_sequence::<Command>,
    ))
}

fn opening_state() -> State {
    State(0)
}

fn apply_command(state: &State, command: &Command) -> State {
    State(state.0.saturating_add(command.0))
}

fn at_most_three(state: &State) -> Holding {
    if state.0 <= 3 {
        Holding::Holds
    } else {
        Holding::Fails
    }
}

fn decode_command(source: &mut Unstructured<'_>) -> arbitrary::Result<Command> {
    Ok(Command(u8::arbitrary(source)?))
}

fn row_specs() -> [RowSpec; 7] {
    [
        RowSpec {
            stem: "compile-lawful",
            claim: "compile-accepts-as-declared",
            subject: "compile-lawful-source",
            check: "exact-compilation",
            subject_material: b"accepted-holder/generated-lawful",
            check_material: COMPILE_METHOD_VERSION,
        },
        RowSpec {
            stem: "compile-exact-refusal",
            claim: "compile-refuses-at-declared-anchor",
            subject: "compile-hostile-source",
            check: "exact-compilation",
            subject_material: b"accepted-holder/generated-hostile",
            check_material: COMPILE_METHOD_VERSION,
        },
        RowSpec {
            stem: "compile-unavailable",
            claim: "compile-prerequisite-standing",
            subject: "compile-unavailable-host",
            check: "exact-compilation",
            subject_material: b"preflight/stable-rustc-absent",
            check_material: COMPILE_METHOD_VERSION,
        },
        RowSpec {
            stem: "temporal-complete",
            claim: "temporal-complete-prefix-holds",
            subject: "temporal-complete-input",
            check: "temporal-drive",
            subject_material: b"supplied/[1,2];cases=2;bytes=2",
            check_material: TEMPORAL_METHOD_VERSION,
        },
        RowSpec {
            stem: "temporal-incomplete",
            claim: "temporal-incomplete-prefix-stays-incomplete",
            subject: "temporal-short-input",
            check: "temporal-drive",
            subject_material: b"supplied/[1];cases=2;bytes=2",
            check_material: TEMPORAL_METHOD_VERSION,
        },
        RowSpec {
            stem: "compile-wrong-span",
            claim: "compile-wrong-span-is-detected",
            subject: "compile-planted-span-control",
            check: "exact-compilation",
            subject_material: b"planted/wrong-span",
            check_material: COMPILE_METHOD_VERSION,
        },
        RowSpec {
            stem: "temporal-counterexample",
            claim: "temporal-counterexample-is-retained",
            subject: "temporal-hostile-input",
            check: "temporal-drive",
            subject_material: b"supplied/[4];cases=1;bytes=1",
            check_material: TEMPORAL_METHOD_VERSION,
        },
    ]
}

fn retained_check(_: &Invocation) -> TrialConclusion {
    TrialConclusion::Passed
}

fn binding(spec: &RowSpec) -> Result<TrialBinding, String> {
    let subject = SubjectRoute::named(OWNER, spec.subject)
        .map_err(|refusal| format!("subject refused: {refusal:?}"))?;
    let check = CheckRef::named(OWNER, spec.check)
        .map_err(|refusal| format!("check refused: {refusal:?}"))?;
    let row = Row::declared(
        ClaimRef::named(OWNER, spec.claim)
            .map_err(|refusal| format!("claim refused: {refusal:?}"))?,
        ExecutionSuite::named(OWNER, "stable-methods")
            .map_err(|refusal| format!("suite refused: {refusal:?}"))?,
        Classification::authored(
            vec![
                Role::named(OWNER, "method-evidence")
                    .map_err(|refusal| format!("role refused: {refusal:?}"))?,
            ],
            vec![
                Tag::named(OWNER, spec.stem)
                    .map_err(|refusal| format!("tag refused: {refusal:?}"))?,
            ],
        )
        .map_err(|refusal| format!("classification refused: {refusal:?}"))?,
        subject,
        check,
        PopulationRef::named(OWNER, "fixed-wave-e-denominator")
            .map_err(|refusal| format!("population refused: {refusal:?}"))?,
        Origin::HandWritten,
    )
    .map_err(|refusal| format!("row refused: {refusal:?}"))?;
    Binding::bound(
        row,
        ExecutableAttachment::attached(
            subject,
            check,
            RevisionBinding::derived(DerivedRevision::from_material(spec.subject_material)),
            RevisionBinding::derived(DerivedRevision::from_material(spec.check_material)),
            retained_check,
        ),
        Provenance::Unproduced,
    )
    .map_err(|refusal| format!("binding refused: {refusal:?}"))
}

fn record_for(binding: &TrialBinding, attempt: RunAttempt) -> HostTrialRecord {
    HostTrialRecord::recorded(
        trial_identity(binding.row()),
        attempt,
        MeasurementReading::Unavailable,
    )
}

fn invocation() -> Invocation {
    Invocation::declared(
        InvocationProfile::declared(
            CaseBudget::declared(2),
            ByteBudget::declared(4_096),
            TimeBudget::declared(60_000_000_000),
        ),
        TargetBinding::bound(
            TargetTriple::declared(TARGET),
            ToolchainIdentity::declared(TOOLCHAIN),
        ),
        TrialSite::located(module_path!(), file!(), line!(), "wave-e-shared-substrate"),
        HarnessClock::unavailable(),
    )
}
