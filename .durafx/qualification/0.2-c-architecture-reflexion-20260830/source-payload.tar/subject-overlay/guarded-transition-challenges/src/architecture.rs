//! The subject-owned high-level package denominator used by architecture reflexion.

/// A package role in the guarded-transition subject journey.
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord)]
pub enum ArchitecturePackage {
    /// The Macroonz facade consumed by the subject journey.
    Macroonz,
    /// The subject-owned proc-macro package.
    SubjectMacros,
    /// The subject package generated through the proc-macro road.
    Subject,
    /// The external challenge package that observes the subject.
    Challenges,
}

/// The complete high-level package denominator declared by this subject journey.
pub const DECLARED_ARCHITECTURE: [(ArchitecturePackage, ArchitecturePackage); 5] = [
    (
        ArchitecturePackage::SubjectMacros,
        ArchitecturePackage::Macroonz,
    ),
    (
        ArchitecturePackage::Subject,
        ArchitecturePackage::SubjectMacros,
    ),
    (ArchitecturePackage::Subject, ArchitecturePackage::Macroonz),
    (
        ArchitecturePackage::Challenges,
        ArchitecturePackage::Subject,
    ),
    (
        ArchitecturePackage::Challenges,
        ArchitecturePackage::Macroonz,
    ),
];
