//! External execution helpers for the guarded-transition subject.

#![forbid(unsafe_code)]
#![deny(warnings)]

use guarded_transition_subject::{
    Capability, Event, GuardRefusal, GuardedContract, Reading, Standing,
};

pub mod architecture;

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ReadBack {
    value: u64,
    standing: Standing,
    effects: usize,
    states: usize,
    events: usize,
    transitions: usize,
    capabilities: usize,
    operations: usize,
    policies: usize,
    associations: usize,
    projections: usize,
}

impl core::fmt::Display for ReadBack {
    fn fmt(&self, formatter: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        write!(
            formatter,
            "VALUE={};STATE={:?};EFFECTS={};STATES={};EVENTS={};TRANSITIONS={};CAPABILITIES={};OPERATIONS={};POLICIES={};ASSOCIATIONS={};PROJECTIONS={}",
            self.value,
            self.standing,
            self.effects,
            self.states,
            self.events,
            self.transitions,
            self.capabilities,
            self.operations,
            self.policies,
            self.associations,
            self.projections,
        )
    }
}

fn lawful<Road: GuardedContract>() -> Result<Reading, GuardRefusal> {
    Road::execute(Capability::Elevated, &[Event::Arm, Event::Finish], 0)
}

/// Executes the generated subject road and returns its externally readable result.
///
/// # Errors
///
/// Returns the subject refusal when the declared lawful sequence cannot execute.
pub fn generated_readback() -> Result<ReadBack, GuardRefusal> {
    let reading = lawful::<guarded_transition_subject::generated::GeneratedRoad>()?;
    Ok(from_generated(&reading))
}

/// Executes the renderer-refactored subject road and returns its externally readable result.
///
/// # Errors
///
/// Returns the subject refusal when the declared lawful sequence cannot execute.
pub fn refactored_readback() -> Result<ReadBack, GuardRefusal> {
    let reading = lawful::<guarded_transition_subject::refactored::GeneratedRoad>()?;
    Ok(from_refactored(&reading))
}

/// Executes the independently handwritten subject road and returns its externally readable result.
///
/// # Errors
///
/// Returns the subject refusal when the declared lawful sequence cannot execute.
pub fn handwritten_readback() -> Result<ReadBack, GuardRefusal> {
    let reading = lawful::<guarded_transition_subject::handwritten::HandwrittenRoad>()?;
    Ok(ReadBack {
        value: reading.value(),
        standing: reading.standing(),
        effects: reading.effects().len(),
        states: guarded_transition_subject::handwritten::STATES.len(),
        events: guarded_transition_subject::handwritten::EVENTS.len(),
        transitions: guarded_transition_subject::handwritten::TRANSITIONS.len(),
        capabilities: guarded_transition_subject::handwritten::CAPABILITIES.len(),
        operations: guarded_transition_subject::handwritten::OPERATIONS.len(),
        policies: guarded_transition_subject::handwritten::POLICIES.len(),
        associations: guarded_transition_subject::handwritten::ASSOCIATIONS.len(),
        projections: 6,
    })
}

fn from_generated(reading: &Reading) -> ReadBack {
    ReadBack {
        value: reading.value(),
        standing: reading.standing(),
        effects: reading.effects().len(),
        states: guarded_transition_subject::generated::GENERATED_STATES.len(),
        events: guarded_transition_subject::generated::GENERATED_EVENTS.len(),
        transitions: guarded_transition_subject::generated::GENERATED_TRANSITIONS.len(),
        capabilities: guarded_transition_subject::generated::GENERATED_CAPABILITIES.len(),
        operations: guarded_transition_subject::generated::GENERATED_OPERATIONS.len(),
        policies: guarded_transition_subject::generated::GENERATED_POLICIES.len(),
        associations: guarded_transition_subject::generated::GENERATED_ASSOCIATIONS.len(),
        projections: 6,
    }
}

fn from_refactored(reading: &Reading) -> ReadBack {
    ReadBack {
        value: reading.value(),
        standing: reading.standing(),
        effects: reading.effects().len(),
        states: guarded_transition_subject::refactored::GENERATED_STATES.len(),
        events: guarded_transition_subject::refactored::GENERATED_EVENTS.len(),
        transitions: guarded_transition_subject::refactored::GENERATED_TRANSITIONS.len(),
        capabilities: guarded_transition_subject::refactored::GENERATED_CAPABILITIES.len(),
        operations: guarded_transition_subject::refactored::GENERATED_OPERATIONS.len(),
        policies: guarded_transition_subject::refactored::GENERATED_POLICIES.len(),
        associations: guarded_transition_subject::refactored::GENERATED_ASSOCIATIONS.len(),
        projections: 6,
    }
}
