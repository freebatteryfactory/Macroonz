#![forbid(unsafe_code)]
#![deny(warnings)]

use serde_json::Value;
use std::collections::{BTreeMap, BTreeSet};
use std::fs;
use std::path::{Path, PathBuf};
use std::process::Command;

#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord)]
enum DependencyKind {
    Normal,
    Development,
    Build,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord)]
enum DependencyPosture {
    Required,
    Optional,
}

impl DependencyPosture {
    const fn from_optional(optional: bool) -> Self {
        if optional {
            Self::Optional
        } else {
            Self::Required
        }
    }

    const fn suffix(self) -> &'static str {
        match self {
            Self::Required => "",
            Self::Optional => ", optional",
        }
    }
}

impl DependencyKind {
    fn from_metadata(value: Option<&str>) -> Result<Self, String> {
        match value {
            None | Some("normal") => Ok(Self::Normal),
            Some("dev") => Ok(Self::Development),
            Some("build") => Ok(Self::Build),
            Some(other) => Err(format!("unsupported Cargo dependency kind {other:?}")),
        }
    }

    const fn spelling(self) -> &'static str {
        match self {
            Self::Normal => "normal",
            Self::Development => "development",
            Self::Build => "build",
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq, PartialOrd, Ord)]
struct Edge {
    from: String,
    to: String,
    kind: DependencyKind,
    posture: DependencyPosture,
}

impl Edge {
    fn normal(from: &str, to: &str, posture: DependencyPosture) -> Self {
        Self {
            from: from.to_owned(),
            to: to.to_owned(),
            kind: DependencyKind::Normal,
            posture,
        }
    }

    fn rendered(&self) -> String {
        format!(
            "{} -> {} [{}{}]",
            self.from,
            self.to,
            self.kind.spelling(),
            self.posture.suffix()
        )
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum ReadingKind {
    Convergent,
    Divergent,
    Absent,
    Unmapped,
    Unobserved,
    Inapplicable,
}

impl ReadingKind {
    const fn spelling(self) -> &'static str {
        match self {
            Self::Convergent => "convergent",
            Self::Divergent => "divergent",
            Self::Absent => "absent",
            Self::Unmapped => "unmapped",
            Self::Unobserved => "unobserved",
            Self::Inapplicable => "inapplicable",
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
struct Reading {
    method: &'static str,
    kind: ReadingKind,
    subject: String,
    detail: String,
    provenance: ReadingProvenance,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum ReadingProvenance {
    Real,
    Planted,
}

impl ReadingProvenance {
    fn reading(
        self,
        method: &'static str,
        kind: ReadingKind,
        subject: &str,
        detail: &str,
    ) -> Reading {
        match self {
            Self::Real => Reading::real(method, kind, subject, detail),
            Self::Planted => Reading::planted(method, kind, subject, detail),
        }
    }
}

impl Reading {
    fn real(method: &'static str, kind: ReadingKind, subject: &str, detail: &str) -> Self {
        Self {
            method,
            kind,
            subject: subject.to_owned(),
            detail: detail.to_owned(),
            provenance: ReadingProvenance::Real,
        }
    }

    fn planted(method: &'static str, kind: ReadingKind, subject: &str, detail: &str) -> Self {
        Self {
            method,
            kind,
            subject: subject.to_owned(),
            detail: detail.to_owned(),
            provenance: ReadingProvenance::Planted,
        }
    }

    fn rendered(&self) -> String {
        format!(
            "reading method={} kind={} control={} subject={} detail={}",
            self.method,
            self.kind.spelling(),
            match self.provenance {
                ReadingProvenance::Real => "real",
                ReadingProvenance::Planted => "planted",
            },
            self.subject,
            self.detail
        )
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
struct LivenessStep {
    name: &'static str,
    input: String,
    marker: String,
}

const MACROONZ_ROOT: &str = ".";
const SUBJECT_ROOT: &str =
    "target/qualification/0.2-wave-c-architecture-reflexion-20260830/subject";

fn main() -> Result<(), String> {
    let macroonz = PathBuf::from(MACROONZ_ROOT);
    let subject = PathBuf::from(SUBJECT_ROOT);
    require_directory(&macroonz)?;
    require_directory(&subject)?;

    let agents = read(&macroonz.join("AGENTS.md"))?;
    let declared_macroonz = declared_edges_from_agents(&agents)?;
    let metadata = cargo_metadata(&macroonz)?;
    let metadata_edges = metadata_workspace_edges(&metadata)?;
    let manifest_edges = macroonz_manifest_edges(&metadata)?;
    require_equal_edges(
        "Macroonz Cargo metadata and manifests",
        &metadata_edges,
        &manifest_edges,
    )?;

    let declared_subject = declared_subject_edges(&subject)?;
    let observed_subject = subject_manifest_edges(&subject)?;

    let mut readings = Vec::new();
    let macroonz_real = compare_edges(
        "cargo-metadata-plus-manifests",
        &declared_macroonz,
        &metadata_edges,
        ReadingProvenance::Real,
    );
    let subject_real = compare_edges(
        "subject-manifests",
        &declared_subject,
        &observed_subject,
        ReadingProvenance::Real,
    );
    readings.extend(macroonz_real.clone());
    readings.extend(subject_real.clone());

    let macroonz_controls = planted_controls(
        "macroonz-planted-control",
        &declared_macroonz,
        &metadata_edges,
    )?;
    let subject_controls = planted_controls(
        "subject-planted-control",
        &declared_subject,
        &observed_subject,
    )?;
    readings.extend(macroonz_controls);
    readings.extend(subject_controls);

    readings.push(Reading::real(
        "stable-source",
        ReadingKind::Unmapped,
        "macroonz::compiler::codec::MEMBER_CONTRACT",
        "the observed public member is below the deliberately package-level architecture denominator",
    ));
    readings.push(Reading::real(
        "local-cargo-metadata",
        ReadingKind::Unobserved,
        "Macroonz physical Linux and macOS behavior",
        "Windows metadata establishes the resolved graph but not another physical host",
    ));
    readings.push(Reading::real(
        "package-edge-model",
        ReadingKind::Inapplicable,
        "Macroonz private file placement",
        "private file movement behind the same package owner is outside the package-edge rule",
    ));
    readings.push(Reading::real(
        "subject-manifests",
        ReadingKind::Unmapped,
        "guarded-transition hostile feature doors",
        "compile-challenge features are observed but intentionally outside the high-level package-edge denominator",
    ));
    readings.push(Reading::real(
        "subject-stable-source",
        ReadingKind::Unobserved,
        "fresh guarded-transition execution",
        "the retained source shows the journey while this source extractor does not claim a fresh runtime observation",
    ));
    readings.push(Reading::real(
        "subject-package-edge-model",
        ReadingKind::Inapplicable,
        "direct versus refactored renderer layout",
        "private renderer structure is governed by byte and behavior nonmovement rather than package edges",
    ));

    let macroonz_liveness = macroonz_liveness(&macroonz, &declared_macroonz, &metadata_edges)?;
    let subject_liveness = subject_liveness(&subject)?;
    let macroonz_private_reorganization = private_reorganization_control(
        &macroonz,
        "macroonz-compiler",
        "macros/compiler/src/bounded/type_contract.rs",
        "macros/compiler/src/bounded/contract.rs",
        &metadata_edges,
    )?;
    let subject_private_reorganization = subject_renderer_reorganization(&subject)?;

    let real_macroonz_defects = count_real_edge_defects(&macroonz_real);
    let real_subject_defects = count_real_edge_defects(&subject_real);
    let acceptance_blocked = real_macroonz_defects == 0 || real_subject_defects == 0;

    println!("schema=wave-c-architecture-reflexion-v1");
    println!("macroonz-declared-input=AGENTS.md section 2 exact text block");
    println!(
        "macroonz-observed-input=cargo +1.98.0 metadata --locked --offline plus package manifests"
    );
    println!(
        "subject-declared-input=guarded-transition-challenges/src/architecture.rs typed high-level denominator"
    );
    println!(
        "subject-observed-input=retained guarded-transition package manifests and stable source"
    );
    println!(
        "ceiling=local Windows stable source, manifests, Cargo metadata, and retained accepted subject source; no physical Linux, macOS, registry, or fresh subject runtime claim"
    );
    println!("macroonz-declared-edge-count={}", declared_macroonz.len());
    println!("macroonz-observed-edge-count={}", metadata_edges.len());
    println!("subject-declared-edge-count={}", declared_subject.len());
    println!("subject-observed-edge-count={}", observed_subject.len());
    for reading in &readings {
        println!("{}", reading.rendered());
    }
    for step in macroonz_liveness {
        println!(
            "liveness capability=macroonz-compiler-facade step={} input={} marker={}",
            step.name, step.input, step.marker
        );
    }
    for step in subject_liveness {
        println!(
            "liveness capability=subject-guarded-transition step={} input={} marker={}",
            step.name, step.input, step.marker
        );
    }
    println!("lawful-variation={macroonz_private_reorganization}");
    println!("lawful-variation={subject_private_reorganization}");
    println!(
        "non-vacuity=both declared denominators are nonempty and each planted missing-edge control produced Absent"
    );
    println!("macroonz-real-missing-or-forbidden={real_macroonz_defects}");
    println!("subject-real-missing-or-forbidden={real_subject_defects}");
    println!(
        "wave-c-acceptance={}",
        if acceptance_blocked {
            "blocked-no-real-missing-or-forbidden-edge-in-both-required-subjects"
        } else {
            "candidate-for-parent-review"
        }
    );
    Ok(())
}

fn require_directory(path: &Path) -> Result<(), String> {
    if path.is_dir() {
        Ok(())
    } else {
        Err(format!("declared directory is absent: {}", path.display()))
    }
}

fn read(path: &Path) -> Result<String, String> {
    fs::read_to_string(path)
        .map_err(|error| format!("{} was not readable: {error}", path.display()))
}

fn declared_edges_from_agents(agents: &str) -> Result<BTreeSet<Edge>, String> {
    let section_start = agents
        .find("## 2 · Dependencies point one way")
        .ok_or_else(|| "AGENTS.md dependency section was absent".to_owned())?;
    let section = &agents[section_start..];
    let fence_start = section
        .find("```text")
        .ok_or_else(|| "AGENTS.md dependency text fence was absent".to_owned())?;
    let fenced = &section[fence_start + "```text".len()..];
    let fence_end = fenced
        .find("```")
        .ok_or_else(|| "AGENTS.md dependency text fence was not closed".to_owned())?;
    let mut edges = BTreeSet::new();
    for line in fenced[..fence_end].lines() {
        let tokens = line.split_whitespace().collect::<Vec<_>>();
        for (index, token) in tokens.iter().enumerate() {
            let kind = match *token {
                "──▶" => DependencyKind::Normal,
                "┈┈▶" => DependencyKind::Development,
                _ => continue,
            };
            let from = index
                .checked_sub(1)
                .and_then(|position| tokens.get(position))
                .ok_or_else(|| format!("arrow had no source in {line:?}"))?;
            let to = tokens
                .get(index + 1)
                .ok_or_else(|| format!("arrow had no destination in {line:?}"))?;
            let optional = tokens.get(index + 2).copied() == Some("optional");
            edges.insert(Edge {
                from: (*from).to_owned(),
                to: (*to).to_owned(),
                kind,
                posture: DependencyPosture::from_optional(optional),
            });
        }
    }
    if edges.is_empty() {
        Err("AGENTS.md dependency block produced an empty graph".to_owned())
    } else {
        Ok(edges)
    }
}

fn cargo_metadata(root: &Path) -> Result<Value, String> {
    let output = Command::new("cargo")
        .current_dir(root)
        .args([
            "+1.98.0",
            "metadata",
            "--locked",
            "--offline",
            "--format-version",
            "1",
        ])
        .output()
        .map_err(|error| format!("Cargo metadata was not runnable: {error}"))?;
    if !output.status.success() {
        return Err(format!(
            "Cargo metadata failed with {:?}: {}",
            output.status.code(),
            String::from_utf8_lossy(&output.stderr)
        ));
    }
    serde_json::from_slice(&output.stdout)
        .map_err(|error| format!("Cargo metadata JSON was not readable: {error}"))
}

fn metadata_workspace_edges(metadata: &Value) -> Result<BTreeSet<Edge>, String> {
    let packages = metadata
        .get("packages")
        .and_then(Value::as_array)
        .ok_or_else(|| "Cargo metadata packages were absent".to_owned())?;
    let members = metadata
        .get("workspace_members")
        .and_then(Value::as_array)
        .ok_or_else(|| "Cargo metadata workspace members were absent".to_owned())?
        .iter()
        .filter_map(Value::as_str)
        .collect::<BTreeSet<_>>();
    let internal_names = packages
        .iter()
        .filter(|package| {
            package
                .get("id")
                .and_then(Value::as_str)
                .is_some_and(|id| members.contains(id))
        })
        .filter_map(|package| package.get("name").and_then(Value::as_str))
        .map(str::to_owned)
        .collect::<BTreeSet<_>>();
    let mut edges = BTreeSet::new();
    for package in packages {
        let Some(id) = package.get("id").and_then(Value::as_str) else {
            continue;
        };
        if !members.contains(id) {
            continue;
        }
        let from = package
            .get("name")
            .and_then(Value::as_str)
            .ok_or_else(|| "workspace package name was absent".to_owned())?;
        let dependencies = package
            .get("dependencies")
            .and_then(Value::as_array)
            .ok_or_else(|| format!("dependencies were absent for {from}"))?;
        for dependency in dependencies {
            let to = dependency
                .get("name")
                .and_then(Value::as_str)
                .ok_or_else(|| format!("dependency name was absent for {from}"))?;
            if !internal_names.contains(to) {
                continue;
            }
            edges.insert(Edge {
                from: from.to_owned(),
                to: to.to_owned(),
                kind: DependencyKind::from_metadata(
                    dependency.get("kind").and_then(Value::as_str),
                )?,
                posture: DependencyPosture::from_optional(
                    dependency
                        .get("optional")
                        .and_then(Value::as_bool)
                        .unwrap_or(false),
                ),
            });
        }
    }
    Ok(edges)
}

fn macroonz_manifest_edges(metadata: &Value) -> Result<BTreeSet<Edge>, String> {
    let packages = metadata
        .get("packages")
        .and_then(Value::as_array)
        .ok_or_else(|| "Cargo metadata packages were absent".to_owned())?;
    let members = metadata
        .get("workspace_members")
        .and_then(Value::as_array)
        .ok_or_else(|| "Cargo metadata workspace members were absent".to_owned())?
        .iter()
        .filter_map(Value::as_str)
        .collect::<BTreeSet<_>>();
    let internal_names = packages
        .iter()
        .filter(|package| {
            package
                .get("id")
                .and_then(Value::as_str)
                .is_some_and(|id| members.contains(id))
        })
        .filter_map(|package| package.get("name").and_then(Value::as_str))
        .map(str::to_owned)
        .collect::<BTreeSet<_>>();
    let mut edges = BTreeSet::new();
    for package in packages {
        let Some(id) = package.get("id").and_then(Value::as_str) else {
            continue;
        };
        if !members.contains(id) {
            continue;
        }
        let from = package
            .get("name")
            .and_then(Value::as_str)
            .ok_or_else(|| "workspace package name was absent".to_owned())?;
        let manifest = package
            .get("manifest_path")
            .and_then(Value::as_str)
            .ok_or_else(|| format!("manifest path was absent for {from}"))?;
        edges.extend(parse_manifest_dependencies(
            from,
            &read(Path::new(manifest))?,
            &internal_names,
            &BTreeMap::new(),
        ));
    }
    Ok(edges)
}

fn parse_manifest_dependencies(
    from: &str,
    manifest: &str,
    internal_names: &BTreeSet<String>,
    aliases: &BTreeMap<String, String>,
) -> BTreeSet<Edge> {
    let mut section = String::new();
    let mut edges = BTreeSet::new();
    for raw in manifest.lines() {
        let line = raw.trim();
        if line.starts_with('[') && line.ends_with(']') {
            section.clear();
            section.push_str(line);
            continue;
        }
        let kind = if section == "[dev-dependencies]" || section.ends_with(".dev-dependencies]") {
            Some(DependencyKind::Development)
        } else if section == "[build-dependencies]" || section.ends_with(".build-dependencies]") {
            Some(DependencyKind::Build)
        } else if section == "[dependencies]"
            || (!section.starts_with("[workspace.") && section.ends_with(".dependencies]"))
        {
            Some(DependencyKind::Normal)
        } else {
            None
        };
        let Some(kind) = kind else {
            continue;
        };
        let Some((key, value)) = line.split_once('=') else {
            continue;
        };
        let key = key.trim();
        let explicit_package = quoted_field(value, "package");
        let to = explicit_package
            .or_else(|| aliases.get(key).cloned())
            .unwrap_or_else(|| key.to_owned());
        if !internal_names.contains(to.as_str()) {
            continue;
        }
        edges.insert(Edge {
            from: from.to_owned(),
            to,
            kind,
            posture: DependencyPosture::from_optional(value.contains("optional = true")),
        });
    }
    edges
}

fn quoted_field(value: &str, field: &str) -> Option<String> {
    let prefix = format!("{field} = \"");
    let start = value.find(&prefix)? + prefix.len();
    let remainder = value.get(start..)?;
    let end = remainder.find('"')?;
    remainder.get(..end).map(str::to_owned)
}

fn subject_manifest_edges(root: &Path) -> Result<BTreeSet<Edge>, String> {
    let workspace = read(&root.join("Cargo.toml"))?;
    let aliases = workspace_aliases(&workspace);
    let manifest_paths = [
        "guarded-transition-subject-macros/Cargo.toml",
        "guarded-transition-subject/Cargo.toml",
        "guarded-transition-challenges/Cargo.toml",
    ];
    let mut names = BTreeMap::new();
    for relative in manifest_paths {
        let contents = read(&root.join(relative))?;
        names.insert(relative, package_name(&contents)?);
    }
    let internal_names = names
        .values()
        .cloned()
        .chain(["macroonz".to_owned()])
        .collect::<BTreeSet<_>>();
    let mut edges = BTreeSet::new();
    for (relative, from) in names {
        let contents = read(&root.join(relative))?;
        edges.extend(parse_manifest_dependencies(
            &from,
            &contents,
            &internal_names,
            &aliases,
        ));
    }
    Ok(edges)
}

fn workspace_aliases(workspace: &str) -> BTreeMap<String, String> {
    let mut section = String::new();
    let mut aliases = BTreeMap::new();
    for raw in workspace.lines() {
        let line = raw.trim();
        if line.starts_with('[') && line.ends_with(']') {
            section.clear();
            section.push_str(line);
            continue;
        }
        if section != "[workspace.dependencies]" {
            continue;
        }
        let Some((key, value)) = line.split_once('=') else {
            continue;
        };
        if let Some(package) = quoted_field(value, "package") {
            aliases.insert(key.trim().to_owned(), package);
        }
    }
    aliases
}

fn package_name(manifest: &str) -> Result<String, String> {
    let mut package = false;
    for raw in manifest.lines() {
        let line = raw.trim();
        if line.starts_with('[') && line.ends_with(']') {
            package = line == "[package]";
            continue;
        }
        if package
            && let Some(name) = line
                .strip_prefix("name = \"")
                .and_then(|value| value.strip_suffix('"'))
        {
            return Ok(name.to_owned());
        }
    }
    Err("package manifest had no package name".to_owned())
}

fn declared_subject_edges(root: &Path) -> Result<BTreeSet<Edge>, String> {
    let source = read(&root.join("guarded-transition-challenges/src/architecture.rs"))?;
    let declaration = source
        .split_once("pub const DECLARED_ARCHITECTURE")
        .map(|(_, declaration)| declaration)
        .ok_or_else(|| "the subject-owned architecture declaration was absent".to_owned())?;
    let body = declaration
        .split_once("= [")
        .map(|(_, body)| body)
        .and_then(|body| body.split_once("];"))
        .map(|(body, _)| body)
        .ok_or_else(|| "the subject-owned architecture declaration body was absent".to_owned())?;
    let prefix = "ArchitecturePackage::";
    let mut packages = Vec::new();
    let mut remaining = body;
    while let Some(start) = remaining.find(prefix) {
        let after_prefix = remaining
            .get(start + prefix.len()..)
            .ok_or_else(|| "subject architecture source offset was invalid".to_owned())?;
        let end = after_prefix
            .find(|character: char| !(character.is_ascii_alphanumeric() || character == '_'))
            .unwrap_or(after_prefix.len());
        let package = after_prefix
            .get(..end)
            .ok_or_else(|| "subject architecture package range was invalid".to_owned())?;
        packages.push(subject_package_name(package)?);
        remaining = after_prefix
            .get(end..)
            .ok_or_else(|| "subject architecture remainder was invalid".to_owned())?;
    }
    if packages.is_empty() {
        return Err("the subject-owned architecture denominator was empty".to_owned());
    }
    if packages.len() % 2 != 0 {
        return Err(
            "the subject-owned architecture denominator ended with an unpaired role".to_owned(),
        );
    }
    let mut declared_count = 0_usize;
    let mut edges = BTreeSet::new();
    let mut package_pairs = packages.into_iter();
    while let Some(from) = package_pairs.next() {
        let to = package_pairs
            .next()
            .ok_or_else(|| "the subject-owned architecture pair was incomplete".to_owned())?;
        declared_count = declared_count
            .checked_add(1)
            .ok_or_else(|| "subject architecture edge count overflowed".to_owned())?;
        edges.insert(Edge::normal(from, to, DependencyPosture::Required));
    }
    if edges.is_empty() {
        return Err("the subject-owned architecture denominator was empty".to_owned());
    }
    if edges.len() != declared_count {
        return Err("the subject-owned architecture denominator repeated an edge".to_owned());
    }
    Ok(edges)
}

fn subject_package_name(value: &str) -> Result<&'static str, String> {
    match value {
        "Macroonz" => Ok("macroonz"),
        "SubjectMacros" => Ok("guarded-transition-subject-macros"),
        "Subject" => Ok("guarded-transition-subject"),
        "Challenges" => Ok("guarded-transition-challenges"),
        other => Err(format!(
            "unknown subject architecture package role {other:?}"
        )),
    }
}

fn require_equal_edges(
    label: &str,
    left: &BTreeSet<Edge>,
    right: &BTreeSet<Edge>,
) -> Result<(), String> {
    if left == right {
        Ok(())
    } else {
        Err(format!("{label} disagree: left={left:?}, right={right:?}"))
    }
}

fn compare_edges(
    method: &'static str,
    declared: &BTreeSet<Edge>,
    observed: &BTreeSet<Edge>,
    provenance: ReadingProvenance,
) -> Vec<Reading> {
    let mut readings = Vec::new();
    for edge in declared {
        if observed.contains(edge) {
            readings.push(provenance.reading(
                method,
                ReadingKind::Convergent,
                &edge.rendered(),
                "declared and observed edge agree",
            ));
        } else {
            readings.push(provenance.reading(
                method,
                ReadingKind::Absent,
                &edge.rendered(),
                "required declared edge was not observed",
            ));
        }
    }
    for edge in observed.difference(declared) {
        readings.push(provenance.reading(
            method,
            ReadingKind::Divergent,
            &edge.rendered(),
            "observed internal edge has no permitted declared counterpart",
        ));
    }
    readings
}

fn planted_controls(
    method: &'static str,
    declared: &BTreeSet<Edge>,
    observed: &BTreeSet<Edge>,
) -> Result<Vec<Reading>, String> {
    let missing = declared
        .first()
        .ok_or_else(|| "cannot plant a missing edge into an empty denominator".to_owned())?;
    let mut missing_observed = observed.clone();
    if !missing_observed.remove(missing) {
        return Err(
            "non-vacuity failed: planted missing edge was not observed initially".to_owned(),
        );
    }
    let missing_readings = compare_edges(
        method,
        declared,
        &missing_observed,
        ReadingProvenance::Planted,
    );
    if !missing_readings
        .iter()
        .any(|reading| reading.kind == ReadingKind::Absent && reading.subject == missing.rendered())
    {
        return Err("planted missing edge was not classified Absent".to_owned());
    }

    let reversed = Edge {
        from: missing.to.clone(),
        to: missing.from.clone(),
        kind: DependencyKind::Normal,
        posture: DependencyPosture::Required,
    };
    let mut forbidden_observed = observed.clone();
    if declared.contains(&reversed) || observed.contains(&reversed) {
        return Err("selected forbidden backedge was already declared or observed".to_owned());
    }
    forbidden_observed.insert(reversed.clone());
    let forbidden_readings = compare_edges(
        method,
        declared,
        &forbidden_observed,
        ReadingProvenance::Planted,
    );
    if !forbidden_readings.iter().any(|reading| {
        reading.kind == ReadingKind::Divergent && reading.subject == reversed.rendered()
    }) {
        return Err("planted forbidden backedge was not classified Divergent".to_owned());
    }

    Ok(missing_readings
        .into_iter()
        .filter(|reading| reading.kind == ReadingKind::Absent)
        .chain(
            forbidden_readings
                .into_iter()
                .filter(|reading| reading.kind == ReadingKind::Divergent),
        )
        .collect())
}

fn count_real_edge_defects(readings: &[Reading]) -> usize {
    readings
        .iter()
        .filter(|reading| {
            reading.provenance == ReadingProvenance::Real
                && matches!(reading.kind, ReadingKind::Absent | ReadingKind::Divergent)
        })
        .count()
}

fn require_marker(path: &Path, input: &str, marker: &str) -> Result<LivenessStep, String> {
    let contents = read(path)?;
    if contents.contains(marker) {
        Ok(LivenessStep {
            name: "observed",
            input: input.to_owned(),
            marker: marker.to_owned(),
        })
    } else {
        Err(format!(
            "liveness marker {marker:?} was absent from {}",
            path.display()
        ))
    }
}

fn macroonz_liveness(
    root: &Path,
    declared: &BTreeSet<Edge>,
    observed: &BTreeSet<Edge>,
) -> Result<Vec<LivenessStep>, String> {
    let compiler_edge = declared
        .iter()
        .find(|edge| edge.from == "macroonz" && edge.to == "macroonz-compiler")
        .ok_or_else(|| "the parsed architecture had no facade-to-compiler promise".to_owned())?;
    if !observed.contains(compiler_edge) {
        return Err("the facade-to-compiler promise had no observed Cargo holder".to_owned());
    }
    let mut steps = vec![LivenessStep {
        name: "declaration-or-promise",
        input: root.join("AGENTS.md").display().to_string(),
        marker: compiler_edge.rendered(),
    }];
    let mut construction = require_marker(
        &root.join("Cargo.toml"),
        "Cargo.toml",
        "macroonz-compiler = { workspace = true, features = [\"host\"] }",
    )?;
    construction.name = "lawful-checked-construction";
    steps.push(construction);
    steps.push(LivenessStep {
        name: "informed-value",
        input: "cargo +1.98.0 metadata --locked --offline".to_owned(),
        marker: compiler_edge.rendered(),
    });
    let mut holder = require_marker(
        &root.join("src/lib.rs"),
        "src/lib.rs",
        "pub use macroonz_compiler as compiler;",
    )?;
    holder.name = "real-holder";
    steps.push(holder);
    let mut consumer = require_marker(
        &root.join("tests/facade_surface.rs"),
        "tests/facade_surface.rs",
        "macroonz::compiler::NoQuestions",
    )?;
    consumer.name = "real-consumer";
    steps.push(consumer);
    let mut consequence = require_marker(
        &root.join("tests/facade_surface.rs"),
        "tests/facade_surface.rs",
        "size_of::<macroonz::compiler::NoQuestions>()",
    )?;
    consequence.name = "observable-consequence";
    steps.push(consequence);
    let mut witness = require_marker(
        &root.join("tests/facade_surface.rs"),
        "tests/facade_surface.rs",
        "fn compiler_stays_under_its_owner()",
    )?;
    witness.name = "external-witness";
    steps.push(witness);
    steps.push(LivenessStep {
        name: "hostile-reversal",
        input: "planted graph control".to_owned(),
        marker: format!("remove {} and require Absent", compiler_edge.rendered()),
    });
    Ok(steps)
}

fn subject_liveness(root: &Path) -> Result<Vec<LivenessStep>, String> {
    let source = root.join("guarded-transition-subject/src/lib.rs");
    let engine = root.join("guarded-transition-subject-macros/src/engine.rs");
    let challenge = root.join("guarded-transition-challenges/src/lib.rs");
    let journey = root.join("guarded-transition-challenges/tests/journey.rs");
    let mut steps = Vec::new();
    let mut declaration = require_marker(
        &source,
        "guarded-transition-subject/src/lib.rs",
        "baseline_declaration!(guarded_transition);",
    )?;
    declaration.name = "declaration-or-promise";
    steps.push(declaration);
    let mut construction = require_marker(
        &engine,
        "guarded-transition-subject-macros/src/engine.rs",
        "pub(crate) fn read_declaration(",
    )?;
    construction.name = "lawful-checked-construction";
    steps.push(construction);
    let mut informed = require_marker(
        &engine,
        "guarded-transition-subject-macros/src/engine.rs",
        "pub(crate) struct GuardedDeclaration",
    )?;
    informed.name = "informed-value";
    steps.push(informed);
    let mut holder = require_marker(
        &engine,
        "guarded-transition-subject-macros/src/engine.rs",
        "GeneratedToken::word(\"GeneratedRoad\")",
    )?;
    holder.name = "real-holder";
    steps.push(holder);
    let mut consumer = require_marker(
        &challenge,
        "guarded-transition-challenges/src/lib.rs",
        "pub fn generated_readback()",
    )?;
    consumer.name = "real-consumer";
    steps.push(consumer);
    let mut consequence = require_marker(
        &journey,
        "guarded-transition-challenges/tests/journey.rs",
        "const READBACK: &str =",
    )?;
    consequence.name = "observable-consequence";
    steps.push(consequence);
    let mut witness = require_marker(
        &journey,
        "guarded-transition-challenges/tests/journey.rs",
        "fn guarded_transition_journey_executes_and_enters_report_standing()",
    )?;
    witness.name = "external-witness";
    steps.push(witness);
    let mut hostile = require_marker(
        &source,
        "guarded-transition-subject/src/lib.rs",
        "pub mod planted_wrong",
    )?;
    hostile.name = "hostile-reversal";
    steps.push(hostile);
    Ok(steps)
}

fn private_reorganization_control(
    root: &Path,
    owner: &str,
    before: &str,
    after: &str,
    package_edges: &BTreeSet<Edge>,
) -> Result<String, String> {
    if before == after || package_edges.is_empty() {
        return Err("private reorganization control was vacuous".to_owned());
    }
    let before_relative = Path::new(before);
    let after_relative = Path::new(after);
    if before_relative.parent() != after_relative.parent() {
        return Err("private reorganization control crossed its semantic home".to_owned());
    }
    if !root.join(before_relative).is_file() {
        return Err(format!(
            "private reorganization control source was absent: {before}"
        ));
    }
    if root.join(after_relative).exists() {
        return Err(format!(
            "private reorganization control destination was already occupied: {after}"
        ));
    }
    Ok(format!(
        "control=planted; owner={owner}; before={before}; after={after}; result=admitted; package-edge-set-unchanged={}",
        package_edges.len()
    ))
}

fn subject_renderer_reorganization(root: &Path) -> Result<String, String> {
    let source = read(&root.join("guarded-transition-subject/src/lib.rs"))?;
    let engine = read(&root.join("guarded-transition-subject-macros/src/engine.rs"))?;
    let claims = read(&root.join("guarded-transition-subject-macros/tests/engine_claims.rs"))?;
    for marker in [
        "pub mod refactored",
        "pub(crate) enum RenderStyle",
        "fn private_renderer_refactor_preserves_every_identity_and_exact_byte()",
    ] {
        if !(source.contains(marker) || engine.contains(marker) || claims.contains(marker)) {
            return Err(format!(
                "renderer reorganization marker was absent: {marker}"
            ));
        }
    }
    Ok("control=real-retained; owner=guarded-transition-subject; direct-and-refactored-renderers=observed; exact-identity-and-byte-nonmovement-witness=present; result=admitted".to_owned())
}
