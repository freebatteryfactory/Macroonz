//! Scratch-only stable bounded verification composed from current Macroonz owners.

use arbitrary::{Arbitrary, Unstructured};
use macroonz_harness::clock::{HarnessClock, MeasurementReading};
use macroonz_harness::descriptor::{
    Binding, CheckRef, ClaimRef, Classification, DerivedRevision, ExecutableAttachment,
    ExecutionSuite, Origin, PopulationRef, Provenance, RevisionBinding, Role, Row, SubjectRoute,
    Tag,
};
use macroonz_harness::generate::{
    ByteReducerExecution, ByteReducerId, ByteSource, CaseWidth, FingerprintPreservation,
    GenerationDisposition, GenerationHalt, GenerationPlan, InputOrigin, ProbeOutcome,
    ReductionBudget, ReductionHalt, ReductionPlan, ReductionProbeBinding, RejectionAllowance,
    SizeProgression, capture_replay, reduce,
};
use macroonz_harness::properties::{
    ContractRefusal, Holding, TemporalClaim, TemporalDemand, TemporalDriveReading,
    TemporalDriveStanding, TransitionContract, holds_over_drive,
};
use macroonz_harness::report::{
    ByteBudget, CaseBudget, FailureClass, FindingCause, FindingLocation, Fingerprint,
    GenerationProfile, HostTrialRecord, InfrastructureFailure, InfrastructureFault,
    InvocationProfile, MinimizationProfile, ReplayPosture, RunAttempt, TargetBinding, TargetTriple,
    TimeBudget, ToolchainIdentity, TrialConclusion, TrialFinding, TrialReport, TrialSite,
};
use macroonz_harness::runner::{Invocation, TrialBinding, record_one, trial_identity};
use std::collections::BTreeSet;

const OWNER: &str = "wave-f-bounded-verification";
const CLAIM_CAUSE: FindingCause = FindingCause::named(OWNER, "byte-roundtrip");
const HOSTILE_MEMBER: u8 = 0xA5;
const TARGET: &str = "x86_64-pc-windows-msvc";
const TOOLCHAIN: &str = "cargo 1.98.0 (797e8a9bc 2026-08-05); rustc 1.98.0 (88d9e12ae 2026-08-18)";

macro_rules! require {
    ($condition:expr, $message:expr $(,)?) => {
        if $condition {
            Ok(())
        } else {
            Err($message.to_owned())
        }
    };
}

#[derive(Debug, Clone, PartialEq, Eq)]
struct Member(u8);

#[derive(Debug, Clone, PartialEq, Eq)]
struct RoundtripState {
    original: Option<u8>,
    recovered: Option<u8>,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum MethodIdentity {
    RotateXorV1,
    InvertV1,
    RotateXorHostileV1,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct CompleteReading {
    method: MethodIdentity,
    denominator: usize,
    evaluated: usize,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct IncompleteReading {
    halt: GenerationHalt,
    denominator: usize,
    generated: usize,
    evaluated: usize,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct CounterexampleReading {
    method: MethodIdentity,
    member: u8,
    position: usize,
    evaluated: usize,
}

#[derive(Debug, Clone, PartialEq, Eq)]
struct ReplayReading {
    input: u8,
    halt: ReductionHalt,
    probes: u32,
    accepted: u32,
    fingerprint_moved: u32,
    no_failure: u32,
    posture: ReplayPosture,
}

/// The complete host-neutral reading produced by the bounded Wave F witness.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Qualification {
    denominator: usize,
    lawful: CompleteReading,
    variation: CompleteReading,
    source_incomplete: IncompleteReading,
    resource_incomplete: IncompleteReading,
    counterexample: CounterexampleReading,
    replay: ReplayReading,
    unavailable: RunAttempt,
    vacuity: ContractRefusal,
}

impl Qualification {
    /// Render the exact host-neutral facts retained by this semantic lot.
    #[must_use]
    pub fn rendered(&self) -> String {
        format!(
            concat!(
                "WAVE_F_BOUNDED=qualified-semantic-half\n",
                "DENOMINATOR_DERIVATION=inclusive-u8-min-through-u8-max\n",
                "DENOMINATOR={}\n",
                "LAWFUL_METHOD={:?};EVALUATED={}\n",
                "VARIATION_METHOD={:?};EVALUATED={};ORDER=reversed\n",
                "SOURCE_INCOMPLETE={:?};GENERATED={};EVALUATED={}\n",
                "RESOURCE_INCOMPLETE={:?};GENERATED={};EVALUATED={}\n",
                "COUNTEREXAMPLE_METHOD={:?};MEMBER=0x{:02X};POSITION={};EVALUATED={}\n",
                "REPLAY_INPUT=0x{:02X};HALT={:?};PROBES={};ACCEPTED={};FINGERPRINT_MOVED={};NO_FAILURE={};POSTURE={:?}\n",
                "PLANTED_UNAVAILABLE={:?}\n",
                "VACUITY={:?}\n",
                "PROBE_CEILING=capture-free-function-pointer-rederives-trial;construction-failure-refuses-qualification\n",
                "DISPOSITION=existing-owner-composition-sufficient;standalone-FiniteDomain-rejected\n",
                "CEILING=exhaustive-within-declared-one-byte-domain;not-symbolic-or-universal\n"
            ),
            self.denominator,
            self.lawful.method,
            self.lawful.evaluated,
            self.variation.method,
            self.variation.evaluated,
            self.source_incomplete.halt,
            self.source_incomplete.generated,
            self.source_incomplete.evaluated,
            self.resource_incomplete.halt,
            self.resource_incomplete.generated,
            self.resource_incomplete.evaluated,
            self.counterexample.method,
            self.counterexample.member,
            self.counterexample.position,
            self.counterexample.evaluated,
            self.replay.input,
            self.replay.halt,
            self.replay.probes,
            self.replay.accepted,
            self.replay.fingerprint_moved,
            self.replay.no_failure,
            self.replay.posture,
            self.unavailable,
            self.vacuity,
        )
    }
}

/// Execute the complete scratch-only bounded-verification composition.
///
/// # Errors
///
/// Returns the first exact constructor, denominator, property, report, reduction, or replay contradiction encountered by the witness.
pub fn qualify() -> Result<Qualification, String> {
    let domain = complete_u8_domain();
    let denominator = derived_u8_denominator();
    require!(
        domain.len() == denominator,
        "the u8 roster length moved from its derived bound",
    )?;

    let lawful = complete_reading(
        "lawful",
        domain.clone(),
        MethodIdentity::RotateXorV1,
        apply_rotate_xor,
    )?;

    let mut reversed = domain.clone();
    reversed.reverse();
    let variation = complete_reading(
        "variation",
        reversed,
        MethodIdentity::InvertV1,
        apply_invert,
    )?;

    let source_incomplete = source_incomplete(&domain, denominator)?;
    let resource_incomplete = resource_incomplete(&domain, denominator)?;
    let hostile = temporal_reading(
        "hostile",
        domain.clone(),
        denominator,
        denominator,
        apply_hostile,
    )?;
    let counterexample = counterexample(&hostile, denominator)?;
    let replay = report_reduce_replay(&hostile, counterexample)?;

    let unavailable = RunAttempt::InfrastructureFailed(InfrastructureFailure::recorded(
        InfrastructureFault::GenerationUnavailable,
        None,
    ));
    let Err(vacuity) = TransitionContract::<RoundtripState, Member>::declared(
        opening_state,
        apply_rotate_xor,
        Vec::new(),
    ) else {
        return Err("a claim-free contract was admitted".to_owned());
    };
    require!(
        vacuity == ContractRefusal::NoClaimDeclared,
        "the claim-free contract refusal moved",
    )?;

    Ok(Qualification {
        denominator,
        lawful,
        variation,
        source_incomplete,
        resource_incomplete,
        counterexample,
        replay,
        unavailable,
        vacuity,
    })
}

fn complete_u8_domain() -> Vec<u8> {
    (u8::MIN..=u8::MAX).collect()
}

fn derived_u8_denominator() -> usize {
    (u8::MIN..=u8::MAX).count()
}

fn complete_reading(
    stem: &'static str,
    bytes: Vec<u8>,
    method: MethodIdentity,
    apply: fn(&RoundtripState, &Member) -> RoundtripState,
) -> Result<CompleteReading, String> {
    let denominator = derived_u8_denominator();
    let expected = bytes.clone();
    let reading = temporal_reading(stem, bytes, denominator, denominator, apply)?;
    inspect_complete(&reading, &expected, denominator)?;
    Ok(CompleteReading {
        method,
        denominator,
        evaluated: reading.evaluated(),
    })
}

fn temporal_reading(
    stem: &'static str,
    supplied: Vec<u8>,
    cases: usize,
    bytes: usize,
    apply: fn(&RoundtripState, &Member) -> RoundtripState,
) -> Result<TemporalDriveReading<Member>, String> {
    let case_budget = u32::try_from(cases)
        .map_err(|_| "the derived denominator exceeded the case-budget width".to_owned())?;
    let byte_budget = u64::try_from(bytes)
        .map_err(|_| "the derived byte count exceeded the byte-budget width".to_owned())?;
    let plan = GenerationPlan::declared(
        PopulationRef::named(OWNER, stem)
            .map_err(|refusal| format!("population refused: {refusal:?}"))?,
        GenerationProfile::declared(stem, 1),
        InputOrigin::Supplied(supplied),
        CaseBudget::declared(case_budget),
        ByteBudget::declared(byte_budget),
        RejectionAllowance::declared(0),
        SizeProgression::Constant {
            width: CaseWidth::declared(1)
                .map_err(|refusal| format!("case width refused: {refusal:?}"))?,
        },
    )
    .map_err(|refusal| format!("generation plan refused: {refusal:?}"))?;
    let source = ByteSource::of_plan(&plan);
    let contract = TransitionContract::declared(
        opening_state,
        apply,
        vec![TemporalClaim::declared(
            CLAIM_CAUSE,
            TemporalDemand::Always(roundtrip_holds),
        )],
    )
    .map_err(|refusal| format!("transition contract refused: {refusal:?}"))?;
    Ok(holds_over_drive(
        &contract,
        &plan,
        &source,
        decode_member,
        macroonz_harness::generate::admit_every_sequence::<Member>,
    ))
}

fn inspect_complete(
    reading: &TemporalDriveReading<Member>,
    expected_order: &[u8],
    denominator: usize,
) -> Result<(), String> {
    require!(
        reading.generated().halt() == GenerationHalt::CaseBudgetMet,
        "the complete drive did not meet its case budget",
    )?;
    require!(
        reading.evaluated() == denominator,
        "the complete drive did not evaluate its derived denominator",
    )?;
    require!(
        reading.standing() == &TemporalDriveStanding::Concluded(TrialConclusion::Passed),
        "the complete drive did not conclude with a pass",
    )?;
    inspect_generated_domain(reading, expected_order, denominator)
}

fn inspect_generated_domain(
    reading: &TemporalDriveReading<Member>,
    expected_order: &[u8],
    denominator: usize,
) -> Result<(), String> {
    require!(
        reading.generated().sequences().len() == denominator,
        "the complete drive admitted a different sequence count",
    )?;
    let denominator_u32 = u32::try_from(denominator)
        .map_err(|_| "the denominator exceeded the generation census width".to_owned())?;
    require!(
        reading
            .generated()
            .census()
            .count_of(GenerationDisposition::Generated)
            == denominator_u32,
        "the generated census did not equal the derived denominator",
    )?;
    require!(
        reading.generated().census().attempted() == denominator_u32,
        "the complete census counted a non-generated disposition",
    )?;

    let mut seen = BTreeSet::new();
    for (position, (sequence, expected)) in reading
        .generated()
        .sequences()
        .iter()
        .zip(expected_order)
        .enumerate()
    {
        let [Member(member)] = sequence.commands() else {
            return Err("one fixed-width case did not decode exactly one member".to_owned());
        };
        let [input] = sequence.input() else {
            return Err("one fixed-width case did not retain exactly one input byte".to_owned());
        };
        require!(
            member == expected,
            "decoded member order moved from supplied bytes",
        )?;
        require!(
            input == expected,
            "retained input differed from its decoded member",
        )?;
        let ordinal = u32::try_from(position)
            .map_err(|_| "one sequence position exceeded the case-index width".to_owned())?;
        require!(
            sequence.case().ordinal() == ordinal,
            "one sequence case index differed from its retained position",
        )?;
        require!(seen.insert(*member), "one decoded member was duplicated")?;
    }
    require!(seen.len() == denominator, "one decoded member was omitted")?;
    require!(
        seen.iter().copied().eq(complete_u8_domain()),
        "the decoded member set differed from the complete u8 vocabulary",
    )
}

fn source_incomplete(domain: &[u8], denominator: usize) -> Result<IncompleteReading, String> {
    let incomplete_denominator = denominator
        .checked_sub(1usize)
        .ok_or_else(|| "the derived denominator had no shorter source".to_owned())?;
    let short = domain
        .iter()
        .copied()
        .take(incomplete_denominator)
        .collect::<Vec<_>>();
    let reading = temporal_reading(
        "short-source",
        short,
        denominator,
        denominator,
        apply_rotate_xor,
    )?;
    incomplete_reading(&reading, denominator, GenerationHalt::SourceExhausted)
}

fn resource_incomplete(domain: &[u8], denominator: usize) -> Result<IncompleteReading, String> {
    let incomplete_denominator = denominator
        .checked_sub(1usize)
        .ok_or_else(|| "the derived denominator had no tighter byte budget".to_owned())?;
    let reading = temporal_reading(
        "tight-byte-budget",
        domain.to_vec(),
        denominator,
        incomplete_denominator,
        apply_rotate_xor,
    )?;
    incomplete_reading(&reading, denominator, GenerationHalt::ByteBudgetExhausted)
}

fn incomplete_reading(
    reading: &TemporalDriveReading<Member>,
    denominator: usize,
    expected_halt: GenerationHalt,
) -> Result<IncompleteReading, String> {
    let generated = reading.generated().sequences().len();
    require!(
        reading.generated().halt() == expected_halt,
        "the incomplete control reached the wrong halt",
    )?;
    require!(
        reading.standing() == &TemporalDriveStanding::Incomplete,
        "the incomplete control was promoted to a conclusion",
    )?;
    require!(
        generated < denominator,
        "the incomplete control reached the denominator",
    )?;
    require!(
        reading.evaluated() == generated,
        "the incomplete control did not evaluate its admitted prefix",
    )?;
    Ok(IncompleteReading {
        halt: expected_halt,
        denominator,
        generated,
        evaluated: reading.evaluated(),
    })
}

fn counterexample(
    reading: &TemporalDriveReading<Member>,
    denominator: usize,
) -> Result<CounterexampleReading, String> {
    require!(
        reading.generated().halt() == GenerationHalt::CaseBudgetMet,
        "the hostile generation denominator did not complete",
    )?;
    inspect_generated_domain(reading, &complete_u8_domain(), denominator)?;
    let TemporalDriveStanding::Concluded(TrialConclusion::Refused(finding)) = reading.standing()
    else {
        return Err("the hostile operation produced no typed counterexample".to_owned());
    };
    require!(
        finding.class() == FailureClass::PropertyDisagreement,
        "the hostile operation reached the wrong failure class",
    )?;
    require!(
        finding.cause() == CLAIM_CAUSE,
        "the hostile operation reached the wrong failure cause",
    )?;
    let position = reading
        .evaluated()
        .checked_sub(1usize)
        .ok_or_else(|| "the hostile operation refused before evaluating a member".to_owned())?;
    let sequence = reading
        .generated()
        .sequences()
        .get(position)
        .ok_or_else(|| "the retained counterexample position was absent".to_owned())?;
    let [Member(member)] = sequence.commands() else {
        return Err("the retained counterexample was not one member".to_owned());
    };
    require!(
        *member == HOSTILE_MEMBER,
        "the hostile member identity moved",
    )?;
    require!(
        sequence.input() == [HOSTILE_MEMBER],
        "the hostile input did not preserve the counterexample byte",
    )?;
    require!(
        reading.generated().sequences().len() == denominator,
        "the hostile generation did not retain the complete denominator",
    )?;
    Ok(CounterexampleReading {
        method: MethodIdentity::RotateXorHostileV1,
        member: *member,
        position,
        evaluated: reading.evaluated(),
    })
}

fn report_reduce_replay(
    reading: &TemporalDriveReading<Member>,
    counterexample: CounterexampleReading,
) -> Result<ReplayReading, String> {
    let TemporalDriveStanding::Concluded(conclusion @ TrialConclusion::Refused(_)) =
        reading.standing()
    else {
        return Err("the replay handoff received no refused temporal conclusion".to_owned());
    };
    let binding = hostile_binding()?;
    let invocation = invocation()?;
    let host = HostTrialRecord::recorded(
        trial_identity(binding.row()),
        RunAttempt::Executed(conclusion.clone()),
        MeasurementReading::Unavailable,
    );
    let report = record_one(&binding, &invocation, host)
        .map_err(|refusal| format!("the hostile report join refused: {refusal:?}"))?;
    let expected_fingerprint = refused_fingerprint(&report)?;
    let input = [counterexample.member];
    require!(
        hostile_probe(&input) == ProbeOutcome::Reproduced(expected_fingerprint),
        "the capture-free hostile probe could not rederive the report trial",
    )?;
    let schema = macroonz_harness::descriptor::GeneratedSupportSchema::published()
        .map_err(|refusal| format!("the generated-support schema refused: {refusal:?}"))?
        .identity()
        .map_err(|refusal| format!("the generated-support schema did not encode: {refusal:?}"))?;
    let probe = ReductionProbeBinding::bound(
        &report,
        GenerationProfile::declared("complete-u8-domain", 1),
        schema,
        RevisionBinding::derived(DerivedRevision::from_material(b"wave-f-hostile-probe/v1")),
        hostile_probe,
    )
    .map_err(|refusal| format!("the reduction probe binding refused: {refusal:?}"))?;
    let plan = ReductionPlan::declared(
        MinimizationProfile::declared("one-byte-counterexample", 1),
        ByteReducerId::ChunkRemovalAndZeroing,
        Vec::new(),
        FingerprintPreservation::Required,
        ReductionBudget::declared(8),
    )
    .map_err(|refusal| format!("the reduction plan refused: {refusal:?}"))?;
    let evidence = reduce(&plan, &input, &probe)
        .map_err(|refusal| format!("the counterexample reduction refused: {refusal:?}"))?;
    require!(
        evidence.outcome().input() == input,
        "the one-byte reduction moved from the exact hostile member",
    )?;
    require!(
        evidence.outcome().halt() == ReductionHalt::FixedPointReached,
        "the one-byte reduction did not reach its fixed point",
    )?;
    require!(
        evidence.byte_reducer()
            == ByteReducerExecution::Executed(ByteReducerId::ChunkRemovalAndZeroing),
        "the generic byte reducer was not reached",
    )?;
    let census = evidence.outcome().census();
    require!(
        census.accepted() == 0,
        "the one-byte reduction admitted a shrink",
    )?;
    require!(
        census.fingerprint_moved() == 0,
        "the one-byte reduction reached another fingerprint",
    )?;
    require!(
        census.no_failure() == 2,
        "the one-byte reduction did not refuse exactly empty and zeroed candidates",
    )?;
    let capsule = capture_replay(&evidence);
    require!(
        capsule.input() == input,
        "the replay capsule did not retain the hostile member",
    )?;
    require!(
        capsule.posture() == ReplayPosture::ExactDerived,
        "the replay capsule did not retain its derived-revision ceiling",
    )?;
    require!(
        capsule.key() == report.standing().key(),
        "the replay capsule moved from the refused execution",
    )?;
    let [replay_member] = capsule.input() else {
        return Err("the replay capsule did not retain exactly one member".to_owned());
    };
    Ok(ReplayReading {
        input: *replay_member,
        halt: evidence.outcome().halt(),
        probes: census.probes(),
        accepted: census.accepted(),
        fingerprint_moved: census.fingerprint_moved(),
        no_failure: census.no_failure(),
        posture: capsule.posture(),
    })
}

fn refused_fingerprint(report: &TrialReport) -> Result<Fingerprint, String> {
    match report.attempt() {
        RunAttempt::Executed(TrialConclusion::Refused(finding)) => {
            Ok(Fingerprint::of(report.trial(), finding))
        }
        RunAttempt::Executed(TrialConclusion::Passed)
        | RunAttempt::SkippedWithReason(_)
        | RunAttempt::TimedOut
        | RunAttempt::InfrastructureFailed(_) => {
            Err("the hostile report retained no failure fingerprint".to_owned())
        }
    }
}

fn hostile_binding() -> Result<TrialBinding, String> {
    let subject = SubjectRoute::named(OWNER, "rotate-xor-hostile")
        .map_err(|refusal| format!("subject refused: {refusal:?}"))?;
    let check = CheckRef::named(OWNER, "temporal-drive")
        .map_err(|refusal| format!("check refused: {refusal:?}"))?;
    let row = Row::declared(
        ClaimRef::named(OWNER, "hostile-byte-roundtrip")
            .map_err(|refusal| format!("claim refused: {refusal:?}"))?,
        ExecutionSuite::named(OWNER, "stable-bounded")
            .map_err(|refusal| format!("suite refused: {refusal:?}"))?,
        Classification::authored(
            vec![
                Role::named(OWNER, "bounded-verification")
                    .map_err(|refusal| format!("role refused: {refusal:?}"))?,
            ],
            vec![
                Tag::named(OWNER, "hostile")
                    .map_err(|refusal| format!("tag refused: {refusal:?}"))?,
            ],
        )
        .map_err(|refusal| format!("classification refused: {refusal:?}"))?,
        subject,
        check,
        PopulationRef::named(OWNER, "complete-u8-domain")
            .map_err(|refusal| format!("population refused: {refusal:?}"))?,
        Origin::HandWritten,
    )
    .map_err(|refusal| format!("row refused: {refusal:?}"))?;
    Binding::bound(
        row,
        ExecutableAttachment::attached(
            subject,
            check,
            RevisionBinding::derived(DerivedRevision::from_material(b"rotate-xor-hostile/v1")),
            RevisionBinding::derived(DerivedRevision::from_material(b"temporal-drive/v1")),
            hostile_check,
        ),
        Provenance::Unproduced,
    )
    .map_err(|refusal| format!("binding refused: {refusal:?}"))
}

fn invocation() -> Result<Invocation, String> {
    let denominator = derived_u8_denominator();
    let cases = u32::try_from(denominator)
        .map_err(|_| "the derived denominator exceeded the invocation case width".to_owned())?;
    let bytes = u64::try_from(denominator)
        .map_err(|_| "the derived denominator exceeded the invocation byte width".to_owned())?;
    Ok(Invocation::declared(
        InvocationProfile::declared(
            CaseBudget::declared(cases),
            ByteBudget::declared(bytes),
            TimeBudget::declared(60_000_000_000),
        ),
        TargetBinding::bound(
            TargetTriple::declared(TARGET),
            ToolchainIdentity::declared(TOOLCHAIN),
        ),
        TrialSite::located(
            module_path!(),
            file!(),
            line!(),
            "wave-f-bounded-verification",
        ),
        HarnessClock::unavailable(),
    ))
}

fn hostile_probe(input: &[u8]) -> ProbeOutcome {
    if input != [HOSTILE_MEMBER] {
        return ProbeOutcome::NoFailure;
    }
    let Ok(binding) = hostile_binding() else {
        return ProbeOutcome::NoFailure;
    };
    ProbeOutcome::Reproduced(Fingerprint::over(
        trial_identity(binding.row()),
        CLAIM_CAUSE,
        FailureClass::PropertyDisagreement,
    ))
}

fn hostile_check(_: &Invocation) -> TrialConclusion {
    TrialConclusion::Refused(TrialFinding::established(
        FailureClass::PropertyDisagreement,
        CLAIM_CAUSE,
        FindingLocation::at(file!(), line!()),
        None,
    ))
}

fn decode_member(source: &mut Unstructured<'_>) -> arbitrary::Result<Member> {
    Ok(Member(u8::arbitrary(source)?))
}

fn opening_state() -> RoundtripState {
    RoundtripState {
        original: None,
        recovered: None,
    }
}

fn apply_rotate_xor(_: &RoundtripState, command: &Member) -> RoundtripState {
    let encoded = command.0.rotate_left(3) ^ 0xA7;
    RoundtripState {
        original: Some(command.0),
        recovered: Some((encoded ^ 0xA7).rotate_right(3)),
    }
}

fn apply_invert(_: &RoundtripState, command: &Member) -> RoundtripState {
    let encoded = !command.0;
    RoundtripState {
        original: Some(command.0),
        recovered: Some(!encoded),
    }
}

fn apply_hostile(_: &RoundtripState, command: &Member) -> RoundtripState {
    let lawful = apply_rotate_xor(&opening_state(), command);
    let recovered = if command.0 == HOSTILE_MEMBER {
        lawful.recovered.map(|value| value.wrapping_add(1u8))
    } else {
        lawful.recovered
    };
    RoundtripState {
        original: lawful.original,
        recovered,
    }
}

fn roundtrip_holds(state: &RoundtripState) -> Holding {
    match (state.original, state.recovered) {
        (None, None) => Holding::Holds,
        (Some(original), Some(recovered)) if original == recovered => Holding::Holds,
        (Some(_) | None, Some(_)) | (Some(_), None) => Holding::Fails,
    }
}
