//! Human-readable execution of the scratch-only bounded-verification witness.

use std::io::{self, Write};

fn main() -> Result<(), String> {
    let qualified = macroonz_wave_f_bounded_verification::qualify()?;
    io::stdout()
        .write_all(qualified.rendered().as_bytes())
        .map_err(|error| format!("the qualified reading could not be written: {error}"))
}
