# Wave F bounded semantic verification

This scratch result records a Windows x64 observation against the current repository source at `c7766b73be999aef09c49f83d7b36aaa18bca134`.
It does not seal evidence, alter repository authority, accept Wave F, establish a cross-host fact, prove symbolic completeness, or claim universal correctness.
The scratch workspace remains intact for parent review and later targeted mutation pressure.

## Authority and custody

- The working law, portable context, completion-program sections 8.1 through 8.7, Wave F, complete current generation, temporal-property, report, reduction/replay, and relevant descriptor owners were read before authorship.
- The accepted Wave E receipt was read whole at `.durafx/qualification/0.2-e-shared-substrate-20260830/receipt.md` and independently hashed as `7E829292760C3FF9E04B6B434C7CB1B50C87513E0A3FDC2B3627728426E2E64E`.
- The scratch workspace is `target/qualification/0.2-wave-f-bounded-verification-20260830` and its Cargo target is its own `target/` child.
- Cargo metadata reports exactly one scratch workspace member, `macroonz-wave-f-bounded-verification@0.0.0`.
- The only Macroonz dependency is the current live `macroonz-harness` package through the relative path `../../../harness`, so this is current-source qualification rather than registry-delivered or clean-package qualification.
- The tracked worktree and index remained clean at the recorded baseline after the lot.
- No tracked file, Git ref, `.durafx` artifact, portable context, documentation owner, manifest owner, or product source was changed.

## Denominator and composition

The declared input vocabulary is the inclusive iterator `u8::MIN..=u8::MAX` collected into supplied bytes.
The denominator is derived by counting the same inclusive `u8::MIN..=u8::MAX` iterator, which evaluates to 256 without a separately authored cardinality constant.
The source composes current `GenerationPlan`, `InputOrigin::Supplied`, `ByteSource::of_plan`, constant `CaseWidth::declared(1)`, `TransitionContract`, and `holds_over_drive` owners.
The lawful subject operation is a rotate-and-XOR encoding followed by its inverse, and the declared nontrivial property is that every recovered byte equals its original byte.
The complete drive is admitted only when generation halts at `CaseBudgetMet`, the generated census equals the derived denominator, the evaluated count equals the derived denominator, and the temporal standing is `Passed`.
Every generated sequence is inspected as exactly one retained byte and exactly one decoded member.
Every case ordinal is compared with its supplied position, a `BTreeSet` rejects duplicate decoded members, and the resulting set is compared with the complete derived vocabulary to reject omissions.
The lawful drive observed 256 generated, distinct, ordered, decoded, and evaluated members.

## Variation, incomplete controls, and vacuity

The lawful `InvertV1` variation uses another bijective operation and the reverse supplied order.
It preserves the declared roundtrip property over all 256 members while expressly not claiming unchanged method identity or order.
The shorter-source control supplies one derived member fewer while retaining the full case and byte budgets.
It observed `SourceExhausted`, 255 generated members, 255 evaluated members, and an `Incomplete` temporal standing.
The tighter-resource control supplies the full vocabulary with a byte budget one derived member short.
It observed `ByteBudgetExhausted`, 255 generated members, 255 evaluated members, and an `Incomplete` temporal standing.
These source and resource stops remain distinct typed observations.
A claim-free `TransitionContract` observed the exact `NoClaimDeclared` refusal rather than a passing conclusion.

## Hostile operation and replay handoff

The planted hostile operation uses the lawful rotate-and-XOR operation except that the inverse is wrong only for the exact member `0xA5`.
Generation still retained and independently inspected all 256 members before the temporal drive stopped evaluation at the first counterexample.
The observed refusal was `PropertyDisagreement` with cause `wave-f-bounded-verification/byte-roundtrip` at zero-based member position 165 after 166 evaluations.
The retained source byte and decoded member were both exactly `0xA5`.
The refusal crossed the current report join through an actual `HostTrialRecord` and `record_one` call.
The report-derived fingerprint was independently rederived by the capture-free reduction probe before reduction was allowed to begin.
The current generic byte reducer tested the empty and zeroed candidates, rejected both as `NoFailure`, accepted no shrink, moved to no other fingerprint, and halted at `FixedPointReached`.
The replay capsule retained exactly `0xA5`, the refused execution key, and the `ExactDerived` posture.
The ordinary scratch library surface and external `tests/bounded.rs` target retain these facts for the later targeted mutation sublot.

## Observed and planted facts

- The complete lawful and variation conclusions, exact member census, generation halts, incomplete standings, vacuity refusal, hostile property refusal, report join, reduction census, and replay capsule are observed results of this execution.
- The `0xA5` subject defect is intentionally planted and is not a discovered product defect.
- `InfrastructureFailed(GenerationUnavailable)` is an intentionally constructed typed unavailable posture and is not an observed host failure.
- No generic finite-domain verifier, `FiniteDomain` type, new product package, product dependency, or product test plumbing was needed.
- No public-constructor seam blocked the composition.
- The reduction probe is constrained to a capture-free function pointer, so it deterministically reconstructs the same trial binding rather than carrying a construction error.
- An exact precheck compares that reconstruction with the report-derived fingerprint, and any reconstruction failure refuses this qualification instead of becoming evidence.
- The lowest reuse-first disposition is that existing owners are sufficient for this bounded composition and the banked standalone `FiniteDomain` candidate is rejected.

## Exact output

Two direct executions of the built binary produced byte-identical output after LF normalization.
The 14-line, 929-byte UTF-8 output has SHA-256 `1D47AA7C63C433426FEC4FBCCD813A819A5D4AE3BEFCB70566F752FD544CD587`.
The executed binary has SHA-256 `A528320140FDDB261D7FC2EB1C6C06723C33DB85048999F39C3D8966EDB785D4`.

```text
WAVE_F_BOUNDED=qualified-semantic-half
DENOMINATOR_DERIVATION=inclusive-u8-min-through-u8-max
DENOMINATOR=256
LAWFUL_METHOD=RotateXorV1;EVALUATED=256
VARIATION_METHOD=InvertV1;EVALUATED=256;ORDER=reversed
SOURCE_INCOMPLETE=SourceExhausted;GENERATED=255;EVALUATED=255
RESOURCE_INCOMPLETE=ByteBudgetExhausted;GENERATED=255;EVALUATED=255
COUNTEREXAMPLE_METHOD=RotateXorHostileV1;MEMBER=0xA5;POSITION=165;EVALUATED=166
REPLAY_INPUT=0xA5;HALT=FixedPointReached;PROBES=2;ACCEPTED=0;FINGERPRINT_MOVED=0;NO_FAILURE=2;POSTURE=ExactDerived
PLANTED_UNAVAILABLE=InfrastructureFailed(InfrastructureFailure { fault: GenerationUnavailable, foreign: None })
VACUITY=NoClaimDeclared
PROBE_CEILING=capture-free-function-pointer-rederives-trial;construction-failure-refuses-qualification
DISPOSITION=existing-owner-composition-sufficient;standalone-FiniteDomain-rejected
CEILING=exhaustive-within-declared-one-byte-domain;not-symbolic-or-universal
```

## Toolchain and commands

The host is `x86_64-pc-windows-msvc` on Windows 11 Core 64-bit.
The compiler is `rustc 1.98.0 (88d9e12ae 2026-08-18)` with LLVM 22.1.8.
Cargo is `cargo 1.98.0 (797e8a9bc 2026-08-05)`.
The lockfile was prepared once with `cargo +1.98.0 generate-lockfile --offline`.
Every subsequent Cargo qualification command used the exact scratch lockfile, offline dependency resolution, the Windows x64 target, and one Cargo job where compilation occurred.
The isolated manifest carries the repository's warnings-denied Rust and `all` plus `pedantic` Clippy wall, including the no-suppression, checked-arithmetic, no-panic, and no-stdout-macro rules that apply to this source.

- `cargo +1.98.0 fmt --all -- --check` completed successfully.
- `cargo +1.98.0 check --locked --offline --all-targets --target x86_64-pc-windows-msvc --jobs 1` completed successfully.
- `cargo +1.98.0 test --locked --offline --all-targets --target x86_64-pc-windows-msvc --jobs 1 -- --test-threads=1` completed with two external integration tests passed and no failures.
- `cargo +1.98.0 clippy --locked --offline --all-targets --target x86_64-pc-windows-msvc --jobs 1 -- -D warnings` completed successfully under the manifest-declared repository lint wall.
- `cargo +1.98.0 metadata --locked --offline --no-deps --format-version 1` reported the exact isolated scratch workspace and target directory.
- A source-law search over the complete authored-file roster found no unsafe operation, `#[allow]`, `#[expect]`, library `#[cfg(test)]` item, authored build script, personal identity, absolute user path, CRLF text, byte-order mark, or reparse point.
- Two direct binary executions returned success and identical output bytes.

## Source roster

Every source file is UTF-8 without a byte-order mark and contains LF line endings only.

- `Cargo.toml`: 1299 bytes, 51 lines, SHA-256 `65088A5FE5DCA9F30ABE5F110598A8C8A45F8721B06D7D4A46E170DC227EC24F`.
- `Cargo.lock`: 3309 bytes, 126 lines, SHA-256 `294ECCD45C08EED79D6E7D447DDD0BAD37708F090097D9D4AC3922AE0777F6D1`.
- `rust-toolchain.toml`: 86 bytes, 4 lines, SHA-256 `E879701472A698533F43F54989BBF5F3101EB0503472159D32633F3BB8A13FDF`.
- `src/lib.rs`: 25960 bytes, 744 lines, SHA-256 `3A22884F05427B354E3A242A1E4C3C57FE98C0354B809D71D84B96BF22A40F5E`.
- `src/main.rs`: 373 bytes, 10 lines, SHA-256 `9075948EAE5D9A2E33EFF9D1195B3C96D8EF03A55F54D3ECF6ACD4F87610511A`.
- `tests/bounded.rs`: 1705 bytes, 35 lines, SHA-256 `2DDD9C336A69992C09ECE5315763CE430913773EC62ED76CB35E6C3EA342C869`.

## Ceilings and handoff

This is exhaustive only within the declared one-byte domain and the declared property.
It is not symbolic proof, a universal theorem, a Linux or macOS observation, registry-delivered qualification, package qualification, global wall evidence, targeted mutation evidence, or human acceptance.
The unavailable/resource posture is planted while the byte-budget stop is observed.
Targeted Muterprater pressure is deliberately deferred to its separate Wave F sublot.
The scratch source, lockfile, outputs, and build directory remain intact for parent QA, sealing, and later cleanup authority.
