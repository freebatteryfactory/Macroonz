//! External mutation-visible claims over the scratch library surface.

use macroonz_wave_f_bounded_verification::qualify;

#[test]
fn complete_domain_counterexample_and_ceilings_remain_explicit() -> Result<(), String> {
    let reading = qualify()?;
    let rendered = reading.rendered();
    let expected = concat!(
        "WAVE_F_BOUNDED=qualified-semantic-half\n",
        "DENOMINATOR_DERIVATION=inclusive-u8-min-through-u8-max\n",
        "DENOMINATOR=256\n",
        "LAWFUL_METHOD=RotateXorV1;EVALUATED=256\n",
        "VARIATION_METHOD=InvertV1;EVALUATED=256;ORDER=reversed\n",
        "SOURCE_INCOMPLETE=SourceExhausted;GENERATED=255;EVALUATED=255\n",
        "RESOURCE_INCOMPLETE=ByteBudgetExhausted;GENERATED=255;EVALUATED=255\n",
        "COUNTEREXAMPLE_METHOD=RotateXorHostileV1;MEMBER=0xA5;POSITION=165;EVALUATED=166\n",
        "REPLAY_INPUT=0xA5;HALT=FixedPointReached;PROBES=2;ACCEPTED=0;FINGERPRINT_MOVED=0;NO_FAILURE=2;POSTURE=ExactDerived\n",
        "PLANTED_UNAVAILABLE=InfrastructureFailed(InfrastructureFailure { fault: GenerationUnavailable, foreign: None })\n",
        "VACUITY=NoClaimDeclared\n",
        "PROBE_CEILING=capture-free-function-pointer-rederives-trial;construction-failure-refuses-qualification\n",
        "DISPOSITION=existing-owner-composition-sufficient;standalone-FiniteDomain-rejected\n",
        "CEILING=exhaustive-within-declared-one-byte-domain;not-symbolic-or-universal\n",
    );
    assert_eq!(rendered, expected);
    Ok(())
}

#[test]
fn repeated_execution_is_byte_identical() -> Result<(), String> {
    let first = qualify()?.rendered();
    let second = qualify()?.rendered();
    assert_eq!(first.as_bytes(), second.as_bytes());
    Ok(())
}
