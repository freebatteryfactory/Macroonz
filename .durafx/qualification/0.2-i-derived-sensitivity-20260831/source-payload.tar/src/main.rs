mod model;
mod render;

use std::fs;
use std::path::PathBuf;

fn main() {
    if let Err(error) = run() {
        eprintln!("sensitivity account refused: {error}");
        std::process::exit(1);
    }
}

fn run() -> Result<(), String> {
    let repo = PathBuf::from("../../..");
    let receipts = PathBuf::from("input/receipts.tsv");
    let rows = PathBuf::from("input/rows.tsv");
    let contexts = PathBuf::from("input/contexts.tsv");
    let output = PathBuf::from("out");
    let account = model::load(&repo, &receipts, &rows, &contexts)?;
    let refusals = model::qualify_refusals(&repo, &account)?;
    fs::create_dir_all(&output).map_err(|error| format!("{}: {error}", output.display()))?;
    let tsv = render::tsv(&account);
    let markdown = render::markdown(&account);
    write(&output.join("account.tsv"), &tsv)?;
    write(&output.join("account.md"), &markdown)?;
    write(&output.join("refusals.tsv"), &render::refusals(&refusals))?;
    println!("account rows: {}", account.rows.len());
    println!("receipt inputs: {}", account.receipts.len());
    println!("qualified refusals: {}", refusals.len());
    Ok(())
}

fn write(path: &PathBuf, content: &str) -> Result<(), String> {
    if content.contains('\r') {
        return Err(format!("{} contains CR bytes", path.display()));
    }
    fs::write(path, content.as_bytes()).map_err(|error| format!("{}: {error}", path.display()))
}
