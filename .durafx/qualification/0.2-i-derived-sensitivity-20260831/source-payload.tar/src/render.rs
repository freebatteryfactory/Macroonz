use std::fmt::Write as _;

use crate::model::{Account, Refusal, Row};

pub fn tsv(account: &Account) -> String {
    let mut output = String::from(
        "id\tclaim\tdamage\tmethod\tmethod_version\tmethod_request\treceipt\tcoordinates\tstanding\tactivation\tsensitivity\tcustody\tfoundation\tcost\tcost_coordinates\tdisposition\tceiling\n",
    );
    for row in &account.rows {
        write_row(&mut output, row);
    }
    output
}

pub fn markdown(account: &Account) -> String {
    let mut output = String::from("# Wave I claim-by-damage-by-method account\n\n");
    output.push_str("This account composes only facts in the exact receipt roster below.\n\n");
    output.push_str("It does not aggregate, score, rank, or infer method adequacy.\n\n");
    output.push_str("## Receipt custody\n\n");
    output.push_str("| Identity | Path | Git commit |\n| --- | --- | --- |\n");
    for receipt in &account.receipts {
        writeln!(
            &mut output,
            "| `{}` | `{}` | `{}` |",
            receipt.id, receipt.path, receipt.commit
        )
        .expect("writing into String cannot fail");
    }
    output.push_str("\n## Account\n\n");
    for row in &account.rows {
        writeln!(&mut output, "### `{}`\n", row.id).expect("writing into String cannot fail");
        field(&mut output, "Claim", &row.claim);
        field(&mut output, "Damage", &row.damage);
        field(&mut output, "Method", &row.method);
        field(&mut output, "Method version", &row.method_version);
        field(&mut output, "Method request", &row.method_request());
        field(&mut output, "Receipt", &row.receipt);
        field(&mut output, "Coordinates", &row.coordinates);
        field(&mut output, "Standing", &row.standing);
        field(&mut output, "Activation", &row.activation);
        field(&mut output, "Sensitivity evidence", &row.sensitivity);
        field(
            &mut output,
            "Counterexample, replay, and custody",
            &row.custody,
        );
        field(&mut output, "Shared-foundation warning", &row.foundation);
        field(&mut output, "Cost evidence", &row.cost);
        field(&mut output, "Cost coordinates", &row.cost_coordinates);
        field(&mut output, "Disposition", &row.disposition);
        field(&mut output, "Ceiling", &row.ceiling);
        output.push('\n');
    }
    output
}

fn write_row(output: &mut String, row: &Row) {
    writeln!(
        output,
        "{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}",
        row.id,
        row.claim,
        row.damage,
        row.method,
        row.method_version,
        row.method_request(),
        row.receipt,
        row.coordinates,
        row.standing,
        row.activation,
        row.sensitivity,
        row.custody,
        row.foundation,
        row.cost,
        row.cost_coordinates,
        row.disposition,
        row.ceiling
    )
    .expect("writing into String cannot fail");
}

pub fn refusals(refusals: &[Refusal]) -> String {
    let mut output = String::from("id\tstanding\tobservation\n");
    for refusal in refusals {
        writeln!(output, "{}\trefused\t{}", refusal.id, refusal.observed)
            .expect("writing into String cannot fail");
    }
    output
}

fn field(output: &mut String, name: &str, value: &str) {
    writeln!(output, "- {name}: {value}").expect("writing into String cannot fail");
}
