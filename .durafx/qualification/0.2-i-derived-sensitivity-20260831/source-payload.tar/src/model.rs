use std::collections::{BTreeMap, BTreeSet};
use std::fs;
use std::path::{Path, PathBuf};
use std::process::Command;

const RECEIPT_FIELDS: usize = 4;
const ROW_FIELDS: usize = 13;
const CONTEXT_FIELDS: usize = 4;

#[derive(Clone, Debug)]
pub struct Receipt {
    pub id: String,
    pub path: String,
    pub commit: String,
    pub anchors: Vec<String>,
}

#[derive(Clone, Debug)]
pub struct Row {
    pub id: String,
    pub claim: String,
    pub damage: String,
    pub method: String,
    pub receipt: String,
    pub coordinates: String,
    pub standing: String,
    pub activation: String,
    pub sensitivity: String,
    pub cost: String,
    pub cost_coordinates: String,
    pub disposition: String,
    pub ceiling: String,
    pub method_version: String,
    pub custody: String,
    pub foundation: String,
}

#[derive(Clone, Debug)]
struct Context {
    row: String,
    method_version: String,
    custody: String,
    foundation: String,
}

pub struct Refusal {
    pub id: &'static str,
    pub observed: String,
}

pub struct Account {
    pub receipts: Vec<Receipt>,
    pub rows: Vec<Row>,
}

pub fn load(
    repo: &Path,
    receipts_path: &Path,
    rows_path: &Path,
    contexts_path: &Path,
) -> Result<Account, String> {
    let receipts = parse_receipts(receipts_path)?;
    let mut rows = parse_rows(rows_path)?;
    let contexts = parse_contexts(contexts_path)?;
    attach_contexts(&mut rows, contexts)?;
    validate_receipts(repo, &receipts)?;
    validate_rows(repo, &receipts, &rows)?;
    Ok(Account { receipts, rows })
}

fn parse_receipts(path: &Path) -> Result<Vec<Receipt>, String> {
    let records = parse_table(path, RECEIPT_FIELDS)?;
    records
        .into_iter()
        .map(|fields| {
            let [id, receipt_path, commit, anchors]: [String; RECEIPT_FIELDS] =
                fields
                    .try_into()
                    .map_err(|_| "receipt field count changed unexpectedly".to_owned())?;
            Ok(Receipt {
                id,
                path: receipt_path,
                commit,
                anchors: anchors.split('|').map(str::to_owned).collect(),
            })
        })
        .collect()
}

fn parse_rows(path: &Path) -> Result<Vec<Row>, String> {
    let records = parse_table(path, ROW_FIELDS)?;
    records
        .into_iter()
        .map(|fields| {
            let [
                id,
                claim,
                damage,
                method,
                receipt,
                coordinates,
                standing,
                activation,
                sensitivity,
                cost,
                cost_coordinates,
                disposition,
                ceiling,
            ]: [String; ROW_FIELDS] = fields
                .try_into()
                .map_err(|_| "account field count changed unexpectedly".to_owned())?;
            Ok(Row {
                id,
                claim,
                damage,
                method,
                receipt,
                coordinates,
                standing,
                activation,
                sensitivity,
                cost,
                cost_coordinates,
                disposition,
                ceiling,
                method_version: String::new(),
                custody: String::new(),
                foundation: String::new(),
            })
        })
        .collect()
}

fn parse_contexts(path: &Path) -> Result<Vec<Context>, String> {
    let records = parse_table(path, CONTEXT_FIELDS)?;
    records
        .into_iter()
        .map(|fields| {
            let [row, method_version, custody, foundation]: [String; CONTEXT_FIELDS] = fields
                .try_into()
                .map_err(|_| "context field count changed unexpectedly".to_owned())?;
            Ok(Context {
                row,
                method_version,
                custody,
                foundation,
            })
        })
        .collect()
}

fn attach_contexts(rows: &mut [Row], contexts: Vec<Context>) -> Result<(), String> {
    let mut context_rows = BTreeSet::new();
    for context in &contexts {
        unique(&mut context_rows, &context.row, "method context")?;
        validate_token(&context.row, "method context row")?;
    }
    let mut by_row: BTreeMap<_, _> = contexts
        .into_iter()
        .map(|context| (context.row.clone(), context))
        .collect();
    for row in rows {
        let context = by_row
            .remove(&row.id)
            .ok_or_else(|| format!("row {} lacks method context", row.id))?;
        row.method_version = context.method_version;
        row.custody = context.custody;
        row.foundation = context.foundation;
    }
    if let Some(identity) = by_row.keys().next() {
        Err(format!("method context cites unknown row {identity}"))
    } else {
        Ok(())
    }
}

fn parse_table(path: &Path, field_count: usize) -> Result<Vec<Vec<String>>, String> {
    let text = fs::read_to_string(path).map_err(|error| format!("{}: {error}", path.display()))?;
    let mut lines = text.lines();
    let header = lines
        .next()
        .ok_or_else(|| format!("{} is empty", path.display()))?;
    if header.split('\t').count() != field_count {
        return Err(format!(
            "{} header does not have {field_count} fields",
            path.display()
        ));
    }
    lines
        .enumerate()
        .filter(|(_, line)| !line.is_empty())
        .map(|(index, line)| {
            let fields: Vec<_> = line.split('\t').map(str::to_owned).collect();
            if fields.len() != field_count || fields.iter().any(String::is_empty) {
                return Err(format!(
                    "{} line {} must have {field_count} nonempty fields",
                    path.display(),
                    index + 2
                ));
            }
            Ok(fields)
        })
        .collect()
}

fn validate_receipts(repo: &Path, receipts: &[Receipt]) -> Result<(), String> {
    let mut ids = BTreeSet::new();
    for receipt in receipts {
        unique(&mut ids, &receipt.id, "receipt")?;
        validate_token(&receipt.id, "receipt identity")?;
        if receipt.path.contains('\\')
            || receipt.path.starts_with('/')
            || receipt.path.contains("..")
        {
            return Err(format!("receipt {} has a non-neutral path", receipt.id));
        }
        if !receipt.path.starts_with(".durafx/") || !receipt.path.ends_with("/receipt.md") {
            return Err(format!(
                "receipt {} is outside accepted receipt custody",
                receipt.id
            ));
        }
        validate_commit(&receipt.commit, &receipt.id)?;
        git_success(
            repo,
            &["cat-file", "-e", &format!("{}^{{commit}}", receipt.commit)],
        )?;
        git_success(
            repo,
            &["merge-base", "--is-ancestor", &receipt.commit, "HEAD"],
        )?;
        let bytes = git_output(
            repo,
            &["show", &format!("{}:{}", receipt.commit, receipt.path)],
        )?;
        let current = fs::read(repo.join(PathBuf::from(&receipt.path)))
            .map_err(|error| format!("{}: {error}", receipt.path))?;
        if bytes != current {
            return Err(format!(
                "receipt {} differs from declared Git custody",
                receipt.id
            ));
        }
        let text =
            String::from_utf8(bytes).map_err(|error| format!("{}: {error}", receipt.path))?;
        for anchor in &receipt.anchors {
            if anchor.is_empty() || !text.contains(anchor) {
                return Err(format!(
                    "receipt {} lacks declared anchor {anchor:?}",
                    receipt.id
                ));
            }
        }
    }
    Ok(())
}

fn validate_rows(repo: &Path, receipts: &[Receipt], rows: &[Row]) -> Result<(), String> {
    let receipt_map: BTreeMap<_, _> = receipts
        .iter()
        .map(|receipt| (&receipt.id, receipt))
        .collect();
    let mut ids = BTreeSet::new();
    for row in rows {
        unique(&mut ids, &row.id, "row")?;
        validate_token(&row.id, "row identity")?;
        validate_member(
            &row.standing,
            &[
                "distinguished",
                "not-distinguished",
                "inconclusive",
                "unavailable",
                "unviable",
                "backend-failed",
            ],
            "standing",
        )?;
        validate_member(
            &row.activation,
            &[
                "observed",
                "unobservable-under-backend",
                "not-materialized",
                "not-applicable",
            ],
            "activation",
        )?;
        validate_member(
            &row.cost,
            &[
                "exact-current",
                "exact-historical",
                "unavailable",
                "inapplicable",
                "not-comparable",
            ],
            "cost",
        )?;
        validate_member(
            &row.disposition,
            &[
                "current-reusable",
                "historical-only",
                "inconclusive",
                "unavailable",
                "blocked",
            ],
            "disposition",
        )?;
        let receipt = receipt_map
            .get(&row.receipt)
            .ok_or_else(|| format!("row {} cites unknown receipt {}", row.id, row.receipt))?;
        validate_custody(repo, receipt, row)?;
        validate_cost_join(row)?;
        if row.method_version.is_empty() || row.custody.is_empty() || row.foundation.is_empty() {
            return Err(format!("row {} has incomplete method context", row.id));
        }
    }
    Ok(())
}

pub fn qualify_refusals(repo: &Path, account: &Account) -> Result<Vec<Refusal>, String> {
    let mut observations = Vec::new();

    let mut duplicate = account.rows.clone();
    duplicate.push(
        account
            .rows
            .first()
            .ok_or_else(|| "account has no row for refusal qualification".to_owned())?
            .clone(),
    );
    observations.push(observe_refusal(
        "duplicate-row-identity",
        validate_rows(repo, &account.receipts, &duplicate),
        "duplicate row identity",
    )?);

    let mut unknown = account.rows.clone();
    let unknown_standing = &mut unknown
        .first_mut()
        .ok_or_else(|| "account has no row for refusal qualification".to_owned())?
        .standing;
    "invented-standing".clone_into(unknown_standing);
    observations.push(observe_refusal(
        "unknown-vocabulary",
        validate_rows(repo, &account.receipts, &unknown),
        "unknown standing value",
    )?);

    let mut mismatched = account.rows.clone();
    let cost_row = mismatched
        .iter_mut()
        .find(|row| row.cost == "exact-historical")
        .ok_or_else(|| "account has no exact cost row for refusal qualification".to_owned())?;
    "source=mismatch;host=none;target=none;toolchain=none;bounds=none"
        .clone_into(&mut cost_row.cost_coordinates);
    observations.push(observe_refusal(
        "mismatched-exact-cost",
        validate_rows(repo, &account.receipts, &mismatched),
        "claims an exact cost join across different coordinates",
    )?);

    let mut broken = account.receipts.clone();
    broken
        .first_mut()
        .ok_or_else(|| "account has no receipt for refusal qualification".to_owned())?
        .anchors
        .push("anchor-that-is-not-in-the-receipt".to_owned());
    observations.push(observe_refusal(
        "broken-receipt-anchor",
        validate_receipts(repo, &broken),
        "lacks declared anchor",
    )?);

    Ok(observations)
}

fn observe_refusal(
    id: &'static str,
    result: Result<(), String>,
    expected: &str,
) -> Result<Refusal, String> {
    let observed = result.err().ok_or_else(|| format!("{id} was admitted"))?;
    if observed.contains(expected) {
        Ok(Refusal { id, observed })
    } else {
        Err(format!("{id} produced unexpected refusal: {observed}"))
    }
}

impl Row {
    pub fn method_request(&self) -> String {
        let bounds = coordinate_value(&self.coordinates, "bounds")
            .expect("validated row coordinates always contain bounds");
        format!(
            "claim={};damage={};bounds={bounds}",
            self.claim, self.damage
        )
    }
}

fn validate_custody(repo: &Path, receipt: &Receipt, row: &Row) -> Result<(), String> {
    let source = coordinate_value(&row.coordinates, "source")?;
    let text = fs::read_to_string(repo.join(&receipt.path))
        .map_err(|error| format!("{}: {error}", receipt.path))?;
    if !text.contains(source) {
        return Err(format!(
            "row {} source {source} is not cited by receipt {}",
            row.id, receipt.id
        ));
    }
    for required in ["host", "target", "toolchain", "bounds"] {
        let _ = coordinate_value(&row.coordinates, required)?;
    }
    Ok(())
}

fn validate_cost_join(row: &Row) -> Result<(), String> {
    match row.cost.as_str() {
        "exact-current" | "exact-historical" => {
            if row.cost_coordinates != row.coordinates {
                return Err(format!(
                    "row {} claims an exact cost join across different coordinates",
                    row.id
                ));
            }
        }
        _ if row.cost_coordinates != "none" => {
            return Err(format!(
                "row {} has cost coordinates without an exact join",
                row.id
            ));
        }
        _ => {}
    }
    Ok(())
}

fn coordinate_value<'a>(coordinates: &'a str, key: &str) -> Result<&'a str, String> {
    coordinates
        .split(';')
        .find_map(|part| {
            part.strip_prefix(key)
                .and_then(|rest| rest.strip_prefix('='))
        })
        .filter(|value| !value.is_empty())
        .ok_or_else(|| format!("coordinate lacks {key}= value: {coordinates}"))
}

fn validate_commit(commit: &str, identity: &str) -> Result<(), String> {
    if commit.len() == 40
        && commit
            .bytes()
            .all(|byte| byte.is_ascii_hexdigit() && !byte.is_ascii_uppercase())
    {
        Ok(())
    } else {
        Err(format!(
            "receipt {identity} has a noncanonical commit identity"
        ))
    }
}

fn git_success(repo: &Path, arguments: &[&str]) -> Result<(), String> {
    let status = Command::new("git")
        .arg("-C")
        .arg(repo)
        .args(arguments)
        .status()
        .map_err(|error| format!("cannot execute git: {error}"))?;
    if status.success() {
        Ok(())
    } else {
        Err(format!("git {} refused with {status}", arguments.join(" ")))
    }
}

fn git_output(repo: &Path, arguments: &[&str]) -> Result<Vec<u8>, String> {
    let output = Command::new("git")
        .arg("-C")
        .arg(repo)
        .args(arguments)
        .output()
        .map_err(|error| format!("cannot execute git: {error}"))?;
    if output.status.success() {
        Ok(output.stdout)
    } else {
        Err(format!(
            "git {} refused with {}",
            arguments.join(" "),
            output.status
        ))
    }
}

fn validate_member(value: &str, allowed: &[&str], vocabulary: &str) -> Result<(), String> {
    if allowed.contains(&value) {
        Ok(())
    } else {
        Err(format!("unknown {vocabulary} value {value:?}"))
    }
}

fn validate_token(value: &str, label: &str) -> Result<(), String> {
    if value
        .bytes()
        .all(|byte| byte.is_ascii_lowercase() || byte.is_ascii_digit() || byte == b'-')
    {
        Ok(())
    } else {
        Err(format!("{label} {value:?} is not a stable token"))
    }
}

fn unique(set: &mut BTreeSet<String>, value: &str, label: &str) -> Result<(), String> {
    if set.insert(value.to_owned()) {
        Ok(())
    } else {
        Err(format!("duplicate {label} identity {value}"))
    }
}
