# Macroonz 0.2 Wave I sensitivity-account scratch result

## Plane and authority

This is one disposable local Windows x64 derivation at repository input `e65a049c981d7019085fd0be5d788d209d06d149`.

It composes accepted tracked receipts and does not rerun a witness, mutation campaign, benchmark, package build, coverage campaign, or hostile control.

It introduces no tracked package, product source, dependency, feature, API, evidence schema, aggregate verdict, method ranking, commit, push, cleanup, plan edit, or portable-context edit.

The generator is safe Rust with no dependency and uses stable Rust 1.98.0 only.

The earlier proposed hand-written SHA-256 implementation was rejected during parent QA and removed before qualification.

Git remains the custody mechanism.

## Declared input and custody

`input/receipts.tsv` declares nineteen receipt identities, repository-relative paths, exact Git commits, and content anchors.

For every receipt, the generator requires:

- a stable unique identity;
- a host-neutral path beneath tracked `.durafx` custody;
- an exact forty-hex Git commit;
- a commit object that resolves;
- a commit that is an ancestor of input `HEAD`;
- bytes from `git show COMMIT:PATH` that equal the current working-tree receipt bytes;
- every declared content anchor.

`input/rows.tsv` declares thirty-one unique claim-by-damage-by-method rows.

`input/contexts.tsv` supplies exactly one method version, counterexample or replay custody statement, and shared-foundation warning for every row.

The declared method request is exactly `claim identity + damage identity + bounds coordinate`.

For every row, the generator requires:

- a known receipt identity;
- allowed standing, activation, cost, and disposition vocabulary;
- source, host, target, toolchain, and bounds coordinates;
- a source revision that appears in the cited receipt;
- an exact method version;
- a nonempty counterexample, replay, and custody statement;
- a nonempty shared-foundation warning that does not presume independence;
- identical sensitivity and cost coordinates before an exact cost join is admitted;
- `none` cost coordinates for every nonexact cost posture.

The fixed scratch-relative ports prevent command-line or environment input from silently changing the denominator.

## Account result

The final account contains thirty-one rows backed by nineteen receipts.

Disposition census:

- seventeen `current-reusable` rows;
- six `historical-only` rows;
- five `inconclusive` rows;
- two `unavailable` rows;
- one `blocked` row.

Standing census:

- nineteen `distinguished` rows;
- three `unviable` rows;
- two `inconclusive` rows;
- one `not-distinguished` equivalent row;
- five `unavailable` rows;
- one `backend-failed` historical infrastructure row.

Cost census:

- two exact historical sensitivity-cost joins;
- three inapplicable cost rows;
- three noncomparable cost rows;
- twenty-three rows with unavailable same-coordinate cost;
- zero exact current-source cost joins.

The account deliberately preserves these ceilings:

- the current guarded-transition mutation suite distinguishes viable damage but cannot assign every kill to one method;
- compile, fuzz, and finite-domain compiler-unviable mutations remain inconclusive rather than kills;
- Cargo Mutants activation remains unobservable where the backend does not report it;
- the assessed guarded payload-alignment mutation remains equivalent and not distinguished;
- Wave C has no genuine repository architecture defect and remains blocked rather than receiving a manufactured defect;
- an unavailable baseline remains incomparable rather than becoming method blindness;
- incomplete temporal standing remains outside the generic `RunAttempt` rail;
- the proc-macro analyzer remains unavailable while the package-shaped consumer independently distinguishes the planted rename;
- the first compatibility matrix's host-storage failure remains historical infrastructure failure rather than a product verdict;
- stable branch coverage and MC/DC remain unavailable;
- passing long concurrency campaigns and facade build-cost measurements do not become sensitivity evidence without damage controls.

The stable-coverage row names its exact control pair: hostile `[1, 2, 3]` added distinct coverage, repeated `[0]` remained known, and the hostile input reduced to exact replay `[1]`.

The SemVer library-break row names its exact planted damage: `Bounded::try_push` narrowed from public to crate-private visibility.

Every row exposes its evidence-method identity and version, derived method request, counterexample or replay custody, and shared-foundation warning in both output forms.

No aggregate score, trust scalar, automatic recommendation, or method ranking is emitted.

## Exact output

Two independent executions produced byte-identical files.

| Output | Bytes | SHA-256 |
| --- | ---: | --- |
| `out-a/account.tsv` | 29,571 | `4B52617A344E79BD4E424AB275A85F34D7C0F7481BA38FD79A7B4274E4270488` |
| `out-b/account.tsv` | 29,571 | `4B52617A344E79BD4E424AB275A85F34D7C0F7481BA38FD79A7B4274E4270488` |
| `out-a/account.md` | 40,976 | `BAA6387F7CA8B5A14EAE10B4BB49C147FAEB107A378EE402BBCF99C34466479E` |
| `out-b/account.md` | 40,976 | `BAA6387F7CA8B5A14EAE10B4BB49C147FAEB107A378EE402BBCF99C34466479E` |
| `out-a/refusals.tsv` | 388 | `2FADBC16CBE6F7E09671E81AC4A22BFD3C4284AD616E7B7810616898F8E0D9D6` |
| `out-b/refusals.tsv` | 388 | `2FADBC16CBE6F7E09671E81AC4A22BFD3C4284AD616E7B7810616898F8E0D9D6` |

The final machine-readable output adds the three declared context fields and the deterministically derived method request to the thirteen-field base rows.

Earlier draft and pre-context executions remain visibly preserved as `draft-a`, `draft-b`, `schema-gap-a`, and `schema-gap-b`; they are superseded and have no result authority.

## Negative validation observations

Every final execution cloned the admitted values in memory and observed four exact refusals without modifying any authoritative input byte:

- duplicate row identity refused as `duplicate row identity compile-error-code`;
- unknown vocabulary refused as `unknown standing value "invented-standing"`;
- mismatched exact cost coordinates refused as `row guarded-cost-control claims an exact cost join across different coordinates`;
- broken receipt custody anchor refused as `receipt compile-holder lacks declared anchor "anchor-that-is-not-in-the-receipt"`.

The concise observation is retained identically in `out-a/refusals.tsv` and `out-b/refusals.tsv`.

## Source and input hashes

| File | SHA-256 |
| --- | --- |
| `Cargo.toml` | `FBE0209E730F1683B9AAB50C136B2969612D7E1AEF386B8E8BE77ACCA51791AA` |
| `Cargo.lock` | `BBD6E894C21CCE7330ABC11C7F0E49A2A506EBBDBDE66433CFADFCB802F645C1` |
| `rust-toolchain.toml` | `71342820693D6EC2DB785CD0EC39102D6F10F6A59DC29DFEA0E7565123E9CCEF` |
| `README.md` | `168B77A99CBFF7DE6587D9A4F746A21D2465CC248A3FDD2203A85CE55CB85057` |
| `src/main.rs` | `D286B51B25CF060D15576706E27DB45F18A49A9C572E6BC3BC10402D8B8E8061` |
| `src/model.rs` | `3852CE03A54C4FB7F08A9A8B34C0C9D9C37CA95C3580BFCEFDEA56BAB65DA075` |
| `src/render.rs` | `9F449EB27EA486F15F97971FDF693D7DB2F119A3AE3B4E42367202F9C0C0915C` |
| `input/receipts.tsv` | `55BBB7949AB4812ADBA93EAFC944CA9D0EE7AAC7ED4EFA42FAAA7AE372309565` |
| `input/rows.tsv` | `3D5A2EFAA6A43C016B9085BC0DFA3B2F43D900B60C57AD34397B3BDEA5B5987C` |
| `input/contexts.tsv` | `6D12FEB157E650317F19088C2F99AABCFD3E00021F1283CBF49FD003149C308B` |

## Qualification commands

The commands below use `$scratch` for this exact scratch home and `$repo` for the repository root.

```powershell
cargo +1.98.0 generate-lockfile --manifest-path "$scratch/Cargo.toml" --offline
cargo +1.98.0 fmt --manifest-path "$scratch/Cargo.toml" --all
cargo +1.98.0 check --manifest-path "$scratch/Cargo.toml" --locked --offline --all-targets --target x86_64-pc-windows-msvc --jobs 1
cargo +1.98.0 clippy --manifest-path "$scratch/Cargo.toml" --locked --offline --all-targets --target x86_64-pc-windows-msvc --jobs 1 -- -D warnings -D clippy::all -D clippy::pedantic
Push-Location -LiteralPath $scratch
cargo +1.98.0 run --manifest-path Cargo.toml --locked --offline --target x86_64-pc-windows-msvc --jobs 1
Move-Item -LiteralPath out -Destination out-a
cargo +1.98.0 run --manifest-path Cargo.toml --locked --offline --target x86_64-pc-windows-msvc --jobs 1
Move-Item -LiteralPath out -Destination out-b
Pop-Location
```

Stable check passed.

Strict all-target Clippy passed with warnings denied after the argument port was replaced by fixed declared paths.

Both executions passed with `account rows: 31`, `receipt inputs: 19`, and `qualified refusals: 4`.

## Genuine missing-method and later-cost disposition

Wave I requires no new witness or mutation run after this composition.

The real Wave C defect row remains blocked because no genuine defect exists; manufacturing one would not satisfy that acceptance sentence.

Wave J current-source cost comparability remains separate because this account has no exact current-source cost join.

The smallest current-source rerun denominator is the already accepted guarded-transition economics observer, the already accepted cross-subject shape and projection economics observer, and the bounded facade adopter-cost postures, all at the current subject revision, current package artifacts, the same Windows x64 target, stable Rust 1.98.0, one Cargo job, and their original declared axes and bounds.

Existing direct and planted controls must be reused when their exact subject revision remains current and must not be rerun merely to attach a method or damage name.

The one cross-subject Muterprater cost mutation needs another run only if its exact cost-claim subject revision no longer matches the current cost observer; unchanged exact source custody is not a reason to rerun it.

No other genuine missing-method run was found.

## Parent verification

Parent read the complete generator source, declared receipt roster, base rows, method contexts, generated accounts, refusal observations, and this report.

Parent found that duplicate method-context rows could overwrite one another during the scratch-only join even though missing and extra context identities already refused.

The join now refuses duplicate method-context identities before collection and requires each context identity to use the same stable token vocabulary as an account row.

That repair changed only disposable generator source and did not change any declared row or generated output byte.

Parent reran stable Rust 1.98 formatting, locked and offline all-target checking, and strict all-target Clippy with warnings, `all`, and `pedantic` denied through a separate exact target directory.

Parent ran the generator twice after the repair and independently reproduced 31 account rows, 19 receipt inputs, four qualified refusals, and the exact accepted account and refusal hashes.

Every parent output matched both agent-generated output sets byte for byte.

## Repository state

The tracked worktree and index remained clean.

No tracked file or Git ref changed.

This scratch home remains uncleaned for parent QA.
