# Wave I sensitivity account generator

This disposable external generator composes accepted receipt facts into one deterministic claim-by-damage-by-method account.

It validates each declared receipt commit, Git ancestry, tracked bytes, receipt anchors, unique identities, controlled vocabularies, source-custody citations, and exact cost-join coordinates before writing output.

`input/contexts.tsv` declares every method version, counterexample or replay custody, and shared-foundation warning separately from the base claim rows.

The declared method request is exactly the row's claim identity, damage identity, and bounds coordinate.

It does not inspect product source, run a witness, rerun mutation, infer a score, rank methods, or define a product evidence type.

Its declared repository, input, and output paths are fixed relative to this scratch home, so no command-line or environment port can silently change the denominator.

Each execution also retains four negative observations proving refusal of a duplicate row identity, unknown vocabulary, mismatched exact cost coordinates, and a broken receipt anchor without changing the authoritative input files.
