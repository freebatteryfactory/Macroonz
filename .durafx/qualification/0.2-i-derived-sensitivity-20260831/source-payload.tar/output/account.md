# Wave I claim-by-damage-by-method account

This account composes only facts in the exact receipt roster below.

It does not aggregate, score, rank, or infer method adequacy.

## Receipt custody

| Identity | Path | Git commit |
| --- | --- | --- |
| `compile-holder` | `.durafx/qualification/0.2-a-compile-contract-holder-20260829/receipt.md` | `8fcd9df93bd5f019b1d3720a3ccc46a614ff9dda` |
| `compile-mutation` | `.durafx/qualification/0.2-a-compile-contract-mutation-20260829/receipt.md` | `2b1150b0f76ec9ecacaaebc3c57e9b0d60c4d659` |
| `stable-coverage` | `.durafx/qualification/0.2-q1-docs-blind-coverage-20260829/receipt.md` | `d330b0f03dba88635cbe3b9f4e1f7d18c7828f43` |
| `fuzz-mutation` | `.durafx/fuzz/wave-f-fuzz-targeted-mutation-20260828/receipt.md` | `44c5e16fb78f428c6b341a2979318de005517906` |
| `guarded-adoption` | `.durafx/qualification/0.2-b-guarded-transition-structural-adoption-20260830/receipt.md` | `c3894108b2c63e177165d58736f6f33ffa39c01b` |
| `structural-mutation` | `.durafx/qualification/0.2-b-structural-current-mutation-20260830/receipt.md` | `091aa44b42014671752bd2413fc721237d031a01` |
| `architecture` | `.durafx/qualification/0.2-c-architecture-reflexion-20260830/receipt.md` | `b6334b6bcd3d461245c622807af9177efae26fa2` |
| `change-impact` | `.durafx/qualification/0.2-d-change-impact-20260830/receipt.md` | `2f03aa2ed103dd4f3b6e70f36f8b35b05ab69be4` |
| `shared-substrate` | `.durafx/qualification/0.2-e-shared-substrate-20260830/receipt.md` | `c7766b73be999aef09c49f83d7b36aaa18bca134` |
| `finite-domain` | `.durafx/qualification/0.2-f-bounded-verification-20260830/receipt.md` | `2828e7de9652db5de8ac5fd8a555428a4b059bed` |
| `finite-mutation` | `.durafx/qualification/0.2-f-bounded-mutation-20260830/receipt.md` | `b44dbdd7a5982f55c360d906c31cea4f44b39e18` |
| `runtime-host` | `.durafx/qualification/0.2-g-runtime-host-20260830/receipt.md` | `73ffa61b8555290deebee2d463f207ba10651036` |
| `compatibility` | `.durafx/qualification/0.2-h-api-compatibility-20260831/receipt.md` | `e65a049c981d7019085fd0be5d788d209d06d149` |
| `bench-work` | `.durafx/performance/wave-f-work-evidence-20260827/receipt.md` | `9f2679e1bb8ae084dee2bb75aa026c117e729de7` |
| `guarded-economics` | `.durafx/qualification/0.2-b-guarded-transition-economics-20260829/receipt.md` | `2d910af1d4f14bb16035752e27dda4df502c19c5` |
| `cross-economics` | `.durafx/qualification/0.2-b-cross-subject-economics-20260829/receipt.md` | `7c5de1cf9b990793e153b95fe47c347c9aafbe5d` |
| `adopter-cost` | `.durafx/performance/wave-f-adopter-cost-windows-20260827/receipt.md` | `1559edb0a5cdc35a149579310abd9d88af0f377b` |
| `long-schedule` | `.durafx/schedule/wave-f-long-local-20260827/receipt.md` | `9f2679e1bb8ae084dee2bb75aa026c117e729de7` |
| `repository-coverage` | `.durafx/coverage/wave-f-stable-windows-20260827/receipt.md` | `1559edb0a5cdc35a149579310abd9d88af0f377b` |

## Account

### `compile-error-code`

- Claim: compiled refusal identifies the declared compiler error
- Damage: wrong compiler error code
- Method: compiled-oracle exact diagnostic comparison
- Method version: compiled-oracle@98122b2076e8037cc35c8b60001bbb86d5a43d27
- Method request: claim=compiled refusal identifies the declared compiler error;damage=wrong compiler error code;bounds=one-wrong-code-control
- Receipt: compile-holder
- Coordinates: source=98122b2076e8037cc35c8b60001bbb86d5a43d27;host=windows-local;target=x86_64-pc-windows-msvc;toolchain=rustc-1.98.0;bounds=one-wrong-code-control
- Standing: distinguished
- Activation: observed
- Sensitivity evidence: The wrong-code control reached compiled-diagnostic-error-code.
- Counterexample, replay, and custody: receipt=compile-holder;counterexample=wrong-code-control;replay=exact-compile-fixture
- Shared-foundation warning: shared=compiled-oracle-runner-report;independence=not-assumed
- Cost evidence: unavailable
- Cost coordinates: none
- Disposition: current-reusable
- Ceiling: One local Windows compiler process; no cross-host sensitivity claim.

### `compile-primary-span`

- Claim: compiled refusal identifies the declared primary span
- Damage: wrong primary diagnostic span
- Method: compiled-oracle exact diagnostic comparison
- Method version: compiled-oracle@98122b2076e8037cc35c8b60001bbb86d5a43d27
- Method request: claim=compiled refusal identifies the declared primary span;damage=wrong primary diagnostic span;bounds=one-wrong-span-control
- Receipt: compile-holder
- Coordinates: source=98122b2076e8037cc35c8b60001bbb86d5a43d27;host=windows-local;target=x86_64-pc-windows-msvc;toolchain=rustc-1.98.0;bounds=one-wrong-span-control
- Standing: distinguished
- Activation: observed
- Sensitivity evidence: The wrong-span control reached compiled-diagnostic-primary-span.
- Counterexample, replay, and custody: receipt=compile-holder;counterexample=wrong-span-control;replay=exact-compile-fixture
- Shared-foundation warning: shared=compiled-oracle-runner-report;independence=not-assumed
- Cost evidence: unavailable
- Cost coordinates: none
- Disposition: current-reusable
- Ceiling: One local Windows compiler process; no cost observation on the same coordinates.

### `compile-mutation-caught`

- Claim: compile-contract comparison and invariant nucleus reject viable damage
- Damage: selected viable mutation across comparison conclusion and guard
- Method: cargo-mutants compiled-suite pressure
- Method version: cargo-mutants@27.0.0
- Method request: claim=compile-contract comparison and invariant nucleus reject viable damage;damage=selected viable mutation across comparison conclusion and guard;bounds=49-selected-mutations
- Receipt: compile-mutation
- Coordinates: source=7377e3fb5edf92ee810782daa926460d1ba24208;host=windows-local;target=x86_64-pc-windows-msvc;toolchain=rustc-1.98.0;bounds=49-selected-mutations
- Standing: distinguished
- Activation: unobservable-under-backend
- Sensitivity evidence: Twenty-eight viable mutations were caught by existing external contracts.
- Counterexample, replay, and custody: receipt=compile-mutation;counterexample=selected-mutant-roster;replay=exact-source-command-and-holder
- Shared-foundation warning: shared=compiled-suite-and-compile-contracts;independence=not-assumed
- Cost evidence: unavailable
- Cost coordinates: none
- Disposition: current-reusable
- Ceiling: Activation and equivalence were not observed by this backend.

### `compile-mutation-unviable`

- Claim: compile-contract mutation denominator remains complete
- Damage: compiler-rejected generated replacement
- Method: cargo-mutants materialization classification
- Method version: cargo-mutants@27.0.0
- Method request: claim=compile-contract mutation denominator remains complete;damage=compiler-rejected generated replacement;bounds=49-selected-mutations
- Receipt: compile-mutation
- Coordinates: source=7377e3fb5edf92ee810782daa926460d1ba24208;host=windows-local;target=x86_64-pc-windows-msvc;toolchain=rustc-1.98.0;bounds=49-selected-mutations
- Standing: unviable
- Activation: unobservable-under-backend
- Sensitivity evidence: Twenty-one replacements could not compile against the structural types and do not become kills.
- Counterexample, replay, and custody: receipt=compile-mutation;counterexample=none-unviable;replay=exact-source-command-and-holder
- Shared-foundation warning: shared=compiled-suite-and-compile-contracts;independence=not-assumed
- Cost evidence: unavailable
- Cost coordinates: none
- Disposition: inconclusive
- Ceiling: No behavioral sensitivity conclusion follows for compiler-unviable rows.

### `stable-coverage-novelty`

- Claim: stable rustc source coverage distinguishes candidate execution paths
- Damage: hostile input [1, 2, 3] adds distinct coverage while repeated lawful input [0] remains known
- Method: instrument-coverage novelty frontier
- Method version: rustc-instrument-coverage@1.98.0+llvm-tools@22.1.8
- Method request: claim=stable rustc source coverage distinguishes candidate execution paths;damage=hostile input [1, 2, 3] adds distinct coverage while repeated lawful input [0] remains known;bounds=three-attempt-five-byte-public-road
- Receipt: stable-coverage
- Coordinates: source=0.1.0;host=windows-local;target=x86_64-pc-windows-msvc;toolchain=rustc-1.98.0;bounds=three-attempt-five-byte-public-road
- Standing: distinguished
- Activation: observed
- Sensitivity evidence: Hostile input [1, 2, 3] succeeded at the process plane and added distinct coverage; repeated [0] was known rather than novel; the hostile input reduced to exact replay [1].
- Counterexample, replay, and custody: receipt=stable-coverage;counterexample=hostile-[1,2,3];replay=exact-[1]
- Shared-foundation warning: shared=harness-fuzz-corpus-reduction-replay;independence=not-assumed
- Cost evidence: unavailable
- Cost coordinates: none
- Disposition: current-reusable
- Ceiling: Stable source-line coverage only; explicit branch and edge coverage are not claimed.

### `fuzz-mutation-caught`

- Claim: fuzz authority and custody joins reject viable implementation damage
- Damage: selected viable mutation at the declared fuzz decision points
- Method: cargo-mutants compiled-suite pressure
- Method version: cargo-mutants@27.0.0
- Method request: claim=fuzz authority and custody joins reject viable implementation damage;damage=selected viable mutation at the declared fuzz decision points;bounds=44-selected-mutations
- Receipt: fuzz-mutation
- Coordinates: source=b93a1c1;host=windows-local;target=x86_64-pc-windows-msvc;toolchain=rustc-1.98.0;bounds=44-selected-mutations
- Standing: distinguished
- Activation: unobservable-under-backend
- Sensitivity evidence: Thirty-one viable mutations were caught after the three initial misses earned promoted regressions.
- Counterexample, replay, and custody: receipt=fuzz-mutation;counterexample=selected-mutant-roster;replay=promoted-owning-regressions
- Shared-foundation warning: shared=harness-fuzz-external-tests-and-custody;independence=not-assumed
- Cost evidence: unavailable
- Cost coordinates: none
- Disposition: current-reusable
- Ceiling: No hosted cross-host or general mutation-adequacy claim.

### `fuzz-mutation-unviable`

- Claim: fuzz mutation denominator retains materialization standing
- Damage: compiler-rejected generated replacement
- Method: cargo-mutants materialization classification
- Method version: cargo-mutants@27.0.0
- Method request: claim=fuzz mutation denominator retains materialization standing;damage=compiler-rejected generated replacement;bounds=44-selected-mutations
- Receipt: fuzz-mutation
- Coordinates: source=b93a1c1;host=windows-local;target=x86_64-pc-windows-msvc;toolchain=rustc-1.98.0;bounds=44-selected-mutations
- Standing: unviable
- Activation: unobservable-under-backend
- Sensitivity evidence: Thirteen selected replacements could not construct informed private types and were not counted as kills.
- Counterexample, replay, and custody: receipt=fuzz-mutation;counterexample=none-unviable;replay=exact-selector-and-console
- Shared-foundation warning: shared=harness-fuzz-external-tests-and-custody;independence=not-assumed
- Cost evidence: unavailable
- Cost coordinates: none
- Disposition: inconclusive
- Ceiling: No behavioral sensitivity conclusion follows for compiler-unviable rows.

### `guarded-current-suite`

- Claim: guarded-transition structural adoption resists current selected damage
- Damage: viable mutations across the engine and shared structural batteries
- Method: cargo-mutants combined external suites
- Method version: cargo-mutants@27.0.0
- Method request: claim=guarded-transition structural adoption resists current selected damage;damage=viable mutations across the engine and shared structural batteries;bounds=57-engine-plus-86-pre-cure-plus-17-post-cure
- Receipt: structural-mutation
- Coordinates: source=b353f71cd5cded0d29e9c9b83dc2531d1ccc52d5;host=windows-local;target=x86_64-pc-windows-msvc;toolchain=rustc-1.98.0;bounds=57-engine-plus-86-pre-cure-plus-17-post-cure
- Standing: distinguished
- Activation: unobservable-under-backend
- Sensitivity evidence: The accepted campaign reports caught viable mutations and zero surviving viable mutation across its exact selectors.
- Counterexample, replay, and custody: receipt=structural-mutation;counterexample=selected-engine-and-battery-mutants;replay=exact-source-selectors-and-external-suites
- Shared-foundation warning: shared=one-guarded-engine-and-combined-external-suites;independence=not-assumed
- Cost evidence: unavailable
- Cost coordinates: none
- Disposition: inconclusive
- Ceiling: The combined suite does not establish per-method attribution for each caught mutation.

### `guarded-equivalent-row`

- Claim: guarded-transition mutation account separates equivalent structure-preserving replacement
- Damage: payload alignment comparison replacement
- Method: cargo-mutants equivalence assessment
- Method version: cargo-mutants@27.0.0
- Method request: claim=guarded-transition mutation account separates equivalent structure-preserving replacement;damage=payload alignment comparison replacement;bounds=one-payload-alignment-mutation
- Receipt: structural-mutation
- Coordinates: source=b353f71cd5cded0d29e9c9b83dc2531d1ccc52d5;host=windows-local;target=x86_64-pc-windows-msvc;toolchain=rustc-1.98.0;bounds=one-payload-alignment-mutation
- Standing: not-distinguished
- Activation: unobservable-under-backend
- Sensitivity evidence: The replacement was classified equivalent because equality at that comparison is unwritable through the informed construction chain.
- Counterexample, replay, and custody: receipt=structural-mutation;counterexample=none-equivalent;replay=exact-payload-alignment-mutation
- Shared-foundation warning: shared=guarded-engine-informed-construction-chain;independence=not-assumed
- Cost evidence: inapplicable
- Cost coordinates: none
- Disposition: current-reusable
- Ceiling: This is an assessed equivalent row rather than a sensitivity failure.

### `architecture-absent-edge`

- Claim: architecture correspondence detects a missing declared edge
- Damage: one removed Macroonz edge or one removed subject edge
- Method: bidirectional package-edge correspondence
- Method version: architecture-correspondence@f9495381e6f6eb95adb278086ed441c15f1d856c
- Method request: claim=architecture correspondence detects a missing declared edge;damage=one removed Macroonz edge or one removed subject edge;bounds=two-planted-missing-edge-controls
- Receipt: architecture
- Coordinates: source=f9495381e6f6eb95adb278086ed441c15f1d856c;host=windows-local;target=x86_64-pc-windows-msvc;toolchain=rustc-1.98.0;bounds=two-planted-missing-edge-controls
- Standing: distinguished
- Activation: observed
- Sensitivity evidence: Each planted missing edge produced Absent from a nonempty denominator where the edge was initially observed.
- Counterexample, replay, and custody: receipt=architecture;counterexample=planted-missing-edge;replay=exact-driver-and-graph-input
- Shared-foundation warning: shared=repository-and-package-graph;independence=not-assumed
- Cost evidence: unavailable
- Cost coordinates: none
- Disposition: current-reusable
- Ceiling: Planted controls are not relabeled as real repository defects.

### `architecture-reverse-edge`

- Claim: architecture correspondence detects a forbidden reverse edge
- Damage: one planted backedge in each graph
- Method: bidirectional package-edge correspondence
- Method version: architecture-correspondence@f9495381e6f6eb95adb278086ed441c15f1d856c
- Method request: claim=architecture correspondence detects a forbidden reverse edge;damage=one planted backedge in each graph;bounds=two-planted-reverse-edge-controls
- Receipt: architecture
- Coordinates: source=f9495381e6f6eb95adb278086ed441c15f1d856c;host=windows-local;target=x86_64-pc-windows-msvc;toolchain=rustc-1.98.0;bounds=two-planted-reverse-edge-controls
- Standing: distinguished
- Activation: observed
- Sensitivity evidence: Each planted reverse backedge produced Divergent.
- Counterexample, replay, and custody: receipt=architecture;counterexample=planted-reverse-backedge;replay=exact-driver-and-graph-input
- Shared-foundation warning: shared=repository-and-package-graph;independence=not-assumed
- Cost evidence: unavailable
- Cost coordinates: none
- Disposition: current-reusable
- Ceiling: Private placement and renderer layout are outside this method.

### `architecture-real-defect`

- Claim: architecture method can classify a genuine repository architecture defect
- Damage: missing or forbidden real package edge
- Method: bidirectional package-edge correspondence
- Method version: architecture-correspondence@f9495381e6f6eb95adb278086ed441c15f1d856c
- Method request: claim=architecture method can classify a genuine repository architecture defect;damage=missing or forbidden real package edge;bounds=no-genuine-defect-present
- Receipt: architecture
- Coordinates: source=f9495381e6f6eb95adb278086ed441c15f1d856c;host=windows-local;target=x86_64-pc-windows-msvc;toolchain=rustc-1.98.0;bounds=no-genuine-defect-present
- Standing: unavailable
- Activation: not-materialized
- Sensitivity evidence: No genuine accepted repository defect existed to exercise this row.
- Counterexample, replay, and custody: receipt=architecture;counterexample=none;replay=none
- Shared-foundation warning: shared=repository-and-package-graph;independence=not-assumed
- Cost evidence: unavailable
- Cost coordinates: none
- Disposition: blocked
- Ceiling: Wave C real-defect acceptance remains blocked without manufacturing a defect.

### `change-impact-shortcut`

- Claim: change-impact witness notices projection-order drift
- Damage: caller-offered order rendered instead of informed denominator order
- Method: canonical-byte property comparison
- Method version: change-impact-driver@b6334b6bcd3d461245c622807af9177efae26fa2
- Method request: claim=change-impact witness notices projection-order drift;damage=caller-offered order rendered instead of informed denominator order;bounds=one-planted-order-shortcut
- Receipt: change-impact
- Coordinates: source=b6334b6bcd3d461245c622807af9177efae26fa2;host=windows-local;target=x86_64-pc-windows-msvc;toolchain=rustc-1.98.0;bounds=one-planted-order-shortcut
- Standing: distinguished
- Activation: observed
- Sensitivity evidence: The planted shortcut changed canonical bytes and the existing property road returned a typed disagreement.
- Counterexample, replay, and custody: receipt=change-impact;counterexample=planted-order-shortcut;replay=exact-canonical-byte-input
- Shared-foundation warning: shared=canonical-encoding-and-property-road;independence=not-assumed
- Cost evidence: unavailable
- Cost coordinates: none
- Disposition: current-reusable
- Ceiling: No fresh benchmark or mutation campaign was part of this receipt.

### `change-impact-no-baseline`

- Claim: change-impact method preserves an unavailable comparison
- Damage: baseline not recorded
- Method: report comparison
- Method version: change-impact-driver@b6334b6bcd3d461245c622807af9177efae26fa2
- Method request: claim=change-impact method preserves an unavailable comparison;damage=baseline not recorded;bounds=one-unavailable-baseline-control
- Receipt: change-impact
- Coordinates: source=b6334b6bcd3d461245c622807af9177efae26fa2;host=windows-local;target=x86_64-pc-windows-msvc;toolchain=rustc-1.98.0;bounds=one-unavailable-baseline-control
- Standing: unavailable
- Activation: not-applicable
- Sensitivity evidence: Baseline unavailable remained NotCompared and is not relabeled as method blindness.
- Counterexample, replay, and custody: receipt=change-impact;counterexample=none-unavailable;replay=not-compared-baseline-posture
- Shared-foundation warning: shared=report-comparison-rail;independence=not-assumed
- Cost evidence: inapplicable
- Cost coordinates: none
- Disposition: unavailable
- Ceiling: An unavailable comparison cannot establish sensitivity.

### `shared-compile-span`

- Claim: shared runner and report rail preserves compiled-oracle refusal
- Damage: wrong compiled primary span
- Method: method-specific adapter over shared runner rail
- Method version: shared-substrate-driver@2f03aa2ed103dd4f3b6e70f36f8b35b05ab69be4
- Method request: claim=shared runner and report rail preserves compiled-oracle refusal;damage=wrong compiled primary span;bounds=one-planted-wrong-span
- Receipt: shared-substrate
- Coordinates: source=2f03aa2ed103dd4f3b6e70f36f8b35b05ab69be4;host=windows-local;target=x86_64-pc-windows-msvc;toolchain=rustc-1.98.0;bounds=one-planted-wrong-span
- Standing: distinguished
- Activation: observed
- Sensitivity evidence: The planted wrong-span declaration mapped to an executed OracleDisagreement refusal.
- Counterexample, replay, and custody: receipt=shared-substrate;counterexample=planted-wrong-span;replay=reused-exact-compile-holder
- Shared-foundation warning: shared=compiled-oracle-runner-report;independence=explicitly-not-independent-of-compile-holder
- Cost evidence: unavailable
- Cost coordinates: none
- Disposition: current-reusable
- Ceiling: The underlying rustc observation is reused rather than a fresh process run.

### `shared-temporal-incomplete`

- Claim: shared rail does not forge a conclusion for an incomplete method reading
- Damage: generation source exhausted before conclusion
- Method: method-specific temporal adapter
- Method version: shared-substrate-driver@2f03aa2ed103dd4f3b6e70f36f8b35b05ab69be4
- Method request: claim=shared rail does not forge a conclusion for an incomplete method reading;damage=generation source exhausted before conclusion;bounds=one-incomplete-drive-row
- Receipt: shared-substrate
- Coordinates: source=2f03aa2ed103dd4f3b6e70f36f8b35b05ab69be4;host=windows-local;target=x86_64-pc-windows-msvc;toolchain=rustc-1.98.0;bounds=one-incomplete-drive-row
- Standing: inconclusive
- Activation: not-applicable
- Sensitivity evidence: The incomplete row remains typed and visible outside RunAttempt and selecting it without a record refuses MissingSelectedRecord.
- Counterexample, replay, and custody: receipt=shared-substrate;counterexample=source-exhausted-reading;replay=exact-temporal-drive
- Shared-foundation warning: shared=runner-report-and-temporal-property;independence=not-assumed
- Cost evidence: inapplicable
- Cost coordinates: none
- Disposition: inconclusive
- Ceiling: No current RunAttempt arm can carry this standing truthfully.

### `finite-domain-direct`

- Claim: bounded finite-domain verification detects a planted inverse defect
- Damage: wrong inverse result at byte 0xA5
- Method: exhaustive property evaluation
- Method version: bounded-verification-driver@c7766b73be999aef09c49f83d7b36aaa18bca134
- Method request: claim=bounded finite-domain verification detects a planted inverse defect;damage=wrong inverse result at byte 0xA5;bounds=256-byte-complete-denominator
- Receipt: finite-domain
- Coordinates: source=c7766b73be999aef09c49f83d7b36aaa18bca134;host=windows-local;target=x86_64-pc-windows-msvc;toolchain=rustc-1.98.0;bounds=256-byte-complete-denominator
- Standing: distinguished
- Activation: observed
- Sensitivity evidence: The planted defect produced PropertyDisagreement at position 165 after 166 evaluations.
- Counterexample, replay, and custody: receipt=finite-domain;counterexample=byte-0xA5-at-position-165;replay=exact-256-byte-denominator
- Shared-foundation warning: shared=property-and-generation-road;independence=not-assumed
- Cost evidence: unavailable
- Cost coordinates: none
- Disposition: current-reusable
- Ceiling: The counterexample is planted and is not a discovered product defect.

### `finite-mutation-caught`

- Claim: finite-domain external witnesses reject viable semantic damage
- Damage: selected viable mutation across 24 semantic functions
- Method: cargo-mutants compiled-suite pressure
- Method version: cargo-mutants@27.0.0
- Method request: claim=finite-domain external witnesses reject viable semantic damage;damage=selected viable mutation across 24 semantic functions;bounds=42-selected-mutations
- Receipt: finite-mutation
- Coordinates: source=2828e7de9652db5de8ac5fd8a555428a4b059bed;host=windows-local;target=x86_64-pc-windows-msvc;toolchain=rustc-1.98.0;bounds=42-selected-mutations
- Standing: distinguished
- Activation: unobservable-under-backend
- Sensitivity evidence: Sixteen built mutants were rejected by the external witnesses and zero viable mutant survived.
- Counterexample, replay, and custody: receipt=finite-mutation;counterexample=selected-semantic-mutants;replay=exact-source-selector-and-external-witnesses
- Shared-foundation warning: shared=finite-domain-external-witness-suite;independence=not-assumed
- Cost evidence: unavailable
- Cost coordinates: none
- Disposition: current-reusable
- Ceiling: Activation and equivalence are not established by this backend.

### `finite-mutation-unviable`

- Claim: finite-domain mutation account preserves unviable materialization
- Damage: compiler-rejected generated replacement
- Method: cargo-mutants materialization classification
- Method version: cargo-mutants@27.0.0
- Method request: claim=finite-domain mutation account preserves unviable materialization;damage=compiler-rejected generated replacement;bounds=42-selected-mutations
- Receipt: finite-mutation
- Coordinates: source=2828e7de9652db5de8ac5fd8a555428a4b059bed;host=windows-local;target=x86_64-pc-windows-msvc;toolchain=rustc-1.98.0;bounds=42-selected-mutations
- Standing: unviable
- Activation: unobservable-under-backend
- Sensitivity evidence: Twenty-six mutants could not compile and remain inconclusive rather than entering the kill count.
- Counterexample, replay, and custody: receipt=finite-mutation;counterexample=none-unviable;replay=exact-source-selector-and-console
- Shared-foundation warning: shared=finite-domain-external-witness-suite;independence=not-assumed
- Cost evidence: unavailable
- Cost coordinates: none
- Disposition: inconclusive
- Ceiling: No behavioral sensitivity conclusion follows for compiler-unviable rows.

### `runtime-logical-order`

- Claim: runtime exploration detects a logical ordering counterexample
- Damage: declared schedule ordering violation
- Method: bounded interleave exploration
- Method version: runtime-host-driver@b44dbdd7a5982f55c360d906c31cea4f44b39e18
- Method request: claim=runtime exploration detects a logical ordering counterexample;damage=declared schedule ordering violation;bounds=one-logical-order-counterexample
- Receipt: runtime-host
- Coordinates: source=b44dbdd7a5982f55c360d906c31cea4f44b39e18;host=windows-local;target=x86_64-pc-windows-msvc;toolchain=rustc-1.98.0;bounds=one-logical-order-counterexample
- Standing: distinguished
- Activation: observed
- Sensitivity evidence: The local method retained one logical-order counterexample.
- Counterexample, replay, and custody: receipt=runtime-host;counterexample=logical-order-counterexample;replay=exact-bounded-schedule-input
- Shared-foundation warning: shared=harness-runner-report-and-schedule-types;independence=not-assumed
- Cost evidence: unavailable
- Cost coordinates: none
- Disposition: current-reusable
- Ceiling: One local host and exact bound only.

### `runtime-abort`

- Claim: process observation classifies a real abort as a crash
- Damage: child process abort
- Method: external fuzz execution classifier
- Method version: runtime-host-driver@b44dbdd7a5982f55c360d906c31cea4f44b39e18
- Method request: claim=process observation classifies a real abort as a crash;damage=child process abort;bounds=one-aborting-child
- Receipt: runtime-host
- Coordinates: source=b44dbdd7a5982f55c360d906c31cea4f44b39e18;host=windows-local;target=x86_64-pc-windows-msvc;toolchain=rustc-1.98.0;bounds=one-aborting-child
- Standing: distinguished
- Activation: observed
- Sensitivity evidence: The caller-owned supervisor observed std::process::abort and classified the non-successful exit as Crash.
- Counterexample, replay, and custody: receipt=runtime-host;counterexample=aborting-child-exit;replay=exact-child-and-supervisor-input
- Shared-foundation warning: shared=harness-fuzz-execution-classifier-and-report;independence=not-assumed
- Cost evidence: unavailable
- Cost coordinates: none
- Disposition: current-reusable
- Ceiling: Generic infrastructure standing remains unresolved.

### `semver-library-break`

- Claim: package compatibility detects public visibility narrowing
- Damage: Bounded::try_push changes from public to crate-private
- Method: cargo-semver-checks plus package-shaped controls
- Method version: cargo-semver-checks@0.50.0
- Method request: claim=package compatibility detects public visibility narrowing;damage=Bounded::try_push changes from public to crate-private;bounds=one-planted-library-break
- Receipt: compatibility
- Coordinates: source=73ffa61b8555290deebee2d463f207ba10651036;host=windows-local;target=x86_64-pc-windows-msvc;toolchain=rustc-1.98.0;bounds=one-planted-library-break
- Standing: distinguished
- Activation: observed
- Sensitivity evidence: The analyzer detected the planted Bounded::try_push visibility narrowing while the additive control was admitted.
- Counterexample, replay, and custody: receipt=compatibility;counterexample=Bounded::try_push-public-to-crate-private;replay=exact-baseline-and-candidate-packages
- Shared-foundation warning: shared=same-package-baseline-and-candidate;independence=not-assumed
- Cost evidence: unavailable
- Cost coordinates: none
- Disposition: current-reusable
- Ceiling: Analyzer skips remain explicit non-observations.

### `semver-proc-analyzer`

- Claim: package compatibility analyzes proc-macro entry removal
- Damage: proc-macro entry renamed
- Method: cargo-semver-checks analyzer
- Method version: cargo-semver-checks@0.50.0
- Method request: claim=package compatibility analyzes proc-macro entry removal;damage=proc-macro entry renamed;bounds=proc-package-no-library-target
- Receipt: compatibility
- Coordinates: source=73ffa61b8555290deebee2d463f207ba10651036;host=windows-local;target=x86_64-pc-windows-msvc;toolchain=rustc-1.98.0;bounds=proc-package-no-library-target
- Standing: unavailable
- Activation: not-materialized
- Sensitivity evidence: The analyzer skipped macroonz-macros because it has no ordinary library target.
- Counterexample, replay, and custody: receipt=compatibility;counterexample=network-proc-entry-rename;replay=exact-proc-baseline-and-candidate
- Shared-foundation warning: shared=same-package-baseline-and-candidate;independence=not-assumed
- Cost evidence: unavailable
- Cost coordinates: none
- Disposition: unavailable
- Ceiling: The analyzer result cannot establish proc-macro compatibility sensitivity.

### `semver-proc-consumer`

- Claim: package-shaped consumer detects proc-macro entry removal
- Damage: public network proc-macro renamed
- Method: independent renamed-facade consumer
- Method version: rustc-consumer@1.98.0
- Method request: claim=package-shaped consumer detects proc-macro entry removal;damage=public network proc-macro renamed;bounds=one-renamed-proc-control
- Receipt: compatibility
- Coordinates: source=73ffa61b8555290deebee2d463f207ba10651036;host=windows-local;target=x86_64-pc-windows-msvc;toolchain=rustc-1.98.0;bounds=one-renamed-proc-control
- Standing: distinguished
- Activation: observed
- Sensitivity evidence: The otherwise identical consumer refused with E0433 because network was absent from macros.
- Counterexample, replay, and custody: receipt=compatibility;counterexample=network-proc-entry-rename;replay=exact-renamed-facade-consumer
- Shared-foundation warning: shared=same-proc-baseline-candidate-and-facade;independence=not-assumed
- Cost evidence: unavailable
- Cost coordinates: none
- Disposition: current-reusable
- Ceiling: This fills a package-shaped consumer crossing and does not upgrade the analyzer.

### `semver-host-exhaustion`

- Claim: package compatibility execution retains infrastructure failure separately
- Damage: host storage exhaustion interrupted the expanded posture run
- Method: package compatibility execution
- Method version: compatibility-matrix@73ffa61b8555290deebee2d463f207ba10651036
- Method request: claim=package compatibility execution retains infrastructure failure separately;damage=host storage exhaustion interrupted the expanded posture run;bounds=initial-expanded-posture-run
- Receipt: compatibility
- Coordinates: source=73ffa61b8555290deebee2d463f207ba10651036;host=windows-local;target=x86_64-pc-windows-msvc;toolchain=rustc-1.98.0;bounds=initial-expanded-posture-run
- Standing: backend-failed
- Activation: not-applicable
- Sensitivity evidence: The first expanded posture run refused with operating-system error 112 when the host drive filled; the later bounded run is the accepted compatibility result.
- Counterexample, replay, and custody: receipt=compatibility;counterexample=host-error-112;replay=none-infrastructure-failure
- Shared-foundation warning: shared=same-package-and-consumer-matrix;independence=not-applicable
- Cost evidence: unavailable
- Cost coordinates: none
- Disposition: historical-only
- Ceiling: Infrastructure failure carries no product or method-sensitivity verdict and is not erased by the later successful run.

### `bench-planted-work`

- Claim: benchmark work evidence distinguishes the planted-worse curve
- Damage: avoidable extra work over the same input sizes
- Method: typed benchmark work-count comparison
- Method version: macroonz-harness-bench@d4a9dc3ac4145a269b3ad8a5af56c896b13cbfee
- Method request: claim=benchmark work evidence distinguishes the planted-worse curve;damage=avoidable extra work over the same input sizes;bounds=three-input-work-curves
- Receipt: bench-work
- Coordinates: source=d4a9dc3ac4145a269b3ad8a5af56c896b13cbfee;host=windows-local;target=x86_64-pc-windows-msvc;toolchain=rustc-1.98.0;bounds=three-input-work-curves
- Standing: distinguished
- Activation: observed
- Sensitivity evidence: Measured counts 4 8 and 16 were distinguished from planted-worse counts 8 32 and 128 at input sizes 2 4 and 8.
- Counterexample, replay, and custody: receipt=bench-work;counterexample=planted-worse-work-curve;replay=exact-input-and-work-counts
- Shared-foundation warning: shared=harness-bench-owner-and-neutral-receiver;independence=not-assumed
- Cost evidence: unavailable
- Cost coordinates: none
- Disposition: current-reusable
- Ceiling: This is work evidence rather than a portable wall-time or throughput claim.

### `guarded-cost-control`

- Claim: guarded-transition economics distinguishes declared avoidable work
- Damage: duplicated compiler invocation or quadratic runtime scan
- Method: bench typed-work planted-worse comparison
- Method version: guarded-economics-driver@1aac20896d0444f2cc918498c7dfe3d967f3231f
- Method request: claim=guarded-transition economics distinguishes declared avoidable work;damage=duplicated compiler invocation or quadratic runtime scan;bounds=guarded-economics-declared-axes
- Receipt: guarded-economics
- Coordinates: source=1aac20896d0444f2cc918498c7dfe3d967f3231f;host=windows-local;target=x86_64-pc-windows-msvc;toolchain=rustc-1.98.0;bounds=guarded-economics-declared-axes
- Standing: distinguished
- Activation: observed
- Sensitivity evidence: Every declared planted-worse control was distinguished and an identical control refused before timing.
- Counterexample, replay, and custody: receipt=guarded-economics;counterexample=declared-planted-worse-controls;replay=exact-source-payload-and-readback
- Shared-foundation warning: shared=harness-bench-compiler-proc-fuzz-and-subject;independence=not-assumed
- Cost evidence: exact-historical
- Cost coordinates: source=1aac20896d0444f2cc918498c7dfe3d967f3231f;host=windows-local;target=x86_64-pc-windows-msvc;toolchain=rustc-1.98.0;bounds=guarded-economics-declared-axes
- Disposition: historical-only
- Ceiling: Exact within this historical source and host; no universal threshold runtime ranking or peak-memory claim.

### `cross-cost-mutation`

- Claim: projection-accounting benchmark detects collapsed cost distinction
- Damage: one-pass replacement of declared two-pass control
- Method: Muterprater compiled-suite pressure over bench claim
- Method version: cargo-mutants@27.0.0
- Method request: claim=projection-accounting benchmark detects collapsed cost distinction;damage=one-pass replacement of declared two-pass control;bounds=one-cost-claim-mutation
- Receipt: cross-economics
- Coordinates: source=2d910af1d4f14bb16035752e27dda4df502c19c5;host=windows-local;target=x86_64-pc-windows-msvc;toolchain=rustc-1.98.0;bounds=one-cost-claim-mutation
- Standing: distinguished
- Activation: unobservable-under-backend
- Sensitivity evidence: One tested mutation was caught when the N versus 2N distinction collapsed.
- Counterexample, replay, and custody: receipt=cross-economics;counterexample=two-pass-to-one-pass-mutation;replay=exact-cost-source-console-and-holder
- Shared-foundation warning: shared=harness-bench-projection-subject-and-external-suite;independence=not-assumed
- Cost evidence: exact-historical
- Cost coordinates: source=2d910af1d4f14bb16035752e27dda4df502c19c5;host=windows-local;target=x86_64-pc-windows-msvc;toolchain=rustc-1.98.0;bounds=one-cost-claim-mutation
- Disposition: historical-only
- Ceiling: Activation is unobservable and equivalence not assessed; exact historical coordinates only.

### `facade-build-cost`

- Claim: facade postures retain bounded build-cost observations
- Damage: no admitted damage method in the same run
- Method: path-adopter build observation
- Method version: adopter-cost-driver@9c5279a37e5d2923001e178e46fe5fc322eec9af
- Method request: claim=facade postures retain bounded build-cost observations;damage=no admitted damage method in the same run;bounds=three-postures-three-clean-three-warm
- Receipt: adopter-cost
- Coordinates: source=9c5279a37e5d2923001e178e46fe5fc322eec9af;host=windows-local;target=x86_64-pc-windows-msvc;toolchain=rustc-1.98.0;bounds=three-postures-three-clean-three-warm
- Standing: unavailable
- Activation: not-applicable
- Sensitivity evidence: This receipt measured three lawful postures but executed no damage control for method sensitivity.
- Counterexample, replay, and custody: receipt=adopter-cost;counterexample=none;replay=three-exact-facade-postures
- Shared-foundation warning: shared=cargo-build-graph-and-facade-packages;independence=not-established
- Cost evidence: not-comparable
- Cost coordinates: none
- Disposition: historical-only
- Ceiling: The cost observation cannot join a Wave I sensitivity row and is not portable.

### `long-schedule-baseline`

- Claim: long concurrency campaigns retain bounded passing observations
- Damage: no admitted damage control in the same campaign
- Method: interleave network and preemption long campaigns
- Method version: macroonz-harness-schedule@d4a9dc3ac4145a269b3ad8a5af56c896b13cbfee
- Method request: claim=long concurrency campaigns retain bounded passing observations;damage=no admitted damage control in the same campaign;bounds=369600-exhaustive-plus-4096-sampled
- Receipt: long-schedule
- Coordinates: source=d4a9dc3ac4145a269b3ad8a5af56c896b13cbfee;host=windows-local;target=x86_64-pc-windows-msvc;toolchain=rustc-1.98.0;bounds=369600-exhaustive-plus-4096-sampled
- Standing: unavailable
- Activation: not-applicable
- Sensitivity evidence: The campaigns passed their declared baselines but did not damage the subject to measure sensitivity.
- Counterexample, replay, and custody: receipt=long-schedule;counterexample=none-passing-baselines;replay=exact-seeds-bounds-and-transcripts
- Shared-foundation warning: shared=harness-interleave-network-and-preemption-owners;independence=not-assumed
- Cost evidence: not-comparable
- Cost coordinates: none
- Disposition: historical-only
- Ceiling: Passing cost and scale evidence alone cannot establish witness sensitivity.

### `repository-coverage-radar`

- Claim: repository coverage observes exercised source lines
- Damage: source line left unexecuted
- Method: rustc source-coverage census
- Method version: rustc-instrument-coverage@1.98.0+llvm-cov@22.1.8
- Method request: claim=repository coverage observes exercised source lines;damage=source line left unexecuted;bounds=stable-repository-coverage-census
- Receipt: repository-coverage
- Coordinates: source=fb1307bc5a2216a9ed77aea20646ffab75d6486d;host=windows-local;target=x86_64-pc-windows-msvc;toolchain=rustc-1.98.0;bounds=stable-repository-coverage-census
- Standing: inconclusive
- Activation: not-applicable
- Sensitivity evidence: Coverage is a radar for execution and does not by itself prove a behavioral claim distinguishes damage.
- Counterexample, replay, and custody: receipt=repository-coverage;counterexample=none;replay=exact-stable-coverage-census
- Shared-foundation warning: shared=same-repository-test-witnesses;independence=not-assumed
- Cost evidence: not-comparable
- Cost coordinates: none
- Disposition: historical-only
- Ceiling: Stable branch coverage and MC/DC were unavailable and no sensitivity inference is made from line coverage.

