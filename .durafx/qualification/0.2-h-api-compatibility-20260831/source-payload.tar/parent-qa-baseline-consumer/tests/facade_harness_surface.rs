//! Harness-enabled composition observed through the published baseline under a renamed dependency.

#![cfg(feature = "harness")]

bakery::macros::network! {
    harness = bakery::harness,
    module = facade_net,
    namespace = "facade",
    nodes = [client, server],
    link request = client to server,
    schedule quiet = [],
}

/// The baseline renamed facade dependency preserves the proc-macro and harness roads.
#[test]
fn renamed_facade_composes() -> Result<(), facade_net::Fault> {
    let topology = facade_net::topology()?;
    assert_eq!(topology.nodes().len(), 2usize);
    assert_eq!(topology.links().len(), 1usize);
    assert!(facade_net::quiet()?.disciplines().is_empty());
    Ok(())
}
