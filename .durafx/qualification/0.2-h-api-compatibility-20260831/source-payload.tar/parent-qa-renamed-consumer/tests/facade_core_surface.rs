//! Minimal facade composition observed through a renamed dependency.

/// The minimal facade preserves the compiler owner's public constructor path.
#[test]
fn renamed_minimal_facade_preserves_compiler_path() {
    let admitted = bakery::compiler::Bounded::<u8, 1>::new(vec![1u8]);
    assert!(admitted.is_ok());
}
