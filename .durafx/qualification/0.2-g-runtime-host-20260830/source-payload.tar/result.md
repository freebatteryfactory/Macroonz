# Wave G local Windows runtime and host-failure result

## Disposition

Disposition 1 applies at this bounded plane.
Existing public Macroonz owners compose the accepted local observation without a new product source seam, public API, feature, dependency, package, report vocabulary, process host, or tracked qualification architecture.
No first missing product seam was observed.

## Authority and source state

- Repository HEAD was `b44dbdd7a5982f55c360d906c31cea4f44b39e18`.
- The tracked worktree and index were clean before and after the pilot.
- The complete `AGENTS.md`, portable context, governing program sections, and every consumed public source home and external holder were read before the scratch source was authored.
- All disposable source, build output, profiles, and executable material remain beneath this exact scratch directory.
- No tracked repository file, `.durafx`, portable context, Git ref, or commit was edited.

## Tool and host identity

- `rustc 1.98.0 (88d9e12ae 2026-08-18)` at commit `88d9e12ae178fab0fb5cc050a94da85685d449ea`.
- LLVM was `22.1.8`.
- `cargo 1.98.0 (797e8a9bc 2026-08-05)` at commit `797e8a9bca276c1c9f9f738d2a20f484fa4eea9d`.
- The compiler host and explicit Cargo target were `x86_64-pc-windows-msvc`.
- The operating system reported Windows `10.0.26200`, presented by the host as Windows 11 Core, 64-bit.

## Commands and results

The scratch working directory for commands without another stated directory was this directory.

```text
cargo +1.98.0 generate-lockfile --offline
```

The command resolved and locked fifteen packages compatible with Rust 1.98.0 without network access.

```text
cargo +1.98.0 fmt --all
cargo +1.98.0 fmt --all -- --check
cargo +1.98.0 check --all-targets --locked --offline --target x86_64-pc-windows-msvc --jobs 1
cargo +1.98.0 clippy --all-targets --locked --offline --target x86_64-pc-windows-msvc --jobs 1 -- -D warnings
cargo +1.98.0 test --all-targets --locked --offline --target x86_64-pc-windows-msvc --jobs 1 -- --test-threads=1
```

Formatting, all-target compilation, the repository-equivalent warnings-denied Rust and complete `all` plus `pedantic` Clippy wall, and the external test passed.
The external test result was one passed, zero failed, zero ignored, zero measured, and zero filtered out.

```text
cargo +1.98.0 clippy --workspace --all-targets --all-features --locked --offline --target x86_64-pc-windows-msvc --jobs 1 -- -D warnings
```

From the repository root, the complete root workspace passed the declared lint wall.

```text
cargo +1.98.0 clippy --manifest-path macros/proc/tests/support/capture-observer/Cargo.toml --all-targets --locked --offline --target x86_64-pc-windows-msvc --target-dir target/qualification/0.2-wave-g-runtime-host-20260830/capture-observer-target --jobs 1 -- -D warnings
```

The separately isolated compiler-required proc-macro observer fixture also passed and placed its build output inside this scratch directory.

```text
git ls-files '*.rs'
git grep -n -w unsafe -- '*.rs'
tracked Rust source scan for `unsafe fn`, `unsafe trait`, `unsafe impl`, `unsafe extern`, and `unsafe {`
git grep -n -E '#\[(allow|expect)(\(|\])' -- '*.rs'
```

The denominator was 571 tracked Rust files.
The broad unsafe-token search found two oracle documentation examples and one token-generator keyword spelling, with zero unsafe-construct hits and zero lint-hatch hits.

```text
cargo +1.98.0 metadata --locked --offline --no-deps --format-version 1
cargo +1.98.0 tree --locked --offline -e normal
```

Metadata confirmed one isolated unpublished scratch package and one direct product dependency, `macroonz-harness = =0.1.0`, with default features disabled.
The normal dependency tree was the harness plus `arbitrary 1.4.2`, `blake3 1.8.6` and its transitive dependencies, and `syn 3.0.3` and its transitive dependencies.

```text
target/x86_64-pc-windows-msvc/debug/macroonz-wave-g-runtime-host.exe
target/x86_64-pc-windows-msvc/debug/macroonz-wave-g-runtime-host.exe
```

Both direct executions exited successfully and produced byte-identical 1,057-byte LF-normalized readings.
The exact normalized reading is `direct-output.txt` at SHA-256 `F018C1DEFBE330568E9BF38355B4491A5A0348C06AA2C2C583F922CEC5AA9ABD`.

## Observed claims

- Current Macroonz-owned tracked Rust source contains no unsafe construct under the complete lexical denominator, and the root workspace plus the separate proc-macro observer passed their stable Rust 1.98 warnings-denied lint walls.
- The existing public `interleave::explored` road counted and exhaustively explored an exact two-order logical schedule space.
- The hostile schedule retained `[1, 0]` at ordinal one as the declared withdrawal-before-deposit counterexample after two explored interleavings.
- A distinct lawful two-deposit control exhausted the same two-order space and concluded passed.
- The existing public stable-rustc fuzz-host road compiled a safe-Rust subject with `-C instrument-coverage`, induced `std::process::abort`, and retained Windows exit code `-1073740791` as `FuzzExecution::Crash`.
- The crash produced no admitted coverage observation and was refused from the successful coverage corpus as `CoverageAdmissionRefusal::Execution`.
- The existing runner/report join admitted the host result only as `InfrastructureFailed(BackendExecutionUnresolved)` and did not forge a subject verdict.
- The arithmetic/cardinality claim is cited from the accepted Wave F semantic receipt at commit `2828e7de9652db5de8ac5fd8a555428a4b059bed`, `.durafx/qualification/0.2-f-bounded-verification-20260830/`, receipt SHA-256 `3B3E0BAF9D194D8B2E78D00FABED18BC6F34BB1F0ADF303384BED3494FED49DE`.
- Wave F's joined local Windows closure is cited at commit `b44dbdd7a5982f55c360d906c31cea4f44b39e18` and is not relabeled as a fresh Wave G observation.

## Ceilings

- This is one current local Windows x86-64 observation at one exact stable Rust 1.98 toolchain and one explicit MSVC target.
- No physical-host, cross-host, Linux, macOS, Wasm, architecture-wide, hosted, package-delivery, or human-acceptance claim is made.
- Macroonz-owned source contains no FFI spelling and declares no native-library link in this road.
- Rustc and LLVM are native compiler machinery and were used.
- Dependency, standard-library, compiler, LLVM, operating-system, and adopter-code internals were not audited for FFI, native code, or unsafe implementation.
- Safe Macroonz-owned source and lint conformance are not relabeled as general memory-safety or undefined-behavior freedom.
- Logical schedule exploration is not thread execution, aliasing analysis, data-race detection, memory-model proof, or undefined-behavior detection.
- The process observation induced abort only.
- Timeout, stack exhaustion, resource causality, sandboxing, and complete descendant-process cleanup were not established by this pilot.
- The process was waited to completion by the caller-owned supervisor, but broader process-tree cleanup remains outside the observation.
- Nightly Miri, sanitizers, `cargo-careful`, and other postponed dynamic methods were not used or required.

## Sensors encountered

The first formatting pass refused a struct literal used without expression parentheses.
The first strict Clippy pass refused two boolean-bearing structs and three trivially-copy-by-reference callback arguments.
The scratch source was repaired by making the state explicit, removing an unnecessary retained boolean, and removing `Copy` rather than weakening the wall.
One initial test-tool poll returned before its final test line was delivered; a complete rerun and two independent direct executions all passed.

## Authored source hashes before this result

| Path | Bytes | SHA-256 |
| --- | ---: | --- |
| `Cargo.toml` | 1,295 | `CD956F634BCFA5C7BD735E985405A9F3F12F0711F336585123B8A9A74CD3B829` |
| `Cargo.lock` | 3,287 | `E1161E7FBC43EEA65FCF6A90BFCD5E4BC696604C68DD8E410B5FFD7EA30A9DEB` |
| `README.md` | 817 | `9A3699AAFC6ABB4717FE0AEFF6B6953847436CAF34C42FD671AF2768AD525510` |
| `rust-toolchain.toml` | 101 | `23CCFE7A3D1D73658C102BA716D14948476CB079724C4E20513CE994E350EFA7` |
| `src/main.rs` | 14,829 | `A0AD3E6F4F5F8C2271DB046FC41344CEEB1A9B015E0A74C5309E1FB294E7C42D` |
| `subjects/runtime_subject.rs` | 371 | `03ADC86A594B4D55257D59E2D828ED512A14A6EC2602947839170589AC42DB4D` |
| `tests/runtime_host.rs` | 1,097 | `C712263F37863452640482D5F83F18C4899BE5963AB10EDD1ADA47CB2496209E` |
