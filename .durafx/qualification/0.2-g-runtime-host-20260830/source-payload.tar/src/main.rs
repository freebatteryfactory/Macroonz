//! Scratch-only Wave G composition over existing Macroonz public roads.

use macroonz_harness::clock::MeasurementReading;
use macroonz_harness::descriptor::{
    Binding, CheckRef, ClaimRef, Classification, DerivedRevision, ExecutableAttachment,
    ExecutionSuite, Origin, PopulationRef, Provenance, RevisionBinding, Role, Row, SubjectRoute,
    Tag,
};
use macroonz_harness::fuzz::{
    CoverageAdmissionRefusal, CoverageBudgets, CoverageCampaign, CoverageCorpus, CoverageProfile,
    CoverageSourceRoot, FuzzExecution, InstrumentedTarget, RUSTC_COVERAGE_TOOLCHAIN,
    RustcProfileRequest, observe_rustc_profile, preflight_ready,
};
use macroonz_harness::generate::RootSeed;
use macroonz_harness::interleave::{
    ExplorationBound, ExplorationMode, ExplorationSite, ExplorationStanding, InterleavingSpace,
    Strand, StrandSet, concluded, explored,
};
use macroonz_harness::properties::{Holding, TemporalClaim, TemporalDemand, TransitionContract};
use macroonz_harness::report::{
    ByteBudget, CaseBudget, FindingCause, ForeignText, InfrastructureFailure, InfrastructureFault,
    InvocationProfile, RunAttempt, TimeBudget, TrialConclusion, TrialSite,
};
use macroonz_harness::runner::{Invocation, TrialBinding, record_one, trial_identity};
use std::fmt;
use std::io::Write;
use std::path::{Path, PathBuf};
use std::process::{Child, Command};

const OWNER: &str = "wave-g-runtime-host";
const ORDERING_CAUSE: FindingCause = FindingCause::named(OWNER, "withdrawal-before-deposit");

#[derive(Debug, Clone, PartialEq, Eq)]
enum Move {
    Deposit(u8),
    Withdraw(u8),
}

#[derive(Debug, Clone, PartialEq, Eq)]
struct Account {
    balance: i16,
    standing: AccountStanding,
}

#[derive(Debug, Clone, PartialEq, Eq)]
enum AccountStanding {
    Solvent,
    Overdrawn,
}

struct QualificationFailure(String);

impl fmt::Debug for QualificationFailure {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter
            .debug_tuple("QualificationFailure")
            .field(&self.0)
            .finish()
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
struct ScheduleReading {
    space: u128,
    explored: u64,
    choices: Vec<u8>,
    lawful_explored: u64,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct HostReading {
    execution: FuzzExecution,
    infrastructure: InfrastructureFault,
}

fn main() -> Result<(), QualificationFailure> {
    let schedule = schedule_reading()?;
    let host = host_reading()?;
    let output = rendered(&schedule, host);
    std::io::stdout()
        .lock()
        .write_all(output.as_bytes())
        .map_err(failed)?;
    Ok(())
}

fn opening() -> Account {
    Account {
        balance: 0i16,
        standing: AccountStanding::Solvent,
    }
}

fn applied(state: &Account, command: &Move) -> Account {
    let balance = match command {
        Move::Deposit(amount) => state.balance.saturating_add(i16::from(*amount)),
        Move::Withdraw(amount) => state.balance.saturating_sub(i16::from(*amount)),
    };
    Account {
        balance,
        standing: if state.standing == AccountStanding::Overdrawn || balance < 0i16 {
            AccountStanding::Overdrawn
        } else {
            AccountStanding::Solvent
        },
    }
}

fn overdrawn(state: &Account) -> Holding {
    if state.standing == AccountStanding::Overdrawn {
        Holding::Holds
    } else {
        Holding::Fails
    }
}

fn contract() -> Result<TransitionContract<Account, Move>, QualificationFailure> {
    TransitionContract::declared(
        opening,
        applied,
        vec![TemporalClaim::declared(
            ORDERING_CAUSE,
            TemporalDemand::Never(overdrawn),
        )],
    )
    .map_err(failed)
}

fn schedule_reading() -> Result<ScheduleReading, QualificationFailure> {
    let depositor =
        Strand::declared(name("depositor")?, vec![Move::Deposit(5u8)]).map_err(failed)?;
    let withdrawer =
        Strand::declared(name("withdrawer")?, vec![Move::Withdraw(5u8)]).map_err(failed)?;
    let hostile = StrandSet::declared(vec![depositor, withdrawer]).map_err(failed)?;
    let bound = ExplorationBound::declared(2u32, 1u32).map_err(failed)?;
    let reading = explored(
        &hostile,
        &contract()?,
        bound,
        population("hostile-orders")?,
        RootSeed::declared(7u64),
    )
    .map_err(failed)?;
    let ExplorationStanding::CounterexampleFound(counterexample) = reading.standing() else {
        return Err(QualificationFailure(
            "ordering defect was not retained".to_owned(),
        ));
    };
    if reading.space() != InterleavingSpace::Counted(2u128)
        || reading.mode() != ExplorationMode::Exhaustive
        || reading.explored() != 2u64
        || counterexample.site() != (ExplorationSite::Enumerated { ordinal: 1u64 })
        || counterexample.interleaving().choices() != [1u8, 0u8]
        || counterexample.finding().cause() != ORDERING_CAUSE
        || !matches!(concluded(&reading), TrialConclusion::Refused(_))
    {
        return Err(QualificationFailure(
            "ordering evidence disagreed".to_owned(),
        ));
    }
    let steady = Strand::declared(name("steady")?, vec![Move::Deposit(2u8)]).map_err(failed)?;
    let eager = Strand::declared(name("eager")?, vec![Move::Deposit(3u8)]).map_err(failed)?;
    let lawful = StrandSet::declared(vec![steady, eager]).map_err(failed)?;
    let control = explored(
        &lawful,
        &contract()?,
        bound,
        population("lawful-orders")?,
        RootSeed::declared(7u64),
    )
    .map_err(failed)?;
    if control.space() != InterleavingSpace::Counted(2u128)
        || control.mode() != ExplorationMode::Exhaustive
        || control.explored() != 2u64
        || control.standing() != &ExplorationStanding::SpaceExhaustedAllHold
        || concluded(&control) != TrialConclusion::Passed
    {
        return Err(QualificationFailure(
            "lawful schedule control disagreed".to_owned(),
        ));
    }
    Ok(ScheduleReading {
        space: 2u128,
        explored: reading.explored(),
        choices: counterexample.interleaving().choices().to_vec(),
        lawful_explored: control.explored(),
    })
}

fn host_reading() -> Result<HostReading, QualificationFailure> {
    let manifest = PathBuf::from(env!("CARGO_MANIFEST_DIR"));
    let run = manifest.join("run");
    std::fs::create_dir_all(&run).map_err(failed)?;
    let source = manifest.join("subjects").join("runtime_subject.rs");
    let executable = run.join(format!("runtime-subject{}", std::env::consts::EXE_SUFFIX));
    let rustc = rustc_path()?;
    compile_subject(&rustc, &source, &executable)?;
    let campaign = coverage_campaign()?;
    let target = InstrumentedTarget::declared(executable, Vec::new()).map_err(failed)?;
    let root =
        CoverageSourceRoot::declared(name("runtime-source")?, manifest.clone()).map_err(failed)?;
    let request = RustcProfileRequest::declared(rustc, target, root, run.join("cases"), campaign)
        .map_err(failed)?;
    let ready = preflight_ready(request).map_err(failed)?;
    let mut corpus = CoverageCorpus::opening(&ready);
    let result =
        observe_rustc_profile(&ready, &mut corpus, &[0xff], wait_for_crash).map_err(failed)?;
    let execution = result.execution();
    if !matches!(execution, FuzzExecution::Crash(_)) || !result.observation().points().is_empty() {
        return Err(QualificationFailure(
            "abort was not retained as a crash".to_owned(),
        ));
    }
    let coverage_admission_refused = matches!(
        corpus.admit(result),
        Err(CoverageAdmissionRefusal::Execution(FuzzExecution::Crash(_)))
    );
    if !coverage_admission_refused {
        return Err(QualificationFailure(
            "crash entered successful coverage".to_owned(),
        ));
    }
    let binding = host_binding()?;
    let trial = trial_identity(binding.row());
    let infrastructure = InfrastructureFault::BackendExecutionUnresolved;
    let foreign = ForeignText::admitted(b"stable-rustc host retained FuzzExecution::Crash");
    let record = macroonz_harness::report::HostTrialRecord::recorded(
        trial,
        RunAttempt::InfrastructureFailed(InfrastructureFailure::recorded(
            infrastructure,
            Some(foreign),
        )),
        MeasurementReading::Unavailable,
    );
    let invocation = Invocation::declared(
        InvocationProfile::declared(
            CaseBudget::declared(1u32),
            ByteBudget::declared(1u64),
            TimeBudget::declared(5_000_000_000u64),
        ),
        ready.standing().target().clone(),
        TrialSite::located(module_path!(), file!(), line!(), "wave-g-runtime-host"),
        macroonz_harness::clock::HarnessClock::unavailable(),
    );
    let report = record_one(&binding, &invocation, record).map_err(failed)?;
    let RunAttempt::InfrastructureFailed(failure) = report.attempt() else {
        return Err(QualificationFailure(
            "host record forged a subject verdict".to_owned(),
        ));
    };
    if failure.fault() != infrastructure {
        return Err(QualificationFailure(
            "host infrastructure fault moved".to_owned(),
        ));
    }
    Ok(HostReading {
        execution,
        infrastructure,
    })
}

fn host_binding() -> Result<TrialBinding, QualificationFailure> {
    let subject = SubjectRoute::named(OWNER, "abort-subject").map_err(failed)?;
    let check = CheckRef::named(OWNER, "process-boundary").map_err(failed)?;
    let row = Row::declared(
        ClaimRef::named(OWNER, "abort-remains-infrastructure").map_err(failed)?,
        ExecutionSuite::named(OWNER, "stable-runtime").map_err(failed)?,
        Classification::authored(
            vec![Role::named(OWNER, "process-host").map_err(failed)?],
            vec![Tag::named(OWNER, "abort").map_err(failed)?],
        )
        .map_err(failed)?,
        subject,
        check,
        population("runtime-host")?,
        Origin::HandWritten,
    )
    .map_err(failed)?;
    Binding::bound(
        row,
        ExecutableAttachment::attached(
            subject,
            check,
            RevisionBinding::derived(DerivedRevision::from_material(include_bytes!(
                "../subjects/runtime_subject.rs"
            ))),
            RevisionBinding::derived(DerivedRevision::from_material(b"wave-g-host-v1")),
            placeholder,
        ),
        Provenance::Unproduced,
    )
    .map_err(failed)
}

fn placeholder(_invocation: &Invocation) -> TrialConclusion {
    TrialConclusion::Passed
}

fn coverage_campaign() -> Result<CoverageCampaign, QualificationFailure> {
    let budgets = CoverageBudgets::declared(
        CaseBudget::declared(1u32),
        ByteBudget::declared(1u64),
        1_048_576u64,
        65_536u64,
        CaseBudget::declared(1u32),
        ByteBudget::declared(1u64),
    )
    .map_err(failed)?;
    Ok(CoverageCampaign::declared(
        population("runtime-candidates")?,
        RevisionBinding::derived(DerivedRevision::from_material(include_bytes!(
            "../subjects/runtime_subject.rs"
        ))),
        CoverageProfile::declared(name("stable-rustc-source-coverage")?, 1u32),
        budgets,
    ))
}

fn compile_subject(
    rustc: &Path,
    source: &Path,
    executable: &Path,
) -> Result<(), QualificationFailure> {
    let status = Command::new(rustc)
        .args([
            "--edition=2024",
            "-C",
            "instrument-coverage",
            "-C",
            "opt-level=0",
        ])
        .arg(source)
        .arg("-o")
        .arg(executable)
        .status()
        .map_err(failed)?;
    if status.success() {
        Ok(())
    } else {
        Err(QualificationFailure(format!(
            "instrumented subject compilation failed with {status}"
        )))
    }
}

fn rustc_path() -> Result<PathBuf, QualificationFailure> {
    let output = Command::new("rustup")
        .args(["which", "--toolchain", RUSTC_COVERAGE_TOOLCHAIN, "rustc"])
        .output()
        .map_err(failed)?;
    if !output.status.success() {
        return Err(QualificationFailure(format!(
            "rustup which failed with {}",
            output.status
        )));
    }
    let spelling = String::from_utf8(output.stdout).map_err(failed)?;
    let path = PathBuf::from(spelling.trim());
    if path.is_absolute() {
        Ok(path)
    } else {
        Err(QualificationFailure(
            "rustup returned a relative rustc path".to_owned(),
        ))
    }
}

fn wait_for_crash(child: &mut Child) -> Result<FuzzExecution, String> {
    let status = child.wait().map_err(|error| error.to_string())?;
    if status.success() {
        Err("abort control exited successfully".to_owned())
    } else {
        Ok(FuzzExecution::Crash(status.code()))
    }
}

fn name(
    stem: &'static str,
) -> Result<macroonz_harness::descriptor::NamespacedName, QualificationFailure> {
    macroonz_harness::descriptor::NamespacedName::named(OWNER, stem).map_err(failed)
}

fn population(stem: &'static str) -> Result<PopulationRef, QualificationFailure> {
    PopulationRef::named(OWNER, stem).map_err(failed)
}

fn rendered(schedule: &ScheduleReading, host: HostReading) -> String {
    let crash_code = match host.execution {
        FuzzExecution::Crash(code) => format!("{code:?}"),
        FuzzExecution::Success
        | FuzzExecution::NonzeroExit(_)
        | FuzzExecution::Timeout
        | FuzzExecution::ResourceExhaustion => "not-a-crash".to_owned(),
    };
    format!(
        "toolchain=stable-rust-1.98.0\nhost=windows-x86_64-current-local\ntarget=x86_64-pc-windows-msvc\nsource-posture=macroonz-owned-safe-rust-lint-wall\nschedule-method=interleave-exhaustive\nschedule-space={}\nschedule-explored={}\nschedule-counterexample-choices={:?}\nschedule-lawful-control-explored={}\nprocess-method=stable-rustc-fuzz-host\nprocess-execution=crash\nprocess-exit-code={crash_code}\nprocess-report-standing={:?}\ncrash-refused-from-coverage-admission=true\nwave-f-arithmetic-boundary=cited-2828e7de-u8-256-exhaustive-within-declared-domain\nwave-f-joined-closure=cited-b44dbdd7-local-windows\nnightly=not-required\nmacroonz-owned-ffi=none\nmacroonz-owned-native-library-link=none\nrustc-llvm-native-toolchain=used\ndependency-ffi-native-internals=not-audited\nprocess-tree-cleanup=not-established\nstack-exhaustion=not-induced\nresource-causality=not-established\nphysical-host-generality=not-claimed\ncross-host=not-established\nundefined-behavior-freedom=not-claimed\nmemory-safety=not-claimed\ndependency-internal-unsafe-freedom=not-claimed\n",
        schedule.space,
        schedule.explored,
        schedule.choices,
        schedule.lawful_explored,
        host.infrastructure,
    )
}

fn failed(error: impl fmt::Debug) -> QualificationFailure {
    QualificationFailure(format!("{error:?}"))
}
