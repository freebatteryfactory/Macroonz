# Wave G stable runtime and host-failure witness

This disposable package composes the existing public interleave, stable-rustc fuzz-host, runner, and report roads without adding a Macroonz product owner.

The logical schedule claim exhausts one two-order space and retains the planted ordering defect as an interleave counterexample.
The host claim compiles one safe-Rust instrumented subject with stable Rust 1.98, observes its process abort as `FuzzExecution::Crash`, and admits only an unresolved infrastructure attempt through the existing host-record join.

The witness does not claim memory safety, undefined-behavior freedom, process-tree cleanup, stack-exhaustion coverage, resource causality, sandboxing, or safety of dependencies, the standard library, rustc, LLVM, the operating system, or adopter code.

