#![forbid(unsafe_code)]

use std::io::{self, Read};

fn main() -> io::Result<()> {
    let mut input = Vec::new();
    io::stdin().read_to_end(&mut input)?;
    match input.as_slice() {
        [0xff] => std::process::abort(),
        [0xfe] => loop {
            std::thread::park();
        },
        _ => {}
    }
    std::hint::black_box(input.len());
    Ok(())
}

