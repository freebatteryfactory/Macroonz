//! External claims over the complete scratch executable.

use std::process::Command;

fn output() -> Result<std::process::Output, std::io::Error> {
    Command::new(env!("CARGO_BIN_EXE_macroonz-wave-g-runtime-host")).output()
}

#[test]
fn existing_schedule_and_host_roads_retain_distinct_findings()
-> Result<(), Box<dyn std::error::Error>> {
    let first = output()?;
    assert!(first.status.success());
    let second = output()?;
    assert!(second.status.success());
    assert_eq!(first.stdout, second.stdout);
    let text = String::from_utf8(first.stdout)?;
    for claim in [
        "schedule-space=2",
        "schedule-explored=2",
        "schedule-counterexample-choices=[1, 0]",
        "schedule-lawful-control-explored=2",
        "process-execution=crash",
        "process-report-standing=BackendExecutionUnresolved",
        "crash-refused-from-coverage-admission=true",
        "nightly=not-required",
        "undefined-behavior-freedom=not-claimed",
        "memory-safety=not-claimed",
    ] {
        assert!(text.lines().any(|line| line == claim));
    }
    Ok(())
}
