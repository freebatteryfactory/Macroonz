# Wave J guarded-transition economics result

## Plane and verdict

This scratch lot establishes the current-source family-1 economics observation for the adopted guarded-transition subject on one local Windows x64 host.
It reuses the accepted guarded-transition economics observer and cost vocabulary rather than creating a second schema.
It consumes only the accepted adopted source and the exact Wave H package candidates at repository revision `73ffa61b8555290deebee2d463f207ba10651036`.
No live-worktree source supplied a product package fallback.
The complete requested local denominator produced observations or an explicit unavailable or incomparable disposition.
No product source, public API, feature, dependency, package, facade edge, receipt, plan, context, Git ref, registry state, or hosted state changed.
This result is not Wave J acceptance, a cross-host claim, a universal threshold, or a ranking.

## Authority

The accepted historical economics payload has SHA-256 `4001B4BC1364AF9B6C517CFDCCE09362B87AAACD4268AA35CBB1F5EAE2D52E67`.
The accepted structural-adoption payload has SHA-256 `0682911A9A6EB947248764DA6608C8C4ECD9C3B58A818ADA3FC160CACB340AE1`.
The Wave H package-candidate payload has SHA-256 `3B073B916F58F601537983B3C325800C52C499E8C638D90FE167352E41480450`.
The adopted engine has SHA-256 `903AC855D941E2EBC3DF447BE8F55A5DA2AE94581C0592301E3EB327ED3A7D46`.
The adopted subject library has SHA-256 `6F1DB5F27F948209721AF7B07224E0C05D6ED3ABFF49404E2E114E6683E4AE96`.
The scratch economics adapter changes only historical raw-collection field reads to the adopted informed roster and assignment readers and has SHA-256 `E0D3505C1842B634D4F92818C69CD33EC1C4135131BD317BC06F8F0E02071E14`.

Every package archive carries `.cargo_vcs_info.json` revision `73ffa61b8555290deebee2d463f207ba10651036`.

| Package archive | Bytes | SHA-256 |
| --- | ---: | --- |
| `macroonz-0.1.0.crate` | 128,357 | `B3E5BDF0490E11A580961A6C5438ABB27D3B9A1305E9536A95F4F6284E5A5B6D` |
| `macroonz-compiler-0.1.0.crate` | 408,178 | `5C4D7A7BC70E19B547ACD1857D38CE8646A93B9EF3BAFBAAF57CD9D0F114D070` |
| `macroonz-harness-0.1.0.crate` | 460,813 | `6CB879B11168691CA44E74BD590790060D039040A2B2CD08BEFAFC637BC0157B` |
| `macroonz-macros-0.1.0.crate` | 20,824 | `4731975F381C8339B4B8343F7DC2EDC0B1A708244B185F4BED4FECC09B2204AF` |

The four archives total 1,018,172 bytes.

## Toolchain, host, and execution posture

All retained Cargo work used stable rustc `1.98.0 (88d9e12ae 2026-08-18)`, Cargo `1.98.0 (797e8a9bc 2026-08-05)`, target `x86_64-pc-windows-msvc`, locked and offline dependency resolution, and one Cargo job.
The matching coverage tools were `llvm-profdata` and `llvm-cov` `22.1.8-rust-1.98.0-stable` from that Rust toolchain.
The host was Windows 11 Home `10.0.26200` build `26200` on an Intel Core i7-8700 with 12 logical processors and 34,227,007,488 visible memory bytes.
The host was an ordinary interactive machine without exclusive contention, power-state control, antivirus isolation, thermal isolation, or a dedicated benchmark runner.
The locally available Cargo registry cache was prepared before the retained locked and offline commands.
Cold means a fresh Cargo target directory with locally cached dependencies, not a cold machine or cold network.
Cargo compilation used the ordinary unoptimized test or development profile with debug information.
Runtime readings used the exact Cargo `test`-profile subject binaries produced by the typed economics preflight for the stable toolchain's implicit `x86_64-pc-windows-msvc` host target.
Coverage compilation used direct rustc with `-C instrument-coverage`, `-C codegen-units=1`, and `-C opt-level=0`.

## Reconciliation and correctness preflight

The accepted historical economics workspace compiled only after its field reads were reconciled to the adopted `KeyedRoster` and `KeyedRosterAssignment` readers.
That scratch-only adapter preserved every metric and changed no subject semantics.
The complete scratch workspace passed stable Rust 1.98 locked and offline all-target checking before measurement.
The typed economics lane passed both existing claims in 57,394 milliseconds from a prepared scratch target.
The semantic journey passed its one existing claim in 113,924 milliseconds.
The exact-source economics readback ran twice and produced byte-identical 1,191-byte streams at SHA-256 `F71DDB05B9729519F261E3CCE3E085F0328B6A24F681EEE9CCCA2E4E16C689FB`.
The existing planted-worse protocol remained intact: duplicated compiler work, duplicated callable compiler invocations, and avoidable quadratic runtime work are distinguished from the lawful road, while an identical compiler control is refused before timing.
No new control or cost verdict was invented.

## Callable compiler work and generated output

The compiler axis is declaration size 2, 4, and 8, and the callable invocation axis is 1, 2, 4, and 8 repeated calls.
The generated and handwritten runtime axes are 2, 4, and 8 executions.
The exact engine keeps a fixed six-projection roster.

| Declaration size | Source bytes | Captured trees | Depth | Vocabulary | Transitions | Policies | Associations | Planned units | Generated bytes | Canonical bytes | Delivered bytes |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 2 | 317 | 82 | 3 | 12 | 1 | 2 | 1 | 6 | 6,428 | 412 | 6,428 |
| 4 | 495 | 166 | 3 | 20 | 3 | 6 | 3 | 6 | 10,232 | 770 | 10,232 |
| 8 | 851 | 334 | 3 | 36 | 7 | 14 | 7 | 6 | 17,840 | 1,486 | 17,840 |

Every typed row retained six rendered units, nine explanation seats, and six disposition seats.
Direct and refactored render styles retained equal typed metrics at declaration size eight.
The adopted baseline retained 707 source bytes, 117 captured trees, depth three, 15 vocabulary members, two transitions, three policies, two associations, six planned and rendered units, 8,026 generated and delivered bytes, 669 canonical bytes, nine explanation seats, and six disposition seats.
These are typed work and byte observations, not elapsed-time complexity claims.

### Typed proc-style invocation formula

The retained formula is `six planned projections per proc-style invocation`.
Each measured invocation performs the exact adopted baseline compiler work, whose generated and delivered payload is 8,026 bytes.
The planted control duplicates every invocation and therefore doubles every reported count without changing the input coordinate.

| Input coordinate | Measured invocations | Measured planned/rendered units | Measured generated/delivered bytes | Planted invocations | Planted planned/rendered units | Planted generated/delivered bytes |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 1 | 1 | 6 | 8,026 | 2 | 12 | 16,052 |
| 2 | 2 | 12 | 16,052 | 4 | 24 | 32,104 |
| 4 | 4 | 24 | 32,104 | 8 | 48 | 64,208 |
| 8 | 8 | 48 | 64,208 | 16 | 96 | 128,416 |

### Typed runtime formula

The retained formula is `two declared event steps per subject execution`.
Generated and handwritten roads reported the same measured curve and the same planted-control curve.
The planted control preserves the two declared event steps and adds one complete input-size-squared redundant comparison scan.

| Input coordinate | Measured executions | Measured event steps | Measured redundant comparisons | Measured declared work | Planted executions | Planted event steps | Planted redundant comparisons | Planted declared work |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 2 | 2 | 4 | 0 | 4 | 2 | 4 | 4 | 8 |
| 4 | 4 | 8 | 0 | 8 | 4 | 8 | 16 | 24 |
| 8 | 8 | 16 | 0 | 16 | 8 | 16 | 64 | 80 |

The green typed economics lane independently required these exact formulas and distinguished every planted control.

## Actual procedural crossing and carrier posture

Each of three samples began from a fresh target.
The carrier-defined row checks the proc-macro package without a consuming declaration.
The carrier-invoked row checks the adopted subject and therefore crosses the real proc-macro boundary.

| Posture | Samples in milliseconds | Median | Dispersion | Median target bytes |
| --- | --- | ---: | ---: | ---: |
| Carrier defined but not invoked | 23,355; 22,504; 21,996 | 22,504 | 1,359 | 173,179,734 |
| Carrier invoked by adopted subject | 19,608; 20,158; 19,053 | 19,608 | 1,105 | 343,887,701 |
| Invoked posture added target bytes | 170,707,973; 170,707,967; 170,707,965 | 170,707,967 | 8 | 170,707,967 |

The interactive carrier timing is explicitly non-comparative because the invoked median was lower than the carrier-defined median under uncontrolled contention.
No timing winner or procedural-cost ordering follows from those wall readings.
The distinguished typed posture is target growth: invoking the adopted subject added a median 170,707,967 bytes over the immediately corresponding carrier floor.

## Subject build postures

Every retained build names exactly the generated, handwritten, and refactored subject binaries.
Every cold sample used a fresh target with locally available locked dependencies.
Every warm no-op immediately repeated its corresponding cold build.
Every valid incremental sample began from a fresh cold baseline and explicitly moved the changed source's modification time before invoking Cargo.

| Posture | Samples in milliseconds | Median | Dispersion | Median target bytes after |
| --- | --- | ---: | ---: | ---: |
| Cold target | 53,403; 52,544; 52,266 | 52,544 | 1,137 | 688,558,866 |
| Warm no-op | 190; 156; 155 | 156 | 35 | 688,558,866 |
| Incremental declaration change | 4,816; 4,385; 4,339 | 4,385 | 477 | 728,392,935 |
| Incremental unrelated doc edit | 4,842; 4,748; 4,951 | 4,842 | 203 | 727,507,470 |

The declaration variant adds exactly one lawful `Basic` to `FinishOp` edge and has SHA-256 `7F466F81148369827BB4E73F5BC21F116BEE391B87BF5A32B9CA0A819A5718A1`.
The unrelated variant changes one doc sentence and has SHA-256 `663B7EEAED3E3A3FDF36808F44CBD7410230331B0EF83741F7FDB2391F294ED6`.
The baseline was restored between semantic variants and has SHA-256 `6F1DB5F27F948209721AF7B07224E0C05D6ED3ABFF49404E2E114E6683E4AE96`.
The declaration and unrelated rows are separate typed edit postures, not evidence that one change class is universally cheaper.

The first incremental attempt copied changed bytes while preserving the source modification time.
Cargo correctly treated those copies as no-op controls at 138 to 171 milliseconds.
Those rows are excluded from incremental-cost interpretation.
The explicit modification-time movement is the retained correction.

## Generated versus handwritten runtime

The generated, handwritten, and refactored binaries each received one direct correctness preflight, five process warmups, and three samples of 100 fresh child-process executions.
Every execution exited successfully, every road wrote no standard error, and all three roads produced the same 129-byte output.
The binaries were created under `work-target-198/debug` between 05:36:45.229 and 05:36:46.347 UTC, before the observer emitted the green typed-bench logs at 05:36:46.958 UTC.
Their Cargo fingerprints carry `compile_kind: 0`, default package features, and the exact package dependency graph, while the target's `.rustc_info.json` names stable rustc 1.98.0 commit `88d9e12ae178fab0fb5cc050a94da85685d449ea` and host `x86_64-pc-windows-msvc`.

| Road | Binary bytes | Samples in milliseconds | Median | Dispersion |
| --- | ---: | --- | ---: | ---: |
| Generated | 179,200 | 1,262; 1,375; 1,259 | 1,262 | 116 |
| Handwritten | 175,616 | 1,350; 1,501; 1,435 | 1,435 | 151 |
| Refactored generated | 179,200 | 1,914; 2,126; 2,506 | 2,126 | 592 |

The generated binary has SHA-256 `02F7C83C4F56CEE648D9E6F174A52CC6AC8B49B2DE1EA9E23AA0C4395013DB58`.
The handwritten binary has SHA-256 `C9374918E8E2D8532D35CD0D7DDE474C73CDDF8BDE77643271D54FFC85F451FB`.
The refactored generated binary has SHA-256 `07FA81628118A5A29FFB25E74F9D5A6A28C48E66060CF2424E29AE95F4DD5442`.
The generated binary was 3,584 bytes larger than the handwritten binary on this exact target and profile.
The interactive wall distributions and visible contention earn no runtime speed ranking or winner.

## Stable rustc source coverage

The coverage source has SHA-256 `57281D8D269391AF515F476B5960A8AFB5F2A0E015FFF77BFE944C503EE0DA32`.
Each of three samples used a fresh stage directory and the matching stable toolchain.
The stages are kept separate so compiler work, target execution, profile merging, LCOV export, informed readback, cleanup, and repeated parsing are not blended into one number.

| Stage | Samples in milliseconds | Median | Dispersion | Typed output |
| --- | --- | ---: | ---: | --- |
| Instrumented compile | 228; 234; 219 | 228 | 15 | 1,718,272 target bytes |
| Instrumented run | 102; 72; 63 | 72 | 39 | 616-byte raw profile |
| Profile merge | 21; 21; 23 | 21 | 2 | 960-byte merged profile |
| LCOV export | 19; 19; 19 | 19 | 0 | 655-byte raw LCOV |
| Current-harness readback | 82; 16; 17 | 17 | 66 | 541-byte normalized LCOV and 13 points |
| Guarded exact cleanup | 23; 130; 17 | 23 | 113 | 176,221 bytes to zero |
| 10,000 current-harness parses | 268; 273; 267; 216; 237 | 267 | 57 | equal informed result each iteration |

The raw LCOV embeds the absolute scratch source path and therefore remains disposable.
Normalizing only that path produced a 541-byte LCOV at SHA-256 `29E867FF719C581459F1DC5E972D47440F79D999E628425A61476D7FADF83771` in all three samples.
The exact current candidate harness read that normalized LCOV into the same 13 stable source points in all three samples.
The three 2,377-byte readbacks are byte-identical at SHA-256 `B724A5140579047B05FA0FD8A1C30749C7EEB6BEFDB30371D176E2D20030FBA1`.
The point lines are 5, 6, 7, 8, 9, 10, 12, 13, 14, 19, 21, 22, and 23 of the retained subject.
The coverage unit is stable source regions and points.
This is not edge coverage, explicit branch coverage, branch throughput, or a fuzz-execution throughput claim.
The parse binary embeds the exact normalized LCOV at compile time and owns the fixed 10,000-iteration denominator, so every retained parse timing is an argument-free invocation.

The cleanup helper admitted only `coverage-subject.exe`, `coverage.profraw`, `coverage.profdata`, `coverage.lcov`, and the exact `.wave-j-coverage-cleanup` authority marker in its isolated directory.
The `coverage.lcov` seat carried the exact normalized LCOV bytes.
All three cleanup samples reduced that exact roster to zero residual bytes.

## Current-source mutation sensitivity

No mutation campaign was rerun merely to attach cost.
The accepted current-source mutation receipt is `.durafx/qualification/0.2-b-structural-current-mutation-20260830/receipt.md` at SHA-256 `EF585305925ACF1C9D141E51B690F29009A89AB66BC9FA2739865A979D8797E9`.
Its adopted-engine selector used this exact engine hash and accounted for 57 selected mutations as 37 caught, 20 compiler-unviable, zero missed, and zero timed out.
Its structural-battery pre-cure selector accounted for 86 selected mutations as 24 caught, 48 compiler-unviable, 14 reported candidates, and zero timed out.
Thirteen candidates were real public diagnostic evidence gaps and received external witnesses, while one alignment mutation was equivalent under the informed construction chain.
The post-cure complete 17-member display selector accounted for 15 caught, two compiler-unviable, zero missed, and zero timed out.
Those accepted rows provide exact current-source semantic sensitivity where the source coordinates match.
They do not create a cost-to-sensitivity ranking because the mutation campaign and this economics lot use different observers and execution coordinates.

## Unavailable and incomparable rows

- Carrier-defined versus carrier-invoked wall timing is incomparable under the interactive contention posture, so target growth is retained and no winner is named.
- Generated, handwritten, and refactored runtime wall timing earns no speed ranking on this interactive host.
- The fixed six-projection engine cannot establish projection-count scaling.
- The guarded-transition subject has no independent declaration-shape axis, so declaration-shape scaling remains owned by the accepted shape subject.
- No peak-memory observer was established, so no memory claim is made.
- Stable source instrumentation exposed source regions and line points but no branch or edge denominator, so no branch or edge claim is made.
- No Linux, macOS, Arm64, hosted, cold-machine, or cold-network observation was attempted by this family lot.
- No universal threshold or cross-family rank is inferred from the local samples.

## Excluded setup and refusals

The first typed-bench attempt paired the exact Cargo 1.98 binary with a Rust 1.97.1 compiler inherited from `PATH` and refused with `E0514` because dependency metadata was incompatible.
That command is excluded from every cost row.
The retained correction explicitly bound `RUSTC` and `RUSTDOC` to stable 1.98.0 and used a fresh target.

The first incremental attempt preserved source modification times and therefore measured Cargo no-op behavior instead of incremental compilation.
Those rows remain recorded as excluded setup controls.
The retained correction advanced the exact changed source's modification time before every declaration, restore, and unrelated-edit command.

Two `cargo clean` attempts over pre-existing task targets refused because the directories lacked a valid Cargo `CACHEDIR.TAG`.
No broad delete or tag bypass followed.
Every per-sample Cargo target created by this lot was cleaned through Cargo after its retained observation, and the complete lot scratch remains intact for parent QA.

The first broad scratch Clippy pass refused the temporary coverage readback because a workspace binary accepted file paths through command-line arguments while the inherited product lint wall forbids ambient process arguments.
The scratch driver was repaired to read and write fixed declared files inside its measurement home.
It was rebuilt under stable Rust 1.98, all three readback samples were rerun, and the normalized LCOV plus 13-point output remained byte-identical to the original observation.
The three original CLI-path rows remain unchanged in `observations/commands.tsv` and are excluded from the current-source summary.
The three fixed-source rows remain unchanged in `observations/commands-readback-fixed.tsv`.
A safe-Rust reconciler validates those exact streams and emits `observations/retained-commands.tsv`, replacing only the three old rows and relabeling the fixed rows to the accepted `coverage-readback` method identity.

## Final scratch verification

- All five standalone safe-Rust helpers compiled with stable Rust 1.98, `unsafe_code` forbidden, and warnings denied.
- The complete scratch workspace passed `cargo +1.98.0 fmt --all -- --check`.
- The complete scratch workspace passed stable Rust 1.98 locked and offline checking for the Windows target with all workspace targets and one Cargo job.
- The complete scratch workspace passed stable Rust 1.98 locked and offline Clippy for the Windows target with all workspace targets, one Cargo job, and warnings denied.
- The deterministic summary was generated from the reconciled retained-command stream and reproduced byte for byte at SHA-256 `2736DEF6F6BF02176427CEB5EE6AF26083B3A52C28ACFA3B76329734B8C6D86B`.
- The two economics readbacks were byte-identical.
- The three current-harness coverage readbacks were byte-identical.
- The authored result, commands, machine summaries, retained readbacks, and authored source carried zero personal-identity or absolute-host-path matches.
- The authored source carried zero unsafe blocks, unsafe functions, foreign blocks, `#[allow]`, or `#[expect]` attributes.
- The tracked Git worktree remained unchanged by this lot.

## Custody

`observations/commands.tsv` is the unmodified raw machine-readable command observation stream, including the excluded pre-cure coverage-readback rows.
`observations/commands-readback-fixed.tsv` is the unmodified raw fixed-source coverage-readback stream.
`observations/retained-commands.tsv` is the validated host-neutral join that replaces only the three old rows with the three fixed-source rows under the accepted method identity.
`observations/summary.tsv` is the deterministic median and max-minus-min dispersion projection of `observations/retained-commands.tsv`.
`observations/economics-readback-a.txt` and `observations/economics-readback-b.txt` are the independently repeated typed economics readbacks.
`observations/coverage-readback-1.txt` through `observations/coverage-readback-3.txt` are the independently repeated informed coverage readbacks.
`observations/host-facts.tsv` and `observations/file-hashes.tsv` carry the host, toolchain, input, source, binary, and output coordinates.
`source/` carries the exact safe-Rust observer, process loop, coverage-stage helper, summarizer, and semantic source variants.
`commands.md` carries host-neutral command reconstruction.
Raw command logs and build output remain disposable scratch and contain no repository authority.
One inert nested mechanical copy under the lot root remains excluded from the evidence roster because local policy rejected its exact recursive cleanup before execution.
It is not referenced by the workspace, commands, observations, readbacks, or result.
The entire scratch tree remains under `target/qualification/0.2-wave-j-guarded-economics-20260831` for independent parent review.

## Current local conclusion

The adopted guarded-transition family has a complete local Windows current-source economics observation for its declared Wave J family-1 denominator.
The observation keeps semantic correctness, typed compiler work, proc crossing, generated bytes, runtime parity, build postures, stable source coverage stages, cleanup, and existing mutation sensitivity distinct.
No genuine architecture, API, identity, byte, diagnostic, package, feature, toolchain, custody, or contract blocker appeared in this bounded lot.
