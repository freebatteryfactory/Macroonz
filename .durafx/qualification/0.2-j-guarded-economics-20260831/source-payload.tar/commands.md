# Wave J guarded-transition economics commands

## Coordinate setup

Every command ran from the repository root in PowerShell.
The following variables express the host-neutral coordinates used below.

```powershell
$repoRoot = (git rev-parse --show-toplevel)
$lot = Join-Path $repoRoot 'target/qualification/0.2-wave-j-guarded-economics-20260831'
$work = Join-Path $lot 'work'
$observations = Join-Path $lot 'observations'
$logs = Join-Path $observations 'logs'
$cargoTarget = Join-Path $lot 'work-target-198'
$targetTriple = 'x86_64-pc-windows-msvc'
$cargo198 = (rustup which --toolchain 1.98.0 cargo)
$rustc198 = (rustup which --toolchain 1.98.0 rustc)
$rustdoc198 = (rustup which --toolchain 1.98.0 rustdoc)
$toolchain = Split-Path (Split-Path $rustc198 -Parent) -Parent
$llvmProfdata = Join-Path $toolchain 'lib/rustlib/x86_64-pc-windows-msvc/bin/llvm-profdata.exe'
$llvmCov = Join-Path $toolchain 'lib/rustlib/x86_64-pc-windows-msvc/bin/llvm-cov.exe'
$observer = Join-Path $lot 'source/observer.exe'
$processLoop = Join-Path $lot 'source/process_loop.exe'
$coverageStage = Join-Path $lot 'source/coverage_stage.exe'
$summarize = Join-Path $lot 'source/summarize.exe'
$env:RUSTC = $rustc198
$env:RUSTDOC = $rustdoc198
$env:CARGO_BUILD_JOBS = '1'
$env:CARGO_TARGET_DIR = $cargoTarget
```

## Authority and package reconciliation

The adopted source was extracted from the accepted structural-adoption payload.
The historical economics observer and protocol were extracted from the accepted economics payload.
The Wave H source payload was extracted into the lot input home.
The four package archives were read from the Wave H candidate home and extracted without a live-worktree fallback.

```powershell
tar -xf '.durafx/qualification/0.2-b-guarded-transition-structural-adoption-20260830/source-payload.tar' -C (Join-Path $lot 'inputs/adopted-subject')
tar --zstd -xf '.durafx/qualification/0.2-b-guarded-transition-economics-20260829/source-payload.tar.zst' -C (Join-Path $lot 'inputs/historical-economics')
tar -xf '.durafx/qualification/0.2-h-api-compatibility-20260831/source-payload.tar' -C (Join-Path $lot 'inputs/wave-h')
$candidateArchives = Join-Path $repoRoot 'target/qualification/0.2-wave-h-semver-pilot-20260831/candidate-archives'
tar -xf (Join-Path $candidateArchives 'macroonz-0.1.0.crate') -C (Join-Path $work 'packages-current')
tar -xf (Join-Path $candidateArchives 'macroonz-compiler-0.1.0.crate') -C (Join-Path $work 'packages-current')
tar -xf (Join-Path $candidateArchives 'macroonz-harness-0.1.0.crate') -C (Join-Path $work 'packages-current')
tar -xf (Join-Path $candidateArchives 'macroonz-macros-0.1.0.crate') -C (Join-Path $work 'packages-current')
Get-ChildItem -LiteralPath $candidateArchives -Filter '*.crate' | Get-FileHash -Algorithm SHA256
```

The package candidates each carried `.cargo_vcs_info.json` revision `73ffa61b8555290deebee2d463f207ba10651036`.
The scratch workspace patched crates.io resolution only to those extracted candidates.

## Safe helper compilation

The four helper programs are standalone safe Rust and deny every warning.

```powershell
& $rustc198 --edition=2024 (Join-Path $lot 'source/observer.rs') -o $observer
& $rustc198 --edition=2024 (Join-Path $lot 'source/process_loop.rs') -o $processLoop
& $rustc198 --edition=2024 (Join-Path $lot 'source/coverage_stage.rs') -o $coverageStage
& $rustc198 --edition=2024 (Join-Path $lot 'source/summarize.rs') -o $summarize
```

## Correctness preflight and typed economics

The observer writes raw standard output and standard error separately and appends one machine-readable row to `observations/commands.tsv`.
These preflight commands used the stable toolchain's implicit host target.
The retained Cargo output path and `.rustc_info.json` establish that host target as `x86_64-pc-windows-msvc` without an explicit `--target` argument.

```powershell
& $observer (Join-Path $observations 'commands.tsv') $logs 'typed-bench' '3' $work $cargoTarget $cargo198 test --manifest-path (Join-Path $work 'Cargo.toml') --test economics --locked --offline --jobs 1 -- --test-threads=1
& $observer (Join-Path $observations 'commands.tsv') $logs 'semantic-journey' '3' $work $cargoTarget $cargo198 test --manifest-path (Join-Path $work 'Cargo.toml') --test journey --locked --offline --jobs 1 -- --test-threads=1
& $observer (Join-Path $observations 'commands.tsv') $logs 'economics-readback-a' '3' $work $cargoTarget $cargo198 run --manifest-path (Join-Path $work 'Cargo.toml') --package guarded-transition-challenges --bin economics_readback --locked --offline --jobs 1
& $observer (Join-Path $observations 'commands.tsv') $logs 'economics-readback-b' '3' $work $cargoTarget $cargo198 run --manifest-path (Join-Path $work 'Cargo.toml') --package guarded-transition-challenges --bin economics_readback --locked --offline --jobs 1
```

The two readback streams were compared byte for byte before retention.

## Procedural carrier posture

Each of three samples used one fresh target directory.
The first command defines the proc-macro carrier but has no consumer declaration that invokes it.
The second command checks the adopted subject and therefore crosses the real proc-macro boundary.

```powershell
$env:CARGO_TARGET_DIR = $sampleTarget
& $observer (Join-Path $observations 'commands.tsv') $logs 'carrier-defined' $sample $work $sampleTarget $cargo198 check --manifest-path (Join-Path $work 'Cargo.toml') --package guarded-transition-subject-macros --lib --locked --offline --target $targetTriple --jobs 1
& $observer (Join-Path $observations 'commands.tsv') $logs 'carrier-invoked' $sample $work $sampleTarget $cargo198 check --manifest-path (Join-Path $work 'Cargo.toml') --package guarded-transition-subject --lib --locked --offline --target $targetTriple --jobs 1
& $cargo198 clean --manifest-path (Join-Path $work 'Cargo.toml') --target-dir $sampleTarget
```

The target-byte delta, not the noisy wall ordering, distinguishes the two typed postures.

## Subject build postures

Each cold sample named exactly the generated, handwritten, and refactored readback binaries and used a fresh target.
Each warm no-op immediately repeated the same locked and offline command.

```powershell
$env:CARGO_TARGET_DIR = $sampleTarget
& $observer (Join-Path $observations 'commands.tsv') $logs 'subject-cold' $sample $work $sampleTarget $cargo198 build --manifest-path (Join-Path $work 'Cargo.toml') --package guarded-transition-challenges --bin generated-readback --bin handwritten-readback --bin refactored-readback --locked --offline --target $targetTriple --jobs 1
& $observer (Join-Path $observations 'commands.tsv') $logs 'subject-warm-noop' $sample $work $sampleTarget $cargo198 build --manifest-path (Join-Path $work 'Cargo.toml') --package guarded-transition-challenges --bin generated-readback --bin handwritten-readback --bin refactored-readback --locked --offline --target $targetTriple --jobs 1
& $cargo198 clean --manifest-path (Join-Path $work 'Cargo.toml') --target-dir $sampleTarget
```

The first incremental attempt copied bytes while preserving source timestamps, so Cargo truthfully performed no work and those rows are excluded as setup controls.
The valid incremental samples copied the exact variant bytes and then advanced `LastWriteTimeUtc` before invoking Cargo.

```powershell
Copy-Item -LiteralPath (Join-Path $lot 'source/declaration-change-subject.rs') -Destination (Join-Path $work 'guarded-transition-subject/src/lib.rs') -Force
(Get-Item -LiteralPath (Join-Path $work 'guarded-transition-subject/src/lib.rs')).LastWriteTimeUtc = [DateTime]::UtcNow.AddSeconds(2)
& $observer (Join-Path $observations 'commands.tsv') $logs 'subject-incremental-declaration-valid' $sample $work $sampleTarget $cargo198 build --manifest-path (Join-Path $work 'Cargo.toml') --package guarded-transition-challenges --bin generated-readback --bin handwritten-readback --bin refactored-readback --locked --offline --target $targetTriple --jobs 1
Copy-Item -LiteralPath (Join-Path $lot 'source/baseline-subject.rs') -Destination (Join-Path $work 'guarded-transition-subject/src/lib.rs') -Force
(Get-Item -LiteralPath (Join-Path $work 'guarded-transition-subject/src/lib.rs')).LastWriteTimeUtc = [DateTime]::UtcNow.AddSeconds(4)
& $observer (Join-Path $observations 'commands.tsv') $logs 'subject-incremental-restore-valid' $sample $work $sampleTarget $cargo198 build --manifest-path (Join-Path $work 'Cargo.toml') --package guarded-transition-challenges --bin generated-readback --bin handwritten-readback --bin refactored-readback --locked --offline --target $targetTriple --jobs 1
Copy-Item -LiteralPath (Join-Path $lot 'source/unrelated-edit-subject.rs') -Destination (Join-Path $work 'guarded-transition-subject/src/lib.rs') -Force
(Get-Item -LiteralPath (Join-Path $work 'guarded-transition-subject/src/lib.rs')).LastWriteTimeUtc = [DateTime]::UtcNow.AddSeconds(6)
& $observer (Join-Path $observations 'commands.tsv') $logs 'subject-incremental-unrelated-valid' $sample $work $sampleTarget $cargo198 build --manifest-path (Join-Path $work 'Cargo.toml') --package guarded-transition-challenges --bin generated-readback --bin handwritten-readback --bin refactored-readback --locked --offline --target $targetTriple --jobs 1
```

## Runtime parity

The typed-bench command produced the three ordinary binaries under `work-target-198/debug` in Cargo's `test` profile before the observer emitted the green typed-bench log.
The exact host-target binaries then received one direct preflight, five process warmups, and three samples of 100 child executions per road.

```powershell
$runtimeRoot = Join-Path $cargoTarget 'debug'
$binary = Join-Path $runtimeRoot "$road-readback.exe"
& $observer (Join-Path $observations 'commands.tsv') $logs "runtime-$road-preflight" '1' $work $cargoTarget $binary
1..5 | ForEach-Object { & $observer (Join-Path $observations 'commands.tsv') $logs "runtime-$road-warmup" $_ $work $cargoTarget $binary }
1..3 | ForEach-Object { & $observer (Join-Path $observations 'commands.tsv') $logs "runtime-$road-sample" $_ $work $cargoTarget $processLoop $binary '100' }
```

The generated, handwritten, and refactored standard-output streams were compared byte for byte, and every standard-error stream was empty.

## Stable rustc source-coverage stages

Each of three samples used a fresh stage directory and direct stable rustc instrumentation.
The coverage unit is stable source regions and points, not edges or explicit branch coverage.

```powershell
& $observer (Join-Path $observations 'commands.tsv') $logs 'coverage-compile' $sample $work $stageTarget $rustc198 --edition=2024 -C instrument-coverage -C codegen-units=1 -C opt-level=0 (Join-Path $work 'measurement-source/coverage-stage/subject.rs') -o (Join-Path $stageTarget 'coverage-subject.exe')
& $observer (Join-Path $observations 'commands.tsv') $logs 'coverage-run' $sample $work $stageTarget $coverageStage run (Join-Path $stageTarget 'coverage-subject.exe') (Join-Path $stageTarget 'coverage.profraw') '1,2,3'
& $observer (Join-Path $observations 'commands.tsv') $logs 'coverage-merge' $sample $work $stageTarget $llvmProfdata merge -sparse (Join-Path $stageTarget 'coverage.profraw') -o (Join-Path $stageTarget 'coverage.profdata')
& $observer (Join-Path $observations 'commands.tsv') $logs 'coverage-export' $sample $work $stageTarget $llvmCov export --format=lcov --instr-profile=(Join-Path $stageTarget 'coverage.profdata') (Join-Path $stageTarget 'coverage-subject.exe')
Copy-Item -LiteralPath (Join-Path $logs "coverage-export-$sample.stdout") -Destination (Join-Path $stageTarget 'coverage-raw.lcov') -Force
Copy-Item -LiteralPath (Join-Path $stageTarget 'coverage-raw.lcov') -Destination (Join-Path $work 'measurement-source/coverage-stage/coverage-raw.lcov') -Force
& $observer (Join-Path $observations 'commands.tsv') $logs 'coverage-readback' $sample $work $stageTarget (Join-Path $cargoTarget 'x86_64-pc-windows-msvc/debug/coverage_readback.exe')
Copy-Item -LiteralPath (Join-Path $work 'measurement-source/coverage-stage/coverage-neutral.lcov') -Destination (Join-Path $stageTarget 'coverage-neutral.lcov') -Force
```

The readback consumes fixed declared raw and neutral files in the measurement home, normalizes only the absolute source path to `C:\qualification\subject.rs`, consumes that LCOV through the exact current package candidate, and prints the informed source-point set.
Each cleanup sample copied exactly the instrumented executable, raw profile, merged profile, normalized LCOV, and authority marker into its own temporary directory before invoking the guarded safe-Rust cleanup helper.
The normalized LCOV entered the cleanup roster under the exact name `coverage.lcov` required by the helper.

```powershell
New-Item -ItemType Directory -Path $cleanupTarget
Copy-Item -LiteralPath (Join-Path $stageTarget 'coverage-subject.exe') -Destination (Join-Path $cleanupTarget 'coverage-subject.exe')
Copy-Item -LiteralPath (Join-Path $stageTarget 'coverage.profraw') -Destination (Join-Path $cleanupTarget 'coverage.profraw')
Copy-Item -LiteralPath (Join-Path $stageTarget 'coverage.profdata') -Destination (Join-Path $cleanupTarget 'coverage.profdata')
Copy-Item -LiteralPath (Join-Path $stageTarget 'coverage-neutral.lcov') -Destination (Join-Path $cleanupTarget 'coverage.lcov')
Copy-Item -LiteralPath (Join-Path $lot 'source/coverage-cleanup-marker') -Destination (Join-Path $cleanupTarget '.wave-j-coverage-cleanup')
& $observer (Join-Path $observations 'commands.tsv') $logs 'coverage-cleanup' $sample $work $cleanupTarget $coverageStage cleanup $cleanupTarget
```

The coverage-parse binary embeds the exact host-neutral LCOV at compile time and fixes its own iteration denominator at 10,000.
It received one argument-free warmup and five argument-free samples.

```powershell
& $observer (Join-Path $observations 'commands.tsv') $logs 'coverage-parse-build' '1' $work $cargoTarget $cargo198 build --manifest-path (Join-Path $work 'Cargo.toml') --package guarded-transition-challenges --bin coverage_parse --locked --offline --jobs 1
& $observer (Join-Path $observations 'commands.tsv') $logs 'coverage-parse-warmup' '1' $work $cargoTarget (Join-Path $cargoTarget 'debug/coverage_parse.exe')
1..5 | ForEach-Object { & $observer (Join-Path $observations 'commands.tsv') $logs 'coverage-parse-sample' $_ $work $cargoTarget (Join-Path $cargoTarget 'debug/coverage_parse.exe') }
```

## Deterministic summary

The summarizer requires every retained label, exact sample denominator, unique sample ordinals, and zero exit codes before it computes the odd-denominator median and max-minus-min dispersion.
The raw command stream remains byte-for-byte measurement custody and still contains the three excluded pre-cure coverage-readback rows.
The fixed-source command stream carries the three genuine replacement rows under its distinct raw label.
A safe-Rust reconciler validates both exact raw streams, replaces only those three rows, relabels the fixed rows to the accepted method identity, and emits the host-neutral retained command stream consumed by the summarizer.

```powershell
& $rustc198 --edition=2024 (Join-Path $lot 'source/reconcile_commands.rs') -o (Join-Path $lot 'source/reconcile_commands.exe')
& (Join-Path $lot 'source/reconcile_commands.exe') (Join-Path $observations 'commands.tsv') (Join-Path $observations 'commands-readback-fixed.tsv') (Join-Path $observations 'retained-commands.tsv')
& $summarize (Join-Path $observations 'retained-commands.tsv') (Join-Path $observations 'summary.tsv')
```

## Excluded setup observations

The first typed-bench command inherited a Rust 1.97.1 compiler from `PATH` while using Cargo 1.98.0, refused with `E0514`, and is excluded.
The correction was to set `RUSTC` and `RUSTDOC` explicitly to the stable 1.98.0 toolchain before using the exact Cargo binary.
The first three coverage readbacks used the pre-cure CLI-path scratch driver and remain only in the raw command stream and raw logs.
The fixed declared-file driver produced the three rows in `commands-readback-fixed.tsv`; only the reconciled retained stream feeds `summary.tsv`.
The timestamp-preserving incremental copies produced honest no-op rows and are excluded from the incremental-cost rows.
The correction was the explicit `LastWriteTimeUtc` movement shown above.
Two `cargo clean` attempts over pre-existing task targets refused because those directories lacked a valid Cargo `CACHEDIR.TAG`; no bypass or broad deletion followed.
