//! External typed-work and planted-control economics for the exact guarded-transition source.

#![forbid(unsafe_code)]
#![deny(warnings)]

#[path = "../../guarded-transition-subject-macros/src/engine.rs"]
mod engine;
#[path = "economics/claims.rs"]
mod claims;
#[path = "economics/fixture.rs"]
mod fixture;
#[path = "economics/source.rs"]
mod source;
#[path = "economics/support.rs"]
mod support;

#[test]
fn exact_source_qualifies_typed_scaling_and_planted_controls() -> Result<(), String> {
    support::prove_host()?;
    let table = fixture::table()?;
    let report = bakery::harness::bench::run_all(&table, &support::bench_invocation())
        .map_err(support::described)?;
    bakery::harness::bench::bench_verdict(&report).map_err(support::described)?;
    claims::assert_complete_report(&table, &report)
}

#[test]
fn identical_compiler_control_is_refused_before_timing() -> Result<(), String> {
    support::prove_host()?;
    let table = fixture::identical_compiler_control_table()?;
    let report = bakery::harness::bench::run_all(&table, &support::bench_invocation())
        .map_err(support::described)?;
    claims::assert_identical_control_refused(&report)
}
