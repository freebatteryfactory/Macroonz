//! Typed benchmark rows, executable work, planted controls, and owner judgment.

use super::source::{
    COMPILER_AXIS, CompilerMetrics, INVOCATION_AXIS, PROJECTION_COUNT, RUNTIME_AXIS,
    baseline_metrics, compiler_metrics, scaled_declaration,
};
use super::support::{self, OWNER};
use bakery::harness::bench::{
    BenchAttachment, BenchBinding, BenchCall, BenchMeasurement, BenchReferences, BenchRow,
    BenchTable, BenchTableName, ComplexityClaimRef, ContentionPosture, DeclaredBudgets,
    InputSizeAxis, PlantedWorseRef, WorkConclusion, WorkCurve, WorkCurvePoint, WorkFormula,
    WorkGapStanding, WorkJudge, WorkJudgeBinding, WorkJudgment, WorkJudgmentInput,
    WorkObservationRef, WorkRecorder, WorkRecordingRefusal, WorkloadRef,
};
use bakery::harness::descriptor::Provenance;
use guarded_transition_subject::{Capability, Event, GuardedContract, Reading, Standing};

const COMPILER_FORMULA: &[u8] = b"one compiler pass per declared algebra size";
const INVOCATION_FORMULA: &[u8] = b"six planned projections per proc-style invocation";
const RUNTIME_FORMULA: &[u8] = b"two declared event steps per subject execution";
const MEASURED_REFUSED: bakery::harness::report::FindingCause =
    bakery::harness::report::FindingCause::named(OWNER, "measured-curve-refused");
const CONTROL_REFUSED: bakery::harness::report::FindingCause =
    bakery::harness::report::FindingCause::named(OWNER, "planted-control-refused");
const GAP_REFUSED: bakery::harness::report::FindingCause =
    bakery::harness::report::FindingCause::named(OWNER, "declared-gap-not-observed");

const COMPILER_OBSERVATIONS: [&str; 14] = [
    "source-bytes",
    "captured-trees",
    "captured-depth",
    "vocabulary-members",
    "transition-edges",
    "policy-edges",
    "association-edges",
    "planned-units",
    "rendered-units",
    "generated-bytes",
    "canonical-bytes",
    "explanation-seats",
    "disposition-seats",
    "delivered-bytes",
];
const INVOCATION_OBSERVATIONS: [&str; 5] = [
    "macro-invocations",
    "planned-units",
    "rendered-units",
    "generated-bytes",
    "delivered-bytes",
];
const RUNTIME_OBSERVATIONS: [&str; 4] = [
    "executions",
    "event-steps",
    "redundant-comparisons",
    "declared-work",
];

#[derive(Clone, Copy)]
struct BindingSpec {
    workload: &'static str,
    control: &'static str,
    complexity: &'static str,
    formula: &'static [u8],
    axis: &'static [u64],
    measured: BenchCall,
    planted: BenchCall,
    judge: WorkJudge,
    observations: &'static [&'static str],
}

#[derive(Clone, Copy)]
enum RuntimeCurveKind {
    Measured,
    PlantedWorse,
}

pub(super) fn table() -> Result<BenchTable, String> {
    let bindings = vec![
        compiler_binding()?,
        invocation_binding()?,
        runtime_binding(
            "generated-runtime",
            "generated-redundant-scan",
            generated_runtime,
            generated_runtime_control,
        )?,
        runtime_binding(
            "handwritten-runtime",
            "handwritten-redundant-scan",
            handwritten_runtime,
            handwritten_runtime_control,
        )?,
    ];
    BenchTable::authored(
        BenchTableName::named(OWNER, "guarded-transition-economics").map_err(support::described)?,
        Provenance::Unproduced,
        bindings,
    )
    .map_err(support::described)
}

pub(super) fn identical_compiler_control_table() -> Result<BenchTable, String> {
    let binding = binding(BindingSpec {
        workload: "callable-compiler",
        control: "identical-compiler-pass",
        complexity: "single-pass-compiler-growth",
        formula: COMPILER_FORMULA,
        axis: &COMPILER_AXIS,
        measured: compiler_measured,
        planted: compiler_measured,
        judge: compiler_judge,
        observations: &COMPILER_OBSERVATIONS,
    })?;
    BenchTable::authored(
        BenchTableName::named(OWNER, "guarded-transition-identical-control")
            .map_err(support::described)?,
        Provenance::Unproduced,
        vec![binding],
    )
    .map_err(support::described)
}

fn compiler_binding() -> Result<BenchBinding, String> {
    binding(BindingSpec {
        workload: "callable-compiler",
        control: "repeated-compiler-pass",
        complexity: "single-pass-compiler-growth",
        formula: COMPILER_FORMULA,
        axis: &COMPILER_AXIS,
        measured: compiler_measured,
        planted: compiler_control,
        judge: compiler_judge,
        observations: &COMPILER_OBSERVATIONS,
    })
}

fn invocation_binding() -> Result<BenchBinding, String> {
    binding(BindingSpec {
        workload: "proc-style-invocations",
        control: "duplicated-invocation-work",
        complexity: "linear-projection-growth",
        formula: INVOCATION_FORMULA,
        axis: &INVOCATION_AXIS,
        measured: invocation_measured,
        planted: invocation_control,
        judge: invocation_judge,
        observations: &INVOCATION_OBSERVATIONS,
    })
}

fn runtime_binding(
    workload: &'static str,
    control: &'static str,
    measured: BenchCall,
    planted: BenchCall,
) -> Result<BenchBinding, String> {
    binding(BindingSpec {
        workload,
        control,
        complexity: "linear-subject-execution",
        formula: RUNTIME_FORMULA,
        axis: &RUNTIME_AXIS,
        measured,
        planted,
        judge: runtime_judge,
        observations: &RUNTIME_OBSERVATIONS,
    })
}

fn binding(spec: BindingSpec) -> Result<BenchBinding, String> {
    let workload = WorkloadRef::named(OWNER, spec.workload).map_err(support::described)?;
    let planted_ref = PlantedWorseRef::named(OWNER, spec.control).map_err(support::described)?;
    let complexity =
        ComplexityClaimRef::named(OWNER, spec.complexity).map_err(support::described)?;
    let references = BenchReferences::declared(
        workload,
        bakery::harness::bench::PreflightRef::named(OWNER, "guarded-transition-correctness")
            .map_err(support::described)?,
        planted_ref,
        complexity,
    );
    let measurement = BenchMeasurement::declared(
        InputSizeAxis::declared(spec.axis.to_vec()).map_err(support::described)?,
        DeclaredBudgets::declared(1, 1, 2, 1).map_err(support::described)?,
        ContentionPosture::NoDeclaredContention,
        Some(WorkFormula::encoded(spec.formula.to_vec()).map_err(support::described)?),
    );
    let row = BenchRow::declared(references, measurement).map_err(support::described)?;
    let observations = spec
        .observations
        .iter()
        .map(|stem| WorkObservationRef::named(OWNER, stem).map_err(support::described))
        .collect::<Result<Vec<_>, _>>()?;
    let attachment = BenchAttachment::attached(
        workload,
        spec.measured,
        planted_ref,
        spec.planted,
        WorkJudgeBinding::bound(complexity, spec.judge),
        observations,
    )
    .map_err(support::described)?;
    BenchBinding::bound(row, attachment, support::preflight()?).map_err(support::described)
}

fn compiler_measured(
    input_size: u64,
    recorder: &mut WorkRecorder,
) -> Result<(), WorkRecordingRefusal> {
    let Some(metrics) = compiler_metrics(input_size) else {
        return refuse_recording(recorder, "compiler-work-refused", input_size);
    };
    record_compiler(recorder, &metrics, 1)
}

fn compiler_control(
    input_size: u64,
    recorder: &mut WorkRecorder,
) -> Result<(), WorkRecordingRefusal> {
    let (Some(first), Some(second)) = (compiler_metrics(input_size), compiler_metrics(input_size))
    else {
        return refuse_recording(recorder, "compiler-control-refused", input_size);
    };
    if first != second {
        return refuse_recording(recorder, "compiler-control-drifted", input_size);
    }
    record_compiler(recorder, &first, 2)
}

fn record_compiler(
    recorder: &mut WorkRecorder,
    metrics: &CompilerMetrics,
    multiplier: u64,
) -> Result<(), WorkRecordingRefusal> {
    for (stem, amount) in compiler_values(metrics) {
        record_scaled(recorder, stem, amount, multiplier)?;
    }
    Ok(())
}

fn compiler_values(metrics: &CompilerMetrics) -> [(&'static str, u64); 14] {
    [
        ("source-bytes", metrics.source_bytes),
        ("captured-trees", metrics.captured_trees),
        ("captured-depth", metrics.captured_depth),
        ("vocabulary-members", metrics.vocabulary_members),
        ("transition-edges", metrics.transition_edges),
        ("policy-edges", metrics.policy_edges),
        ("association-edges", metrics.association_edges),
        ("planned-units", metrics.planned_units),
        ("rendered-units", metrics.rendered_units),
        ("generated-bytes", metrics.generated_bytes),
        ("canonical-bytes", metrics.canonical_bytes),
        ("explanation-seats", metrics.explanation_seats),
        ("disposition-seats", metrics.disposition_seats),
        ("delivered-bytes", metrics.delivered_bytes),
    ]
}

fn invocation_measured(
    input_size: u64,
    recorder: &mut WorkRecorder,
) -> Result<(), WorkRecordingRefusal> {
    record_invocations(input_size, recorder, 1)
}

fn invocation_control(
    input_size: u64,
    recorder: &mut WorkRecorder,
) -> Result<(), WorkRecordingRefusal> {
    record_invocations(input_size, recorder, 2)
}

fn record_invocations(
    input_size: u64,
    recorder: &mut WorkRecorder,
    multiplier: u64,
) -> Result<(), WorkRecordingRefusal> {
    let Some(total) = input_size.checked_mul(multiplier) else {
        return overflow("macro-invocations", input_size);
    };
    let mut aggregate: Option<CompilerMetrics> = None;
    for _ordinal in 0..total {
        let Some(metrics) = baseline_metrics() else {
            return refuse_recording(recorder, "invocation-compile-refused", input_size);
        };
        aggregate = Some(match aggregate {
            None => metrics,
            Some(existing) => add_metrics(existing, &metrics, input_size)?,
        });
    }
    let Some(metrics) = aggregate else {
        return refuse_recording(recorder, "invocation-axis-empty", input_size);
    };
    record(recorder, "macro-invocations", total)?;
    record(recorder, "planned-units", metrics.planned_units)?;
    record(recorder, "rendered-units", metrics.rendered_units)?;
    record(recorder, "generated-bytes", metrics.generated_bytes)?;
    record(recorder, "delivered-bytes", metrics.delivered_bytes)
}

fn add_metrics(
    mut total: CompilerMetrics,
    next: &CompilerMetrics,
    input_size: u64,
) -> Result<CompilerMetrics, WorkRecordingRefusal> {
    total.planned_units = add(
        total.planned_units,
        next.planned_units,
        "planned-units",
        input_size,
    )?;
    total.rendered_units = add(
        total.rendered_units,
        next.rendered_units,
        "rendered-units",
        input_size,
    )?;
    total.generated_bytes = add(
        total.generated_bytes,
        next.generated_bytes,
        "generated-bytes",
        input_size,
    )?;
    total.delivered_bytes = add(
        total.delivered_bytes,
        next.delivered_bytes,
        "delivered-bytes",
        input_size,
    )?;
    Ok(total)
}

fn add(
    left: u64,
    right: u64,
    stem: &'static str,
    input_size: u64,
) -> Result<u64, WorkRecordingRefusal> {
    left.checked_add(right)
        .ok_or_else(|| amount_overflow(stem, input_size))
}

fn generated_runtime(
    input_size: u64,
    recorder: &mut WorkRecorder,
) -> Result<(), WorkRecordingRefusal> {
    runtime_measured::<guarded_transition_subject::generated::GeneratedRoad>(input_size, recorder)
}

fn handwritten_runtime(
    input_size: u64,
    recorder: &mut WorkRecorder,
) -> Result<(), WorkRecordingRefusal> {
    runtime_measured::<guarded_transition_subject::handwritten::HandwrittenRoad>(
        input_size, recorder,
    )
}

fn generated_runtime_control(
    input_size: u64,
    recorder: &mut WorkRecorder,
) -> Result<(), WorkRecordingRefusal> {
    runtime_control::<guarded_transition_subject::generated::GeneratedRoad>(input_size, recorder)
}

fn handwritten_runtime_control(
    input_size: u64,
    recorder: &mut WorkRecorder,
) -> Result<(), WorkRecordingRefusal> {
    runtime_control::<guarded_transition_subject::handwritten::HandwrittenRoad>(
        input_size, recorder,
    )
}

fn runtime_measured<Road: GuardedContract>(
    input_size: u64,
    recorder: &mut WorkRecorder,
) -> Result<(), WorkRecordingRefusal> {
    if execute_many::<Road>(input_size).is_none() {
        return refuse_recording(recorder, "runtime-refused", input_size);
    }
    let event_steps = input_size
        .checked_mul(2)
        .ok_or_else(|| amount_overflow("event-steps", input_size))?;
    record(recorder, "executions", input_size)?;
    record(recorder, "event-steps", event_steps)?;
    record(recorder, "redundant-comparisons", 0)?;
    record(recorder, "declared-work", event_steps)
}

fn runtime_control<Road: GuardedContract>(
    input_size: u64,
    recorder: &mut WorkRecorder,
) -> Result<(), WorkRecordingRefusal> {
    if execute_many::<Road>(input_size).is_none() {
        return refuse_recording(recorder, "runtime-control-refused", input_size);
    }
    let redundant = repeated_scan(input_size)?;
    let event_steps = input_size
        .checked_mul(2)
        .ok_or_else(|| amount_overflow("event-steps", input_size))?;
    let work = event_steps
        .checked_add(redundant)
        .ok_or_else(|| amount_overflow("declared-work", input_size))?;
    record(recorder, "executions", input_size)?;
    record(recorder, "event-steps", event_steps)?;
    record(recorder, "redundant-comparisons", redundant)?;
    record(recorder, "declared-work", work)
}

fn execute_many<Road: GuardedContract>(input_size: u64) -> Option<Reading> {
    let mut last = None;
    for _ordinal in 0..input_size {
        let reading = Road::execute(Capability::Elevated, &[Event::Arm, Event::Finish], 0).ok()?;
        if reading.value() != 5 || reading.standing() != Standing::Done {
            return None;
        }
        last = Some(reading);
    }
    last
}

fn repeated_scan(input_size: u64) -> Result<u64, WorkRecordingRefusal> {
    let mut comparisons = 0_u64;
    for outer in 0..input_size {
        for inner in 0..input_size {
            std::hint::black_box((outer, inner));
            comparisons = comparisons
                .checked_add(1)
                .ok_or_else(|| amount_overflow("redundant-comparisons", input_size))?;
        }
    }
    Ok(comparisons)
}

fn record_scaled(
    recorder: &mut WorkRecorder,
    stem: &'static str,
    amount: u64,
    multiplier: u64,
) -> Result<(), WorkRecordingRefusal> {
    let Some(amount) = amount.checked_mul(multiplier) else {
        return overflow(stem, multiplier);
    };
    record(recorder, stem, amount)
}

fn record(
    recorder: &mut WorkRecorder,
    stem: &'static str,
    amount: u64,
) -> Result<(), WorkRecordingRefusal> {
    let observation =
        WorkObservationRef::named(OWNER, stem).map_err(WorkRecordingRefusal::ObservationName)?;
    recorder.record(observation, amount)
}

fn refuse_recording(
    recorder: &mut WorkRecorder,
    stem: &'static str,
    input_size: u64,
) -> Result<(), WorkRecordingRefusal> {
    let unknown =
        WorkObservationRef::named(OWNER, stem).map_err(WorkRecordingRefusal::ObservationName)?;
    recorder.record(unknown, input_size)
}

fn overflow(stem: &'static str, input_size: u64) -> Result<(), WorkRecordingRefusal> {
    Err(amount_overflow(stem, input_size))
}

fn amount_overflow(stem: &'static str, input_size: u64) -> WorkRecordingRefusal {
    match WorkObservationRef::named(OWNER, stem) {
        Ok(observation) => WorkRecordingRefusal::AmountOverflow {
            observation,
            input_size,
        },
        Err(refusal) => WorkRecordingRefusal::ObservationName(refusal),
    }
}

fn compiler_judge(input: &WorkJudgmentInput<'_>) -> WorkJudgment {
    let owner = owner_matches(input, "single-pass-compiler-growth", COMPILER_FORMULA);
    let measured = if owner && compiler_curve_holds(input.measured(), 1) {
        WorkConclusion::Satisfied
    } else {
        WorkConclusion::Refused(MEASURED_REFUSED)
    };
    let control = if owner && compiler_curve_holds(input.planted_worse(), 2) {
        WorkConclusion::Refused(CONTROL_REFUSED)
    } else {
        WorkConclusion::Satisfied
    };
    let gap = if owner && curves_scaled(input.measured(), input.planted_worse(), 2) {
        WorkGapStanding::Distinguished
    } else {
        WorkGapStanding::NotDistinguished(GAP_REFUSED)
    };
    WorkJudgment::stated(measured, control, gap)
}

fn invocation_judge(input: &WorkJudgmentInput<'_>) -> WorkJudgment {
    let owner = owner_matches(input, "linear-projection-growth", INVOCATION_FORMULA);
    let measured = if owner && invocation_curve_holds(input.measured(), 1) {
        WorkConclusion::Satisfied
    } else {
        WorkConclusion::Refused(MEASURED_REFUSED)
    };
    let control = if owner && invocation_curve_holds(input.planted_worse(), 2) {
        WorkConclusion::Refused(CONTROL_REFUSED)
    } else {
        WorkConclusion::Satisfied
    };
    let gap = if owner && curves_scaled(input.measured(), input.planted_worse(), 2) {
        WorkGapStanding::Distinguished
    } else {
        WorkGapStanding::NotDistinguished(GAP_REFUSED)
    };
    WorkJudgment::stated(measured, control, gap)
}

fn runtime_judge(input: &WorkJudgmentInput<'_>) -> WorkJudgment {
    let owner = owner_matches(input, "linear-subject-execution", RUNTIME_FORMULA);
    let measured = if owner && runtime_curve_holds(input.measured(), RuntimeCurveKind::Measured) {
        WorkConclusion::Satisfied
    } else {
        WorkConclusion::Refused(MEASURED_REFUSED)
    };
    let control =
        if owner && runtime_curve_holds(input.planted_worse(), RuntimeCurveKind::PlantedWorse) {
            WorkConclusion::Refused(CONTROL_REFUSED)
        } else {
            WorkConclusion::Satisfied
        };
    let gap = if owner && runtime_gap_holds(input.measured(), input.planted_worse()) {
        WorkGapStanding::Distinguished
    } else {
        WorkGapStanding::NotDistinguished(GAP_REFUSED)
    };
    WorkJudgment::stated(measured, control, gap)
}

fn owner_matches(
    input: &WorkJudgmentInput<'_>,
    complexity: &'static str,
    formula: &'static [u8],
) -> bool {
    ComplexityClaimRef::named(OWNER, complexity).is_ok_and(|expected| {
        input.complexity() == expected
            && input
                .formula()
                .is_some_and(|observed| observed.bytes() == formula)
    })
}

fn compiler_curve_holds(curve: &WorkCurve, multiplier: u64) -> bool {
    if curve.points().len() != COMPILER_AXIS.len() {
        return false;
    }
    let mut previous_growth = None;
    for point in curve.points() {
        let size = point.input_size();
        let Some(source) = scaled_declaration(size) else {
            return false;
        };
        let exact = [
            ("source-bytes", u64::try_from(source.len()).ok()),
            (
                "vocabulary-members",
                size.checked_mul(4).and_then(|value| value.checked_add(4)),
            ),
            ("transition-edges", size.checked_sub(1)),
            (
                "policy-edges",
                size.checked_sub(1).and_then(|value| value.checked_mul(2)),
            ),
            ("association-edges", size.checked_sub(1)),
            ("planned-units", Some(PROJECTION_COUNT)),
            ("rendered-units", Some(PROJECTION_COUNT)),
            ("disposition-seats", Some(PROJECTION_COUNT)),
        ];
        if exact.into_iter().any(|(stem, expected)| {
            expected
                .and_then(|value| value.checked_mul(multiplier))
                .is_none_or(|value| count(point, stem) != Some(value))
        }) {
            return false;
        }
        let Some(growth) = growth_tuple(point) else {
            return false;
        };
        if previous_growth.is_some_and(|previous| !strictly_grows(previous, growth)) {
            return false;
        }
        previous_growth = Some(growth);
    }
    true
}

fn growth_tuple(point: &WorkCurvePoint) -> Option<[u64; 5]> {
    Some([
        count(point, "captured-trees")?,
        count(point, "generated-bytes")?,
        count(point, "canonical-bytes")?,
        count(point, "delivered-bytes")?,
        count(point, "vocabulary-members")?,
    ])
}

fn strictly_grows(earlier: [u64; 5], later: [u64; 5]) -> bool {
    earlier
        .into_iter()
        .zip(later)
        .all(|(earlier, later)| later > earlier)
}

fn invocation_curve_holds(curve: &WorkCurve, multiplier: u64) -> bool {
    let Some(first) = curve.points().first() else {
        return false;
    };
    for point in curve.points() {
        let Some(invocations) = point.input_size().checked_mul(multiplier) else {
            return false;
        };
        if count(point, "macro-invocations") != Some(invocations)
            || count(point, "planned-units") != invocations.checked_mul(PROJECTION_COUNT)
            || count(point, "rendered-units") != invocations.checked_mul(PROJECTION_COUNT)
        {
            return false;
        }
        for stem in ["generated-bytes", "delivered-bytes"] {
            let Some(base) = count(first, stem).and_then(|value| value.checked_div(multiplier))
            else {
                return false;
            };
            if count(point, stem) != base.checked_mul(invocations) {
                return false;
            }
        }
    }
    true
}

fn runtime_curve_holds(curve: &WorkCurve, kind: RuntimeCurveKind) -> bool {
    if curve.points().len() != RUNTIME_AXIS.len() {
        return false;
    }
    curve.points().iter().all(|point| {
        let size = point.input_size();
        let Some(steps) = size.checked_mul(2) else {
            return false;
        };
        let redundant = match kind {
            RuntimeCurveKind::Measured => 0,
            RuntimeCurveKind::PlantedWorse => {
                let Some(value) = size.checked_mul(size) else {
                    return false;
                };
                value
            }
        };
        count(point, "executions") == Some(size)
            && count(point, "event-steps") == Some(steps)
            && count(point, "redundant-comparisons") == Some(redundant)
            && count(point, "declared-work") == steps.checked_add(redundant)
    })
}

fn runtime_gap_holds(measured: &WorkCurve, control: &WorkCurve) -> bool {
    measured
        .points()
        .iter()
        .zip(control.points())
        .all(|(measured, control)| {
            let (Some(measured), Some(control)) = (
                count(measured, "declared-work"),
                count(control, "declared-work"),
            ) else {
                return false;
            };
            measured
                .checked_mul(2)
                .is_some_and(|floor| control >= floor)
        })
}

fn curves_scaled(measured: &WorkCurve, control: &WorkCurve, multiplier: u64) -> bool {
    measured
        .points()
        .iter()
        .zip(control.points())
        .all(|(measured, control)| {
            measured.input_size() == control.input_size()
                && measured.counts().len() == control.counts().len()
                && measured
                    .counts()
                    .iter()
                    .zip(control.counts())
                    .all(|(measured, control)| {
                        measured.observation() == control.observation()
                            && measured
                                .count()
                                .checked_mul(multiplier)
                                .is_some_and(|expected| expected == control.count())
                    })
        })
}

pub(super) fn count(point: &WorkCurvePoint, stem: &'static str) -> Option<u64> {
    let observation = WorkObservationRef::named(OWNER, stem).ok()?;
    point
        .counts()
        .iter()
        .find(|count| count.observation() == observation)
        .map(|count| count.count())
}
