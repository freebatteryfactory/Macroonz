//! Host facts, correctness preflight, and shared benchmark construction.

use super::source::{COMPILER_AXIS, compiler_metrics, render_styles_preserve_metrics};
use bakery::harness::bench::{BenchInvocation, ContentionPosture, PreflightRef, PreflightTrial};
use bakery::harness::clock::HarnessClock;
use bakery::harness::descriptor::{
    Binding, CheckRef, ClaimRef, Classification, ExecutableAttachment, ExecutionSuite, Origin,
    PopulationRef, Provenance, RevisionBinding, Role, Row, SubjectRoute, Tag,
};
use bakery::harness::identity::{ContentAddress, DomainTag, IdentityProfileVersion};
use bakery::harness::properties::{Holding, concluded};
use bakery::harness::report::{
    ByteBudget, CaseBudget, FailureClass, FindingCause, InvocationProfile, TargetBinding,
    TargetTriple, TimeBudget, ToolchainIdentity, TrialConclusion, TrialSite,
};
use bakery::harness::runner::{Invocation, TrialBinding};
use guarded_transition_subject::{Capability, Event, GuardedContract};
use std::path::Path;
use std::sync::atomic::{AtomicU64, Ordering};

pub(super) const OWNER: &str = "guarded-transition-economics";
pub(super) const TARGET: &str = "x86_64-pc-windows-msvc";
pub(super) const TOOLCHAIN: &str = "rustc 1.98.0 (88d9e12ae 2026-08-18)";
const REVISION_TAG: DomainTag = DomainTag::declared(
    "guarded-transition-economics-revision",
    IdentityProfileVersion::declared(1),
);
const PREFLIGHT_REFUSED: FindingCause = FindingCause::named(OWNER, "correctness-preflight-refused");
static CLOCK_TICKS: AtomicU64 = AtomicU64::new(0);

pub(super) fn described(error: impl core::fmt::Debug) -> String {
    format!("{error:?}")
}

pub(super) fn prove_host() -> Result<(), String> {
    let rustc = Path::new(env!("CARGO")).with_file_name("rustc.exe");
    let output = std::process::Command::new(rustc)
        .arg("-vV")
        .output()
        .map_err(described)?;
    if !output.status.success() {
        return Err("rustc host preflight failed".to_owned());
    }
    let facts = String::from_utf8(output.stdout).map_err(described)?;
    if facts.contains("release: 1.98.0") && facts.contains(&format!("host: {TARGET}")) {
        Ok(())
    } else {
        Err(format!("unexpected rustc host facts: {facts}"))
    }
}

fn clock_reading() -> u64 {
    CLOCK_TICKS.fetch_add(1, Ordering::SeqCst)
}

pub(super) fn target() -> TargetBinding {
    TargetBinding::bound(
        TargetTriple::declared(TARGET),
        ToolchainIdentity::declared(TOOLCHAIN),
    )
}

pub(super) fn bench_invocation() -> BenchInvocation {
    BenchInvocation::declared(
        target(),
        HarnessClock::reading(clock_reading),
        ContentionPosture::NoDeclaredContention,
    )
}

pub(super) fn preflight() -> Result<PreflightTrial, String> {
    let reference =
        PreflightRef::named(OWNER, "guarded-transition-correctness").map_err(described)?;
    Ok(PreflightTrial::bound(
        reference,
        trial_binding()?,
        Invocation::declared(
            InvocationProfile::declared(
                CaseBudget::declared(1),
                ByteBudget::declared(8_192),
                TimeBudget::declared(60_000_000_000),
            ),
            target(),
            TrialSite::located(module_path!(), file!(), line!(), "economics-preflight"),
            HarnessClock::unavailable(),
        ),
    ))
}

fn trial_binding() -> Result<TrialBinding, String> {
    let subject =
        SubjectRoute::named(OWNER, "exact-guarded-transition-source").map_err(described)?;
    let check = CheckRef::named(OWNER, "economics-correctness").map_err(described)?;
    let row = Row::declared(
        ClaimRef::named(OWNER, "economics-measures-correct-work").map_err(described)?,
        ExecutionSuite::named(OWNER, "typed-scaling").map_err(described)?,
        Classification::authored(
            vec![Role::named(OWNER, "benchmark").map_err(described)?],
            vec![Tag::named(OWNER, "guarded-transition").map_err(described)?],
        )
        .map_err(described)?,
        subject,
        check,
        PopulationRef::named(OWNER, "declared-scaling-axes").map_err(described)?,
        Origin::HandWritten,
    )
    .map_err(described)?;
    let revision = RevisionBinding::declared(ContentAddress::derived(
        REVISION_TAG,
        include_bytes!("../../../guarded-transition-subject-macros/src/engine.rs"),
    ));
    Binding::bound(
        row,
        ExecutableAttachment::attached(subject, check, revision, revision, correctness_preflight),
        Provenance::Unproduced,
    )
    .map_err(described)
}

fn correctness_preflight(_invocation: &Invocation) -> TrialConclusion {
    if compiler_scaling_holds() && render_styles_preserve_metrics(8) && semantic_parity_holds() {
        TrialConclusion::Passed
    } else {
        concluded(
            Holding::Fails,
            FailureClass::PropertyDisagreement,
            PREFLIGHT_REFUSED,
        )
    }
}

fn compiler_scaling_holds() -> bool {
    let metrics = COMPILER_AXIS
        .into_iter()
        .map(compiler_metrics)
        .collect::<Option<Vec<_>>>();
    let Some(metrics) = metrics else {
        return false;
    };
    metrics.windows(2).all(|pair| {
        let [earlier, later] = pair else {
            return false;
        };
        later.source_bytes > earlier.source_bytes
            && later.captured_trees > earlier.captured_trees
            && later.vocabulary_members > earlier.vocabulary_members
            && later.transition_edges > earlier.transition_edges
            && later.policy_edges > earlier.policy_edges
            && later.generated_bytes > earlier.generated_bytes
            && later.canonical_bytes > earlier.canonical_bytes
            && later.delivered_bytes > earlier.delivered_bytes
    })
}

fn semantic_parity_holds() -> bool {
    let events = [Event::Arm, Event::Finish];
    let generated = guarded_transition_subject::generated::GeneratedRoad::execute(
        Capability::Elevated,
        &events,
        0,
    );
    let handwritten = guarded_transition_subject::handwritten::HandwrittenRoad::execute(
        Capability::Elevated,
        &events,
        0,
    );
    let planted = guarded_transition_subject::planted_wrong::GeneratedRoad::execute(
        Capability::Elevated,
        &events,
        0,
    );
    generated.is_ok() && generated == handwritten && generated != planted
}
