//! Declared scaling inputs and the exact compiler readings they produce.

use super::engine::{self, GuardedDeclaration, RenderStyle};
use bakery::compiler::{CanonicalContent, CapturedTokenTree, TextCapture};

pub(super) const COMPILER_AXIS: [u64; 3] = [2, 4, 8];
pub(super) const INVOCATION_AXIS: [u64; 4] = [1, 2, 4, 8];
pub(super) const RUNTIME_AXIS: [u64; 3] = [2, 4, 8];
pub(super) const PROJECTION_COUNT: u64 = 6;

#[derive(Debug, Clone, PartialEq, Eq)]
pub(super) struct CompilerMetrics {
    pub(super) source_bytes: u64,
    pub(super) captured_trees: u64,
    pub(super) captured_depth: u64,
    pub(super) vocabulary_members: u64,
    pub(super) transition_edges: u64,
    pub(super) policy_edges: u64,
    pub(super) association_edges: u64,
    pub(super) planned_units: u64,
    pub(super) rendered_units: u64,
    pub(super) generated_bytes: u64,
    pub(super) canonical_bytes: u64,
    pub(super) explanation_seats: u64,
    pub(super) disposition_seats: u64,
    pub(super) delivered_bytes: u64,
}

pub(super) fn scaled_declaration(size: u64) -> Option<String> {
    let size = usize::try_from(size).ok()?;
    if !(2..=8).contains(&size) {
        return None;
    }
    let mut source = String::new();
    roster(&mut source, "states", "S", size);
    roster(&mut source, "events", "E", size.saturating_sub(1));
    source.push_str("initial { S0 }\nterminal { S");
    source.push_str(&size.saturating_sub(1).to_string());
    source.push_str(" }\ntransitions { ");
    transitions(&mut source, size);
    source.push_str("}\neffects { ");
    effects(&mut source, size);
    source.push_str("}\n");
    roster(&mut source, "capabilities", "C", size);
    roster(&mut source, "operations", "O", size.saturating_sub(1));
    source.push_str("associations { ");
    associations(&mut source, size);
    source.push_str("}\npolicies { ");
    policies(&mut source, size);
    source.push_str(
        "}\nprojections { production, property, mutation, benchmark, compile, receipt, }\n",
    );
    Some(source)
}

fn roster(into: &mut String, name: &str, prefix: &str, count: usize) {
    into.push_str(name);
    into.push_str(" { ");
    for ordinal in 0..count {
        into.push_str(prefix);
        into.push_str(&ordinal.to_string());
        into.push_str(", ");
    }
    into.push_str("}\n");
}

fn transitions(into: &mut String, size: usize) {
    for ordinal in 0..size.saturating_sub(1) {
        into.push('S');
        into.push_str(&ordinal.to_string());
        into.push_str(" + E");
        into.push_str(&ordinal.to_string());
        into.push_str(" -> S");
        into.push_str(&ordinal.saturating_add(1).to_string());
        into.push_str(", ");
    }
}

fn effects(into: &mut String, size: usize) {
    for ordinal in 0..size.saturating_sub(1) {
        into.push('S');
        into.push_str(&ordinal.to_string());
        into.push_str(" + E");
        into.push_str(&ordinal.to_string());
        into.push_str(" -> S");
        into.push_str(&ordinal.saturating_add(1).to_string());
        into.push_str(" = Fx");
        into.push_str(&ordinal.to_string());
        into.push_str(" add(");
        into.push_str(&ordinal.saturating_add(1).to_string());
        into.push_str("), ");
    }
}

fn associations(into: &mut String, size: usize) {
    for ordinal in 0..size.saturating_sub(1) {
        into.push('E');
        into.push_str(&ordinal.to_string());
        into.push_str(" => O");
        into.push_str(&ordinal.to_string());
        into.push_str(", ");
    }
}

fn policies(into: &mut String, size: usize) {
    for ordinal in 0..size.saturating_sub(1) {
        into.push_str("C0 => O");
        into.push_str(&ordinal.to_string());
        into.push_str(", C");
        into.push_str(&ordinal.saturating_add(1).to_string());
        into.push_str(" => O");
        into.push_str(&ordinal.to_string());
        into.push_str(", ");
    }
}

pub(super) fn compiler_metrics(size: u64) -> Option<CompilerMetrics> {
    let source = scaled_declaration(size)?;
    let captured = TextCapture::read(&source).ok()?;
    let (captured_trees, captured_depth) = tree_shape(captured.input().trees(), 1);
    let declaration = engine::read_declaration(captured.input()).ok()?;
    let accounted = engine::compile(captured.input().clone(), RenderStyle::Direct).ok()?;
    metrics(
        u64::try_from(source.len()).ok()?,
        captured_trees,
        captured_depth,
        &declaration,
        &accounted,
    )
}

pub(super) fn render_styles_preserve_metrics(size: u64) -> bool {
    render_style_metrics(size).is_some_and(|(direct, refactored)| direct == refactored)
}

fn render_style_metrics(size: u64) -> Option<(CompilerMetrics, CompilerMetrics)> {
    let source = scaled_declaration(size)?;
    let captured = TextCapture::read(&source).ok()?;
    let (captured_trees, captured_depth) = tree_shape(captured.input().trees(), 1);
    let declaration = engine::read_declaration(captured.input()).ok()?;
    let direct = engine::compile(captured.input().clone(), RenderStyle::Direct).ok()?;
    let refactored = engine::compile(captured.input().clone(), RenderStyle::Refactored).ok()?;
    let source_bytes = u64::try_from(source.len()).ok()?;
    let direct_metrics = metrics(
        source_bytes,
        captured_trees,
        captured_depth,
        &declaration,
        &direct,
    )?;
    let refactored_metrics = metrics(
        source_bytes,
        captured_trees,
        captured_depth,
        &declaration,
        &refactored,
    )?;
    Some((direct_metrics, refactored_metrics))
}

fn metrics(
    source_bytes: u64,
    captured_trees: u64,
    captured_depth: u64,
    declaration: &GuardedDeclaration,
    accounted: &bakery::compiler::Accounted<engine::GuardedProjection, engine::ProjectionKinds>,
) -> Option<CompilerMetrics> {
    let expansion = accounted.expansion();
    let rendered = expansion.closure().rendered();
    let generated_bytes = rendered.units().iter().try_fold(0_u64, |total, unit| {
        let width = u64::try_from(unit.bytes().len()).ok()?;
        total.checked_add(width)
    })?;
    let delivered_bytes = expansion
        .emit()
        .tokens()
        .and_then(|tree| u64::try_from(tree.canonical_bytes().len()).ok())
        .unwrap_or(0);
    Some(CompilerMetrics {
        source_bytes,
        captured_trees,
        captured_depth,
        vocabulary_members: vocabulary_members(declaration)?,
        transition_edges: u64::try_from(declaration.effects.denominator().count()).ok()?,
        policy_edges: u64::try_from(declaration.policies.count()).ok()?,
        association_edges: u64::try_from(declaration.associations.count()).ok()?,
        planned_units: u64::try_from(expansion.plan().membership().count()).ok()?,
        rendered_units: u64::try_from(rendered.count()).ok()?,
        generated_bytes,
        canonical_bytes: u64::try_from(declaration.canonical_content_bytes().len()).ok()?,
        explanation_seats: u64::try_from(expansion.explain().seats()).ok()?,
        disposition_seats: u64::try_from(accounted.dispositions().len()).ok()?,
        delivered_bytes,
    })
}

fn vocabulary_members(declaration: &GuardedDeclaration) -> Option<u64> {
    [
        declaration.states.count(),
        declaration.associations.denominator().count(),
        declaration.capabilities.count(),
        declaration.operations.count(),
        declaration.projections.count(),
    ]
    .into_iter()
    .try_fold(0_u64, |total, count| {
        total.checked_add(u64::try_from(count).ok()?)
    })
}

fn tree_shape(trees: &[CapturedTokenTree], depth: u64) -> (u64, u64) {
    let mut count = u64::try_from(trees.len()).unwrap_or(u64::MAX);
    let mut greatest = depth;
    for tree in trees {
        if let Some((_delimiter, members)) = tree.group() {
            let (nested, nested_depth) = tree_shape(members, depth.saturating_add(1));
            count = count.saturating_add(nested);
            greatest = greatest.max(nested_depth);
        }
    }
    (count, greatest)
}

pub(super) fn baseline_metrics() -> Option<CompilerMetrics> {
    let source = include_str!("../../../guarded-transition-subject/src/lib.rs");
    let start = source.find("states { Idle, Armed, Done, }")?;
    let end_marker = "projections { production, property, mutation, benchmark, compile, receipt, }";
    let relative_end = source.get(start..)?.find(end_marker)?;
    let end = start
        .checked_add(relative_end)?
        .checked_add(end_marker.len())?;
    let declaration_source = source.get(start..end)?;
    let captured = TextCapture::read(declaration_source).ok()?;
    let (trees, depth) = tree_shape(captured.input().trees(), 1);
    let declaration = engine::read_declaration(captured.input()).ok()?;
    let accounted = engine::compile(captured.input().clone(), RenderStyle::Direct).ok()?;
    metrics(
        u64::try_from(declaration_source.len()).ok()?,
        trees,
        depth,
        &declaration,
        &accounted,
    )
}
