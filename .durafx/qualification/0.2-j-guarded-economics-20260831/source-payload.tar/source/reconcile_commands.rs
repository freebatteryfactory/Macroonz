#![forbid(unsafe_code)]
#![deny(warnings)]

use std::env;
use std::fs;
use std::io::Write as _;

const HEADER: &str = "label\tsample\telapsed-ms\texit-code\tstdout-bytes\tstderr-bytes\ttarget-before-bytes\ttarget-after-bytes";
const PRE_CURE: [&str; 3] = [
    "coverage-readback\t1\t83\t0\t2377\t0\t1720503\t1721044",
    "coverage-readback\t2\t16\t0\t2377\t0\t1720503\t1721044",
    "coverage-readback\t3\t15\t0\t2377\t0\t1720503\t1721044",
];
const FIXED: [&str; 3] = [
    "coverage-readback-fixed\t1\t82\t0\t2377\t0\t1721044\t1721044",
    "coverage-readback-fixed\t2\t16\t0\t2377\t0\t1721044\t1721044",
    "coverage-readback-fixed\t3\t17\t0\t2377\t0\t1721044\t1721044",
];

fn main() -> Result<(), String> {
    let arguments = env::args_os().skip(1).collect::<Vec<_>>();
    let [raw_path, fixed_path, output_path] = arguments.as_slice() else {
        return Err("expected RAW_COMMANDS FIXED_COMMANDS OUTPUT".to_owned());
    };
    let raw = fs::read_to_string(raw_path).map_err(described)?;
    let fixed = fs::read_to_string(fixed_path).map_err(described)?;
    let fixed_lines = fixed.lines().collect::<Vec<_>>();
    let expected_fixed = std::iter::once(HEADER)
        .chain(FIXED)
        .collect::<Vec<_>>();
    if fixed_lines != expected_fixed {
        return Err("fixed-source command stream did not match its exact retained rows".to_owned());
    }
    let mut raw_lines = raw.lines();
    if raw_lines.next() != Some(HEADER) {
        return Err("raw command stream header moved".to_owned());
    }
    let mut output = fs::File::create(output_path).map_err(described)?;
    writeln!(output, "{HEADER}").map_err(described)?;
    let mut replacements = 0_usize;
    for line in raw_lines {
        if let Some(position) = PRE_CURE.iter().position(|candidate| *candidate == line) {
            let retained = FIXED
                .get(position)
                .ok_or_else(|| "fixed row position was absent".to_owned())?
                .replacen("coverage-readback-fixed", "coverage-readback", 1);
            writeln!(output, "{retained}").map_err(described)?;
            replacements = replacements
                .checked_add(1)
                .ok_or_else(|| "replacement count overflowed".to_owned())?;
        } else {
            if line.starts_with("coverage-readback\t") {
                return Err("raw command stream carried an unexpected coverage-readback row".to_owned());
            }
            writeln!(output, "{line}").map_err(described)?;
        }
    }
    if replacements != PRE_CURE.len() {
        return Err(format!(
            "replaced {replacements} coverage-readback rows rather than {}",
            PRE_CURE.len()
        ));
    }
    Ok(())
}

fn described(error: impl core::fmt::Debug) -> String {
    format!("{error:?}")
}
