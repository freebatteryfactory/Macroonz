#![forbid(unsafe_code)]
#![deny(warnings)]

use std::env;
use std::fs;
use std::io::Write;
use std::path::Path;
use std::process::{Command, Stdio};

fn main() -> Result<(), String> {
    let arguments = env::args_os().skip(1).collect::<Vec<_>>();
    match arguments.as_slice() {
        [operation, program, profile, input] if operation == "run" => {
            run(program.as_ref(), profile.as_ref(), input.to_str())
        }
        [operation, directory] if operation == "cleanup" => cleanup(directory.as_ref()),
        _ => Err("expected run PROGRAM PROFILE BYTE_CSV or cleanup DIRECTORY".to_owned()),
    }
}

fn run(program: &Path, profile: &Path, input: Option<&str>) -> Result<(), String> {
    let input = input
        .ok_or_else(|| "input was not text".to_owned())?
        .split(',')
        .map(|value| value.parse::<u8>().map_err(described))
        .collect::<Result<Vec<_>, _>>()?;
    let mut child = Command::new(program)
        .env("LLVM_PROFILE_FILE", profile)
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn()
        .map_err(described)?;
    child
        .stdin
        .take()
        .ok_or_else(|| "child stdin was absent".to_owned())?
        .write_all(&input)
        .map_err(described)?;
    let output = child.wait_with_output().map_err(described)?;
    if !output.status.success() {
        return Err(format!("coverage subject exited {:?}", output.status.code()));
    }
    if !output.stdout.is_empty() || !output.stderr.is_empty() {
        return Err("coverage subject wrote unexpected output".to_owned());
    }
    let bytes = fs::metadata(profile).map_err(described)?.len();
    writeln!(std::io::stdout().lock(), "profile-bytes={bytes}").map_err(described)
}

fn cleanup(directory: &Path) -> Result<(), String> {
    let marker = directory.join(".wave-j-coverage-cleanup");
    if fs::read(&marker).map_err(described)? != b"wave-j-coverage-cleanup\n" {
        return Err("cleanup marker did not carry the exact authority bytes".to_owned());
    }
    let mut entries = fs::read_dir(directory)
        .map_err(described)?
        .map(|entry| entry.map_err(described))
        .collect::<Result<Vec<_>, _>>()?;
    entries.sort_by_key(fs::DirEntry::file_name);
    for entry in entries {
        let name = entry.file_name();
        let name = name
            .to_str()
            .ok_or_else(|| "cleanup entry name was not UTF-8".to_owned())?;
        if !matches!(
            name,
            ".wave-j-coverage-cleanup"
                | "coverage-subject.exe"
                | "coverage.profraw"
                | "coverage.profdata"
                | "coverage.lcov"
        ) {
            return Err(format!("cleanup directory contained unexpected entry {name}"));
        }
        if !entry.file_type().map_err(described)?.is_file() {
            return Err(format!("cleanup entry {name} was not a file"));
        }
    }
    for name in [
        "coverage-subject.exe",
        "coverage.profraw",
        "coverage.profdata",
        "coverage.lcov",
        ".wave-j-coverage-cleanup",
    ] {
        let file = directory.join(name);
        if file.exists() {
            fs::remove_file(file).map_err(described)?;
        }
    }
    fs::remove_dir(directory).map_err(described)
}

fn described(error: impl core::fmt::Debug) -> String {
    format!("{error:?}")
}
