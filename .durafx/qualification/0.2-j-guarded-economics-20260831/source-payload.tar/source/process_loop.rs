#![forbid(unsafe_code)]
#![deny(warnings)]

use std::env;
use std::io::Write;
use std::process::Command;

fn main() -> Result<(), String> {
    let arguments = env::args_os().skip(1).collect::<Vec<_>>();
    let [program, iterations] = arguments.as_slice() else {
        return Err("expected PROGRAM ITERATIONS".to_owned());
    };
    let iterations = iterations
        .to_str()
        .ok_or_else(|| "iteration count was not text".to_owned())?
        .parse::<u64>()
        .map_err(described)?;
    if iterations == 0 {
        return Err("iteration count must be positive".to_owned());
    }
    let mut expected = None;
    for _iteration in 0..iterations {
        let result = Command::new(program).output().map_err(described)?;
        if !result.status.success() {
            return Err(format!("child exited {:?}", result.status.code()));
        }
        if let Some(prior) = &expected {
            if prior != &result.stdout {
                return Err("child output moved inside one sample".to_owned());
            }
        } else {
            expected = Some(result.stdout);
        }
        if !result.stderr.is_empty() {
            return Err("child wrote to stderr".to_owned());
        }
    }
    std::io::stdout()
        .lock()
        .write_all(expected.as_deref().unwrap_or_default())
        .map_err(described)
}

fn described(error: impl core::fmt::Debug) -> String {
    format!("{error:?}")
}
