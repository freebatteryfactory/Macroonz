#![forbid(unsafe_code)]
#![deny(warnings)]

use std::collections::BTreeMap;
use std::env;
use std::fs;
use std::io::Write;

const LABELS: [(&str, usize); 16] = [
    ("carrier-defined", 3),
    ("carrier-invoked", 3),
    ("subject-cold", 3),
    ("subject-warm-noop", 3),
    ("subject-incremental-declaration-valid", 3),
    ("subject-incremental-unrelated-valid", 3),
    ("runtime-generated-sample", 3),
    ("runtime-handwritten-sample", 3),
    ("runtime-refactored-sample", 3),
    ("coverage-compile", 3),
    ("coverage-run", 3),
    ("coverage-merge", 3),
    ("coverage-export", 3),
    ("coverage-readback", 3),
    ("coverage-cleanup", 3),
    ("coverage-parse-sample", 5),
];

#[derive(Debug, Clone, Copy)]
struct Observation {
    sample: u64,
    elapsed_ms: u64,
    exit_code: i32,
    target_before_bytes: u64,
    target_after_bytes: u64,
}

fn main() -> Result<(), String> {
    let arguments = env::args_os().skip(1).collect::<Vec<_>>();
    let [input, output] = arguments.as_slice() else {
        return Err("expected INPUT_TSV OUTPUT_TSV".to_owned());
    };
    let source = fs::read_to_string(input).map_err(described)?;
    let mut rows = BTreeMap::<String, Vec<Observation>>::new();
    for (line_number, line) in source.lines().enumerate().skip(1) {
        let fields = line.split('\t').collect::<Vec<_>>();
        let [label, sample, elapsed_ms, exit_code, _stdout_bytes, _stderr_bytes, target_before_bytes, target_after_bytes] =
            fields.as_slice()
        else {
            return Err(format!("line {} did not carry eight fields", line_number + 1));
        };
        rows.entry((*label).to_owned()).or_default().push(Observation {
            sample: parsed(sample)?,
            elapsed_ms: parsed(elapsed_ms)?,
            exit_code: parsed(exit_code)?,
            target_before_bytes: parsed(target_before_bytes)?,
            target_after_bytes: parsed(target_after_bytes)?,
        });
    }
    let mut output = fs::File::create(output).map_err(described)?;
    writeln!(
        output,
        "label\tsamples-ms\tmedian-ms\tminimum-ms\tmaximum-ms\tdispersion-ms\ttarget-before-median-bytes\ttarget-after-median-bytes"
    )
    .map_err(described)?;
    for (label, denominator) in LABELS {
        let observations = rows
            .get(label)
            .ok_or_else(|| format!("required label {label} was absent"))?;
        if observations.len() != denominator {
            return Err(format!(
                "label {label} carried {} observations rather than {denominator}",
                observations.len()
            ));
        }
        let mut ordinals = observations.iter().map(|row| row.sample).collect::<Vec<_>>();
        ordinals.sort_unstable();
        ordinals.dedup();
        if ordinals.len() != denominator || observations.iter().any(|row| row.exit_code != 0) {
            return Err(format!("label {label} had duplicate samples or a nonzero exit"));
        }
        let elapsed = observations.iter().map(|row| row.elapsed_ms).collect::<Vec<_>>();
        let before = observations
            .iter()
            .map(|row| row.target_before_bytes)
            .collect::<Vec<_>>();
        let after = observations
            .iter()
            .map(|row| row.target_after_bytes)
            .collect::<Vec<_>>();
        let mut elapsed_sorted = elapsed.clone();
        elapsed_sorted.sort_unstable();
        writeln!(
            output,
            "{label}\t{}\t{}\t{}\t{}\t{}\t{}\t{}",
            joined(&elapsed),
            median(&elapsed)?,
            elapsed_sorted.first().copied().unwrap_or_default(),
            elapsed_sorted.last().copied().unwrap_or_default(),
            dispersion(&elapsed)?,
            median(&before)?,
            median(&after)?,
        )
        .map_err(described)?;
    }
    let defined = rows
        .get("carrier-defined")
        .ok_or_else(|| "carrier-defined rows were absent".to_owned())?;
    let invoked = rows
        .get("carrier-invoked")
        .ok_or_else(|| "carrier-invoked rows were absent".to_owned())?;
    let added = defined
        .iter()
        .zip(invoked)
        .map(|(defined, invoked)| {
            if defined.sample != invoked.sample
                || defined.target_after_bytes != invoked.target_before_bytes
            {
                return Err("carrier sample coordinates did not join exactly".to_owned());
            }
            invoked
                .target_after_bytes
                .checked_sub(defined.target_after_bytes)
                .ok_or_else(|| "carrier target bytes moved backward".to_owned())
        })
        .collect::<Result<Vec<_>, _>>()?;
    writeln!(
        output,
        "carrier-invoked-added-target-bytes\t{}\t{}\t{}\t{}\t{}\t0\t{}",
        joined(&added),
        median(&added)?,
        added.iter().min().copied().unwrap_or_default(),
        added.iter().max().copied().unwrap_or_default(),
        dispersion(&added)?,
        median(&added)?,
    )
    .map_err(described)
}

fn parsed<T: core::str::FromStr>(value: &str) -> Result<T, String>
where
    T::Err: core::fmt::Debug,
{
    value.parse().map_err(described)
}

fn median(values: &[u64]) -> Result<u64, String> {
    if values.is_empty() || values.len().is_multiple_of(2) {
        return Err("median requires a nonempty odd denominator".to_owned());
    }
    let mut sorted = values.to_vec();
    sorted.sort_unstable();
    sorted
        .get(sorted.len() / 2)
        .copied()
        .ok_or_else(|| "median position was absent".to_owned())
}

fn dispersion(values: &[u64]) -> Result<u64, String> {
    let minimum = values.iter().min().copied().ok_or_else(|| "minimum was absent".to_owned())?;
    let maximum = values.iter().max().copied().ok_or_else(|| "maximum was absent".to_owned())?;
    maximum
        .checked_sub(minimum)
        .ok_or_else(|| "dispersion moved backward".to_owned())
}

fn joined(values: &[u64]) -> String {
    values
        .iter()
        .map(u64::to_string)
        .collect::<Vec<_>>()
        .join(";")
}

fn described(error: impl core::fmt::Debug) -> String {
    format!("{error:?}")
}
