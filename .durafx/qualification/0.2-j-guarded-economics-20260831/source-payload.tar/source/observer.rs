#![forbid(unsafe_code)]
#![deny(warnings)]

use std::env;
use std::fs::{self, OpenOptions};
use std::io::Write;
use std::path::{Path, PathBuf};
use std::process::Command;
use std::time::Instant;

fn main() -> Result<(), String> {
    let arguments = env::args_os().skip(1).collect::<Vec<_>>();
    let [output, log_directory, label, sample, working_directory, target_directory, program, command_arguments @ ..] =
        arguments.as_slice()
    else {
        return Err("expected OUTPUT LOG_DIRECTORY LABEL SAMPLE WORKING_DIRECTORY TARGET_DIRECTORY PROGRAM [ARGUMENTS...]".to_owned());
    };
    let label = label
        .to_str()
        .filter(|value| !value.contains(['\t', '\r', '\n']))
        .ok_or_else(|| "label was not one host-neutral TSV field".to_owned())?;
    let sample = sample
        .to_str()
        .filter(|value| !value.contains(['\t', '\r', '\n']))
        .ok_or_else(|| "sample was not one host-neutral TSV field".to_owned())?;
    fs::create_dir_all(log_directory).map_err(described)?;
    let before = directory_bytes(Path::new(target_directory))?;
    let started = Instant::now();
    let result = Command::new(program)
        .args(command_arguments)
        .current_dir(working_directory)
        .output()
        .map_err(described)?;
    let elapsed = started.elapsed().as_millis();
    let after = directory_bytes(Path::new(target_directory))?;
    let log_stem = format!("{label}-{sample}");
    fs::write(
        Path::new(log_directory).join(format!("{log_stem}.stdout")),
        &result.stdout,
    )
    .map_err(described)?;
    fs::write(
        Path::new(log_directory).join(format!("{log_stem}.stderr")),
        &result.stderr,
    )
    .map_err(described)?;
    let mut output = OpenOptions::new()
        .create(true)
        .append(true)
        .open(output)
        .map_err(described)?;
    if output.metadata().map_err(described)?.len() == 0 {
        writeln!(
            output,
            "label\tsample\telapsed-ms\texit-code\tstdout-bytes\tstderr-bytes\ttarget-before-bytes\ttarget-after-bytes"
        )
        .map_err(described)?;
    }
    writeln!(
        output,
        "{label}\t{sample}\t{elapsed}\t{}\t{}\t{}\t{before}\t{after}",
        result.status.code().map_or(-1, i32::from),
        result.stdout.len(),
        result.stderr.len(),
    )
    .map_err(described)?;
    if result.status.success() {
        Ok(())
    } else {
        Err(format!(
            "{label} sample {sample} exited {:?}",
            result.status.code()
        ))
    }
}

fn directory_bytes(path: &Path) -> Result<u64, String> {
    if !path.exists() {
        return Ok(0);
    }
    let mut total = 0_u64;
    let mut pending = vec![PathBuf::from(path)];
    while let Some(directory) = pending.pop() {
        for entry in fs::read_dir(directory).map_err(described)? {
            let entry = entry.map_err(described)?;
            let kind = entry.file_type().map_err(described)?;
            if kind.is_dir() {
                pending.push(entry.path());
            } else if kind.is_file() {
                total = total
                    .checked_add(entry.metadata().map_err(described)?.len())
                    .ok_or_else(|| "target-directory byte total overflowed u64".to_owned())?;
            } else {
                return Err("target directory contained a non-file, non-directory entry".to_owned());
            }
        }
    }
    Ok(total)
}

fn described(error: impl core::fmt::Debug) -> String {
    format!("{error:?}")
}
