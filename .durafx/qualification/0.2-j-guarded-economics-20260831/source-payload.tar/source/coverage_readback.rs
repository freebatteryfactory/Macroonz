#![forbid(unsafe_code)]
#![deny(warnings)]

use bakery::harness::descriptor::NamespacedName;
use bakery::harness::fuzz::{CoverageSourceRoot, read_lcov};
use std::fmt::Write as _;
use std::io::Write as _;
use std::path::PathBuf;

fn main() -> Result<(), String> {
    let raw_path = "measurement-source/coverage-stage/coverage-raw.lcov";
    let neutral_path = "measurement-source/coverage-stage/coverage-neutral.lcov";
    let raw = std::fs::read_to_string(raw_path).map_err(described)?;
    let mut neutral = String::new();
    let mut source_records = 0_usize;
    for line in raw.lines() {
        if line.starts_with("SF:") {
            source_records = source_records
                .checked_add(1)
                .ok_or_else(|| "source-record count overflowed".to_owned())?;
            writeln!(neutral, "SF:C:\\qualification\\subject.rs").map_err(described)?;
        } else {
            writeln!(neutral, "{line}").map_err(described)?;
        }
    }
    if source_records != 1 {
        return Err(format!(
            "expected one source record, found {source_records}"
        ));
    }
    std::fs::write(neutral_path, neutral.as_bytes()).map_err(described)?;
    let logical = NamespacedName::named("guarded-transition-economics", "coverage-stage")
        .map_err(described)?;
    let source_root = CoverageSourceRoot::declared(logical, PathBuf::from(r"C:\qualification"))
        .map_err(described)?;
    let observation = read_lcov(&source_root, neutral.as_bytes()).map_err(described)?;
    writeln!(
        std::io::stdout().lock(),
        "coverage-unit=stable-source-regions-and-points;points={:?}",
        observation.points()
    )
    .map_err(described)
}

fn described(error: impl core::fmt::Debug) -> String {
    format!("{error:?}")
}
