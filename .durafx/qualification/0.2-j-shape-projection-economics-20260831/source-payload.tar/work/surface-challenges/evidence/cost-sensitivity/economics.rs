//! The scratch challenge's explicit planted-control magnitude.

/// The number of complete accounting passes required by the planted-worse control.
#[must_use]
pub const fn planted_worse_accounting_passes() -> u64 {
    2
}
