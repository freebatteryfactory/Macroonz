#![forbid(unsafe_code)]
#![deny(warnings)]

pub mod economics;

/// The exact read-back line emitted by the challenge binaries.
#[must_use]
pub const fn readback_line(value: u64) -> ReadBackLine {
    ReadBackLine(value)
}

/// A display-only read-back value for the external challenge process.
pub struct ReadBackLine(u64);

impl core::fmt::Display for ReadBackLine {
    fn fmt(&self, formatter: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        write!(formatter, "VALUE={}", self.0)
    }
}
