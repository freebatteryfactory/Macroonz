#![forbid(unsafe_code)]
#![deny(warnings)]

use bakery::harness::clock::{HarnessClock, MeasurementReading};
use bakery::harness::descriptor::{
    AuthoredTableName, Binding, CheckRef, ClaimRef, Classification, DerivedRevision,
    ExecutableAttachment, ExecutionSuite, Origin, PopulationRef, Provenance, RevisionBinding, Role,
    Row, SubjectRoute, Tag,
};
use bakery::harness::oracle::{
    CompilationDisagreement, CompilationVerdict, CompiledDisagreement, CompiledObservation,
    CompiledVerdict, DeclaredBehavior, DeclaredCompilation, DeclaredReadBack,
    DeclaredReadBackRoster, DiagnosticAnchor, ObservedCompilation, ObservedMember, ObservedValue,
    PrimarySourceSpan, RelativeSourcePath, RustcErrorCode, SourcePosition,
};
use bakery::harness::report::{
    ByteBudget, CaseBudget, CheckRevisionId, FailureClass, FindingLocation, HostTrialRecord,
    InvocationProfile, ReplayPosture, RunAttempt, SubjectRevisionId, TargetBinding, TargetTriple,
    TimeBudget, ToolchainIdentity, TrialConclusion, TrialReport, TrialSite,
};
use bakery::harness::runner::{
    Invocation, Selection, SelectionPlan, TrialBinding, TrialTable, record_all, record_one,
    trial_identity,
};
use std::path::Path;
use std::process::{Command, ExitStatus, Output, Stdio};
use std::sync::mpsc::{self, RecvTimeoutError};
use std::time::Duration;

const OWNER: &str = "surface-challenges";
const TARGET: &str = "x86_64-pc-windows-msvc";
const TOOLCHAIN: &str = "rustc 1.98.0";
const HOST_CEILING: Duration = Duration::from_secs(60);

struct AdmissionCase {
    stem: &'static str,
    revision_material: &'static [u8],
    conclusion: TrialConclusion,
    expected_cause: Option<&'static str>,
}

#[test]
fn generated_and_handwritten_roads_execute_and_enter_report_standing() -> Result<(), String> {
    prove_host()?;
    admit(&admission_cases()?)
}

fn readback_verdicts() -> Result<(CompiledVerdict, CompiledVerdict, CompiledVerdict), String> {
    let generated = executed_readback(
        env!("CARGO_BIN_EXE_generated-readback"),
        "generated-readback",
    )?;
    let handwritten = executed_readback(
        env!("CARGO_BIN_EXE_handwritten-readback"),
        "handwritten-readback",
    )?;
    assert_eq!(generated, handwritten);
    let lawful_members = [DeclaredReadBack {
        name: "VALUE",
        value: ObservedValue::Count(73),
    }];
    let lawful_roster = DeclaredReadBackRoster::declared(&lawful_members)
        .map_err(|refusal| format!("lawful read-back roster refused: {refusal:?}"))?;
    let generated_verdict = bakery::harness::oracle::compiled::compared(
        &generated,
        &DeclaredBehavior::ReadsBack(lawful_roster),
    );
    let handwritten_verdict = bakery::harness::oracle::compiled::compared(
        &handwritten,
        &DeclaredBehavior::ReadsBack(lawful_roster),
    );
    assert_eq!(generated_verdict, CompiledVerdict::Conforms);
    assert_eq!(handwritten_verdict, CompiledVerdict::Conforms);
    let wrong_members = [DeclaredReadBack {
        name: "VALUE",
        value: ObservedValue::Count(74),
    }];
    let wrong_roster = DeclaredReadBackRoster::declared(&wrong_members)
        .map_err(|refusal| format!("wrong-value roster refused: {refusal:?}"))?;
    let wrong_value = bakery::harness::oracle::compiled::compared(
        &generated,
        &DeclaredBehavior::ReadsBack(wrong_roster),
    );
    assert_eq!(
        wrong_value,
        CompiledVerdict::Deviates(CompiledDisagreement::MemberValue {
            member: "VALUE".to_owned(),
        })
    );
    Ok((generated_verdict, handwritten_verdict, wrong_value))
}

fn diagnostic_verdicts()
-> Result<(CompilationVerdict, CompilationVerdict, CompilationVerdict), String> {
    let observed_refusal = observed_macro_removed()?;
    let exact_anchor = anchor("E0425", 7, 10, 26)?;
    assert_eq!(observed_refusal.refusal(), Some(&exact_anchor));
    let exact_diagnostic = bakery::harness::oracle::compiled::compared_compilation(
        &observed_refusal,
        &DeclaredCompilation::refuses(exact_anchor.clone()),
    );
    assert_eq!(exact_diagnostic, CompilationVerdict::Conforms);

    let wrong_code_anchor = anchor("E0433", 7, 10, 26)?;
    let wrong_code = bakery::harness::oracle::compiled::compared_compilation(
        &observed_refusal,
        &DeclaredCompilation::refuses(wrong_code_anchor.clone()),
    );
    assert_eq!(
        wrong_code,
        CompilationVerdict::Deviates(CompilationDisagreement::ErrorCode {
            expected: wrong_code_anchor.code().clone(),
            observed: exact_anchor.code().clone(),
        })
    );

    let wrong_span_anchor = anchor("E0425", 7, 11, 27)?;
    let wrong_span = bakery::harness::oracle::compiled::compared_compilation(
        &observed_refusal,
        &DeclaredCompilation::refuses(wrong_span_anchor.clone()),
    );
    assert_eq!(
        wrong_span,
        CompilationVerdict::Deviates(CompilationDisagreement::PrimarySpan {
            expected: wrong_span_anchor.primary().clone(),
            observed: exact_anchor.primary().clone(),
        })
    );
    Ok((exact_diagnostic, wrong_code, wrong_span))
}

fn admission_cases() -> Result<Vec<AdmissionCase>, String> {
    let (generated, handwritten, wrong_value) = readback_verdicts()?;
    let (exact_diagnostic, wrong_code, wrong_span) = diagnostic_verdicts()?;
    Ok(vec![
        AdmissionCase {
            stem: "generated-readback",
            revision_material: include_bytes!("../src/bin/generated_readback.rs"),
            conclusion: generated.concluded(FindingLocation::at(file!(), line!())),
            expected_cause: None,
        },
        AdmissionCase {
            stem: "handwritten-readback",
            revision_material: include_bytes!("../src/bin/handwritten_readback.rs"),
            conclusion: handwritten.concluded(FindingLocation::at(file!(), line!())),
            expected_cause: None,
        },
        AdmissionCase {
            stem: "wrong-value-control",
            revision_material: include_bytes!("../src/bin/generated_readback.rs"),
            conclusion: wrong_value.concluded(FindingLocation::at(file!(), line!())),
            expected_cause: Some("compiled-member-value"),
        },
        AdmissionCase {
            stem: "macro-removed-anchor",
            revision_material: include_bytes!("../src/bin/macro_removed.rs"),
            conclusion: exact_diagnostic.concluded(FindingLocation::at(file!(), line!())),
            expected_cause: None,
        },
        AdmissionCase {
            stem: "wrong-code-control",
            revision_material: include_bytes!("../src/bin/macro_removed.rs"),
            conclusion: wrong_code.concluded(FindingLocation::at(file!(), line!())),
            expected_cause: Some("compiled-diagnostic-error-code"),
        },
        AdmissionCase {
            stem: "wrong-span-control",
            revision_material: include_bytes!("../src/bin/macro_removed.rs"),
            conclusion: wrong_span.concluded(FindingLocation::at(file!(), line!())),
            expected_cause: Some("compiled-diagnostic-primary-span"),
        },
    ])
}

fn executed_readback(executable: &str, stem: &str) -> Result<CompiledObservation, String> {
    let mut command = Command::new(executable);
    let output = bounded_output(&mut command, stem)?;
    if !output.status.success() {
        return Err(format!(
            "read-back executable failed with {:?}",
            output.status.code()
        ));
    }
    let stdout = String::from_utf8(output.stdout)
        .map_err(|error| format!("read-back stdout was not UTF-8: {error}"))?;
    let spelling = stdout
        .trim()
        .strip_prefix("VALUE=")
        .ok_or_else(|| format!("read-back line had the wrong grammar: {stdout:?}"))?;
    let value = spelling
        .parse::<u64>()
        .map_err(|error| format!("read-back value was not a count: {error}"))?;
    Ok(CompiledObservation::ReadBack(vec![ObservedMember {
        name: "VALUE".to_owned(),
        value: ObservedValue::Count(value),
    }]))
}

fn observed_macro_removed() -> Result<ObservedCompilation, String> {
    let manifest_dir = Path::new(env!("CARGO_MANIFEST_DIR"));
    let workspace = manifest_dir
        .parent()
        .ok_or_else(|| "challenge package had no workspace parent".to_owned())?;
    let mut command = Command::new(env!("CARGO"));
    command.current_dir(workspace).args([
        "check",
        "--manifest-path",
        "Cargo.toml",
        "-p",
        "surface-challenges",
        "--bin",
        "macro-removed",
        "--features",
        "macro-removed",
        "--locked",
        "--offline",
        "--target",
        TARGET,
        "--target-dir",
        "macro-removed-runtime-target",
        "--message-format=json",
    ]);
    let output = bounded_output(&mut command, "macro-removed")?;
    require_failed(&output, "macro-removed compiler challenge")?;
    let stdout = String::from_utf8(output.stdout)
        .map_err(|error| format!("cargo JSON was not UTF-8: {error}"))?;
    let line = stdout
        .lines()
        .find(|line| line.contains("GeneratedSurface") && line.contains("\"code\":\"E0425\""))
        .ok_or_else(|| "the stable macro-removed E0425 diagnostic was absent".to_owned())?;
    for expected in [
        "\"file_name\":\"surface-challenges\\\\src\\\\bin\\\\macro_removed.rs\"",
        "\"is_primary\":true",
        "\"line_start\":7",
        "\"line_end\":7",
        "\"column_start\":10",
        "\"column_end\":26",
    ] {
        if !line.contains(expected) {
            return Err(format!("macro-removed diagnostic omitted {expected}"));
        }
    }
    Ok(ObservedCompilation::refused(anchor("E0425", 7, 10, 26)?))
}

fn require_failed(output: &Output, context: &str) -> Result<(), String> {
    if output.status.success() {
        Err(format!("{context} unexpectedly succeeded"))
    } else {
        Ok(())
    }
}

fn anchor(
    code: &str,
    line: u64,
    column_start: u64,
    column_end: u64,
) -> Result<DiagnosticAnchor, String> {
    let source = RelativeSourcePath::informed("surface-challenges/src/bin/macro_removed.rs")
        .map_err(|refusal| format!("diagnostic source refused: {refusal:?}"))?;
    let start = SourcePosition::informed(line, column_start)
        .map_err(|refusal| format!("diagnostic start refused: {refusal:?}"))?;
    let end = SourcePosition::informed(line, column_end)
        .map_err(|refusal| format!("diagnostic end refused: {refusal:?}"))?;
    let primary = PrimarySourceSpan::informed(source, start, end)
        .map_err(|refusal| format!("diagnostic span refused: {refusal:?}"))?;
    let code = RustcErrorCode::informed(code)
        .map_err(|refusal| format!("diagnostic code refused: {refusal:?}"))?;
    Ok(DiagnosticAnchor::at(code, primary))
}

fn prove_host() -> Result<(), String> {
    let rustc_path = Path::new(env!("CARGO")).with_file_name("rustc.exe");
    let mut rustc_command = Command::new(rustc_path);
    rustc_command.arg("-vV");
    let rustc = bounded_output(&mut rustc_command, "rustc-host")?;
    if !rustc.status.success() {
        return Err("rustc host preflight failed".to_owned());
    }
    let facts = String::from_utf8(rustc.stdout)
        .map_err(|error| format!("rustc host preflight was not UTF-8: {error}"))?;
    if !(facts.contains("release: 1.98.0") && facts.contains(&format!("host: {TARGET}"))) {
        return Err(format!("unexpected rustc host facts: {facts}"));
    }
    let mut cargo_command = Command::new(env!("CARGO"));
    cargo_command.args(["--version", "--verbose"]);
    let cargo = bounded_output(&mut cargo_command, "cargo-host")?;
    if !cargo.status.success() {
        return Err("cargo host preflight failed".to_owned());
    }
    let cargo_facts = String::from_utf8(cargo.stdout)
        .map_err(|error| format!("cargo host preflight was not UTF-8: {error}"))?;
    if !cargo_facts.starts_with("cargo 1.98.0 ") {
        return Err(format!("unexpected cargo host facts: {cargo_facts}"));
    }
    Ok(())
}

fn bounded_output(command: &mut Command, stem: &str) -> Result<Output, String> {
    let workspace = Path::new(env!("CARGO_MANIFEST_DIR"))
        .parent()
        .ok_or_else(|| "challenge package had no workspace parent".to_owned())?;
    let evidence = workspace.join("evidence").join("runtime");
    std::fs::create_dir_all(&evidence)
        .map_err(|error| format!("runtime evidence directory was not writable: {error}"))?;
    let stdout_path = evidence.join(format!("{stem}-stdout.bin"));
    let stderr_path = evidence.join(format!("{stem}-stderr.bin"));
    let stdout = std::fs::File::create(&stdout_path)
        .map_err(|error| format!("{stem} stdout evidence was not writable: {error}"))?;
    let stderr = std::fs::File::create(&stderr_path)
        .map_err(|error| format!("{stem} stderr evidence was not writable: {error}"))?;
    let child = command
        .stdout(Stdio::from(stdout))
        .stderr(Stdio::from(stderr))
        .spawn()
        .map_err(|error| format!("{stem} was not runnable: {error}"))?;
    let status = wait_under_ceiling(child, stem)?;
    output_from_files(status, &stdout_path, &stderr_path, stem)
}

fn wait_under_ceiling(mut child: std::process::Child, stem: &str) -> Result<ExitStatus, String> {
    let process_id = child.id();
    let (sender, receiver) = mpsc::sync_channel(1);
    let waiter = std::thread::spawn(move || {
        let result = child.wait();
        let _sent = sender.send(result);
    });
    let status = match receiver.recv_timeout(HOST_CEILING) {
        Ok(result) => result.map_err(|error| format!("{stem} status was not readable: {error}"))?,
        Err(RecvTimeoutError::Timeout) => {
            terminate_process_tree(process_id, stem)?;
            let _after_kill = receiver.recv().map_err(|error| {
                format!("{stem} waiter disconnected after termination: {error}")
            })?;
            return Err(format!(
                "{stem} exceeded the exact {} second host ceiling",
                HOST_CEILING.as_secs()
            ));
        }
        Err(RecvTimeoutError::Disconnected) => {
            return Err(format!(
                "{stem} waiter disconnected before reporting status"
            ));
        }
    };
    if waiter.join().is_err() {
        return Err(format!("{stem} waiter unwound"));
    }
    Ok(status)
}

fn terminate_process_tree(process_id: u32, stem: &str) -> Result<(), String> {
    let system_root = option_env!("SystemRoot")
        .ok_or_else(|| format!("{stem} exceeded its ceiling but SystemRoot was unavailable"))?;
    let taskkill = Path::new(system_root).join("System32").join("taskkill.exe");
    let status = Command::new(taskkill)
        .args(["/PID", &process_id.to_string(), "/T", "/F"])
        .status()
        .map_err(|error| {
            format!("{stem} exceeded its ceiling and taskkill was not runnable: {error}")
        })?;
    if status.success() {
        Ok(())
    } else {
        Err(format!(
            "{stem} exceeded its ceiling and taskkill returned {:?}",
            status.code()
        ))
    }
}

fn output_from_files(
    status: ExitStatus,
    stdout_path: &Path,
    stderr_path: &Path,
    stem: &str,
) -> Result<Output, String> {
    let stdout = std::fs::read(stdout_path)
        .map_err(|error| format!("{stem} stdout evidence was not readable: {error}"))?;
    let stderr = std::fs::read(stderr_path)
        .map_err(|error| format!("{stem} stderr evidence was not readable: {error}"))?;
    Ok(Output {
        status,
        stdout,
        stderr,
    })
}

fn retained_check(_: &Invocation) -> TrialConclusion {
    TrialConclusion::Passed
}

fn admit(cases: &[AdmissionCase]) -> Result<(), String> {
    let check_revision =
        RevisionBinding::derived(DerivedRevision::from_material(include_bytes!("journey.rs")));
    let invocation = invocation();
    let mut bindings = Vec::with_capacity(cases.len());
    let mut records = Vec::with_capacity(cases.len());
    for case in cases {
        let subject_revision =
            RevisionBinding::derived(DerivedRevision::from_material(case.revision_material));
        let binding = binding(case.stem, subject_revision, check_revision)?;
        let record = HostTrialRecord::recorded(
            trial_identity(binding.row()),
            RunAttempt::Executed(case.conclusion.clone()),
            MeasurementReading::Unavailable,
        );
        let report = record_one(&binding, &invocation, record.clone())
            .map_err(|refusal| format!("record_one refused {}: {refusal:?}", case.stem))?;
        assert_report(&report, case, subject_revision, check_revision)?;
        bindings.push(binding);
        records.push(record);
    }
    let table = TrialTable::authored(
        AuthoredTableName::named(OWNER, "projection-roster-journey")
            .map_err(|refusal| format!("table name refused: {refusal:?}"))?,
        Provenance::Unproduced,
        bindings,
    )
    .map_err(|refusal| format!("trial table refused: {refusal:?}"))?;
    let report = record_all(
        &table.view(),
        &SelectionPlan::of(Selection::All),
        &invocation,
        records,
    )
    .map_err(|refusal| format!("record_all refused: {refusal:?}"))?;
    assert_eq!(report.denominator(), cases.len());
    for (case, accounting) in cases.iter().zip(report.census()) {
        let admitted = accounting
            .disposition()
            .report()
            .ok_or_else(|| format!("{} was not selected", case.stem))?;
        let subject_revision =
            RevisionBinding::derived(DerivedRevision::from_material(case.revision_material));
        assert_report(admitted, case, subject_revision, check_revision)?;
    }
    Ok(())
}

fn binding(
    stem: &'static str,
    subject_revision: RevisionBinding,
    check_revision: RevisionBinding,
) -> Result<TrialBinding, String> {
    let subject = SubjectRoute::named(OWNER, stem)
        .map_err(|refusal| format!("subject route refused: {refusal:?}"))?;
    let check = CheckRef::named(OWNER, "compiled-oracle")
        .map_err(|refusal| format!("check reference refused: {refusal:?}"))?;
    let row = Row::declared(
        ClaimRef::named(OWNER, "direct-generated-public-surface-parity")
            .map_err(|refusal| format!("claim reference refused: {refusal:?}"))?,
        ExecutionSuite::named(OWNER, "external-execution")
            .map_err(|refusal| format!("execution suite refused: {refusal:?}"))?,
        Classification::authored(
            vec![
                Role::named(OWNER, "projection-roster")
                    .map_err(|refusal| format!("role refused: {refusal:?}"))?,
            ],
            vec![Tag::named(OWNER, stem).map_err(|refusal| format!("tag refused: {refusal:?}"))?],
        )
        .map_err(|refusal| format!("classification refused: {refusal:?}"))?,
        subject,
        check,
        PopulationRef::named(OWNER, "fixed-external-challenges")
            .map_err(|refusal| format!("population refused: {refusal:?}"))?,
        Origin::HandWritten,
    )
    .map_err(|refusal| format!("row refused: {refusal:?}"))?;
    Binding::bound(
        row,
        ExecutableAttachment::attached(
            subject,
            check,
            subject_revision,
            check_revision,
            retained_check,
        ),
        Provenance::Unproduced,
    )
    .map_err(|refusal| format!("binding refused: {refusal:?}"))
}

fn invocation() -> Invocation {
    Invocation::declared(
        InvocationProfile::declared(
            CaseBudget::declared(1),
            ByteBudget::declared(4_096),
            TimeBudget::declared(60_000_000_000),
        ),
        TargetBinding::bound(
            TargetTriple::declared(TARGET),
            ToolchainIdentity::declared(TOOLCHAIN),
        ),
        TrialSite::located(
            module_path!(),
            file!(),
            line!(),
            "projection-roster-journey",
        ),
        HarnessClock::unavailable(),
    )
}

fn assert_report(
    report: &TrialReport,
    case: &AdmissionCase,
    subject_revision: RevisionBinding,
    check_revision: RevisionBinding,
) -> Result<(), String> {
    let standing = report.standing();
    let key = standing.key();
    assert_eq!(key.target().target().spelling(), TARGET);
    assert_eq!(key.target().toolchain().spelling(), TOOLCHAIN);
    assert_eq!(
        key.subject(),
        SubjectRevisionId::of_binding(subject_revision)
    );
    assert_eq!(key.check(), CheckRevisionId::of_binding(check_revision));
    assert_eq!(standing.replay(), ReplayPosture::ExactDerived);
    match (case.expected_cause, report.attempt()) {
        (None, RunAttempt::Executed(TrialConclusion::Passed)) => Ok(()),
        (Some(expected), RunAttempt::Executed(TrialConclusion::Refused(finding))) => {
            assert_eq!(finding.class(), FailureClass::OracleDisagreement);
            assert_eq!(
                finding.cause().family(),
                bakery::harness::oracle::ORACLE_CAUSE_FAMILY
            );
            assert_eq!(finding.cause().local(), expected);
            Ok(())
        }
        _ => Err(format!(
            "{} carried an unexpected report attempt: {:?}",
            case.stem,
            report.attempt()
        )),
    }
}
