//! Eight-seat projection-accounting source variant.

use super::VariantMetrics;
use bakery::compiler::{Disposition, DispositionSet, OwnerFact};

const FACT: OwnerFact = OwnerFact {
    home: "surface-challenges",
    name: "projection-accounting-economics",
};

bakery::compiler::kinds! {
    set = ProjectionKinds;
    dispositions = ProjectionDispositions;

    /// The accepted public-surface seat.
    PublicSurface = "surface-subject.public-api", public_surface => (), bakery::compiler::SoleRole, bakery::compiler::NoQuestions;
    /// The accepted consumer-adapter seat.
    ConsumerAdapter = "surface-subject.consumer-adapter", consumer_adapter => (), bakery::compiler::SoleRole, bakery::compiler::NoQuestions;
    /// The accepted publication-guide seat.
    PublicationGuide = "surface-subject.publication-guide", publication_guide => (), bakery::compiler::SoleRole, bakery::compiler::NoQuestions;
    /// The first deterministic extension seat.
    Projection04 = "surface-subject.projection-04", projection_04 => (), bakery::compiler::SoleRole, bakery::compiler::NoQuestions;
    /// The second deterministic extension seat.
    Projection05 = "surface-subject.projection-05", projection_05 => (), bakery::compiler::SoleRole, bakery::compiler::NoQuestions;
    /// The third deterministic extension seat.
    Projection06 = "surface-subject.projection-06", projection_06 => (), bakery::compiler::SoleRole, bakery::compiler::NoQuestions;
    /// The fourth deterministic extension seat.
    Projection07 = "surface-subject.projection-07", projection_07 => (), bakery::compiler::SoleRole, bakery::compiler::NoQuestions;
    /// The fifth deterministic extension seat.
    Projection08 = "surface-subject.projection-08", projection_08 => (), bakery::compiler::SoleRole, bakery::compiler::NoQuestions;
}

const SOURCE: &str = include_str!("eight.rs");

pub(super) fn metrics(passes: u64) -> Option<VariantMetrics> {
    let seats = 8_u64;
    let mut completed_seats = 0_u64;
    for _ordinal in 0..passes {
        let completed = DispositionSet::<ProjectionKinds>::complete(ProjectionDispositions {
            public_surface: Disposition::NotApplicable { because: FACT },
            consumer_adapter: Disposition::NotApplicable { because: FACT },
            publication_guide: Disposition::NotApplicable { because: FACT },
            projection_04: Disposition::NotApplicable { because: FACT },
            projection_05: Disposition::NotApplicable { because: FACT },
            projection_06: Disposition::NotApplicable { because: FACT },
            projection_07: Disposition::NotApplicable { because: FACT },
            projection_08: Disposition::NotApplicable { because: FACT },
        })
        .ok()?;
        completed_seats = completed_seats.checked_add(u64::try_from(completed.len()).ok()?)?;
    }
    Some(VariantMetrics {
        source_bytes: u64::try_from(SOURCE.len()).ok()?,
        projection_seats: seats,
        accounting_passes: passes,
        disposition_comparisons: seats.checked_mul(passes)?,
        completed_seats,
    })
}
