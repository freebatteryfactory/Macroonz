//! Host facts, correctness preflight, and shared benchmark construction.

use super::source::{
    accepted_projection_holds, accepted_shape_holds, projection_scaling_holds, shape_scaling_holds,
};
use bakery::harness::bench::{BenchInvocation, ContentionPosture, PreflightRef, PreflightTrial};
use bakery::harness::clock::HarnessClock;
use bakery::harness::descriptor::{
    Binding, CheckRef, ClaimRef, Classification, ExecutableAttachment, ExecutionSuite, Origin,
    PopulationRef, Provenance, RevisionBinding, Role, Row, SubjectRoute, Tag,
};
use bakery::harness::identity::{ContentAddress, DomainTag, IdentityProfileVersion};
use bakery::harness::properties::{Holding, concluded};
use bakery::harness::report::{
    ByteBudget, CaseBudget, FailureClass, FindingCause, InvocationProfile, TargetBinding,
    TargetTriple, TimeBudget, ToolchainIdentity, TrialConclusion, TrialSite,
};
use bakery::harness::runner::{Invocation, TrialBinding};
use std::path::Path;
use std::sync::atomic::{AtomicU64, Ordering};

pub(super) const OWNER: &str = "cross-subject-economics";
pub(super) const TARGET: &str = "x86_64-pc-windows-msvc";
pub(super) const TOOLCHAIN: &str = "rustc 1.98.0 (88d9e12ae 2026-08-18)";
const REVISION_TAG: DomainTag = DomainTag::declared(
    "cross-subject-economics-revision",
    IdentityProfileVersion::declared(1),
);
const PREFLIGHT_REFUSED: FindingCause = FindingCause::named(OWNER, "correctness-preflight-refused");
static CLOCK_TICKS: AtomicU64 = AtomicU64::new(0);

pub(super) fn described(error: impl core::fmt::Debug) -> String {
    format!("{error:?}")
}

pub(super) fn prove_host() -> Result<(), String> {
    let rustc = Path::new(env!("CARGO")).with_file_name("rustc.exe");
    let output = std::process::Command::new(rustc)
        .arg("-vV")
        .output()
        .map_err(described)?;
    if !output.status.success() {
        return Err("rustc host preflight failed".to_owned());
    }
    let facts = String::from_utf8(output.stdout).map_err(described)?;
    if facts.contains("release: 1.98.0") && facts.contains(&format!("host: {TARGET}")) {
        Ok(())
    } else {
        Err(format!("unexpected rustc host facts: {facts}"))
    }
}

fn clock_reading() -> u64 {
    CLOCK_TICKS.fetch_add(1, Ordering::SeqCst)
}

fn target() -> TargetBinding {
    TargetBinding::bound(
        TargetTriple::declared(TARGET),
        ToolchainIdentity::declared(TOOLCHAIN),
    )
}

pub(super) fn bench_invocation() -> BenchInvocation {
    BenchInvocation::declared(
        target(),
        HarnessClock::reading(clock_reading),
        ContentionPosture::NoDeclaredContention,
    )
}

pub(super) fn preflight() -> Result<PreflightTrial, String> {
    let reference = PreflightRef::named(OWNER, "cross-subject-correctness").map_err(described)?;
    Ok(PreflightTrial::bound(
        reference,
        trial_binding()?,
        Invocation::declared(
            InvocationProfile::declared(
                CaseBudget::declared(1),
                ByteBudget::declared(8_192),
                TimeBudget::declared(60_000_000_000),
            ),
            target(),
            TrialSite::located(module_path!(), file!(), line!(), "economics-preflight"),
            HarnessClock::unavailable(),
        ),
    ))
}

fn trial_binding() -> Result<TrialBinding, String> {
    let subject =
        SubjectRoute::named(OWNER, "accepted-shape-and-projection-sources").map_err(described)?;
    let check = CheckRef::named(OWNER, "callable-economics-correctness").map_err(described)?;
    let row = Row::declared(
        ClaimRef::named(OWNER, "economics-measures-accepted-callable-work").map_err(described)?,
        ExecutionSuite::named(OWNER, "cross-subject-callable-scaling").map_err(described)?,
        Classification::authored(
            vec![Role::named(OWNER, "benchmark").map_err(described)?],
            vec![Tag::named(OWNER, "shape-and-projection").map_err(described)?],
        )
        .map_err(described)?,
        subject,
        check,
        PopulationRef::named(OWNER, "declared-shape-and-projection-axes").map_err(described)?,
        Origin::HandWritten,
    )
    .map_err(described)?;
    let mut revision_bytes = Vec::new();
    revision_bytes.extend_from_slice(include_bytes!(
        "../../../surface-subject-macros/src/engine.rs"
    ));
    revision_bytes.extend_from_slice(include_bytes!(
        "../../../../shape-source/shape-subject-macros/src/engine.rs"
    ));
    let revision =
        RevisionBinding::declared(ContentAddress::derived(REVISION_TAG, &revision_bytes));
    Binding::bound(
        row,
        ExecutableAttachment::attached(subject, check, revision, revision, correctness_preflight),
        Provenance::Unproduced,
    )
    .map_err(described)
}

fn correctness_preflight(_invocation: &Invocation) -> TrialConclusion {
    if accepted_shape_holds()
        && accepted_projection_holds()
        && shape_scaling_holds()
        && projection_scaling_holds()
    {
        TrialConclusion::Passed
    } else {
        concluded(
            Holding::Fails,
            FailureClass::PropertyDisagreement,
            PREFLIGHT_REFUSED,
        )
    }
}
