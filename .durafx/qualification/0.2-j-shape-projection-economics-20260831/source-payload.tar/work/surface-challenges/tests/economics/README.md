# Cross-subject callable economics

This external test support home composes the accepted shape and projection compiler sources with the existing harness benchmark owner.
It keeps codec-member work and projection-accounting work as separate typed axes and never derives a shared algebra score.
Its observations are disposable campaign evidence and create no product owner, public API, or runtime path.
The deterministic clock proves benchmark choreography only and makes no host-performance claim.
The qualified curves serialize into one host-neutral readback whose exact bytes can enter the retained campaign receipt.
The existing scratch package exposes only the planted control's pass count so an external mutation backend can replace two passes with one while these tests continue to execute the real accounting operation.
