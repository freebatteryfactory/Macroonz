//! Deterministic host-neutral serialization of the qualified callable work curves.

use bakery::harness::bench::{BenchOutcome, BenchReport, WorkCurve};
use core::fmt::Write as _;
use std::path::Path;

pub(super) fn write(report: &BenchReport) -> Result<(), String> {
    let rendered = render(report)?;
    let directory = Path::new(env!("CARGO_MANIFEST_DIR")).join("evidence");
    std::fs::create_dir_all(&directory).map_err(described)?;
    let destination = directory.join("cross-subject-callable-economics-v1.txt");
    std::fs::write(&destination, rendered.as_bytes()).map_err(described)?;
    let reread = std::fs::read(&destination).map_err(described)?;
    if reread == rendered.as_bytes() {
        Ok(())
    } else {
        Err("the callable-economics readback changed when reread".to_owned())
    }
}

fn render(report: &BenchReport) -> Result<String, String> {
    let mut output = String::from(
        "format=cross-subject-callable-economics-v1\n\
         target=x86_64-pc-windows-msvc\n\
         toolchain=rustc 1.98.0 (88d9e12ae 2026-08-18)\n\
         timing-posture=deterministic-choreography-only\n\
         accepted-shape-categorical=qualified\n\
         accepted-projection-categorical=qualified\n\
         identical-controls=refused-before-timing\n",
    );
    for reading in report.readings() {
        let row = reading.row().workload().name().stem().written();
        let BenchOutcome::Qualified {
            measured,
            planted_worse,
            ..
        } = reading.outcome()
        else {
            return Err("a readback row was not qualified".to_owned());
        };
        render_curve(&mut output, row, "measured", measured)?;
        render_curve(&mut output, row, "planted-worse", planted_worse)?;
    }
    Ok(output)
}

fn render_curve(
    output: &mut String,
    row: &str,
    curve: &str,
    work: &WorkCurve,
) -> Result<(), String> {
    for point in work.points() {
        for count in point.counts() {
            writeln!(
                output,
                "row={row} curve={curve} input-size={} observation={} count={}",
                point.input_size(),
                count.observation().name().stem().written(),
                count.count(),
            )
            .map_err(described)?;
        }
    }
    Ok(())
}

fn described(error: impl core::fmt::Debug) -> String {
    format!("{error:?}")
}
