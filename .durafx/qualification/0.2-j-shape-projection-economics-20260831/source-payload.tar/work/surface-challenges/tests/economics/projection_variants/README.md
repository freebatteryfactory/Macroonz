# Projection-accounting variants

This support home retains the exact compile-time source variants used to observe one, two, three, four, and eight disposition seats.
The accepted projection engine remains fixed at three seats, so these variants expose an accounting axis without pretending that the product owns a dynamic projection-roster API.
Every variant changes only its declared kind roster and complete disposition record.
