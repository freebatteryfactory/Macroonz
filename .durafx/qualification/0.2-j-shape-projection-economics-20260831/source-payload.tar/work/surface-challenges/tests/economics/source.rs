//! Exact subject inputs and typed compiler/accounting observations.

use super::{projection_engine, shape_engine};
use bakery::compiler::codec::{Cardinality, CodecMemberShape};
use bakery::compiler::{
    CanonicalContent, CapturedTokenTree, Disposition, KindSet, OwnerFact, TextCapture,
};

pub(super) const SHAPE_AXIS: [u64; 6] = [1, 2, 4, 5, 8, 16];
pub(super) const PROJECTION_AXIS: [u64; 5] = [1, 2, 3, 4, 8];

const ACCEPTED_PROJECTION_DECLARATION: &str = concat!(
    "contract = crate::PublicContract, ",
    "member = VALUE, ",
    "generated_type = GeneratedSurface, ",
    "member_type = u64, ",
    "member_value = 73, ",
    "role = public_api, ",
    "destination = declaration_site"
);

const ACCEPTED_SHAPE_SUBJECT: &str =
    include_str!("../../../../shape-source/shape-subject/src/lib.rs");
const ACCEPTED_SHAPE_END: &str =
    "\n}\n\n#[derive(Debug, Clone, PartialEq, Eq)]\npub struct HandwrittenRecord";

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(super) struct ShapeMetrics {
    pub(super) source_bytes: u64,
    pub(super) captured_trees: u64,
    pub(super) captured_depth: u64,
    pub(super) member_rows: u64,
    pub(super) planned_units: u64,
    pub(super) rendered_units: u64,
    pub(super) generated_bytes: u64,
    pub(super) canonical_bytes: u64,
    pub(super) delivered_bytes: u64,
}

pub(super) fn shape_declaration(size: u64) -> Option<String> {
    let size = usize::try_from(size).ok()?;
    if size == 0 {
        return None;
    }
    let mut source = String::from("record ScalingRecord {\n");
    for ordinal in 0..size {
        source.push_str("    value");
        source.push_str(&ordinal.to_string());
        source.push_str(": u64 => count required,\n");
    }
    source.push_str("}\n");
    Some(source)
}

pub(super) fn shape_metrics(size: u64) -> Option<ShapeMetrics> {
    let source = shape_declaration(size)?;
    metrics_for_shape_source(&source)
}

fn metrics_for_shape_source(source: &str) -> Option<ShapeMetrics> {
    let captured = TextCapture::read(source).ok()?;
    let (captured_trees, captured_depth) = tree_shape(captured.input().trees(), 1);
    let declaration = shape_engine::read_declaration(captured.input()).ok()?;
    let content = shape_engine::declared_content(declaration.clone()).ok()?;
    let expansion = shape_engine::compile(captured.input().clone()).ok()?;
    let rendered = expansion.closure().rendered();
    let generated_bytes = rendered.units().iter().try_fold(0_u64, |total, unit| {
        total.checked_add(u64::try_from(unit.bytes().len()).ok()?)
    })?;
    let delivered_bytes = expansion
        .emit()
        .tokens()
        .and_then(|tree| u64::try_from(tree.canonical_bytes().len()).ok())
        .unwrap_or(0);
    let mut canonical = Vec::new();
    content.encode_content_into(&mut canonical);
    Some(ShapeMetrics {
        source_bytes: u64::try_from(source.len()).ok()?,
        captured_trees,
        captured_depth,
        member_rows: u64::try_from(declaration.members.len()).ok()?,
        planned_units: u64::try_from(expansion.plan().membership().count()).ok()?,
        rendered_units: u64::try_from(rendered.count()).ok()?,
        generated_bytes,
        canonical_bytes: u64::try_from(canonical.len()).ok()?,
        delivered_bytes,
    })
}

pub(super) fn accepted_shape_holds() -> bool {
    let Some(source) = accepted_shape_declaration() else {
        return false;
    };
    let Ok(captured) = TextCapture::read(source) else {
        return false;
    };
    let Ok(declaration) = shape_engine::read_declaration(captured.input()) else {
        return false;
    };
    let observed = declaration
        .members
        .iter()
        .map(|member| {
            (
                member.spelling.as_str(),
                member.held_as.as_str(),
                member.shape,
                member.cardinality,
            )
        })
        .collect::<Vec<_>>();
    let expected = vec![
        (
            "count",
            "u16",
            CodecMemberShape::Count,
            Cardinality::Required,
        ),
        (
            "payload",
            "ByteParcel",
            CodecMemberShape::Bytes,
            Cardinality::Required,
        ),
        (
            "label",
            "String",
            CodecMemberShape::Text,
            Cardinality::Optional,
        ),
        (
            "modes",
            "Mode",
            CodecMemberShape::ClosedChoice,
            Cardinality::Repeated,
        ),
        (
            "child",
            "Nested",
            CodecMemberShape::Nested,
            Cardinality::Required,
        ),
    ];
    if observed != expected {
        return false;
    }
    let Some(first) = metrics_for_shape_source(source) else {
        return false;
    };
    let Some(repeated) = metrics_for_shape_source(source) else {
        return false;
    };
    first == repeated
        && first.member_rows == 5
        && first.planned_units == 1
        && first.rendered_units == 1
        && first.generated_bytes > 0
        && first.canonical_bytes > 0
        && first.delivered_bytes > 0
}

fn accepted_shape_declaration() -> Option<&'static str> {
    let start = ACCEPTED_SHAPE_SUBJECT.find("record LedgerRecord {")?;
    let tail = ACCEPTED_SHAPE_SUBJECT.get(start..)?;
    let end = tail.find(ACCEPTED_SHAPE_END)?;
    tail.get(..end)
}

pub(super) fn accepted_projection_holds() -> bool {
    let Ok(captured) = TextCapture::read(ACCEPTED_PROJECTION_DECLARATION) else {
        return false;
    };
    let Ok(declaration) = projection_engine::read_declaration(captured.input()) else {
        return false;
    };
    let Ok(accounted) = projection_engine::compile(captured.input().clone()) else {
        return false;
    };
    let expansion = accounted.expansion();
    declaration.contract_path == ["crate", "PublicContract"]
        && declaration.member == "VALUE"
        && declaration.generated_type == "GeneratedSurface"
        && declaration.member_type == ["u64"]
        && declaration.member_value == 73
        && declaration.role == projection_engine::PublicSurfaceRole::PublicApi
        && expansion.plan().membership().count() == 1
        && expansion.closure().rendered().count() == 1
        && accounted.dispositions().len() == 3
        && accepted_projection_dispositions_hold(accounted.dispositions())
        && <projection_engine::ProjectionKinds as KindSet>::NAMES
            == super::projection_variants::accepted_names()
        && expansion.emit().tokens().is_some()
}

fn accepted_projection_dispositions_hold(
    dispositions: &bakery::compiler::DispositionSet<projection_engine::ProjectionKinds>,
) -> bool {
    let mut rows = dispositions.iter();
    let generated = rows.next().is_some_and(|(name, disposition)| {
        name == "surface-subject.public-api" && matches!(disposition, Disposition::Generated { .. })
    });
    let not_requested = rows.next().is_some_and(|(name, disposition)| {
        name == "surface-subject.consumer-adapter"
            && matches!(
                disposition,
                Disposition::NotRequested { because }
                    if because
                        == &OwnerFact {
                            home: "surface-subject",
                            name: "consumer-adapter-is-not-requested-by-this-declaration",
                        }
            )
    });
    let not_applicable = rows.next().is_some_and(|(name, disposition)| {
        name == "surface-subject.publication-guide"
            && matches!(
                disposition,
                Disposition::NotApplicable { because }
                    if because
                        == &OwnerFact {
                            home: "surface-subject",
                            name: "publication-guide-is-not-a-code-projection",
                        }
            )
    });
    generated && not_requested && not_applicable && rows.next().is_none()
}

pub(super) fn shape_scaling_holds() -> bool {
    let Some(metrics) = SHAPE_AXIS
        .into_iter()
        .map(shape_metrics)
        .collect::<Option<Vec<_>>>()
    else {
        return false;
    };
    metrics.iter().zip(SHAPE_AXIS).all(|(point, size)| {
        point.member_rows == size && point.planned_units == 1 && point.rendered_units == 1
    }) && metrics.windows(2).all(|pair| {
        let [earlier, later] = pair else {
            return false;
        };
        later.source_bytes > earlier.source_bytes
            && later.captured_trees > earlier.captured_trees
            && later.generated_bytes > earlier.generated_bytes
            && later.canonical_bytes > earlier.canonical_bytes
            && later.delivered_bytes > earlier.delivered_bytes
    })
}

pub(super) fn projection_scaling_holds() -> bool {
    let Some(metrics) = PROJECTION_AXIS
        .into_iter()
        .map(super::projection_variants::measured)
        .collect::<Option<Vec<_>>>()
    else {
        return false;
    };
    metrics.iter().zip(PROJECTION_AXIS).all(|(point, size)| {
        point.projection_seats == size
            && point.accounting_passes == 1
            && point.disposition_comparisons == size
            && point.completed_seats == size
    })
}

fn tree_shape(trees: &[CapturedTokenTree], depth: u64) -> (u64, u64) {
    let mut count = u64::try_from(trees.len()).unwrap_or(u64::MAX);
    let mut greatest = depth;
    for tree in trees {
        if let Some((_delimiter, members)) = tree.group() {
            let (nested, nested_depth) = tree_shape(members, depth.saturating_add(1));
            count = count.saturating_add(nested);
            greatest = greatest.max(nested_depth);
        }
    }
    (count, greatest)
}
