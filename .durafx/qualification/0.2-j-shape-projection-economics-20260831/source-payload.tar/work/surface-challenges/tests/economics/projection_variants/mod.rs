//! Exact private source variants for the projection-accounting axis.

mod eight;
mod four;
mod one;
mod three;
mod two;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(super) struct VariantMetrics {
    pub(super) source_bytes: u64,
    pub(super) projection_seats: u64,
    pub(super) accounting_passes: u64,
    pub(super) disposition_comparisons: u64,
    pub(super) completed_seats: u64,
}

pub(super) fn measured(size: u64) -> Option<VariantMetrics> {
    metrics(size, 1)
}

pub(super) fn repeated(size: u64) -> Option<VariantMetrics> {
    metrics(
        size,
        surface_challenges::economics::planted_worse_accounting_passes(),
    )
}

fn metrics(size: u64, passes: u64) -> Option<VariantMetrics> {
    match size {
        1 => one::metrics(passes),
        2 => two::metrics(passes),
        3 => three::metrics(passes),
        4 => four::metrics(passes),
        8 => eight::metrics(passes),
        _ => None,
    }
}

pub(super) fn accepted_names() -> &'static [&'static str] {
    three::names()
}
