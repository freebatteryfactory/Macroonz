//! One-seat projection-accounting source variant.

use super::VariantMetrics;
use bakery::compiler::{Disposition, DispositionSet, OwnerFact};

const FACT: OwnerFact = OwnerFact {
    home: "surface-challenges",
    name: "projection-accounting-economics",
};

bakery::compiler::kinds! {
    set = ProjectionKinds;
    dispositions = ProjectionDispositions;

    /// The accepted public-surface seat.
    PublicSurface = "surface-subject.public-api", public_surface => (), bakery::compiler::SoleRole, bakery::compiler::NoQuestions;
}

const SOURCE: &str = include_str!("one.rs");

pub(super) fn metrics(passes: u64) -> Option<VariantMetrics> {
    let seats = 1_u64;
    let mut completed_seats = 0_u64;
    for _ordinal in 0..passes {
        let completed = DispositionSet::<ProjectionKinds>::complete(ProjectionDispositions {
            public_surface: Disposition::NotApplicable { because: FACT },
        })
        .ok()?;
        completed_seats = completed_seats.checked_add(u64::try_from(completed.len()).ok()?)?;
    }
    Some(VariantMetrics {
        source_bytes: u64::try_from(SOURCE.len()).ok()?,
        projection_seats: seats,
        accounting_passes: passes,
        disposition_comparisons: seats.checked_mul(passes)?,
        completed_seats,
    })
}
