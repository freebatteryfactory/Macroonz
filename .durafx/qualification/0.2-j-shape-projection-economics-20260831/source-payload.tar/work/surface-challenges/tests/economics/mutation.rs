//! Current-source custody and typed pressure for the planted-worse cost control.

use bakery::harness::descriptor::ClaimRef;
use bakery::harness::muterprater::wrap::read_artifact;
use bakery::harness::muterprater::{
    ActivationDisposition, AdapterQualification, AnnouncedRoster, BackendCommand, BackendVersion,
    CompiledSuiteArtifactCustody, CompiledSuiteArtifactStanding, CompiledSuitePressure,
    EquivalenceAxis, FamilyAttribution, GrammarStanding, MutationBackendInvocation, MutationSite,
    MutationSourceRevision, MutationVerdict, OperatorFamilyRef, SourceCoordinate, WrappedBackend,
};
use bakery::harness::report::{TargetBinding, TargetTriple, ToolchainIdentity};

const CONSOLE: &str =
    include_str!("../../evidence/cost-sensitivity/cargo-mutants-27.0.0-console.txt");
const ARTIFACT_SOURCE: &[u8] = include_bytes!("../../evidence/cost-sensitivity/economics.rs");
const CURRENT_SOURCE: &[u8] = include_bytes!("../../src/economics.rs");
const MUTANT_FILE: &str = "surface-challenges/src/economics.rs";
const BACKEND_VERSION: &str = "27.0.0";
const TARGET: &str = "x86_64-pc-windows-msvc";
const TOOLCHAIN: &str = "rustc 1.98.0 (88d9e12ae 2026-08-18)";
const COMMAND: &[&str] = &[
    "+1.98.0",
    "mutants",
    "--no-config",
    "--in-place",
    "--file",
    MUTANT_FILE,
    "--re",
    "planted_worse_accounting_passes -> u64 with 1$",
    "--package",
    "surface-challenges",
    "--baseline",
    "run",
    "--jobserver-tasks",
    "1",
    "--output",
    "../cost-sensitivity-run-parent-strict",
    "--caught",
    "--unviable",
    "--no-times",
    "--colors",
    "never",
    "--annotations",
    "none",
    "--timeout",
    "300",
    "--build-timeout",
    "300",
    "--",
    "--locked",
    "--offline",
    "--target",
    TARGET,
    "--test",
    "economics",
    "--jobs",
    "1",
    "--",
    "--test-threads=1",
];

fn owner(coordinate: &SourceCoordinate) -> Option<ClaimRef> {
    (coordinate.file() == MUTANT_FILE)
        .then(cost_claim)
        .flatten()
}

fn cost_claim() -> Option<ClaimRef> {
    ClaimRef::named("cross-subject-economics", "planted-worse-cost-distinction").ok()
}

fn family(_: &SourceCoordinate, _: &[u8]) -> Option<OperatorFamilyRef> {
    None
}

fn source(bytes: &[u8]) -> Result<MutationSourceRevision, String> {
    MutationSourceRevision::from_content(MUTANT_FILE, bytes).map_err(described)
}

fn described(error: impl core::fmt::Debug) -> String {
    format!("{error:?}")
}

pub(super) fn assert_projection_cost_sensitivity() -> Result<(), String> {
    if ARTIFACT_SOURCE != CURRENT_SOURCE {
        return Err("the retained mutation source is not the current scratch source".to_owned());
    }

    let version = BackendVersion::stated(BACKEND_VERSION).map_err(described)?;
    let command = BackendCommand::declared("cargo", COMMAND).map_err(described)?;
    let invocation = MutationBackendInvocation::declared(
        WrappedBackend::CargoMutants,
        version.clone(),
        command,
        TargetBinding::bound(
            TargetTriple::declared(TARGET),
            ToolchainIdentity::declared(TOOLCHAIN),
        ),
    );
    let manifest = read_artifact(
        CONSOLE,
        invocation,
        vec![source(ARTIFACT_SOURCE)?],
        owner,
        family,
    )
    .map_err(described)?;

    if manifest.invocation().command().arguments() != COMMAND
        || manifest.reading().announced() != AnnouncedRoster::Stated(1)
        || manifest.reading().run().reports().len() != 1
        || manifest.reading().run().kills().count() != 1
        || manifest.reading().run().non_kills().count() != 0
        || manifest.reading().run().survivors().count() != 0
    {
        return Err("the cost-sensitivity artifact lost its complete denominator".to_owned());
    }

    let report = manifest
        .reading()
        .run()
        .reports()
        .first()
        .ok_or_else(|| "the cost-sensitivity artifact omitted its mutant".to_owned())?;
    let MutationSite::Reported(coordinate) = report.target().site() else {
        return Err("the cost-sensitivity mutant lost its backend coordinate".to_owned());
    };
    let expected_claim =
        cost_claim().ok_or_else(|| "the cost claim name was refused".to_owned())?;
    if coordinate.file() != MUTANT_FILE
        || coordinate.line() != 6
        || coordinate.column() != 5
        || report.target().family() != FamilyAttribution::OutsideTheBank
        || report.target().owning_claim() != Some(expected_claim)
        || report.activation() != ActivationDisposition::UnobservableUnderBackend
        || report.equivalence() != EquivalenceAxis::NotAssessed
        || report.verdict() != MutationVerdict::Killed
    {
        return Err("the cost-sensitivity mutant lost its typed interpretation".to_owned());
    }

    let [summary] = manifest.reading().unparsed() else {
        return Err("the cost-sensitivity artifact lost its backend summary".to_owned());
    };
    if summary.ordinal() != 3 || summary.text().bytes() != b"1 mutant tested: 1 caught" {
        return Err("the cost-sensitivity artifact changed its backend summary".to_owned());
    }

    let current_sources = vec![source(CURRENT_SOURCE)?];
    let qualification =
        AdapterQualification::of(manifest.reading(), GrammarStanding::Checked(version))
            .map_err(described)?;
    let custody =
        CompiledSuiteArtifactCustody::current(manifest, current_sources).map_err(described)?;
    let pressure = CompiledSuitePressure::demonstrated(
        CompiledSuiteArtifactStanding::Reported(&custody),
        &qualification,
    )
    .map_err(described)?;
    if pressure.kill().verdict() != MutationVerdict::Killed {
        return Err("the current artifact did not demonstrate suite pressure".to_owned());
    }
    Ok(())
}
