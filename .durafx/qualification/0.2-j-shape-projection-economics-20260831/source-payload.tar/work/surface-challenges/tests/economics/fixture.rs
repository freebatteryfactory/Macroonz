//! Typed benchmark rows, executable work, planted controls, and owner judgment.

use super::projection_variants::{VariantMetrics, measured, repeated};
use super::source::{PROJECTION_AXIS, SHAPE_AXIS, ShapeMetrics, shape_metrics};
use super::support::{self, OWNER};
use bakery::harness::bench::{
    BenchAttachment, BenchBinding, BenchCall, BenchMeasurement, BenchReferences, BenchRow,
    BenchTable, BenchTableName, ComplexityClaimRef, ContentionPosture, DeclaredBudgets,
    InputSizeAxis, PlantedWorseRef, WorkConclusion, WorkCurve, WorkCurvePoint, WorkFormula,
    WorkGapStanding, WorkJudge, WorkJudgeBinding, WorkJudgment, WorkJudgmentInput,
    WorkObservationRef, WorkRecorder, WorkRecordingRefusal, WorkloadRef,
};
use bakery::harness::descriptor::Provenance;

const SHAPE_FORMULA: &[u8] = b"one complete compiler pass per declared member count";
const PROJECTION_FORMULA: &[u8] =
    b"one complete disposition pass per declared projection-accounting seat";
const MEASURED_REFUSED: bakery::harness::report::FindingCause =
    bakery::harness::report::FindingCause::named(OWNER, "measured-curve-refused");
const CONTROL_REFUSED: bakery::harness::report::FindingCause =
    bakery::harness::report::FindingCause::named(OWNER, "planted-control-refused");
const GAP_REFUSED: bakery::harness::report::FindingCause =
    bakery::harness::report::FindingCause::named(OWNER, "declared-gap-not-observed");

const SHAPE_OBSERVATIONS: [&str; 10] = [
    "shape-source-bytes",
    "shape-captured-trees",
    "shape-captured-depth",
    "shape-member-rows",
    "shape-planned-units",
    "shape-rendered-units",
    "shape-generated-bytes",
    "shape-canonical-bytes",
    "shape-delivered-bytes",
    "shape-compiler-passes",
];
const PROJECTION_OBSERVATIONS: [&str; 5] = [
    "projection-source-bytes",
    "projection-accounting-seats",
    "projection-accounting-passes",
    "projection-disposition-comparisons",
    "projection-completed-seats",
];

#[derive(Clone, Copy)]
struct BindingSpec {
    workload: &'static str,
    control: &'static str,
    complexity: &'static str,
    formula: &'static [u8],
    axis: &'static [u64],
    measured: BenchCall,
    planted: BenchCall,
    judge: WorkJudge,
    observations: &'static [&'static str],
}

pub(super) fn table() -> Result<BenchTable, String> {
    BenchTable::authored(
        BenchTableName::named(OWNER, "cross-subject-callable-economics")
            .map_err(support::described)?,
        Provenance::Unproduced,
        vec![
            shape_binding(shape_control)?,
            projection_binding(projection_control)?,
        ],
    )
    .map_err(support::described)
}

pub(super) fn identical_control_table() -> Result<BenchTable, String> {
    BenchTable::authored(
        BenchTableName::named(OWNER, "cross-subject-identical-controls")
            .map_err(support::described)?,
        Provenance::Unproduced,
        vec![
            shape_binding(shape_measured)?,
            projection_binding(projection_measured)?,
        ],
    )
    .map_err(support::described)
}

fn shape_binding(planted: BenchCall) -> Result<BenchBinding, String> {
    binding(BindingSpec {
        workload: "shape-member-count",
        control: "repeated-shape-compiler-pass",
        complexity: "shape-member-growth",
        formula: SHAPE_FORMULA,
        axis: &SHAPE_AXIS,
        measured: shape_measured,
        planted,
        judge: shape_judge,
        observations: &SHAPE_OBSERVATIONS,
    })
}

fn projection_binding(planted: BenchCall) -> Result<BenchBinding, String> {
    binding(BindingSpec {
        workload: "projection-accounting-seats",
        control: "repeated-projection-accounting-pass",
        complexity: "projection-accounting-growth",
        formula: PROJECTION_FORMULA,
        axis: &PROJECTION_AXIS,
        measured: projection_measured,
        planted,
        judge: projection_judge,
        observations: &PROJECTION_OBSERVATIONS,
    })
}

fn binding(spec: BindingSpec) -> Result<BenchBinding, String> {
    let workload = WorkloadRef::named(OWNER, spec.workload).map_err(support::described)?;
    let planted_ref = PlantedWorseRef::named(OWNER, spec.control).map_err(support::described)?;
    let complexity =
        ComplexityClaimRef::named(OWNER, spec.complexity).map_err(support::described)?;
    let references = BenchReferences::declared(
        workload,
        bakery::harness::bench::PreflightRef::named(OWNER, "cross-subject-correctness")
            .map_err(support::described)?,
        planted_ref,
        complexity,
    );
    let measurement = BenchMeasurement::declared(
        InputSizeAxis::declared(spec.axis.to_vec()).map_err(support::described)?,
        DeclaredBudgets::declared(1, 1, 2, 1).map_err(support::described)?,
        ContentionPosture::NoDeclaredContention,
        Some(WorkFormula::encoded(spec.formula.to_vec()).map_err(support::described)?),
    );
    let row = BenchRow::declared(references, measurement).map_err(support::described)?;
    let observations = spec
        .observations
        .iter()
        .map(|stem| WorkObservationRef::named(OWNER, stem).map_err(support::described))
        .collect::<Result<Vec<_>, _>>()?;
    let attachment = BenchAttachment::attached(
        workload,
        spec.measured,
        planted_ref,
        spec.planted,
        WorkJudgeBinding::bound(complexity, spec.judge),
        observations,
    )
    .map_err(support::described)?;
    BenchBinding::bound(row, attachment, support::preflight()?).map_err(support::described)
}

fn shape_measured(
    input_size: u64,
    recorder: &mut WorkRecorder,
) -> Result<(), WorkRecordingRefusal> {
    let Some(metrics) = shape_metrics(input_size) else {
        return refuse_recording(recorder, "shape-compiler-refused", input_size);
    };
    record_shape(recorder, &metrics, 1)
}

fn shape_control(input_size: u64, recorder: &mut WorkRecorder) -> Result<(), WorkRecordingRefusal> {
    let (Some(first), Some(second)) = (shape_metrics(input_size), shape_metrics(input_size)) else {
        return refuse_recording(recorder, "shape-control-refused", input_size);
    };
    if first != second {
        return refuse_recording(recorder, "shape-control-drifted", input_size);
    }
    record_shape(recorder, &first, 2)
}

fn record_shape(
    recorder: &mut WorkRecorder,
    metrics: &ShapeMetrics,
    passes: u64,
) -> Result<(), WorkRecordingRefusal> {
    let values = [
        ("shape-source-bytes", metrics.source_bytes),
        ("shape-captured-trees", metrics.captured_trees),
        ("shape-captured-depth", metrics.captured_depth),
        ("shape-member-rows", metrics.member_rows),
        ("shape-planned-units", metrics.planned_units),
        ("shape-rendered-units", metrics.rendered_units),
        ("shape-generated-bytes", metrics.generated_bytes),
        ("shape-canonical-bytes", metrics.canonical_bytes),
        ("shape-delivered-bytes", metrics.delivered_bytes),
    ];
    for (stem, amount) in values {
        record_scaled(recorder, stem, amount, passes)?;
    }
    record(recorder, "shape-compiler-passes", passes)
}

fn projection_measured(
    input_size: u64,
    recorder: &mut WorkRecorder,
) -> Result<(), WorkRecordingRefusal> {
    let Some(metrics) = measured(input_size) else {
        return refuse_recording(recorder, "projection-accounting-refused", input_size);
    };
    record_projection(recorder, &metrics)
}

fn projection_control(
    input_size: u64,
    recorder: &mut WorkRecorder,
) -> Result<(), WorkRecordingRefusal> {
    let Some(metrics) = repeated(input_size) else {
        return refuse_recording(recorder, "projection-control-refused", input_size);
    };
    record_projection(recorder, &metrics)
}

fn record_projection(
    recorder: &mut WorkRecorder,
    metrics: &VariantMetrics,
) -> Result<(), WorkRecordingRefusal> {
    for (stem, amount) in [
        ("projection-source-bytes", metrics.source_bytes),
        ("projection-accounting-seats", metrics.projection_seats),
        ("projection-accounting-passes", metrics.accounting_passes),
        (
            "projection-disposition-comparisons",
            metrics.disposition_comparisons,
        ),
        ("projection-completed-seats", metrics.completed_seats),
    ] {
        record(recorder, stem, amount)?;
    }
    Ok(())
}

fn record_scaled(
    recorder: &mut WorkRecorder,
    stem: &'static str,
    amount: u64,
    multiplier: u64,
) -> Result<(), WorkRecordingRefusal> {
    let Some(amount) = amount.checked_mul(multiplier) else {
        return Err(amount_overflow(stem, multiplier));
    };
    record(recorder, stem, amount)
}

fn record(
    recorder: &mut WorkRecorder,
    stem: &'static str,
    amount: u64,
) -> Result<(), WorkRecordingRefusal> {
    let observation =
        WorkObservationRef::named(OWNER, stem).map_err(WorkRecordingRefusal::ObservationName)?;
    recorder.record(observation, amount)
}

fn refuse_recording(
    recorder: &mut WorkRecorder,
    stem: &'static str,
    input_size: u64,
) -> Result<(), WorkRecordingRefusal> {
    let observation =
        WorkObservationRef::named(OWNER, stem).map_err(WorkRecordingRefusal::ObservationName)?;
    recorder.record(observation, input_size)
}

fn amount_overflow(stem: &'static str, input_size: u64) -> WorkRecordingRefusal {
    match WorkObservationRef::named(OWNER, stem) {
        Ok(observation) => WorkRecordingRefusal::AmountOverflow {
            observation,
            input_size,
        },
        Err(refusal) => WorkRecordingRefusal::ObservationName(refusal),
    }
}

fn shape_judge(input: &WorkJudgmentInput<'_>) -> WorkJudgment {
    let owner = owner_matches(input, "shape-member-growth", SHAPE_FORMULA);
    let measured = if owner && shape_curve_holds(input.measured(), 1) {
        WorkConclusion::Satisfied
    } else {
        WorkConclusion::Refused(MEASURED_REFUSED)
    };
    let control = if owner && shape_curve_holds(input.planted_worse(), 2) {
        WorkConclusion::Refused(CONTROL_REFUSED)
    } else {
        WorkConclusion::Satisfied
    };
    let gap = if owner && all_counts_scaled(input.measured(), input.planted_worse(), 2) {
        WorkGapStanding::Distinguished
    } else {
        WorkGapStanding::NotDistinguished(GAP_REFUSED)
    };
    WorkJudgment::stated(measured, control, gap)
}

fn projection_judge(input: &WorkJudgmentInput<'_>) -> WorkJudgment {
    let owner = owner_matches(input, "projection-accounting-growth", PROJECTION_FORMULA);
    let measured = if owner && projection_curve_holds(input.measured(), 1) {
        WorkConclusion::Satisfied
    } else {
        WorkConclusion::Refused(MEASURED_REFUSED)
    };
    let control = if owner && projection_curve_holds(input.planted_worse(), 2) {
        WorkConclusion::Refused(CONTROL_REFUSED)
    } else {
        WorkConclusion::Satisfied
    };
    let gap = if owner && projection_gap_holds(input.measured(), input.planted_worse()) {
        WorkGapStanding::Distinguished
    } else {
        WorkGapStanding::NotDistinguished(GAP_REFUSED)
    };
    WorkJudgment::stated(measured, control, gap)
}

fn owner_matches(
    input: &WorkJudgmentInput<'_>,
    complexity: &'static str,
    formula: &'static [u8],
) -> bool {
    ComplexityClaimRef::named(OWNER, complexity).is_ok_and(|expected| {
        input.complexity() == expected
            && input
                .formula()
                .is_some_and(|observed| observed.bytes() == formula)
    })
}

fn shape_curve_holds(curve: &WorkCurve, passes: u64) -> bool {
    if curve.points().len() != SHAPE_AXIS.len() {
        return false;
    }
    curve.points().iter().all(|point| {
        let Some(metrics) = shape_metrics(point.input_size()) else {
            return false;
        };
        let values = [
            ("shape-source-bytes", metrics.source_bytes),
            ("shape-captured-trees", metrics.captured_trees),
            ("shape-captured-depth", metrics.captured_depth),
            ("shape-member-rows", metrics.member_rows),
            ("shape-planned-units", metrics.planned_units),
            ("shape-rendered-units", metrics.rendered_units),
            ("shape-generated-bytes", metrics.generated_bytes),
            ("shape-canonical-bytes", metrics.canonical_bytes),
            ("shape-delivered-bytes", metrics.delivered_bytes),
        ];
        values.into_iter().all(|(stem, amount)| {
            amount
                .checked_mul(passes)
                .is_some_and(|expected| count(point, stem) == Some(expected))
        }) && count(point, "shape-compiler-passes") == Some(passes)
    })
}

fn projection_curve_holds(curve: &WorkCurve, passes: u64) -> bool {
    if curve.points().len() != PROJECTION_AXIS.len() {
        return false;
    }
    curve.points().iter().all(|point| {
        let metrics = match passes {
            1 => measured(point.input_size()),
            2 => repeated(point.input_size()),
            _ => None,
        };
        let Some(metrics) = metrics else {
            return false;
        };
        count(point, "projection-source-bytes") == Some(metrics.source_bytes)
            && count(point, "projection-accounting-seats") == Some(metrics.projection_seats)
            && count(point, "projection-accounting-passes") == Some(metrics.accounting_passes)
            && count(point, "projection-disposition-comparisons")
                == Some(metrics.disposition_comparisons)
            && count(point, "projection-completed-seats") == Some(metrics.completed_seats)
    })
}

fn all_counts_scaled(measured: &WorkCurve, control: &WorkCurve, multiplier: u64) -> bool {
    measured
        .points()
        .iter()
        .zip(control.points())
        .all(|(measured, control)| {
            measured.input_size() == control.input_size()
                && measured.counts().len() == control.counts().len()
                && measured
                    .counts()
                    .iter()
                    .zip(control.counts())
                    .all(|(measured, control)| {
                        measured.observation() == control.observation()
                            && measured
                                .count()
                                .checked_mul(multiplier)
                                .is_some_and(|expected| expected == control.count())
                    })
        })
}

fn projection_gap_holds(measured: &WorkCurve, control: &WorkCurve) -> bool {
    measured
        .points()
        .iter()
        .zip(control.points())
        .all(|(measured, control)| {
            let static_equal = ["projection-source-bytes", "projection-accounting-seats"]
                .into_iter()
                .all(|stem| count(measured, stem) == count(control, stem));
            let doubled = [
                "projection-accounting-passes",
                "projection-disposition-comparisons",
                "projection-completed-seats",
            ]
            .into_iter()
            .all(|stem| {
                count(measured, stem).and_then(|value| value.checked_mul(2)) == count(control, stem)
            });
            measured.input_size() == control.input_size() && static_equal && doubled
        })
}

pub(super) fn count(point: &WorkCurvePoint, stem: &'static str) -> Option<u64> {
    let observation = WorkObservationRef::named(OWNER, stem).ok()?;
    point
        .counts()
        .iter()
        .find(|count| count.observation() == observation)
        .map(|count| count.count())
}
