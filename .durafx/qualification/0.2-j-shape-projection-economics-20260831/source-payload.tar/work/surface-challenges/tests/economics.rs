//! Cross-subject callable economics over the accepted shape and projection sources.

#![forbid(unsafe_code)]
#![deny(warnings)]

#[path = "../../surface-subject-macros/src/engine.rs"]
mod projection_engine;
#[path = "../../../shape-source/shape-subject-macros/src/engine.rs"]
mod shape_engine;
#[path = "economics/claims.rs"]
mod claims;
#[path = "economics/fixture.rs"]
mod fixture;
#[path = "economics/projection_variants/mod.rs"]
mod projection_variants;
#[path = "economics/readback.rs"]
mod readback;
#[path = "economics/source.rs"]
mod source;
#[path = "economics/support.rs"]
mod support;

#[test]
fn callable_shape_and_projection_economics_qualify() -> Result<(), String> {
    support::prove_host()?;
    if !source::accepted_shape_holds() {
        return Err("the accepted heterogeneous shape preflight refused".to_owned());
    }
    if !source::accepted_projection_holds() {
        return Err("the accepted three-seat projection preflight refused".to_owned());
    }
    if !source::shape_scaling_holds() {
        return Err("the homogeneous shape-member scaling preflight refused".to_owned());
    }
    if !source::projection_scaling_holds() {
        return Err("the projection-accounting scaling preflight refused".to_owned());
    }

    let identical = fixture::identical_control_table()?;
    let refused = bakery::harness::bench::run_all(&identical, &support::bench_invocation())
        .map_err(support::described)?;
    claims::assert_identical_controls_refused(&refused)?;

    let table = fixture::table()?;
    let report = bakery::harness::bench::run_all(&table, &support::bench_invocation())
        .map_err(support::described)?;
    bakery::harness::bench::bench_verdict(&report).map_err(support::described)?;
    claims::assert_complete_report(&table, &report)?;
    readback::write(&report)
}
