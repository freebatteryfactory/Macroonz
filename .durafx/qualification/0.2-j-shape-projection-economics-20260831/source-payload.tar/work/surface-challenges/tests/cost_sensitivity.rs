//! Typed custody for the scratch projection cost-sensitivity crossing.

#![forbid(unsafe_code)]
#![deny(warnings)]

#[path = "economics/mutation.rs"]
mod mutation;

#[test]
fn projection_cost_sensitivity_is_current_and_complete() -> Result<(), String> {
    mutation::assert_projection_cost_sensitivity()
}
