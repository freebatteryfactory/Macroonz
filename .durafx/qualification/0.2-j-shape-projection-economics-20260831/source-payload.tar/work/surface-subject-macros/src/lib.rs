#![forbid(unsafe_code)]
#![deny(warnings)]

extern crate proc_macro;

mod engine;

use bakery::compiler::host::{self, Spans};
use proc_macro::TokenStream;

/// Projects an explicit subject contract declaration into its public implementation.
#[proc_macro]
pub fn public_surface(input: TokenStream) -> TokenStream {
    let mut spans = Spans::empty();
    match host::capture(input, &mut spans) {
        Ok(capture) => match engine::compile(capture) {
            Ok(accounted) => host::emit(accounted.expansion()),
            Err(diagnostic) => host::place(&diagnostic, &spans),
        },
        Err(refusal) => refusal.placed(&spans),
    }
}
