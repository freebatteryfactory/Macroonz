#![forbid(unsafe_code)]
#![deny(warnings)]

use bakery::compiler::{
    Accounted, Bounded, CanonicalContent, CapturedInput, CapturedTokenTree, CrateBinding,
    Destination, Diagnostic, Disposition, DispositionSet, Door, Expansion, Family,
    GeneratedDelimiter, GeneratedToken, GeneratedTree, LineBody, NoQuestions, Observed, OwnerFact,
    Phase, Placement, Producer, RefusalClass, Refused, Repair, Request, Role, SoleRole, SpanTable,
};

const DOOR: Door = Door::declared(
    "surface-subject",
    "surface-subject.public-contract",
    "surface_subject_macros::public_surface",
    CrateBinding::declared("bakery"),
    Producer {
        namespace: "surface-subject",
        name: "surface-subject-macros",
    },
);

const GRAMMAR_FAMILY: Family = Family::declared("surface-subject/grammar");
const ACCOUNTING_FAMILY: Family = Family::declared("surface-subject/accounting");

const CONSUMER_NOT_REQUESTED: OwnerFact = OwnerFact {
    home: "surface-subject",
    name: "consumer-adapter-is-not-requested-by-this-declaration",
};

const CONSUMER_NOT_APPLICABLE: OwnerFact = OwnerFact {
    home: "surface-subject",
    name: "consumer-adapter-is-not-applicable-to-this-consumer",
};

const GUIDE_NOT_APPLICABLE: OwnerFact = OwnerFact {
    home: "surface-subject",
    name: "publication-guide-is-not-a-code-projection",
};

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct SurfaceDeclaration {
    pub(crate) contract_path: Vec<String>,
    pub(crate) member: String,
    pub(crate) generated_type: String,
    pub(crate) member_type: Vec<String>,
    pub(crate) member_value: u64,
    pub(crate) role: PublicSurfaceRole,
    pub(crate) destination: Destination,
}

impl CanonicalContent for SurfaceDeclaration {
    fn encode_content_into(&self, into: &mut Vec<u8>) {
        encode_path(&self.contract_path, into);
        bakery::compiler::encode_bytes(self.member.as_bytes(), into);
        bakery::compiler::encode_bytes(self.generated_type.as_bytes(), into);
        encode_path(&self.member_type, into);
        into.extend_from_slice(&self.member_value.to_be_bytes());
        into.extend_from_slice(&self.role.slot().to_be_bytes());
        into.push(match self.destination {
            Destination::DeclarationSite => 0,
            Destination::TestCarrier => 1,
            Destination::PublicationArtifact => 2,
            Destination::BenchCarrier => 3,
        });
    }
}

fn encode_path(path: &[String], into: &mut Vec<u8>) {
    into.extend_from_slice(&u64::try_from(path.len()).unwrap_or(u64::MAX).to_be_bytes());
    for segment in path {
        bakery::compiler::encode_bytes(segment.as_bytes(), into);
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum PublicSurfaceRole {
    PublicApi,
    HostileForeign,
}

impl Role for PublicSurfaceRole {
    const ALL: &'static [Self] = &[Self::PublicApi];

    fn name(self) -> &'static str {
        match self {
            Self::PublicApi => "public-api",
            Self::HostileForeign => "hostile-foreign",
        }
    }

    fn destination(self) -> Destination {
        match self {
            Self::PublicApi | Self::HostileForeign => Destination::DeclarationSite,
        }
    }
}

const _: PublicSurfaceRole = PublicSurfaceRole::HostileForeign;

bakery::compiler::kinds! {
    set = ProjectionKinds;
    dispositions = ProjectionDispositions;

    /// The ordinary public implementation generated at the declaration site.
    PublicSurface = "surface-subject.public-api", public_surface => SurfaceDeclaration, PublicSurfaceRole, NoQuestions;
    /// A possible consumer adapter this declaration does not request.
    ConsumerAdapter = "surface-subject.consumer-adapter", consumer_adapter => (), SoleRole, NoQuestions;
    /// A possible publication guide that is not a code projection here.
    PublicationGuide = "surface-subject.publication-guide", publication_guide => (), SoleRole, NoQuestions;
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum ConsumerPosture {
    NotRequested,
    NotApplicable,
}

const _: ConsumerPosture = ConsumerPosture::NotApplicable;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct GrammarRefusal;

impl Refused for GrammarRefusal {
    const PHASE: Phase = Phase::Capture;
    const FAMILY: Family = GRAMMAR_FAMILY;

    fn class(&self) -> RefusalClass {
        RefusalClass::DeclarationNotRead
    }

    fn first(&self) -> String {
        "the public surface declaration must state contract, member, generated type, member type and value, role, and destination".to_owned()
    }

    fn observed(&self) -> Observed {
        Observed::ContractDisagreement
    }

    fn body(&self) -> LineBody {
        LineBody::SingleCause
    }

    fn related(&self) -> Vec<Vec<u8>> {
        Vec::new()
    }

    fn repairs(&self) -> Bounded<Repair, 8> {
        Bounded::empty()
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct AccountingRefusal;

impl Refused for AccountingRefusal {
    const PHASE: Phase = Phase::Binding;
    const FAMILY: Family = ACCOUNTING_FAMILY;

    fn class(&self) -> RefusalClass {
        RefusalClass::DeclarationNotRead
    }

    fn first(&self) -> String {
        "the projection disposition roster did not completely account for its declared kind set"
            .to_owned()
    }

    fn observed(&self) -> Observed {
        Observed::ContractDisagreement
    }

    fn body(&self) -> LineBody {
        LineBody::SingleCause
    }

    fn related(&self) -> Vec<Vec<u8>> {
        Vec::new()
    }

    fn repairs(&self) -> Bounded<Repair, 8> {
        Bounded::empty()
    }
}

fn whole<E: Refused>(refusal: &E) -> Diagnostic {
    Diagnostic::refused(refusal, &DOOR, &Placement::WholeDeclaration)
}

fn grammar_refusal(capture: &CapturedInput) -> Diagnostic {
    let refusal = GrammarRefusal;
    match capture.trees().first() {
        Some(tree) => Diagnostic::refused(
            &refusal,
            &DOOR,
            &Placement::AtToken {
                token: tree.span(),
                spans: &SpanTable::ProducerHeld,
            },
        ),
        None => whole(&refusal),
    }
}

struct Parser<'tokens> {
    tokens: &'tokens [CapturedTokenTree],
    cursor: usize,
}

impl<'tokens> Parser<'tokens> {
    const fn over(tokens: &'tokens [CapturedTokenTree]) -> Self {
        Self { tokens, cursor: 0 }
    }

    fn next(&mut self) -> Option<&'tokens CapturedTokenTree> {
        let next = self.tokens.get(self.cursor);
        self.cursor = self.cursor.saturating_add(1);
        next
    }

    fn word(&mut self, expected: &str) -> bool {
        self.next().and_then(CapturedTokenTree::word) == Some(expected)
    }

    fn punct(&mut self, expected: char) -> bool {
        self.next().and_then(CapturedTokenTree::punct) == Some(expected)
    }

    fn identifier(&mut self) -> Option<String> {
        self.next()
            .and_then(CapturedTokenTree::word)
            .map(str::to_owned)
    }

    fn path(&mut self) -> Option<Vec<String>> {
        let mut segments = vec![self.identifier()?];
        while self
            .tokens
            .get(self.cursor)
            .is_some_and(|tree| tree.punct() == Some(':'))
        {
            if !(self.punct(':') && self.punct(':')) {
                return None;
            }
            segments.push(self.identifier()?);
        }
        Some(segments)
    }

    fn comma(&mut self) -> bool {
        self.punct(',')
    }

    fn finished(&self) -> bool {
        self.cursor == self.tokens.len()
    }
}

pub(crate) fn read_declaration(capture: &CapturedInput) -> Result<SurfaceDeclaration, Diagnostic> {
    let mut parser = Parser::over(capture.trees());
    let parsed = (|| {
        if !(parser.word("contract") && parser.punct('=')) {
            return None;
        }
        let contract_path = parser.path()?;
        if !(parser.comma() && parser.word("member") && parser.punct('=')) {
            return None;
        }
        let member = parser.identifier()?;
        if !(parser.comma() && parser.word("generated_type") && parser.punct('=')) {
            return None;
        }
        let generated_type = parser.identifier()?;
        if !(parser.comma() && parser.word("member_type") && parser.punct('=')) {
            return None;
        }
        let member_type = parser.path()?;
        if !(parser.comma() && parser.word("member_value") && parser.punct('=')) {
            return None;
        }
        let member_value = parser.next()?.number()?.parse::<u64>().ok()?;
        if !(parser.comma()
            && parser.word("role")
            && parser.punct('=')
            && parser.word("public_api"))
        {
            return None;
        }
        if !(parser.comma()
            && parser.word("destination")
            && parser.punct('=')
            && parser.word("declaration_site")
            && parser.finished())
        {
            return None;
        }
        Some(SurfaceDeclaration {
            contract_path,
            member,
            generated_type,
            member_type,
            member_value,
            role: PublicSurfaceRole::PublicApi,
            destination: Destination::DeclarationSite,
        })
    })();
    parsed.ok_or_else(|| grammar_refusal(capture))
}

fn path_tokens(path: &[String]) -> Vec<GeneratedToken> {
    let mut tokens = Vec::new();
    for segment in path {
        if !tokens.is_empty() {
            tokens.push(GeneratedToken::joint(':'));
            tokens.push(GeneratedToken::alone(':'));
        }
        tokens.push(GeneratedToken::word(segment));
    }
    tokens
}

fn public_tree(
    declaration: &SurfaceDeclaration,
) -> Result<GeneratedTree, bakery::compiler::RenderError> {
    let mut tokens = vec![
        GeneratedToken::word("pub"),
        GeneratedToken::word("struct"),
        GeneratedToken::word(&declaration.generated_type),
        GeneratedToken::alone(';'),
        GeneratedToken::word("impl"),
    ];
    tokens.extend(path_tokens(&declaration.contract_path));
    tokens.push(GeneratedToken::word("for"));
    tokens.push(GeneratedToken::word(&declaration.generated_type));
    let mut body = vec![
        GeneratedToken::word("const"),
        GeneratedToken::word(&declaration.member),
        GeneratedToken::alone(':'),
    ];
    body.extend(path_tokens(&declaration.member_type));
    body.extend([
        GeneratedToken::alone('='),
        GeneratedToken::number(declaration.member_value),
        GeneratedToken::alone(';'),
    ]);
    tokens.push(bakery::compiler::group(GeneratedDelimiter::Brace, body)?);
    GeneratedTree::assembled(tokens).map_err(bakery::compiler::RenderError::from)
}

pub(crate) fn terminal(
    capture: CapturedInput,
    declaration: &SurfaceDeclaration,
) -> Result<Expansion<PublicSurface>, Diagnostic> {
    Request::<PublicSurface>::over(capture, declaration.clone(), &DOOR)
        .render(|_plan, output| output.unit(declaration.role, public_tree(declaration)?))
}

pub(crate) fn accounted(
    expansion: Expansion<PublicSurface>,
    posture: ConsumerPosture,
) -> Result<Accounted<PublicSurface, ProjectionKinds>, Diagnostic> {
    let generated = expansion
        .plan()
        .membership()
        .under(PublicSurfaceRole::PublicApi)
        .map(|member| member.output.semantic_key)
        .ok_or_else(|| whole(&AccountingRefusal))?;
    let consumer_adapter = match posture {
        ConsumerPosture::NotRequested => Disposition::NotRequested {
            because: CONSUMER_NOT_REQUESTED,
        },
        ConsumerPosture::NotApplicable => Disposition::NotApplicable {
            because: CONSUMER_NOT_APPLICABLE,
        },
    };
    let dispositions = DispositionSet::<ProjectionKinds>::complete(ProjectionDispositions {
        public_surface: Disposition::Generated { unit: generated },
        consumer_adapter,
        publication_guide: Disposition::NotApplicable {
            because: GUIDE_NOT_APPLICABLE,
        },
    })
    .map_err(|_refusal| whole(&AccountingRefusal))?;
    Ok(Accounted::seated(expansion, dispositions))
}

pub(crate) fn compile(
    capture: CapturedInput,
) -> Result<Accounted<PublicSurface, ProjectionKinds>, Diagnostic> {
    let declaration = read_declaration(&capture)?;
    let expansion = terminal(capture, &declaration)?;
    accounted(expansion, ConsumerPosture::NotRequested)
}
