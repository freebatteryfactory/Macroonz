#![forbid(unsafe_code)]
#![deny(warnings)]

#[path = "../src/engine.rs"]
mod engine;

mod tests {
    use super::engine::{
        ConsumerPosture, ProjectionKinds, PublicSurface, PublicSurfaceRole, accounted, compile,
        read_declaration, terminal,
    };
    use bakery::compiler::request::committed;
    use bakery::compiler::{
        Closure, ClosureIssue, Disposition, DispositionRecord, DispositionSet, DispositionSetError,
        GeneratedToken, GeneratedTree, KindSet, OwnerFact, PlannedMember, RenderedProjection,
        RenderedUnit, TextCapture,
    };

    const DECLARATION: &str = concat!(
        "contract = crate::PublicContract, ",
        "member = VALUE, ",
        "generated_type = GeneratedSurface, ",
        "member_type = u64, ",
        "member_value = 73, ",
        "role = public_api, ",
        "destination = declaration_site"
    );

    const CHANGED_DECLARATION: &str = concat!(
        "contract = crate::PublicContract, ",
        "member = VALUE, ",
        "generated_type = GeneratedSurface, ",
        "member_type = u64, ",
        "member_value = 74, ",
        "role = public_api, ",
        "destination = declaration_site"
    );

    const HOSTILE_FACT: OwnerFact = OwnerFact {
        home: "surface-challenges",
        name: "hostile-disposition-control",
    };

    fn read(source: &str) -> Result<bakery::compiler::CapturedInput, String> {
        TextCapture::read(source)
            .map(|capture| capture.input().clone())
            .map_err(|error| error.to_string())
    }

    fn expansion(source: &str) -> Result<bakery::compiler::Expansion<PublicSurface>, String> {
        let capture = read(source)?;
        let declaration = read_declaration(&capture).map_err(|error| error.summary().to_owned())?;
        terminal(capture, &declaration).map_err(|error| error.summary().to_owned())
    }

    fn require_refusal<Value, Refusal>(
        result: Result<Value, Refusal>,
        accepted: &str,
    ) -> Result<Refusal, String> {
        match result {
            Ok(_) => Err(accepted.to_owned()),
            Err(refusal) => Ok(refusal),
        }
    }

    #[test]
    fn explicit_declaration_moves_every_semantic_reading() -> Result<(), String> {
        let first_capture = read(DECLARATION)?;
        let repeated_capture = read(DECLARATION)?;
        let changed_capture = read(CHANGED_DECLARATION)?;
        assert_eq!(committed(&first_capture), committed(&repeated_capture));
        assert_ne!(committed(&first_capture), committed(&changed_capture));

        let first = expansion(DECLARATION)?;
        let repeated = expansion(DECLARATION)?;
        let changed = expansion(CHANGED_DECLARATION)?;
        assert_eq!(
            first.plan().account().content_commitment(),
            repeated.plan().account().content_commitment()
        );
        assert_eq!(first.plan().identity(), repeated.plan().identity());
        assert_eq!(first.closure().identity(), repeated.closure().identity());
        assert_eq!(first.explain().identity(), repeated.explain().identity());
        assert_eq!(first.identity(), repeated.identity());

        assert_ne!(
            first.plan().account().content_commitment(),
            changed.plan().account().content_commitment()
        );
        assert_ne!(first.plan().identity(), changed.plan().identity());
        assert_ne!(first.closure().identity(), changed.closure().identity());
        assert_ne!(first.explain().identity(), changed.explain().identity());
        assert_ne!(first.identity(), changed.identity());
        Ok(())
    }

    #[test]
    fn disposition_only_change_preserves_the_exact_expansion() -> Result<(), String> {
        let expansion = expansion(DECLARATION)?;
        let not_requested = accounted(expansion.clone(), ConsumerPosture::NotRequested)
            .map_err(|error| error.summary().to_owned())?;
        let not_applicable = accounted(expansion.clone(), ConsumerPosture::NotApplicable)
            .map_err(|error| error.summary().to_owned())?;
        assert_eq!(not_requested.expansion(), &expansion);
        assert_eq!(not_applicable.expansion(), &expansion);
        assert_ne!(not_requested.dispositions(), not_applicable.dispositions());
        assert_ne!(not_requested, not_applicable);
        assert_eq!(not_requested.dispositions().len(), 3);
        Ok(())
    }

    #[test]
    fn closure_refuses_an_omitted_or_doubled_sole_output() -> Result<(), String> {
        let bound = expansion(DECLARATION)?;
        let planned = bound
            .plan()
            .membership()
            .under(PublicSurfaceRole::PublicApi)
            .ok_or_else(|| "public API plan member absent".to_owned())?;
        let foreign = PlannedMember {
            role: PublicSurfaceRole::HostileForeign,
            output: planned.output.clone(),
        };
        let foreign_tree = GeneratedTree::assembled(vec![
            GeneratedToken::word("struct"),
            GeneratedToken::word("Foreign"),
            GeneratedToken::alone(';'),
        ])
        .map_err(|error| error.to_string())?;
        let foreign_unit = RenderedUnit::materialized(&foreign, foreign_tree)
            .map_err(|error| error.to_string())?;
        let omitted = require_refusal(
            Closure::proved(bound.plan(), RenderedProjection::of_one(foreign_unit)),
            "a rendering omitting the sole planned output unexpectedly closed",
        )?;
        assert!(omitted.issues().iter().any(|issue| {
            issue
                == &ClosureIssue::MemberMissing {
                    role: PublicSurfaceRole::PublicApi,
                }
        }));

        let public = bound
            .closure()
            .rendered()
            .under(PublicSurfaceRole::PublicApi)
            .ok_or_else(|| "public API rendered unit absent".to_owned())?
            .clone();
        let doubled = RenderedProjection::materialized(vec![public.clone(), public])
            .map_err(|error| error.to_string())?;
        let duplicated = require_refusal(
            Closure::proved(bound.plan(), doubled),
            "a doubled sole output unexpectedly closed",
        )?;
        assert!(duplicated.issues().iter().any(|issue| {
            issue
                == &ClosureIssue::MemberDuplicated {
                    role: PublicSurfaceRole::PublicApi,
                    observed: 2,
                }
        }));
        Ok(())
    }

    #[derive(Debug, Clone, Copy, PartialEq, Eq)]
    struct TruncatedRecord;

    impl DispositionRecord for TruncatedRecord {
        fn into_dispositions(self) -> impl Iterator<Item = (&'static str, Disposition)> {
            [
                (
                    "surface-subject.public-api",
                    Disposition::NotApplicable {
                        because: HOSTILE_FACT,
                    },
                ),
                (
                    "surface-subject.consumer-adapter",
                    Disposition::NotRequested {
                        because: HOSTILE_FACT,
                    },
                ),
            ]
            .into_iter()
        }
    }

    struct TruncatedKinds;

    impl KindSet for TruncatedKinds {
        type Dispositions = TruncatedRecord;
        const NAMES: &'static [&'static str] = <ProjectionKinds as KindSet>::NAMES;
    }

    #[derive(Debug, Clone, Copy, PartialEq, Eq)]
    struct ForeignRecord;

    impl DispositionRecord for ForeignRecord {
        fn into_dispositions(self) -> impl Iterator<Item = (&'static str, Disposition)> {
            [
                (
                    "surface-subject.public-api",
                    Disposition::NotApplicable {
                        because: HOSTILE_FACT,
                    },
                ),
                (
                    "surface-subject.foreign",
                    Disposition::NotApplicable {
                        because: HOSTILE_FACT,
                    },
                ),
                (
                    "surface-subject.publication-guide",
                    Disposition::NotApplicable {
                        because: HOSTILE_FACT,
                    },
                ),
            ]
            .into_iter()
        }
    }

    struct ForeignKinds;

    impl KindSet for ForeignKinds {
        type Dispositions = ForeignRecord;
        const NAMES: &'static [&'static str] = <ProjectionKinds as KindSet>::NAMES;
    }

    #[test]
    fn disposition_completion_refuses_omission_and_foreign_substitution() -> Result<(), String> {
        let omitted = require_refusal(
            DispositionSet::<TruncatedKinds>::complete(TruncatedRecord),
            "an incomplete disposition record unexpectedly completed",
        )?;
        assert_eq!(
            omitted,
            DispositionSetError::CountMismatch {
                expected: 3,
                observed: 2,
            }
        );
        let foreign = require_refusal(
            DispositionSet::<ForeignKinds>::complete(ForeignRecord),
            "a foreign disposition record unexpectedly completed",
        )?;
        assert_eq!(
            foreign,
            DispositionSetError::KindMismatch {
                expected: "surface-subject.consumer-adapter",
                observed: "surface-subject.foreign",
            }
        );
        Ok(())
    }

    #[test]
    fn grammar_has_no_selector_or_disposition_clause() -> Result<(), String> {
        let compiled = compile(read(DECLARATION)?).map_err(|error| error.summary().to_owned())?;
        assert_eq!(compiled.dispositions().len(), 3);
        let declaration =
            read_declaration(&read(DECLARATION)?).map_err(|error| error.summary().to_owned())?;
        assert_eq!(declaration.contract_path, ["crate", "PublicContract"]);
        assert_eq!(declaration.member, "VALUE");
        assert_eq!(declaration.generated_type, "GeneratedSurface");
        assert_eq!(declaration.member_type, ["u64"]);
        assert_eq!(declaration.member_value, 73);
        assert_eq!(declaration.role, PublicSurfaceRole::PublicApi);
        Ok(())
    }
}
