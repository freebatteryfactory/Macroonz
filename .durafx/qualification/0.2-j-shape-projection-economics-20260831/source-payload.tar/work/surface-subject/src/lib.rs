#![forbid(unsafe_code)]
#![deny(warnings)]

use surface_subject_macros::public_surface;

/// The subject-owned public contract shared by the direct and generated roads.
pub trait PublicContract {
    /// The public value declared by an implementation.
    const VALUE: u64;
}

public_surface! {
    contract = crate::PublicContract,
    member = VALUE,
    generated_type = GeneratedSurface,
    member_type = u64,
    member_value = 73,
    role = public_api,
    destination = declaration_site
}

/// The direct handwritten equivalent of the generated marker.
pub struct HandwrittenSurface;

impl PublicContract for HandwrittenSurface {
    const VALUE: u64 = 73;
}
