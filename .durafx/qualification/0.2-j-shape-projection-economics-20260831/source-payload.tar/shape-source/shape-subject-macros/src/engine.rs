#![forbid(unsafe_code)]
#![deny(warnings)]

use bakery::compiler::codec::{
    AssemblyPosture, Cardinality, CodecAssembly, CodecContent, CodecDirection, CodecMember,
    CodecMemberShape, CodecPlacement, CodecShape, CodecTypePath, PathRooting, codec_surface,
};
use bakery::compiler::{
    Bounded, CanonicalContent, CapturedDelimiter, CapturedInput, CapturedTokenTree, CrateBinding,
    Diagnostic, Door, Family, GeneratedDelimiter, GeneratedToken, GeneratedTree, Kind, LineBody,
    NoQuestions, Observed, Phase, Placement, Producer, RefusalClass, Refused, Repair, Request,
    SoleRole, SpanHandle, SpanTable,
};

const DOOR: Door = Door::declared(
    "shape-subject",
    "shape-subject.codec-record",
    "shape_subject_macros::codec_record",
    CrateBinding::declared("bakery"),
    Producer {
        namespace: "shape-subject",
        name: "shape-subject-macros",
    },
);

const GRAMMAR_FAMILY: Family = Family::declared("shape-subject/codec-record-grammar");

#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) struct MemberSpec {
    pub(crate) spelling: String,
    pub(crate) held_as: String,
    pub(crate) shape: CodecMemberShape,
    pub(crate) cardinality: Cardinality,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) struct Declaration {
    pub(crate) name: String,
    pub(crate) members: Vec<MemberSpec>,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) struct RecordContent {
    pub(crate) declaration: Declaration,
    pub(crate) codec: CodecContent,
}

impl CanonicalContent for RecordContent {
    fn encode_content_into(&self, into: &mut Vec<u8>) {
        self.codec.encode_content_into(into);
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) struct RecordProjection;

impl Kind for RecordProjection {
    const NAME: &'static str = "shape-subject.codec-record";
    type Content = RecordContent;
    type Role = SoleRole;
    type Question = NoQuestions;
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) enum GrammarIssue {
    MalformedDeclaration,
    RecordNameNotAnIdentifier,
    MembersAbsent,
    MalformedMember,
    UnsupportedShape(String),
    UnsupportedCardinality(String),
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) struct GrammarRefusal {
    issue: GrammarIssue,
    at: Option<SpanHandle>,
}

impl GrammarRefusal {
    pub(crate) const fn issue(&self) -> &GrammarIssue {
        &self.issue
    }

    pub(crate) const fn token(&self) -> Option<SpanHandle> {
        self.at
    }

    fn at(issue: GrammarIssue, token: &CapturedTokenTree) -> Self {
        Self {
            issue,
            at: Some(token.span()),
        }
    }

    fn whole(issue: GrammarIssue) -> Self {
        Self { issue, at: None }
    }

    fn diagnostic(&self) -> Diagnostic {
        match self.token() {
            Some(token) => Diagnostic::refused(
                self,
                &DOOR,
                &Placement::AtToken {
                    token,
                    spans: &SpanTable::ProducerHeld,
                },
            ),
            None => Diagnostic::refused(self, &DOOR, &Placement::WholeDeclaration),
        }
    }
}

impl Refused for GrammarRefusal {
    const PHASE: Phase = Phase::Capture;
    const FAMILY: Family = GRAMMAR_FAMILY;

    fn class(&self) -> RefusalClass {
        RefusalClass::DeclarationNotRead
    }

    fn first(&self) -> String {
        match self.issue() {
            GrammarIssue::MalformedDeclaration => {
                "the declaration must be `record Name { member: Type => shape cardinality, ... }`"
                    .to_owned()
            }
            GrammarIssue::RecordNameNotAnIdentifier => {
                "the declared record name is not one ordinary Rust identifier".to_owned()
            }
            GrammarIssue::MembersAbsent => "the declared record carries no member row".to_owned(),
            GrammarIssue::MalformedMember => {
                "a member must be `name: Type => shape cardinality,`".to_owned()
            }
            GrammarIssue::UnsupportedShape(shape) => {
                format!("the member shape `{shape}` is not in this subject grammar")
            }
            GrammarIssue::UnsupportedCardinality(cardinality) => {
                format!("the member cardinality `{cardinality}` is not in this subject grammar")
            }
        }
    }

    fn observed(&self) -> Observed {
        Observed::ContractDisagreement
    }

    fn body(&self) -> LineBody {
        LineBody::SingleCause
    }

    fn related(&self) -> Vec<Vec<u8>> {
        Vec::new()
    }

    fn repairs(&self) -> Bounded<Repair, 8> {
        Bounded::empty()
    }
}

pub(crate) fn read_declaration(capture: &CapturedInput) -> Result<Declaration, GrammarRefusal> {
    let [record, name, body] = capture.trees() else {
        return Err(capture.trees().first().map_or_else(
            || GrammarRefusal::whole(GrammarIssue::MalformedDeclaration),
            |token| GrammarRefusal::at(GrammarIssue::MalformedDeclaration, token),
        ));
    };
    if record.word() != Some("record") {
        return Err(GrammarRefusal::at(
            GrammarIssue::MalformedDeclaration,
            record,
        ));
    }
    let Some(name) = name
        .word()
        .filter(|spelling| bakery::compiler::rendered_name(spelling))
    else {
        return Err(GrammarRefusal::at(
            GrammarIssue::RecordNameNotAnIdentifier,
            name,
        ));
    };
    let Some((CapturedDelimiter::Brace, member_tokens)) = body.group() else {
        return Err(GrammarRefusal::at(GrammarIssue::MalformedDeclaration, body));
    };
    let members = read_members(member_tokens)?;
    Ok(Declaration {
        name: name.to_owned(),
        members,
    })
}

fn read_members(tokens: &[CapturedTokenTree]) -> Result<Vec<MemberSpec>, GrammarRefusal> {
    if tokens.is_empty() {
        return Err(GrammarRefusal::whole(GrammarIssue::MembersAbsent));
    }
    let (rows, remainder) = tokens.as_chunks::<8>();
    let mut members = Vec::new();
    for [
        spelling,
        colon,
        held_as,
        equals,
        arrow,
        shape,
        cardinality,
        comma,
    ] in rows
    {
        let Some(spelling) = spelling.word() else {
            return Err(GrammarRefusal::at(GrammarIssue::MalformedMember, spelling));
        };
        let Some(held_as) = held_as.word() else {
            return Err(GrammarRefusal::at(GrammarIssue::MalformedMember, held_as));
        };
        if colon.punct() != Some(':') {
            return Err(GrammarRefusal::at(GrammarIssue::MalformedMember, colon));
        }
        if equals.joint_punct() != Some('=') {
            return Err(GrammarRefusal::at(GrammarIssue::MalformedMember, equals));
        }
        if arrow.punct() != Some('>') {
            return Err(GrammarRefusal::at(GrammarIssue::MalformedMember, arrow));
        }
        if comma.punct() != Some(',') {
            return Err(GrammarRefusal::at(GrammarIssue::MalformedMember, comma));
        }
        let shape = read_shape(shape)?;
        let cardinality = read_cardinality(cardinality)?;
        members.push(MemberSpec {
            spelling: spelling.to_owned(),
            held_as: held_as.to_owned(),
            shape,
            cardinality,
        });
    }
    if let Some(token) = remainder.first() {
        return Err(GrammarRefusal::at(GrammarIssue::MalformedMember, token));
    }
    Ok(members)
}

fn read_shape(token: &CapturedTokenTree) -> Result<CodecMemberShape, GrammarRefusal> {
    match token.word() {
        Some("count") => Ok(CodecMemberShape::Count),
        Some("bytes") => Ok(CodecMemberShape::Bytes),
        Some("text") => Ok(CodecMemberShape::Text),
        Some("closed_choice") => Ok(CodecMemberShape::ClosedChoice),
        Some("nested") => Ok(CodecMemberShape::Nested),
        Some(spelling) => Err(GrammarRefusal::at(
            GrammarIssue::UnsupportedShape(spelling.to_owned()),
            token,
        )),
        None => Err(GrammarRefusal::at(GrammarIssue::MalformedMember, token)),
    }
}

fn read_cardinality(token: &CapturedTokenTree) -> Result<Cardinality, GrammarRefusal> {
    match token.word() {
        Some("required") => Ok(Cardinality::Required),
        Some("optional") => Ok(Cardinality::Optional),
        Some("repeated") => Ok(Cardinality::Repeated),
        Some(spelling) => Err(GrammarRefusal::at(
            GrammarIssue::UnsupportedCardinality(spelling.to_owned()),
            token,
        )),
        None => Err(GrammarRefusal::at(GrammarIssue::MalformedMember, token)),
    }
}

fn whole<E: Refused>(refusal: &E) -> Diagnostic {
    Diagnostic::refused(refusal, &DOOR, &Placement::WholeDeclaration)
}

fn in_scope(spelling: &str) -> Result<CodecTypePath, Diagnostic> {
    CodecTypePath::spelled(PathRooting::InScope, vec![spelling.to_owned()])
        .map_err(|refusal| whole(&refusal))
}

pub(crate) fn declared_content(declaration: Declaration) -> Result<RecordContent, Diagnostic> {
    let refusal = format!("{}DecodeError", declaration.name);
    let assembly = CodecAssembly::stated("assembled", AssemblyPosture::Total)
        .map_err(|error| whole(&error))?;
    let members = declaration
        .members
        .iter()
        .map(|member| {
            CodecMember::declared(
                &member.spelling,
                in_scope(&member.held_as)?,
                member.shape,
                member.cardinality,
            )
            .map_err(|error| whole(&error))
        })
        .collect::<Result<Vec<_>, _>>()?;
    let shape = CodecShape::declared(in_scope(&declaration.name)?, &refusal, assembly, members)
        .map_err(|error| whole(&error))?;
    Ok(RecordContent {
        declaration,
        codec: CodecContent {
            shape,
            direction: CodecDirection::RoundTrip,
            placement: CodecPlacement::AtDeclarationSite,
            schema: None,
            byte_role: None,
            assumptions: Bounded::empty(),
        },
    })
}

fn derived() -> Result<Vec<GeneratedToken>, bakery::compiler::Overflow> {
    let traits = vec![
        GeneratedToken::word("Debug"),
        GeneratedToken::alone(','),
        GeneratedToken::word("Clone"),
        GeneratedToken::alone(','),
        GeneratedToken::word("PartialEq"),
        GeneratedToken::alone(','),
        GeneratedToken::word("Eq"),
    ];
    bakery::compiler::attribute(vec![
        GeneratedToken::word("derive"),
        bakery::compiler::group(GeneratedDelimiter::Parenthesis, traits)?,
    ])
}

fn held_tokens(member: &MemberSpec) -> Vec<GeneratedToken> {
    match member.cardinality {
        Cardinality::Required => vec![GeneratedToken::word(&member.held_as)],
        Cardinality::Optional => generic("Option", &member.held_as),
        Cardinality::Repeated => generic("Vec", &member.held_as),
    }
}

fn field(member: &MemberSpec) -> Vec<GeneratedToken> {
    let mut tokens = vec![
        GeneratedToken::word("pub"),
        GeneratedToken::word(&member.spelling),
        GeneratedToken::alone(':'),
    ];
    tokens.extend(held_tokens(member));
    tokens.push(GeneratedToken::alone(','));
    tokens
}

fn parameter(member: &MemberSpec) -> Vec<GeneratedToken> {
    let mut tokens = vec![
        GeneratedToken::word(&member.spelling),
        GeneratedToken::alone(':'),
    ];
    tokens.extend(held_tokens(member));
    tokens.push(GeneratedToken::alone(','));
    tokens
}

fn generic(root: &str, argument: &str) -> Vec<GeneratedToken> {
    vec![
        GeneratedToken::word(root),
        GeneratedToken::alone('<'),
        GeneratedToken::word(argument),
        GeneratedToken::alone('>'),
    ]
}

fn record_tokens(
    declaration: &Declaration,
) -> Result<Vec<GeneratedToken>, bakery::compiler::Overflow> {
    let mut fields = Vec::new();
    let mut parameters = Vec::new();
    let mut values = Vec::new();
    for member in &declaration.members {
        fields.extend(field(member));
        parameters.extend(parameter(member));
        values.push(GeneratedToken::word(&member.spelling));
        values.push(GeneratedToken::alone(','));
    }
    let mut tokens = derived()?;
    tokens.extend([
        GeneratedToken::word("pub"),
        GeneratedToken::word("struct"),
        GeneratedToken::word(&declaration.name),
        bakery::compiler::group(GeneratedDelimiter::Brace, fields)?,
    ]);
    let body = vec![
        GeneratedToken::word("Self"),
        bakery::compiler::group(GeneratedDelimiter::Brace, values)?,
    ];
    let assembly = vec![
        GeneratedToken::word("fn"),
        GeneratedToken::word("assembled"),
        bakery::compiler::group(GeneratedDelimiter::Parenthesis, parameters)?,
        GeneratedToken::joint('-'),
        GeneratedToken::alone('>'),
        GeneratedToken::word("Self"),
        bakery::compiler::group(GeneratedDelimiter::Brace, body)?,
    ];
    tokens.extend([
        GeneratedToken::word("impl"),
        GeneratedToken::word(&declaration.name),
        bakery::compiler::group(GeneratedDelimiter::Brace, assembly)?,
    ]);
    Ok(tokens)
}

fn render_record(
    plan: &bakery::compiler::Plan<RecordProjection>,
    output: &mut bakery::compiler::Output<'_, RecordProjection>,
) -> Result<(), bakery::compiler::RenderError> {
    let mut tokens = record_tokens(&plan.content().declaration)?;
    let codec = codec_surface(&plan.content().codec)?;
    tokens.extend(codec.tokens().iter().cloned());
    output.unit(SoleRole::Sole, GeneratedTree::assembled(tokens)?)
}

pub(crate) fn compile(
    capture: CapturedInput,
) -> Result<bakery::compiler::Expansion<RecordProjection>, Diagnostic> {
    let declaration = read_declaration(&capture).map_err(|refusal| refusal.diagnostic())?;
    let content = declared_content(declaration)?;
    Request::<RecordProjection>::over(capture, content, &DOOR).render(render_record)
}
