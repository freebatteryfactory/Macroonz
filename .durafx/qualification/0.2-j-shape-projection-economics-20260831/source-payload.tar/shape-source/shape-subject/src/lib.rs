#![forbid(unsafe_code)]
#![deny(warnings)]

use shape_subject_macros::codec_record;

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ByteParcel(Vec<u8>);

impl ByteParcel {
    #[must_use]
    pub fn new(bytes: Vec<u8>) -> Self {
        Self(bytes)
    }

    #[must_use]
    pub fn bytes(&self) -> &[u8] {
        &self.0
    }
}

impl AsRef<[u8]> for ByteParcel {
    fn as_ref(&self) -> &[u8] {
        &self.0
    }
}

impl TryFrom<Vec<u8>> for ByteParcel {
    type Error = ();

    fn try_from(bytes: Vec<u8>) -> Result<Self, Self::Error> {
        if bytes.first() == Some(&0xff) {
            Err(())
        } else {
            Ok(Self(bytes))
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Mode {
    First,
    Second,
}

impl Mode {
    pub const ALL: [Self; 2] = [Self::First, Self::Second];

    #[must_use]
    pub const fn slot(self) -> u8 {
        match self {
            Self::First => 0,
            Self::Second => 1,
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Nested(u8);

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct NestedDecodeError;

impl Nested {
    #[must_use]
    pub const fn new(value: u8) -> Self {
        Self(value)
    }

    #[must_use]
    pub const fn value(&self) -> u8 {
        self.0
    }

    pub fn encode_canonical(&self, into: &mut Vec<u8>) {
        into.push(self.0);
    }

    /// Reads one nested value from its complete canonical bytes.
    ///
    /// # Errors
    ///
    /// Returns [`NestedDecodeError`] unless the material is exactly one nonzero byte.
    pub fn decode_canonical(material: &[u8]) -> Result<Self, NestedDecodeError> {
        match material {
            [value] if *value != 0 => Ok(Self(*value)),
            _ => Err(NestedDecodeError),
        }
    }
}

codec_record! {
    record LedgerRecord {
        count: u16 => count required,
        payload: ByteParcel => bytes required,
        label: String => text optional,
        modes: Mode => closed_choice repeated,
        child: Nested => nested required,
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct HandwrittenRecord {
    pub count: u16,
    pub payload: ByteParcel,
    pub label: Option<String>,
    pub modes: Vec<Mode>,
    pub child: Nested,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum HandwrittenDecodeError {
    Truncated,
    Invalid,
    TrailingBytes,
}

impl HandwrittenRecord {
    pub fn encode_canonical(&self, into: &mut Vec<u8>) {
        into.extend_from_slice(&u64::from(self.count).to_be_bytes());
        frame(self.payload.as_ref(), into);
        into.push(u8::from(self.label.is_some()));
        if let Some(label) = &self.label {
            frame(label.as_bytes(), into);
        }
        into.extend_from_slice(
            &u64::try_from(self.modes.len())
                .unwrap_or(u64::MAX)
                .to_be_bytes(),
        );
        into.extend(self.modes.iter().map(|mode| mode.slot()));
        let mut nested = Vec::new();
        self.child.encode_canonical(&mut nested);
        frame(&nested, into);
    }

    /// Reads the handwritten record from its complete canonical bytes.
    ///
    /// # Errors
    ///
    /// Returns [`HandwrittenDecodeError`] when any member is malformed, truncated, or followed by trailing bytes.
    pub fn decode_canonical(material: &[u8]) -> Result<Self, HandwrittenDecodeError> {
        let (count, remaining) = read_u64(material)?;
        let count = u16::try_from(count).map_err(|_| HandwrittenDecodeError::Invalid)?;
        let (payload, remaining) = read_frame(remaining)?;
        let payload =
            ByteParcel::try_from(payload.to_vec()).map_err(|()| HandwrittenDecodeError::Invalid)?;
        let (present, remaining) = remaining
            .split_first()
            .ok_or(HandwrittenDecodeError::Truncated)?;
        let (label, remaining) = match *present {
            0 => (None, remaining),
            1 => {
                let (text, remaining) = read_frame(remaining)?;
                let text = core::str::from_utf8(text)
                    .map_err(|_| HandwrittenDecodeError::Invalid)?
                    .to_owned();
                (Some(text), remaining)
            }
            _ => return Err(HandwrittenDecodeError::Invalid),
        };
        let (mode_count, mut remaining) = read_u64(remaining)?;
        let mode_count =
            usize::try_from(mode_count).map_err(|_| HandwrittenDecodeError::Invalid)?;
        let mut modes = Vec::new();
        while modes.len() < mode_count {
            let (slot, rest) = remaining
                .split_first()
                .ok_or(HandwrittenDecodeError::Truncated)?;
            let mode = Mode::ALL
                .into_iter()
                .find(|candidate| candidate.slot() == *slot)
                .ok_or(HandwrittenDecodeError::Invalid)?;
            modes.push(mode);
            remaining = rest;
        }
        let (nested, remaining) = read_frame(remaining)?;
        let child =
            Nested::decode_canonical(nested).map_err(|_| HandwrittenDecodeError::Invalid)?;
        if !remaining.is_empty() {
            return Err(HandwrittenDecodeError::TrailingBytes);
        }
        Ok(Self {
            count,
            payload,
            label,
            modes,
            child,
        })
    }
}

fn frame(material: &[u8], into: &mut Vec<u8>) {
    into.extend_from_slice(
        &u64::try_from(material.len())
            .unwrap_or(u64::MAX)
            .to_be_bytes(),
    );
    into.extend_from_slice(material);
}

fn read_u64(material: &[u8]) -> Result<(u64, &[u8]), HandwrittenDecodeError> {
    let width = core::mem::size_of::<u64>();
    let bytes = material
        .get(..width)
        .ok_or(HandwrittenDecodeError::Truncated)?;
    let bytes: [u8; 8] = bytes
        .try_into()
        .map_err(|_| HandwrittenDecodeError::Truncated)?;
    let remaining = material
        .get(width..)
        .ok_or(HandwrittenDecodeError::Truncated)?;
    Ok((u64::from_be_bytes(bytes), remaining))
}

fn read_frame(material: &[u8]) -> Result<(&[u8], &[u8]), HandwrittenDecodeError> {
    let (length, remaining) = read_u64(material)?;
    let length = usize::try_from(length).map_err(|_| HandwrittenDecodeError::Invalid)?;
    let framed = remaining
        .get(..length)
        .ok_or(HandwrittenDecodeError::Truncated)?;
    let rest = remaining
        .get(length..)
        .ok_or(HandwrittenDecodeError::Truncated)?;
    Ok((framed, rest))
}
