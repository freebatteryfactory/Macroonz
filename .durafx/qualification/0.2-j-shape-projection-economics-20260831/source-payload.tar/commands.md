# Wave J current shape and projection economics commands

## Coordinate setup

Every command ran from the repository root in PowerShell.

```powershell
$repoRoot = (git rev-parse --show-toplevel)
$scratch = Join-Path $repoRoot 'target/qualification/0.2-wave-j-shape-projection-economics-20260831'
$work = Join-Path $scratch 'work'
$target = Join-Path $scratch 'target-198'
$cargo198 = (rustup which --toolchain 1.98.0 cargo)
$env:RUSTC = (rustup which --toolchain 1.98.0 rustc)
$env:RUSTDOC = (rustup which --toolchain 1.98.0 rustdoc)
$env:CARGO_TARGET_DIR = $target
$env:CARGO_BUILD_JOBS = '1'
$env:CARGO_NET_OFFLINE = 'true'
```

## Input reconstruction

The accepted historical source and the accepted current package-candidate payload were extracted independently.

```powershell
tar --zstd -xf '.durafx/qualification/0.2-b-cross-subject-economics-20260829/source-payload.tar.zst' -C (Join-Path $scratch 'inputs/historical')
tar -xf '.durafx/qualification/0.2-j-guarded-economics-20260831/source-payload.tar' -C (Join-Path $scratch 'inputs/current')
Copy-Item -LiteralPath (Join-Path $scratch 'inputs/historical/projection-source') -Destination $work -Recurse
Copy-Item -LiteralPath (Join-Path $scratch 'inputs/historical/shape-source') -Destination (Join-Path $scratch 'shape-source') -Recurse
```

The four current package archives were extracted beneath the exact path named by the historical workspace's crates.io patches.

```powershell
Get-ChildItem -LiteralPath (Join-Path $scratch 'inputs/current/work/packages-current') -Filter '*.crate' | ForEach-Object {
    tar -xf $_.FullName -C (Join-Path $scratch 'packages-current')
}
```

Every extracted package's `.cargo_vcs_info.json` named revision `73ffa61b8555290deebee2d463f207ba10651036`.

## Stable wall and execution

```powershell
& $cargo198 fmt --manifest-path (Join-Path $work 'Cargo.toml') --all -- --check
& $cargo198 check --manifest-path (Join-Path $work 'Cargo.toml') --workspace --all-targets --locked --offline --target x86_64-pc-windows-msvc --jobs 1
& $cargo198 clippy --manifest-path (Join-Path $work 'Cargo.toml') --workspace --all-targets --locked --offline --target x86_64-pc-windows-msvc --jobs 1 -- -D warnings -D clippy::all -D clippy::pedantic
& $cargo198 test --manifest-path (Join-Path $work 'Cargo.toml') --workspace --all-targets --locked --offline --target x86_64-pc-windows-msvc --jobs 1 -- --test-threads=1
```

The first formatting command was attempted before the separately retained `shape-source` sibling entered its declared topology and refused because the exact `#[path]` source was absent.
The four commands above name the corrected complete reconstruction and all passed.

## Repeatability

The complete test pass wrote the first current account.
One additional focused execution wrote the second account.

```powershell
Copy-Item -LiteralPath (Join-Path $work 'surface-challenges/evidence/cross-subject-callable-economics-v1.txt') -Destination (Join-Path $scratch 'observations/economics-readback-a.txt')
& $cargo198 test --manifest-path (Join-Path $work 'Cargo.toml') --test economics --locked --offline --target x86_64-pc-windows-msvc --jobs 1 -- --test-threads=1
Copy-Item -LiteralPath (Join-Path $work 'surface-challenges/evidence/cross-subject-callable-economics-v1.txt') -Destination (Join-Path $scratch 'observations/economics-readback-b.txt')
```

Both current accounts and the accepted historical account were compared byte for byte and were equal at SHA-256 `4C66B28EE216B5A9C8E3633FA5A0CB87FDCE514C03E3D9908A9278CB0B4FB761`.

## Exact cleanup

The one Cargo target was cleaned immediately after the retained readback comparison.

```powershell
& $cargo198 clean --manifest-path (Join-Path $work 'Cargo.toml') --target-dir $target
```

Cargo removed 2,478 files totaling about 1.1 GiB, and the exact target no longer existed afterward.
