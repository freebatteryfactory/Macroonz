# Wave D bounded change-impact result

This is a disposable scratch result and is not a sealed receipt, a tracked evidence model, Wave D acceptance, or Macroonz 0.2 acceptance.
It records one Windows x64 composition over current public owners at repository HEAD `b6334b6bcd3d461245c622807af9177efae26fa2` and tree `fce9c29b9cd85a685d4e5cab2a3a95740a7ebb36`.

## Authority

The repository law was SHA-256 `6DB01AAB69698C926A4CBBD54FD21D086727D46A70BCBEE4EBD145B2A36BC948`.
The portable context was SHA-256 `CA4302D798DA045EBAA5DD9B2C5259EB8789C92CA10C2E134B3A0D5067F900D1`.
The 0.2 program was SHA-256 `30311A0F7D2809A07AB9A3092078ACA2B9A77408836BEEA3657C6C9795A2A147`.
The current compiler and harness owner source is identified by the repository HEAD and tree above.

The banked `change_impact` composition package was read as an assumption quarry rather than copied.
Its package manifest, README, toolchain file, and source were respectively SHA-256 `1B499ABB3C1EA6FB07DCA3B6A7411274FBD430A2BC9781FD4EAB56C3AE114519`, `A24A870D2C35842E7333E8D9AD7C32186F3295F396A8C9863FB44C8F50D9C799`, `E879701472A698533F43F54989BBF5F3101EB0503472159D32633F3BB8A13FDF`, and `FEDE3FD86BE348183A3BA99B24CE727BDCDDB3F993A22F88684F437D6E47A3BF`.
The candidate overlay's `compare.rs`, `conclude.rs`, `INTEGRATION.md`, `mod.rs`, `README.md`, `type_contract.rs`, `type_guard.rs`, and `types.rs` were respectively SHA-256 `75BA4CD5BAC3A5B44EF9EBA74B27572F9A85CF984632694F815B88F0482B411E`, `2B6C44583CCAD9BB03EC31FD661B8F83B36620CAD584CDD9620EA3A2EF6B9956`, `E37FE2B89CFAE4CE0A59BC0A02E45B935D0A7B7C4FFBD56338B2764E424E4284`, `8B1E4D45C654EAACA475275DE983F5D5752DCEE0D61285EEB53DA4600C9C33E4`, `59A26A02A3E3162B69438A7D70F95D4588A7D5BA7DC3661381826BC17AA292CE`, `3170AEDD22D0A74815C446B034DC6888D97589F419F880456FDD9BF7A2B4667F`, `9B994F70A89CFFF38A36D29BCD2A9FE10C1B70FE13EA8EF61F525A91E0BC6C6D`, and `E2107345ED7BC1266ACEC85EB106973DC13D5A5DF59C9D59DDF583F55B0EE0DE`.

## Candidate disposition

The banked public `harness::impact` home is not adopted.
It duplicates comparison and conclusion mechanics already owned by `report` and `properties`.
It flattens method-specific observations into `Observed([u8; 32])` before their owners' meanings and ceilings can be retained.
Its public `ImpactSnapshot::complete` constructor requires every coordinate, so its missing-before and missing-after comparison arms are unreachable through the proposed public construction road.
This result therefore composes existing owners from a subject-owned executable and introduces no public impact schema or separate evidence model.

## Direct current observations

One semantic payload movement changed the generated canonical bytes.
That movement changed compiler projection-content identity from `53FFAEA054098DFE5BCC721B5B6D35BA18F2915DDC9B87A1EFC37C5B0EE45B5E` to `485B21F7043412B58F57D597399BBB789F7A253E3CCC305F4A07113EEB7CA189`.
The same movement changed the subject-owned harness content identity from `8DDDCB093B8D79890AA8EC017BE624E9A63B0CF59DCADEA5DD2F26AD5BAB9997` to `4717C50DF7EB78551BAF707ECD43E4C12FBF6C0FDC3B82E2212496283172E55A`.
The `InvalidationTrigger::Declared` value carrying that subject-owned harness identity moved with it.
This is the required-movement witness.

Reversing only the offered payload order left the informed assignment's canonical bytes, compiler projection-content identity, harness content identity, and declared invalidation trigger unchanged.
This is the forbidden-movement witness.

One separately named subject identity over fixed unrelated material remained unchanged across the controlled projection movement.
This is the explicit unrelated-material control.

An independently written raw renderer and the paved `keyed_assignment_slice` renderer consumed the same informed `KeyedRosterAssignment` and reached identical canonical bytes under the existing `properties::parity` road.
The property suite named `KeyedRosterAssignment` as shared substrate rather than falsely declaring the renderers foundation-free.
This is the lawful private-reorganization and independent-implementation control.

A locally plausible shortcut that rendered the caller's offered payload order instead of the informed denominator order produced different canonical bytes.
The existing property road returned a typed refusal for that disagreement.
This is the local-change-to-global-regression witness.

A report comparison over one unchanged authored population retained exactly one subject-revision change, no row addition, removal, or revision, and no outcome flip.
This keeps report population, row revision, execution revision, invocation, target, and outcome axes separate.

`Baseline::Unavailable(NoBaselineReason::NotRecorded)` returned `ReportComparison::NotCompared(NotComparedReason::Unavailable(NoBaselineReason::NotRecorded))`.
No empty or synthetic comparison was constructed.

The witness-regression control replaced one executed pass with `RunAttempt::SkippedWithReason(SkipReason::PrerequisiteAbsent)` through the existing external-host record join.
The report comparison retained one `Passed` to `Skipped(PrerequisiteAbsent)` flip.
The existing claim-coverage reading moved from one exercised and zero unexercised to zero exercised and one unexercised.
This is a typed reading that the method became unavailable and the comparison became incomparable, not evidence that its algorithm became blinder or that the subject regressed.

The compiler projection-content identity and harness content address over identical canonical material had different raw bytes.
Their typed subjects, derivation contexts, preimage grammars, and package owners are different, and the repository package graph forbids a normal harness-to-compiler dependency.
This dismisses the compiler-identity-versus-harness-identity similarity nomination as a false duplicate without claiming that unequal digests alone prove distinct authority.

The current package graph observed through locked offline metadata was:

- `macroonz` depends normally on `macroonz-compiler`, `macroonz-macros`, and optional `macroonz-harness`.
- `macroonz-compiler` depends normally on `blake3` and `ra-ap-rustc_lexer`.
- `macroonz-harness` depends normally on `arbitrary`, `blake3`, optional `loom`, and `syn`.
- `macroonz-macros` depends normally on `macroonz-compiler`.

## Accepted evidence reused

The original guarded-transition receipt SHA-256 is `E3AC670BB69B0A25733B4AA297132AF10E700C3F5ED67CBA9151C6CDC502BDD2`.
The guarded-transition structural-adoption receipt SHA-256 is `C9E4D049B48EC48821473BB8A6DE7A7804D845EFD495FEF0D9D4DA36A2AFD5F3`.
The version-evolution structural-adoption receipt SHA-256 is `071D179B9872D52C2B6986169764E89C5D160971CEF139BA715BD332F41408BA`.
Those receipts establish that the subjects' earlier parallel denominator and payload lists were replaced by `KeyedRoster` and `KeyedRosterAssignment` while grammar, diagnostics, identities, generated bytes, behavior, authority, and package graph held.
The guarded-transition denominator/payload pairs are therefore a true duplicate-authority candidate whose accepted disposition is consolidation into the informed assignment, not a new impact abstraction.

The guarded-transition economics receipt SHA-256 is `322C628BF7EE75B4E6BCF37050C10C96088E364EC81A72A4C3B453385748B346`.
The cross-subject economics receipt SHA-256 is `EF70E87974B91B3DE8452D05E426B6ACA6E83CADB6DE981A36A84024265EAA6B`.
They retain typed work curves and no aggregate score or runtime ranking.
The cross-subject receipt also retains the accepted hostile control in which a one-pass replacement collapsed a declared two-pass distinction, stopped at `PlantedWorseNotDistinguished`, and was caught by the existing Muterprater custody holder with one tested, one caught, zero missed, zero timed out, and zero unviable.
No new mutation backend or current-source mutation was needed for this lot.

The Wave B local-acceptance receipt SHA-256 is `A8683AD2177DA0A7B7128D68C37F8590F8FF15AFD597C671078F4358A9E485E2`.
The Wave C architecture-reflexion receipt SHA-256 is `7DFDF237FC0D722F94FDCF5249EFDFDEF8A7A0F5E9FAD551B863127355CAE493`.
Those receipts are reused only at their stated planes.

## Commands and outputs

The host was `x86_64-pc-windows-msvc` under `rustc 1.98.0 (88d9e12ae 2026-08-18)`, LLVM `22.1.8`, and `cargo 1.98.0 (797e8a9bc 2026-08-05)`.

The copied repository lock did not describe the isolated scratch package, so the first locked run refused before compilation with `cannot update the lock file ... because --locked was passed`.
`cargo +1.98.0 generate-lockfile --manifest-path target/qualification/0.2-wave-d-change-impact-20260830/change-impact-driver/Cargo.toml --offline` then created the scratch-only lock while offline and reported `Locking 19 packages to latest Rust 1.98.0 compatible versions`.
Every compiling or executing Cargo command after that preparation used both `--locked` and `--offline`.

`cargo +1.98.0 run --manifest-path target/qualification/0.2-wave-d-change-impact-20260830/change-impact-driver/Cargo.toml --locked --offline --target x86_64-pc-windows-msvc --jobs 1` passed in 45.98 seconds and ended with `wave-d-change-impact=passed`.
`cargo +1.98.0 clippy --manifest-path target/qualification/0.2-wave-d-change-impact-20260830/change-impact-driver/Cargo.toml --locked --offline --target x86_64-pc-windows-msvc --jobs 1 -- -D warnings` passed in 10.65 seconds.
After parent QA, stable locked and offline check, strict Clippy, and execution passed again with the explicit unrelated-material control and corrected incomparable-witness vocabulary.
Two final direct executions of the built binary produced byte-identical seventeen-line output.
The normalized LF UTF-8 output SHA-256 is `05093A731A90AD1A0704E9FB2B49A2A025505BBBB76F7CCFCB0E0C886D8889CF`.
The final binary SHA-256 is `6A8ED15898E34F9F2128E8457035DBC270B33C487499DC0E6FF34D34FDE84814`.

## Scratch roster

The authored scratch files before this result were:

- `change-impact-driver/Cargo.toml`, SHA-256 `DC4148EA3F994EC176C9EBC5BB9AEEAB3E535E5E0337BA6A667A2CD5381831C9`.
- `change-impact-driver/Cargo.lock`, SHA-256 `867E028C31B30B942FD8BF3FE92783FD84FCF50A43F84DE00EEB93A461103018`.
- `change-impact-driver/src/main.rs`, SHA-256 `B9D6AB6E7990378E78282AFF3503F322C846D94B68933A98CA6F43C334C70D31`.

The remaining scratch files are Cargo build output beneath `change-impact-driver/target`.
Before this result file was added, the exact lot contained 899 files totaling 662,977,295 bytes.
After parent QA rebuilt the corrected witness, the exact lot contained 993 files totaling 679,712,331 bytes.
The scratch remained intact through parent QA.
Its authored source may now be retained in one compact tracked payload, while its build output remains disposable.

## Ceilings and remaining dependency

This result establishes one bounded Windows x64 subject composition, not Linux, macOS, another architecture, a hosted result, package publication, or global Wave D acceptance.
The raw and paved renderers share the informed assignment and its token primitives, so their agreement is silent about that declared substrate.
Digest inequality supports the identity-owner mapping but does not establish ownership without the separately read type, preimage, and package authorities.
The report witness proves loss of exercise and comparability for one method; it does not diagnose a subject defect.
No fresh benchmark timing or mutation campaign was run; those facts are reused from the accepted receipts under their stated ceilings.
Wave D's navigation artifact remains deferred to Wave L's single derived evidence model.
Wave D must supply this lot's accepted movements and refusals to that later model rather than inventing an early graph or second schema here.
