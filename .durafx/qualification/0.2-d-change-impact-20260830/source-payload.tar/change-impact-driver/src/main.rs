#![forbid(unsafe_code)]

use macroonz_compiler::identity as compiler_identity;
use macroonz_compiler::{
    GeneratedDelimiter, GeneratedToken, GeneratedTree, Identity, InvalidationTrigger, KeyedRoster,
    KeyedRosterAssignment, Overflow, OwnerIdentity, Transcript, comma_many, group,
    keyed_assignment_slice,
};
use macroonz_harness::clock::{HarnessClock, MeasurementReading};
use macroonz_harness::descriptor::{
    AuthoredTableName, Binding, CheckRef, ClaimRef, Classification, DerivedRevision,
    ExecutableAttachment, ExecutionSuite, Origin, PopulationRef, Provenance, RevisionBinding, Role,
    Row, SubjectRoute, Tag,
};
use macroonz_harness::identity::{ContentAddress, DomainTag, IdentityProfileVersion};
use macroonz_harness::properties::{
    Agreement, ParitySuite, RoadPairing, SharedSubstrate, SubstrateRef, SubstrateRoster, parity,
};
use macroonz_harness::report::{
    Baseline, ByteBudget, CaseBudget, HostTrialRecord, InvocationProfile, NoBaselineReason,
    NotComparedReason, OutcomeClass, ReportComparison, RunAttempt, SkipReason, TargetBinding,
    TargetTriple, TimeBudget, ToolchainIdentity, TrialConclusion, TrialSite, claim_coverage,
};
use macroonz_harness::runner::{
    Invocation, Selection, SelectionPlan, TrialBinding, TrialTable, record_all, run_all,
};
use std::error::Error;
use std::fmt::{self, Display, Formatter};

const MEMBER_LIMIT: usize = 4;
const HARNESS_SUBJECT_TAG: DomainTag =
    DomainTag::declared("wave-d-subject", IdentityProfileVersion::declared(1));
const UNRELATED_SUBJECT_TAG: DomainTag =
    DomainTag::declared("wave-d-unrelated", IdentityProfileVersion::declared(1));
const REPORT_OWNER: &str = "wave-d-change-impact";

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct ScratchFailure(&'static str);

impl Display for ScratchFailure {
    fn fmt(&self, formatter: &mut Formatter<'_>) -> fmt::Result {
        formatter.write_str(self.0)
    }
}

impl Error for ScratchFailure {}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct Member {
    key: &'static str,
    variant: &'static str,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct Payload {
    member: &'static str,
    seat: &'static str,
    variant: &'static str,
    value: u64,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct ProjectionCase {
    first_value: u64,
}

fn members() -> Result<KeyedRoster<Member, &'static str, MEMBER_LIMIT>, ScratchFailure> {
    KeyedRoster::new(
        vec![
            Member {
                key: "first",
                variant: "First",
            },
            Member {
                key: "second",
                variant: "Second",
            },
        ],
        |member| member.key,
    )
    .map_err(|_| ScratchFailure("member roster refused"))
}

fn offered(first_value: u64, reversed: bool) -> Vec<Payload> {
    let first = Payload {
        member: "first",
        seat: "first-seat",
        variant: "First",
        value: first_value,
    };
    let second = Payload {
        member: "second",
        seat: "second-seat",
        variant: "Second",
        value: 2,
    };
    if reversed {
        vec![second, first]
    } else {
        vec![first, second]
    }
}

fn assignment(
    first_value: u64,
    reversed: bool,
) -> Result<
    KeyedRosterAssignment<Member, &'static str, Payload, &'static str, MEMBER_LIMIT>,
    ScratchFailure,
> {
    KeyedRosterAssignment::complete(
        members()?,
        offered(first_value, reversed),
        |payload| payload.member,
        |payload| payload.seat,
    )
    .map_err(|_| ScratchFailure("payload assignment refused"))
}

fn payload_row(
    index: usize,
    key: &str,
    variant: &str,
    seat: &str,
    value: u64,
) -> Result<Vec<GeneratedToken>, Overflow> {
    Ok(vec![group(
        GeneratedDelimiter::Parenthesis,
        comma_many(vec![
            vec![GeneratedToken::number(
                u64::try_from(index).unwrap_or(u64::MAX),
            )],
            vec![GeneratedToken::text(key)],
            vec![GeneratedToken::word(variant)],
            vec![GeneratedToken::text(seat)],
            vec![GeneratedToken::number(value)],
        ]),
    )?])
}

fn tree_bytes(tokens: Vec<GeneratedToken>) -> Result<Vec<u8>, ScratchFailure> {
    GeneratedTree::assembled(tokens)
        .map(|tree| tree.canonical_bytes())
        .map_err(|_| ScratchFailure("generated tree refused"))
}

fn borrowed_slice(rows: Vec<Vec<GeneratedToken>>) -> Result<Vec<GeneratedToken>, ScratchFailure> {
    let body = group(GeneratedDelimiter::Bracket, comma_many(rows))
        .map_err(|_| ScratchFailure("borrowed slice overflowed"))?;
    Ok(vec![GeneratedToken::alone('&'), body])
}

fn paved_projection(case: &ProjectionCase) -> Result<Vec<u8>, ScratchFailure> {
    let assigned = assignment(case.first_value, true)?;
    let tokens = keyed_assignment_slice(&assigned, |index, key, member, seat, payload| {
        payload_row(index, key, member.variant, seat, payload.value)
    })
    .map_err(|_| ScratchFailure("paved projection overflowed"))?;
    tree_bytes(tokens)
}

fn raw_projection(case: &ProjectionCase) -> Result<Vec<u8>, ScratchFailure> {
    let assigned = assignment(case.first_value, true)?;
    let rows = assigned
        .indexed()
        .map(|(index, key, member, seat, payload)| {
            payload_row(index, key, member.variant, seat, payload.value)
        })
        .collect::<Result<Vec<_>, _>>()
        .map_err(|_| ScratchFailure("raw projection overflowed"))?;
    tree_bytes(borrowed_slice(rows)?)
}

fn offered_order_shortcut(case: &ProjectionCase) -> Result<Vec<u8>, ScratchFailure> {
    let rows = offered(case.first_value, true)
        .iter()
        .enumerate()
        .map(|(index, payload)| {
            payload_row(
                index,
                payload.member,
                payload.variant,
                payload.seat,
                payload.value,
            )
        })
        .collect::<Result<Vec<_>, _>>()
        .map_err(|_| ScratchFailure("shortcut projection overflowed"))?;
    tree_bytes(borrowed_slice(rows)?)
}

fn same_projection(
    left: &Result<Vec<u8>, ScratchFailure>,
    right: &Result<Vec<u8>, ScratchFailure>,
) -> Agreement {
    if left == right {
        Agreement::Agrees
    } else {
        Agreement::Differs
    }
}

fn compiler_content_identity(bytes: &[u8]) -> Identity<compiler_identity::ProjectionContent> {
    Identity::derived(Transcript::rooted(
        compiler_identity::Role::ProjectionContent,
        bytes,
        0,
    ))
}

fn harness_content_identity(bytes: &[u8]) -> ContentAddress {
    harness_content_identity_for(HARNESS_SUBJECT_TAG, bytes)
}

fn harness_content_identity_for(tag: DomainTag, bytes: &[u8]) -> ContentAddress {
    ContentAddress::derived(tag, bytes)
}

fn watch_for(address: &ContentAddress) -> InvalidationTrigger {
    InvalidationTrigger::Declared {
        name: "wave-d.subject-projection",
        watched: OwnerIdentity {
            subject: "wave-d.subject-projection",
            bytes: *address.as_bytes(),
        },
    }
}

fn concluded(_invocation: &Invocation) -> TrialConclusion {
    TrialConclusion::Passed
}

fn binding(
    subject_revision: &'static [u8],
    check_revision: &'static [u8],
) -> Result<TrialBinding, ScratchFailure> {
    let subject = SubjectRoute::named(REPORT_OWNER, "projection")
        .map_err(|_| ScratchFailure("subject route refused"))?;
    let check = CheckRef::named(REPORT_OWNER, "parity")
        .map_err(|_| ScratchFailure("check reference refused"))?;
    let row = Row::declared(
        ClaimRef::named(REPORT_OWNER, "projection-stays-accounted")
            .map_err(|_| ScratchFailure("claim reference refused"))?,
        ExecutionSuite::named(REPORT_OWNER, "change-impact")
            .map_err(|_| ScratchFailure("execution suite refused"))?,
        Classification::authored(
            vec![Role::named(REPORT_OWNER, "report").map_err(|_| ScratchFailure("role refused"))?],
            vec![Tag::named(REPORT_OWNER, "wave-d").map_err(|_| ScratchFailure("tag refused"))?],
        )
        .map_err(|_| ScratchFailure("classification refused"))?,
        subject,
        check,
        PopulationRef::named(REPORT_OWNER, "one-projection")
            .map_err(|_| ScratchFailure("population refused"))?,
        Origin::HandWritten,
    )
    .map_err(|_| ScratchFailure("row refused"))?;
    Binding::bound(
        row,
        ExecutableAttachment::attached(
            subject,
            check,
            RevisionBinding::derived(DerivedRevision::from_material(subject_revision)),
            RevisionBinding::derived(DerivedRevision::from_material(check_revision)),
            concluded,
        ),
        Provenance::Unproduced,
    )
    .map_err(|_| ScratchFailure("binding refused"))
}

fn world(binding: TrialBinding) -> Result<TrialTable, ScratchFailure> {
    TrialTable::authored(
        AuthoredTableName::named(REPORT_OWNER, "subject-world")
            .map_err(|_| ScratchFailure("table name refused"))?,
        Provenance::Unproduced,
        vec![binding],
    )
    .map_err(|_| ScratchFailure("authored table refused"))
}

fn invocation() -> Invocation {
    Invocation::declared(
        InvocationProfile::declared(
            CaseBudget::declared(1),
            ByteBudget::declared(64),
            TimeBudget::declared(1_000_000),
        ),
        TargetBinding::bound(
            TargetTriple::declared("x86_64-pc-windows-msvc"),
            ToolchainIdentity::declared("rustc-1.98.0"),
        ),
        TrialSite::located(module_path!(), file!(), line!(), "wave-d-change-impact"),
        HarnessClock::unavailable(),
    )
}

fn ensure(holds: bool, message: &'static str) -> Result<(), ScratchFailure> {
    if holds {
        Ok(())
    } else {
        Err(ScratchFailure(message))
    }
}

fn hex(bytes: &[u8]) -> String {
    let mut rendered = String::with_capacity(bytes.len().saturating_mul(2));
    for byte in bytes {
        rendered.push_str(&format!("{byte:02X}"));
    }
    rendered
}

fn projection_controls() -> Result<(), ScratchFailure> {
    let baseline_case = ProjectionCase { first_value: 1 };
    let moved_case = ProjectionCase { first_value: 9 };
    let baseline = paved_projection(&baseline_case)?;
    let reordered = {
        let assigned = assignment(1, false)?;
        let tokens = keyed_assignment_slice(&assigned, |index, key, member, seat, payload| {
            payload_row(index, key, member.variant, seat, payload.value)
        })
        .map_err(|_| ScratchFailure("reordered projection overflowed"))?;
        tree_bytes(tokens)?
    };
    let moved = paved_projection(&moved_case)?;
    ensure(
        baseline == reordered,
        "payload offering order moved canonical output",
    )?;
    ensure(
        baseline != moved,
        "semantic payload movement did not move canonical output",
    )?;

    let compiler_before = compiler_content_identity(&baseline);
    let compiler_reordered = compiler_content_identity(&reordered);
    let compiler_after = compiler_content_identity(&moved);
    let harness_before = harness_content_identity(&baseline);
    let harness_reordered = harness_content_identity(&reordered);
    let harness_after = harness_content_identity(&moved);
    ensure(
        compiler_before == compiler_reordered,
        "forbidden compiler identity movement occurred",
    )?;
    ensure(
        compiler_before != compiler_after,
        "required compiler identity movement was absent",
    )?;
    ensure(
        harness_before == harness_reordered,
        "forbidden harness identity movement occurred",
    )?;
    ensure(
        harness_before != harness_after,
        "required harness identity movement was absent",
    )?;
    ensure(
        watch_for(&harness_before) == watch_for(&harness_reordered),
        "forbidden plan invalidator movement occurred",
    )?;
    ensure(
        watch_for(&harness_before) != watch_for(&harness_after),
        "required plan invalidator movement was absent",
    )?;
    let unrelated_before = harness_content_identity_for(UNRELATED_SUBJECT_TAG, b"separate-claim");
    let unrelated_after = harness_content_identity_for(UNRELATED_SUBJECT_TAG, b"separate-claim");
    ensure(
        unrelated_before == unrelated_after,
        "unrelated subject identity moved with projection content",
    )?;

    let shared = SubstrateRef::named("wave-d", "keyed-roster-assignment")
        .map_err(|_| ScratchFailure("substrate name refused"))?;
    let standing = SharedSubstrate::Standing(
        SubstrateRoster::declared(&[shared])
            .map_err(|_| ScratchFailure("substrate roster refused"))?,
    );
    let raw_suite = ParitySuite::over(
        RoadPairing::Declared(
            macroonz_harness::descriptor::NamespacedName::named("wave-d", "paved-versus-raw")
                .map_err(|_| ScratchFailure("raw pairing name refused"))?,
        ),
        paved_projection,
        raw_projection,
        same_projection,
        standing.clone(),
    );
    let raw_reading = parity(&raw_suite, &baseline_case);
    ensure(
        raw_reading.conclusion() == &TrialConclusion::Passed,
        "independent raw renderer disagreed with paved renderer",
    )?;

    let shortcut_suite = ParitySuite::over(
        RoadPairing::Declared(
            macroonz_harness::descriptor::NamespacedName::named(
                "wave-d",
                "paved-versus-offered-order-shortcut",
            )
            .map_err(|_| ScratchFailure("shortcut pairing name refused"))?,
        ),
        paved_projection,
        offered_order_shortcut,
        same_projection,
        standing,
    );
    let shortcut_reading = parity(&shortcut_suite, &baseline_case);
    ensure(
        matches!(shortcut_reading.conclusion(), TrialConclusion::Refused(_)),
        "offered-order shortcut escaped the global parity witness",
    )?;

    ensure(
        compiler_before.as_bytes() != harness_before.as_bytes(),
        "distinct compiler and harness identity domains aliased",
    )?;

    println!("required.canonical.before={}", hex(&baseline));
    println!("required.canonical.after={}", hex(&moved));
    println!(
        "required.compiler-identity.before={}",
        hex(compiler_before.as_bytes())
    );
    println!(
        "required.compiler-identity.after={}",
        hex(compiler_after.as_bytes())
    );
    println!(
        "required.harness-identity.before={}",
        hex(harness_before.as_bytes())
    );
    println!(
        "required.harness-identity.after={}",
        hex(harness_after.as_bytes())
    );
    println!("forbidden.reordered-canonical=unchanged");
    println!("unrelated.subject-identity=unchanged");
    println!("private-reorganization.raw-versus-paved=passed");
    println!("global-regression.offered-order-shortcut=property-refused");
    println!("similarity.compiler-versus-harness-identity=distinct-domains");
    Ok(())
}

fn report_controls() -> Result<(), ScratchFailure> {
    let baseline_world = world(binding(b"subject-v1", b"check-v1")?)?;
    let moved_world = world(binding(b"subject-v2", b"check-v1")?)?;
    let invocation = invocation();
    let selection = SelectionPlan::of(Selection::All);
    let baseline = run_all(&baseline_world.view(), &selection, &invocation);
    let moved = run_all(&moved_world.view(), &selection, &invocation);
    let ReportComparison::Compared(movement) =
        macroonz_harness::report::compare(Baseline::Previous(&baseline), &moved)
    else {
        return Err(ScratchFailure("required report comparison refused"));
    };
    ensure(
        movement.population().added().is_empty()
            && movement.population().removed().is_empty()
            && movement.population().revised().is_empty(),
        "subject revision movement changed the report population",
    )?;
    ensure(
        movement.execution().revisions().len() == 1,
        "subject revision movement was not retained",
    )?;
    ensure(
        movement.execution().flips().is_empty(),
        "subject revision movement invented an outcome flip",
    )?;

    let unavailable = macroonz_harness::report::compare(
        Baseline::Unavailable(NoBaselineReason::NotRecorded),
        &baseline,
    );
    ensure(
        unavailable
            == ReportComparison::NotCompared(NotComparedReason::Unavailable(
                NoBaselineReason::NotRecorded,
            )),
        "missing baseline flattened into a comparison",
    )?;

    let trial = baseline
        .census()
        .first()
        .ok_or(ScratchFailure("baseline report had no census row"))?
        .trial();
    let unavailable_observation = record_all(
        &baseline_world.view(),
        &selection,
        &invocation,
        vec![HostTrialRecord::recorded(
            trial,
            RunAttempt::SkippedWithReason(SkipReason::PrerequisiteAbsent),
            MeasurementReading::Unavailable,
        )],
    )
    .map_err(|_| ScratchFailure("unavailable host record refused"))?;
    let ReportComparison::Compared(unavailable_diff) =
        macroonz_harness::report::compare(Baseline::Previous(&baseline), &unavailable_observation)
    else {
        return Err(ScratchFailure("witness regression comparison refused"));
    };
    let [flip] = unavailable_diff.execution().flips() else {
        return Err(ScratchFailure(
            "witness regression did not produce one flip",
        ));
    };
    ensure(
        flip.before() == OutcomeClass::Passed
            && flip.after() == OutcomeClass::Skipped(SkipReason::PrerequisiteAbsent),
        "witness regression did not retain pass-to-skip movement",
    )?;

    let baseline_coverage =
        claim_coverage(&baseline).map_err(|_| ScratchFailure("baseline coverage refused"))?;
    let unavailable_coverage = claim_coverage(&unavailable_observation)
        .map_err(|_| ScratchFailure("unavailable coverage refused"))?;
    let [baseline_claim] = baseline_coverage.entries() else {
        return Err(ScratchFailure(
            "baseline coverage had the wrong claim count",
        ));
    };
    let [unavailable_claim] = unavailable_coverage.entries() else {
        return Err(ScratchFailure(
            "unavailable coverage had the wrong claim count",
        ));
    };
    ensure(
        baseline_claim.exercised() == 1
            && baseline_claim.unexercised() == 0
            && unavailable_claim.exercised() == 0
            && unavailable_claim.unexercised() == 1,
        "witness regression did not become observably incomparable",
    )?;

    println!("required.report-subject-revision-changes=1");
    println!("forbidden.report-population-movement=none");
    println!("incomplete.baseline=not-compared:not-recorded");
    println!("witness-regression.incomparable=passed-to-prerequisite-absent");
    println!("witness-regression.exercise=1-to-0");
    Ok(())
}

fn main() -> Result<(), ScratchFailure> {
    projection_controls()?;
    report_controls()?;
    println!("wave-d-change-impact=passed");
    Ok(())
}
