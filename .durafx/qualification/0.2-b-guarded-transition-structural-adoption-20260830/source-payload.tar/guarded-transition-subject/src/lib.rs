//! Ordinary subject contracts plus generated and independently handwritten guarded-transition roads.

#![forbid(unsafe_code)]
#![deny(warnings)]

use guarded_transition_subject_macros::{guarded_transition, guarded_transition_refactored};

#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord)]
pub enum Standing {
    Idle,
    Armed,
    Done,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord)]
pub enum Event {
    Arm,
    Finish,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord)]
pub enum Capability {
    Basic,
    Elevated,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord)]
pub enum Operation {
    ArmOp,
    FinishOp,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord)]
pub enum EffectSeat {
    Arm,
    Finish,
    Fast,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct TransitionRow {
    from: Standing,
    event: Event,
    to: Standing,
    effect: EffectSeat,
    added: u64,
}

impl TransitionRow {
    #[must_use]
    pub const fn declared(
        from: Standing,
        event: Event,
        to: Standing,
        effect: EffectSeat,
        added: u64,
    ) -> Self {
        Self {
            from,
            event,
            to,
            effect,
            added,
        }
    }

    #[must_use]
    pub const fn from(self) -> Standing {
        self.from
    }

    #[must_use]
    pub const fn event(self) -> Event {
        self.event
    }

    #[must_use]
    pub const fn to(self) -> Standing {
        self.to
    }

    #[must_use]
    pub const fn effect(self) -> EffectSeat {
        self.effect
    }

    #[must_use]
    pub const fn added(self) -> u64 {
        self.added
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord)]
pub struct PolicyEdge {
    capability: Capability,
    operation: Operation,
}

impl PolicyEdge {
    #[must_use]
    pub const fn declared(capability: Capability, operation: Operation) -> Self {
        Self {
            capability,
            operation,
        }
    }

    #[must_use]
    pub const fn capability(self) -> Capability {
        self.capability
    }

    #[must_use]
    pub const fn operation(self) -> Operation {
        self.operation
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord)]
pub struct Association {
    event: Event,
    operation: Operation,
}

impl Association {
    #[must_use]
    pub const fn declared(event: Event, operation: Operation) -> Self {
        Self { event, operation }
    }

    #[must_use]
    pub const fn event(self) -> Event {
        self.event
    }

    #[must_use]
    pub const fn operation(self) -> Operation {
        self.operation
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Reading {
    standing: Standing,
    value: u64,
    effects: Vec<EffectSeat>,
}

impl Reading {
    #[must_use]
    pub const fn standing(&self) -> Standing {
        self.standing
    }

    #[must_use]
    pub const fn value(&self) -> u64 {
        self.value
    }

    #[must_use]
    pub fn effects(&self) -> &[EffectSeat] {
        &self.effects
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum GuardRefusal {
    Unauthorized {
        capability: Capability,
        operation: Operation,
    },
    IllegalTransition {
        standing: Standing,
        event: Event,
    },
    DisconnectedAssociation {
        event: Event,
    },
    Overflow {
        effect: EffectSeat,
    },
}

impl core::fmt::Display for GuardRefusal {
    fn fmt(&self, formatter: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        write!(formatter, "{self:?}")
    }
}

impl core::error::Error for GuardRefusal {}

pub trait GuardedContract {
    /// Executes one declared sequence through the guarded subject contract.
    ///
    /// # Errors
    ///
    /// Returns a refusal when policy, transition, association, or arithmetic meaning rejects the sequence.
    fn execute(
        capability: Capability,
        events: &[Event],
        opening_value: u64,
    ) -> Result<Reading, GuardRefusal>;
}

pub(crate) fn execute_declared(
    capability: Capability,
    events: &[Event],
    opening_value: u64,
    transitions: &[TransitionRow],
    policies: &[PolicyEdge],
    associations: &[Association],
    initial: Standing,
) -> Result<Reading, GuardRefusal> {
    let mut standing = initial;
    let mut value = opening_value;
    let mut effects = Vec::with_capacity(events.len());
    for event in events {
        let operation = associations
            .iter()
            .find(|association| association.event == *event)
            .map(|association| association.operation)
            .ok_or(GuardRefusal::DisconnectedAssociation { event: *event })?;
        if !policies
            .iter()
            .any(|edge| edge.capability == capability && edge.operation == operation)
        {
            return Err(GuardRefusal::Unauthorized {
                capability,
                operation,
            });
        }
        let transition = transitions
            .iter()
            .find(|row| row.from == standing && row.event == *event)
            .ok_or(GuardRefusal::IllegalTransition {
                standing,
                event: *event,
            })?;
        value = value
            .checked_add(transition.added)
            .ok_or(GuardRefusal::Overflow {
                effect: transition.effect,
            })?;
        effects.push(transition.effect);
        standing = transition.to;
    }
    Ok(Reading {
        standing,
        value,
        effects,
    })
}

macro_rules! baseline_declaration {
    ($entry:ident) => {
        $entry! {
            states { Idle, Armed, Done, }
            events { Arm, Finish, }
            initial { Idle }
            terminal { Done }
            transitions {
                Idle + Arm -> Armed,
                Armed + Finish -> Done,
            }
            effects {
                Idle + Arm -> Armed = Arm add(2),
                Armed + Finish -> Done = Finish add(3),
            }
            capabilities { Basic, Elevated, }
            operations { ArmOp, FinishOp, }
            associations { Arm => ArmOp, Finish => FinishOp, }
            policies { Basic => ArmOp, Elevated => ArmOp, Elevated => FinishOp, }
            projections { production, property, mutation, benchmark, compile, receipt, }
        }
    };
}

pub mod generated {
    use super::guarded_transition;
    baseline_declaration!(guarded_transition);
}

pub mod refactored {
    use super::guarded_transition_refactored;
    baseline_declaration!(guarded_transition_refactored);
}

pub mod permuted {
    use super::guarded_transition;
    guarded_transition! {
        states { Idle, Armed, Done, }
        events { Arm, Finish, }
        initial { Idle }
        terminal { Done }
        transitions {
            Armed + Finish -> Done,
            Idle + Arm -> Armed,
        }
        effects {
            Armed + Finish -> Done = Finish add(3),
            Idle + Arm -> Armed = Arm add(2),
        }
        capabilities { Basic, Elevated, }
        operations { ArmOp, FinishOp, }
        associations { Finish => FinishOp, Arm => ArmOp, }
        policies { Elevated => FinishOp, Elevated => ArmOp, Basic => ArmOp, }
        projections { production, property, mutation, benchmark, compile, receipt, }
    }
}

pub mod transition_added {
    use super::guarded_transition;
    guarded_transition! {
        states { Idle, Armed, Done, }
        events { Arm, Finish, }
        initial { Idle }
        terminal { Done }
        transitions {
            Idle + Arm -> Armed,
            Armed + Finish -> Done,
            Idle + Finish -> Done,
        }
        effects {
            Idle + Arm -> Armed = Arm add(2),
            Armed + Finish -> Done = Finish add(3),
            Idle + Finish -> Done = Fast add(5),
        }
        capabilities { Basic, Elevated, }
        operations { ArmOp, FinishOp, }
        associations { Arm => ArmOp, Finish => FinishOp, }
        policies { Basic => ArmOp, Elevated => ArmOp, Elevated => FinishOp, }
        projections { production, property, mutation, benchmark, compile, receipt, }
    }
}

pub mod policy_widened {
    use super::guarded_transition;
    guarded_transition! {
        states { Idle, Armed, Done, }
        events { Arm, Finish, }
        initial { Idle }
        terminal { Done }
        transitions {
            Idle + Arm -> Armed,
            Armed + Finish -> Done,
        }
        effects {
            Idle + Arm -> Armed = Arm add(2),
            Armed + Finish -> Done = Finish add(3),
        }
        capabilities { Basic, Elevated, }
        operations { ArmOp, FinishOp, }
        associations { Arm => ArmOp, Finish => FinishOp, }
        policies { Basic => ArmOp, Basic => FinishOp, Elevated => ArmOp, Elevated => FinishOp, }
        projections { production, property, mutation, benchmark, compile, receipt, }
    }
}

pub mod policy_removed {
    use super::guarded_transition;
    guarded_transition! {
        states { Idle, Armed, Done, }
        events { Arm, Finish, }
        initial { Idle }
        terminal { Done }
        transitions {
            Idle + Arm -> Armed,
            Armed + Finish -> Done,
        }
        effects {
            Idle + Arm -> Armed = Arm add(2),
            Armed + Finish -> Done = Finish add(3),
        }
        capabilities { Basic, Elevated, }
        operations { ArmOp, FinishOp, }
        associations { Arm => ArmOp, Finish => FinishOp, }
        policies { Basic => ArmOp, Elevated => ArmOp, }
        projections { production, property, mutation, benchmark, compile, receipt, }
    }
}

pub mod planted_wrong {
    use super::guarded_transition;
    guarded_transition! {
        states { Idle, Armed, Done, }
        events { Arm, Finish, }
        initial { Idle }
        terminal { Done }
        transitions {
            Idle + Arm -> Armed,
            Armed + Finish -> Done,
        }
        effects {
            Idle + Arm -> Armed = Arm add(2),
            Armed + Finish -> Done = Finish add(4),
        }
        capabilities { Basic, Elevated, }
        operations { ArmOp, FinishOp, }
        associations { Arm => ArmOp, Finish => FinishOp, }
        policies { Basic => ArmOp, Elevated => ArmOp, Elevated => FinishOp, }
        projections { production, property, mutation, benchmark, compile, receipt, }
    }
}

pub mod handwritten {
    use super::{
        Association, Capability, EffectSeat, Event, GuardRefusal, GuardedContract, Operation,
        PolicyEdge, Reading, Standing, TransitionRow,
    };

    pub struct HandwrittenRoad;

    pub const STATES: &[Standing] = &[Standing::Idle, Standing::Armed, Standing::Done];
    pub const EVENTS: &[Event] = &[Event::Arm, Event::Finish];
    pub const TRANSITIONS: &[TransitionRow] = &[
        TransitionRow::declared(
            Standing::Idle,
            Event::Arm,
            Standing::Armed,
            EffectSeat::Arm,
            2,
        ),
        TransitionRow::declared(
            Standing::Armed,
            Event::Finish,
            Standing::Done,
            EffectSeat::Finish,
            3,
        ),
    ];
    pub const EFFECTS: &[EffectSeat] = &[EffectSeat::Arm, EffectSeat::Finish];
    pub const CAPABILITIES: &[Capability] = &[Capability::Basic, Capability::Elevated];
    pub const OPERATIONS: &[Operation] = &[Operation::ArmOp, Operation::FinishOp];
    pub const POLICIES: &[PolicyEdge] = &[
        PolicyEdge::declared(Capability::Basic, Operation::ArmOp),
        PolicyEdge::declared(Capability::Elevated, Operation::ArmOp),
        PolicyEdge::declared(Capability::Elevated, Operation::FinishOp),
    ];
    pub const ASSOCIATIONS: &[Association] = &[
        Association::declared(Event::Arm, Operation::ArmOp),
        Association::declared(Event::Finish, Operation::FinishOp),
    ];
    pub const INITIAL: Standing = Standing::Idle;
    pub const TERMINAL: Standing = Standing::Done;

    const fn associated_operation(event: Event) -> Operation {
        match event {
            Event::Arm => Operation::ArmOp,
            Event::Finish => Operation::FinishOp,
        }
    }

    const fn is_admitted(capability: Capability, operation: Operation) -> bool {
        matches!(
            (capability, operation),
            (Capability::Basic, Operation::ArmOp)
                | (Capability::Elevated, Operation::ArmOp | Operation::FinishOp)
        )
    }

    fn authorize(capability: Capability, operation: Operation) -> Result<(), GuardRefusal> {
        if is_admitted(capability, operation) {
            Ok(())
        } else {
            Err(GuardRefusal::Unauthorized {
                capability,
                operation,
            })
        }
    }

    fn transition(
        standing: Standing,
        event: Event,
    ) -> Result<(Standing, EffectSeat, u64), GuardRefusal> {
        match (standing, event) {
            (Standing::Idle, Event::Arm) => Ok((Standing::Armed, EffectSeat::Arm, 2_u64)),
            (Standing::Armed, Event::Finish) => Ok((Standing::Done, EffectSeat::Finish, 3_u64)),
            _ => Err(GuardRefusal::IllegalTransition { standing, event }),
        }
    }

    impl GuardedContract for HandwrittenRoad {
        fn execute(
            capability: Capability,
            events: &[Event],
            opening_value: u64,
        ) -> Result<Reading, GuardRefusal> {
            let mut standing = Standing::Idle;
            let mut value = opening_value;
            let mut effects = Vec::with_capacity(events.len());
            for event in events {
                let operation = associated_operation(*event);
                authorize(capability, operation)?;
                let (next, effect, added) = transition(standing, *event)?;
                value = value
                    .checked_add(added)
                    .ok_or(GuardRefusal::Overflow { effect })?;
                effects.push(effect);
                standing = next;
            }
            Ok(Reading {
                standing,
                value,
                effects,
            })
        }
    }
}
