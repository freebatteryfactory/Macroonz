//! External custody for the guarded-transition structural-mutation observation.

#![forbid(unsafe_code)]
#![deny(warnings)]

use bakery::harness::descriptor::ClaimRef;
use bakery::harness::muterprater::wrap::read_artifact;
use bakery::harness::muterprater::{
    AdapterQualification, AnnouncedRoster, BackendCommand, BackendVersion, GrammarStanding,
    MutationBackendInvocation, MutationSourceRevision, OperatorFamilyRef, SourceCoordinate,
    WrappedBackend,
};
use bakery::harness::report::{TargetBinding, TargetTriple, ToolchainIdentity};

const CONSOLE: &str = include_str!("mutation-pressure-artifact/cargo-mutants-27.0.0-console.txt");
const HISTORICAL_ENGINE_SOURCE: &[u8] =
    include_bytes!("mutation-pressure-artifact/guarded-transition-engine-mutation-final.rs");
const ENGINE_FILE: &str = "guarded-transition-subject-macros/src/engine.rs";
const BACKEND_VERSION: &str = "27.0.0";
const TARGET: &str = "x86_64-pc-windows-msvc";
const TOOLCHAIN: &str = "rustc 1.98.0 (88d9e12ae 2026-08-18)";
const COMMAND: &[&str] = &[
    "+1.98.0",
    "mutants",
    "--no-config",
    "-p",
    "guarded-transition-subject-macros",
    "--file",
    ENGINE_FILE,
    "--re",
    "(read_(transitions|effects|effect|associations|policies|projections)|accounted)",
    "--test-tool",
    "cargo",
    "--baseline",
    "run",
    "--jobs",
    "1",
    "--jobserver-tasks",
    "1",
    "--no-shuffle",
    "--caught",
    "--unviable",
    "--no-times",
    "--colors",
    "never",
    "--annotations",
    "none",
    "--timeout",
    "120",
    "--build-timeout",
    "120",
    "--output",
    "mutation-run-3",
    "--",
    "--locked",
    "--offline",
    "--test",
    "engine_claims",
    "--target",
    TARGET,
    "--jobs",
    "1",
    "--",
    "--test-threads=1",
];

fn described(error: impl core::fmt::Debug) -> String {
    format!("{error:?}")
}

fn no_owner(_: &SourceCoordinate) -> Option<ClaimRef> {
    None
}

fn no_family(_: &SourceCoordinate, _: &[u8]) -> Option<OperatorFamilyRef> {
    None
}

#[test]
fn historical_guarded_transition_pressure_remains_complete_and_unmapped() -> Result<(), String> {
    let version = BackendVersion::stated(BACKEND_VERSION).map_err(described)?;
    let command = BackendCommand::declared("cargo", COMMAND).map_err(described)?;
    let invocation = MutationBackendInvocation::declared(
        WrappedBackend::CargoMutants,
        version.clone(),
        command,
        TargetBinding::bound(
            TargetTriple::declared(TARGET),
            ToolchainIdentity::declared(TOOLCHAIN),
        ),
    );
    let source = MutationSourceRevision::from_content(ENGINE_FILE, HISTORICAL_ENGINE_SOURCE)
        .map_err(described)?;
    let manifest = read_artifact(
        CONSOLE,
        invocation,
        vec![source.clone()],
        no_owner,
        no_family,
    )
    .map_err(described)?;

    assert_eq!(manifest.invocation().command().executable(), "cargo");
    assert_eq!(manifest.invocation().command().arguments(), COMMAND);
    assert_eq!(manifest.reading().announced(), AnnouncedRoster::Stated(45));
    assert_eq!(manifest.reading().run().reports().len(), 45usize);
    assert_eq!(manifest.reading().run().kills().count(), 37usize);
    assert_eq!(manifest.reading().run().non_kills().count(), 8usize);
    assert_eq!(manifest.reading().run().survivors().count(), 0usize);
    assert!(
        manifest
            .reading()
            .run()
            .reports()
            .iter()
            .all(|report| report.target().owning_claim().is_none())
    );
    let [summary] = manifest.reading().unparsed() else {
        return Err("the mutation summary was not retained exactly once".to_owned());
    };
    assert_eq!(summary.ordinal(), 47usize);
    assert_eq!(
        summary.text().bytes(),
        b"45 mutants tested: 37 caught, 8 unviable"
    );
    assert_eq!(manifest.sources(), core::slice::from_ref(&source));

    let qualification = AdapterQualification::of(
        manifest.reading(),
        GrammarStanding::Checked(version.clone()),
    )
    .map_err(described)?;
    assert_eq!(qualification.standing(), &GrammarStanding::Checked(version));
    Ok(())
}
