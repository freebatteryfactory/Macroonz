#![forbid(unsafe_code)]
#![deny(warnings)]

use bakery::compiler::{
    Accounted, Bounded, CanonicalContent, CapturedDelimiter, CapturedInput, CapturedTokenTree,
    CrateBinding, Destination, Diagnostic, Disposition, DispositionSet, Door, Expansion, Family,
    GeneratedDelimiter, GeneratedToken, GeneratedTree, Kind, LineBody, NoQuestions, Observed,
    Phase, Placement, Producer, RefusalClass, Refused, Repair, Request, Role, SpanHandle,
    SpanTable,
};

const DOOR: Door = Door::declared(
    "guarded-transition-subject",
    "guarded-transition-subject.declaration",
    "guarded_transition_subject_macros::guarded_transition",
    CrateBinding::declared("bakery"),
    Producer {
        namespace: "guarded-transition-subject",
        name: "guarded-transition-subject-macros",
    },
);

const GRAMMAR_FAMILY: Family = Family::declared("guarded-transition-subject/grammar");
const ACCOUNTING_FAMILY: Family = Family::declared("guarded-transition-subject/accounting");
const ROSTER_LIMIT: usize = 8;
const ROW_LIMIT: usize = 16;
const EXPECTED_PROJECTIONS: [&str; 6] = [
    "production",
    "property",
    "mutation",
    "benchmark",
    "compile",
    "receipt",
];

#[derive(Debug, Clone, PartialEq, Eq, PartialOrd, Ord)]
pub(crate) struct NamedSpec {
    pub(crate) name: String,
}

#[derive(Debug, Clone, PartialEq, Eq, PartialOrd, Ord)]
pub(crate) struct TransitionSpec {
    pub(crate) from: String,
    pub(crate) event: String,
    pub(crate) to: String,
}

#[derive(Debug, Clone, PartialEq, Eq, PartialOrd, Ord)]
pub(crate) struct EffectSpec {
    pub(crate) transition: TransitionSpec,
    pub(crate) seat: String,
    pub(crate) added: u64,
}

#[derive(Debug, Clone, PartialEq, Eq, PartialOrd, Ord)]
pub(crate) struct AssociationSpec {
    pub(crate) event: String,
    pub(crate) operation: String,
}

#[derive(Debug, Clone, PartialEq, Eq, PartialOrd, Ord)]
pub(crate) struct PolicySpec {
    pub(crate) capability: String,
    pub(crate) operation: String,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) struct GuardedDeclaration {
    pub(crate) states: Bounded<NamedSpec, ROSTER_LIMIT>,
    pub(crate) events: Bounded<NamedSpec, ROSTER_LIMIT>,
    pub(crate) initial: String,
    pub(crate) terminal: String,
    pub(crate) transitions: Bounded<TransitionSpec, ROW_LIMIT>,
    pub(crate) effects: Bounded<EffectSpec, ROW_LIMIT>,
    pub(crate) capabilities: Bounded<NamedSpec, ROSTER_LIMIT>,
    pub(crate) operations: Bounded<NamedSpec, ROSTER_LIMIT>,
    pub(crate) associations: Bounded<AssociationSpec, ROW_LIMIT>,
    pub(crate) policies: Bounded<PolicySpec, ROW_LIMIT>,
    pub(crate) projections: Bounded<NamedSpec, ROSTER_LIMIT>,
}

impl GuardedDeclaration {
    pub(crate) fn transition_family_bytes(&self) -> Vec<u8> {
        let mut bytes = Vec::new();
        encode_named(&self.states, &mut bytes);
        encode_named(&self.events, &mut bytes);
        bakery::compiler::encode_bytes(self.initial.as_bytes(), &mut bytes);
        bakery::compiler::encode_bytes(self.terminal.as_bytes(), &mut bytes);
        encode_sorted(&self.transitions, &mut bytes, |row, into| {
            bakery::compiler::encode_bytes(row.from.as_bytes(), into);
            bakery::compiler::encode_bytes(row.event.as_bytes(), into);
            bakery::compiler::encode_bytes(row.to.as_bytes(), into);
        });
        encode_sorted(&self.effects, &mut bytes, |row, into| {
            bakery::compiler::encode_bytes(row.transition.from.as_bytes(), into);
            bakery::compiler::encode_bytes(row.transition.event.as_bytes(), into);
            bakery::compiler::encode_bytes(row.transition.to.as_bytes(), into);
            bakery::compiler::encode_bytes(row.seat.as_bytes(), into);
            into.extend_from_slice(&row.added.to_be_bytes());
        });
        bytes
    }

    pub(crate) fn policy_family_bytes(&self) -> Vec<u8> {
        let mut bytes = Vec::new();
        encode_named(&self.capabilities, &mut bytes);
        encode_named(&self.operations, &mut bytes);
        encode_sorted(&self.policies, &mut bytes, |row, into| {
            bakery::compiler::encode_bytes(row.capability.as_bytes(), into);
            bakery::compiler::encode_bytes(row.operation.as_bytes(), into);
        });
        bytes
    }

    pub(crate) fn association_bytes(&self) -> Vec<u8> {
        let mut bytes = Vec::new();
        encode_sorted(&self.associations, &mut bytes, |row, into| {
            bakery::compiler::encode_bytes(row.event.as_bytes(), into);
            bakery::compiler::encode_bytes(row.operation.as_bytes(), into);
        });
        bytes
    }
}

impl CanonicalContent for GuardedDeclaration {
    fn encode_content_into(&self, into: &mut Vec<u8>) {
        bakery::compiler::encode_bytes(&self.transition_family_bytes(), into);
        bakery::compiler::encode_bytes(&self.policy_family_bytes(), into);
        bakery::compiler::encode_bytes(&self.association_bytes(), into);
        encode_named(&self.projections, into);
    }
}

fn encode_named<const LIMIT: usize>(rows: &Bounded<NamedSpec, LIMIT>, into: &mut Vec<u8>) {
    into.extend_from_slice(&u64::try_from(rows.len()).unwrap_or(u64::MAX).to_be_bytes());
    for row in rows.iter() {
        bakery::compiler::encode_bytes(row.name.as_bytes(), into);
    }
}

fn encode_sorted<Row: Ord, const LIMIT: usize>(
    rows: &Bounded<Row, LIMIT>,
    into: &mut Vec<u8>,
    encode: impl Fn(&Row, &mut Vec<u8>),
) {
    let mut sorted: Vec<&Row> = rows.iter().collect();
    sorted.sort_unstable();
    into.extend_from_slice(
        &u64::try_from(sorted.len())
            .unwrap_or(u64::MAX)
            .to_be_bytes(),
    );
    for row in sorted {
        encode(row, into);
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) struct GuardedProjection;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum ProjectionRole {
    Production,
    Property,
    Mutation,
    Benchmark,
    Compile,
    Receipt,
    HostileForeign,
}

impl Role for ProjectionRole {
    const ALL: &'static [Self] = &[
        Self::Production,
        Self::Property,
        Self::Mutation,
        Self::Benchmark,
        Self::Compile,
        Self::Receipt,
    ];

    fn name(self) -> &'static str {
        match self {
            Self::Production => "production",
            Self::Property => "property",
            Self::Mutation => "mutation",
            Self::Benchmark => "benchmark",
            Self::Compile => "compile",
            Self::Receipt => "receipt",
            Self::HostileForeign => "hostile-foreign",
        }
    }

    fn destination(self) -> Destination {
        Destination::DeclarationSite
    }
}

const _: ProjectionRole = ProjectionRole::HostileForeign;

impl Kind for GuardedProjection {
    const NAME: &'static str = "guarded-transition-subject.declaration";
    type Content = GuardedDeclaration;
    type Role = ProjectionRole;
    type Question = NoQuestions;
}

bakery::compiler::kinds! {
    set = ProjectionKinds;
    dispositions = ProjectionDispositions;

    Production = "guarded-transition.production", production => (), bakery::compiler::SoleRole, NoQuestions;
    PropertyEvidence = "guarded-transition.property", property => (), bakery::compiler::SoleRole, NoQuestions;
    MutationSurface = "guarded-transition.mutation", mutation => (), bakery::compiler::SoleRole, NoQuestions;
    BenchmarkAxis = "guarded-transition.benchmark", benchmark => (), bakery::compiler::SoleRole, NoQuestions;
    CompileContract = "guarded-transition.compile", compile => (), bakery::compiler::SoleRole, NoQuestions;
    ReceiptReading = "guarded-transition.receipt", receipt => (), bakery::compiler::SoleRole, NoQuestions;
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) enum GrammarIssue {
    MalformedDeclaration,
    RosterAbsent(&'static str),
    RosterUnbounded(&'static str),
    DuplicateMember {
        roster: &'static str,
        member: String,
    },
    ForeignStanding(String),
    InitialEqualsTerminal,
    TransitionsAbsent,
    TransitionsUnbounded,
    ForeignTransition(TransitionSpec),
    DuplicateTransition(TransitionSpec),
    SelfTransition(TransitionSpec),
    BackwardTransition(TransitionSpec),
    EffectsUnbounded,
    MissingEffect(TransitionSpec),
    DuplicateEffect(TransitionSpec),
    ForeignEffect(TransitionSpec),
    DuplicateEffectSeat(String),
    AssociationsUnbounded,
    MissingAssociation(String),
    DuplicateAssociation(String),
    ForeignAssociation(AssociationSpec),
    PoliciesAbsent,
    PoliciesUnbounded,
    ForeignPolicy(PolicySpec),
    DuplicatePolicy(PolicySpec),
    ProjectionMismatch {
        expected: &'static str,
        observed: String,
    },
    MalformedRoster(&'static str),
    MalformedTransition,
    MalformedEffect,
    MalformedAssociation,
    MalformedPolicy,
    UnsupportedEffectOperation(String),
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) struct GrammarRefusal {
    issue: GrammarIssue,
    at: Option<SpanHandle>,
}

impl GrammarRefusal {
    pub(crate) const fn issue(&self) -> &GrammarIssue {
        &self.issue
    }

    pub(crate) const fn token(&self) -> Option<SpanHandle> {
        self.at
    }

    fn at(issue: GrammarIssue, token: &CapturedTokenTree) -> Self {
        Self {
            issue,
            at: Some(token.span()),
        }
    }

    fn whole(issue: GrammarIssue) -> Self {
        Self { issue, at: None }
    }

    fn diagnostic(&self) -> Diagnostic {
        match self.token() {
            Some(token) => Diagnostic::refused(
                self,
                &DOOR,
                &Placement::AtToken {
                    token,
                    spans: &SpanTable::ProducerHeld,
                },
            ),
            None => Diagnostic::refused(self, &DOOR, &Placement::WholeDeclaration),
        }
    }
}

impl Refused for GrammarRefusal {
    const PHASE: Phase = Phase::Capture;
    const FAMILY: Family = GRAMMAR_FAMILY;

    fn class(&self) -> RefusalClass {
        RefusalClass::DeclarationNotRead
    }

    fn first(&self) -> String {
        format!(
            "the guarded-transition declaration was refused as {:?}",
            self.issue()
        )
    }

    fn observed(&self) -> Observed {
        Observed::ContractDisagreement
    }

    fn body(&self) -> LineBody {
        LineBody::SingleCause
    }

    fn related(&self) -> Vec<Vec<u8>> {
        Vec::new()
    }

    fn repairs(&self) -> Bounded<Repair, 8> {
        Bounded::empty()
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct AccountingRefusal;

impl Refused for AccountingRefusal {
    const PHASE: Phase = Phase::Binding;
    const FAMILY: Family = ACCOUNTING_FAMILY;

    fn class(&self) -> RefusalClass {
        RefusalClass::DeclarationNotRead
    }

    fn first(&self) -> String {
        "the generated projection roster could not be completely dispositioned".to_owned()
    }

    fn observed(&self) -> Observed {
        Observed::ContractDisagreement
    }

    fn body(&self) -> LineBody {
        LineBody::SingleCause
    }

    fn related(&self) -> Vec<Vec<u8>> {
        Vec::new()
    }

    fn repairs(&self) -> Bounded<Repair, 8> {
        Bounded::empty()
    }
}

fn group(token: &CapturedTokenTree) -> Result<&[CapturedTokenTree], GrammarRefusal> {
    let Some((CapturedDelimiter::Brace, members)) = token.group() else {
        return Err(GrammarRefusal::at(
            GrammarIssue::MalformedDeclaration,
            token,
        ));
    };
    Ok(members)
}

pub(crate) fn read_declaration(
    capture: &CapturedInput,
) -> Result<GuardedDeclaration, GrammarRefusal> {
    let [
        states_word,
        states_group,
        events_word,
        events_group,
        initial_word,
        initial_group,
        terminal_word,
        terminal_group,
        transitions_word,
        transitions_group,
        effects_word,
        effects_group,
        capabilities_word,
        capabilities_group,
        operations_word,
        operations_group,
        associations_word,
        associations_group,
        policies_word,
        policies_group,
        projections_word,
        projections_group,
    ] = capture.trees()
    else {
        return Err(capture.trees().first().map_or_else(
            || GrammarRefusal::whole(GrammarIssue::MalformedDeclaration),
            |token| GrammarRefusal::at(GrammarIssue::MalformedDeclaration, token),
        ));
    };
    for (token, expected) in [
        (states_word, "states"),
        (events_word, "events"),
        (initial_word, "initial"),
        (terminal_word, "terminal"),
        (transitions_word, "transitions"),
        (effects_word, "effects"),
        (capabilities_word, "capabilities"),
        (operations_word, "operations"),
        (associations_word, "associations"),
        (policies_word, "policies"),
        (projections_word, "projections"),
    ] {
        if token.word() != Some(expected) {
            return Err(GrammarRefusal::at(
                GrammarIssue::MalformedDeclaration,
                token,
            ));
        }
    }
    informed(&RawDeclaration {
        states: group(states_group)?,
        events: group(events_group)?,
        initial: group(initial_group)?,
        terminal: group(terminal_group)?,
        transitions: group(transitions_group)?,
        effects: group(effects_group)?,
        capabilities: group(capabilities_group)?,
        operations: group(operations_group)?,
        associations: group(associations_group)?,
        policies: group(policies_group)?,
        projections: group(projections_group)?,
    })
}

struct RawDeclaration<'a> {
    states: &'a [CapturedTokenTree],
    events: &'a [CapturedTokenTree],
    initial: &'a [CapturedTokenTree],
    terminal: &'a [CapturedTokenTree],
    transitions: &'a [CapturedTokenTree],
    effects: &'a [CapturedTokenTree],
    capabilities: &'a [CapturedTokenTree],
    operations: &'a [CapturedTokenTree],
    associations: &'a [CapturedTokenTree],
    policies: &'a [CapturedTokenTree],
    projections: &'a [CapturedTokenTree],
}

fn informed(raw: &RawDeclaration<'_>) -> Result<GuardedDeclaration, GrammarRefusal> {
    let states = read_roster(raw.states, "states")?;
    let events = read_roster(raw.events, "events")?;
    let initial = read_single(raw.initial, "initial")?;
    let terminal = read_single(raw.terminal, "terminal")?;
    if !contains(&states, &initial) {
        return Err(GrammarRefusal::whole(GrammarIssue::ForeignStanding(
            initial,
        )));
    }
    if !contains(&states, &terminal) {
        return Err(GrammarRefusal::whole(GrammarIssue::ForeignStanding(
            terminal,
        )));
    }
    if initial == terminal {
        return Err(GrammarRefusal::whole(GrammarIssue::InitialEqualsTerminal));
    }
    let transitions = read_transitions(raw.transitions, &states, &events)?;
    let effects = read_effects(raw.effects, &states, &events, &transitions)?;
    let capabilities = read_roster(raw.capabilities, "capabilities")?;
    let operations = read_roster(raw.operations, "operations")?;
    let associations = read_associations(raw.associations, &events, &operations)?;
    let policies = read_policies(raw.policies, &capabilities, &operations)?;
    let projections = read_projections(raw.projections)?;
    Ok(GuardedDeclaration {
        states,
        events,
        initial,
        terminal,
        transitions,
        effects,
        capabilities,
        operations,
        associations,
        policies,
        projections,
    })
}

fn read_single(
    tokens: &[CapturedTokenTree],
    roster: &'static str,
) -> Result<String, GrammarRefusal> {
    let [token] = tokens else {
        return Err(GrammarRefusal::whole(GrammarIssue::MalformedRoster(roster)));
    };
    token
        .word()
        .filter(|name| bakery::compiler::rendered_name(name))
        .map(str::to_owned)
        .ok_or_else(|| GrammarRefusal::at(GrammarIssue::MalformedRoster(roster), token))
}

fn read_roster(
    tokens: &[CapturedTokenTree],
    roster: &'static str,
) -> Result<Bounded<NamedSpec, ROSTER_LIMIT>, GrammarRefusal> {
    if tokens.is_empty() {
        return Err(GrammarRefusal::whole(GrammarIssue::RosterAbsent(roster)));
    }
    let (rows, remainder) = tokens.as_chunks::<2>();
    if let Some(token) = remainder.first() {
        return Err(GrammarRefusal::at(
            GrammarIssue::MalformedRoster(roster),
            token,
        ));
    }
    let mut names = Vec::new();
    for [name, comma] in rows {
        let Some(spelling) = name
            .word()
            .filter(|candidate| bakery::compiler::rendered_name(candidate))
        else {
            return Err(GrammarRefusal::at(
                GrammarIssue::MalformedRoster(roster),
                name,
            ));
        };
        if comma.punct() != Some(',') {
            return Err(GrammarRefusal::at(
                GrammarIssue::MalformedRoster(roster),
                comma,
            ));
        }
        if names.iter().any(|named: &NamedSpec| named.name == spelling) {
            return Err(GrammarRefusal::at(
                GrammarIssue::DuplicateMember {
                    roster,
                    member: spelling.to_owned(),
                },
                name,
            ));
        }
        names.push(NamedSpec {
            name: spelling.to_owned(),
        });
    }
    Bounded::new(names)
        .map_err(|_overflow| GrammarRefusal::whole(GrammarIssue::RosterUnbounded(roster)))
}

fn contains<const LIMIT: usize>(roster: &Bounded<NamedSpec, LIMIT>, name: &str) -> bool {
    roster.iter().any(|member| member.name == name)
}

fn rank<const LIMIT: usize>(roster: &Bounded<NamedSpec, LIMIT>, name: &str) -> Option<usize> {
    roster.iter().position(|member| member.name == name)
}

fn read_transitions(
    tokens: &[CapturedTokenTree],
    states: &Bounded<NamedSpec, ROSTER_LIMIT>,
    events: &Bounded<NamedSpec, ROSTER_LIMIT>,
) -> Result<Bounded<TransitionSpec, ROW_LIMIT>, GrammarRefusal> {
    if tokens.is_empty() {
        return Err(GrammarRefusal::whole(GrammarIssue::TransitionsAbsent));
    }
    let (rows, remainder) = tokens.as_chunks::<7>();
    if let Some(token) = remainder.first() {
        return Err(GrammarRefusal::at(GrammarIssue::MalformedTransition, token));
    }
    let mut transitions = Vec::new();
    for [from, plus, event, dash, arrow, to, comma] in rows {
        let (Some(from_name), Some(event_name), Some(to_name)) =
            (from.word(), event.word(), to.word())
        else {
            return Err(GrammarRefusal::at(GrammarIssue::MalformedTransition, from));
        };
        if plus.punct() != Some('+') {
            return Err(GrammarRefusal::at(GrammarIssue::MalformedTransition, plus));
        }
        if dash.joint_punct() != Some('-') {
            return Err(GrammarRefusal::at(GrammarIssue::MalformedTransition, dash));
        }
        if arrow.punct() != Some('>') {
            return Err(GrammarRefusal::at(GrammarIssue::MalformedTransition, arrow));
        }
        if comma.punct() != Some(',') {
            return Err(GrammarRefusal::at(GrammarIssue::MalformedTransition, comma));
        }
        let transition = TransitionSpec {
            from: from_name.to_owned(),
            event: event_name.to_owned(),
            to: to_name.to_owned(),
        };
        let Some(from_rank) = rank(states, from_name) else {
            return Err(GrammarRefusal::at(
                GrammarIssue::ForeignTransition(transition.clone()),
                from,
            ));
        };
        if !contains(events, event_name) {
            return Err(GrammarRefusal::at(
                GrammarIssue::ForeignTransition(transition.clone()),
                event,
            ));
        }
        let Some(to_rank) = rank(states, to_name) else {
            return Err(GrammarRefusal::at(
                GrammarIssue::ForeignTransition(transition),
                to,
            ));
        };
        match from_rank.cmp(&to_rank) {
            core::cmp::Ordering::Equal => {
                return Err(GrammarRefusal::at(
                    GrammarIssue::SelfTransition(transition),
                    arrow,
                ));
            }
            core::cmp::Ordering::Greater => {
                return Err(GrammarRefusal::at(
                    GrammarIssue::BackwardTransition(transition),
                    arrow,
                ));
            }
            core::cmp::Ordering::Less => {}
        }
        if transitions.iter().any(|row| row == &transition) {
            return Err(GrammarRefusal::at(
                GrammarIssue::DuplicateTransition(transition),
                from,
            ));
        }
        transitions.push(transition);
    }
    Bounded::new(transitions)
        .map_err(|_overflow| GrammarRefusal::whole(GrammarIssue::TransitionsUnbounded))
}

fn read_effects(
    tokens: &[CapturedTokenTree],
    states: &Bounded<NamedSpec, ROSTER_LIMIT>,
    events: &Bounded<NamedSpec, ROSTER_LIMIT>,
    transitions: &Bounded<TransitionSpec, ROW_LIMIT>,
) -> Result<Bounded<EffectSpec, ROW_LIMIT>, GrammarRefusal> {
    let (rows, remainder) = tokens.as_chunks::<11>();
    if let Some(token) = remainder.first() {
        return Err(GrammarRefusal::at(GrammarIssue::MalformedEffect, token));
    }
    let mut effects = Vec::new();
    for row in rows {
        effects.push(read_effect(row, states, events, transitions, &effects)?);
    }
    for transition in transitions.iter() {
        if !effects
            .iter()
            .any(|effect: &EffectSpec| &effect.transition == transition)
        {
            return Err(GrammarRefusal::whole(GrammarIssue::MissingEffect(
                transition.clone(),
            )));
        }
    }
    Bounded::new(effects).map_err(|_overflow| GrammarRefusal::whole(GrammarIssue::EffectsUnbounded))
}

fn read_effect(
    row: &[CapturedTokenTree; 11],
    states: &Bounded<NamedSpec, ROSTER_LIMIT>,
    events: &Bounded<NamedSpec, ROSTER_LIMIT>,
    transitions: &Bounded<TransitionSpec, ROW_LIMIT>,
    effects: &[EffectSpec],
) -> Result<EffectSpec, GrammarRefusal> {
    let [
        from,
        plus,
        event,
        dash,
        arrow,
        to,
        equals,
        seat,
        operation,
        arguments,
        comma,
    ] = row;
    let (Some(from_name), Some(event_name), Some(to_name), Some(seat_name)) = (
        from.word(),
        event.word(),
        to.word(),
        seat.word()
            .filter(|candidate| bakery::compiler::rendered_name(candidate)),
    ) else {
        return Err(GrammarRefusal::at(GrammarIssue::MalformedEffect, from));
    };
    read_effect_punctuation(plus, dash, arrow, equals, comma)?;
    let Some(operation_name) = operation.word() else {
        return Err(GrammarRefusal::at(GrammarIssue::MalformedEffect, operation));
    };
    if operation_name != "add" {
        return Err(GrammarRefusal::at(
            GrammarIssue::UnsupportedEffectOperation(operation_name.to_owned()),
            operation,
        ));
    }
    let Some((CapturedDelimiter::Parenthesis, [amount])) = arguments.group() else {
        return Err(GrammarRefusal::at(GrammarIssue::MalformedEffect, arguments));
    };
    let Some(added) = amount
        .number()
        .and_then(|number| number.parse::<u64>().ok())
    else {
        return Err(GrammarRefusal::at(GrammarIssue::MalformedEffect, amount));
    };
    let transition = TransitionSpec {
        from: from_name.to_owned(),
        event: event_name.to_owned(),
        to: to_name.to_owned(),
    };
    if !contains(states, from_name) {
        return Err(GrammarRefusal::at(
            GrammarIssue::ForeignEffect(transition.clone()),
            from,
        ));
    }
    if !contains(events, event_name) {
        return Err(GrammarRefusal::at(
            GrammarIssue::ForeignEffect(transition.clone()),
            event,
        ));
    }
    if !contains(states, to_name) {
        return Err(GrammarRefusal::at(
            GrammarIssue::ForeignEffect(transition),
            to,
        ));
    }
    if !transitions.iter().any(|declared| declared == &transition) {
        return Err(GrammarRefusal::at(
            GrammarIssue::ForeignEffect(transition),
            from,
        ));
    }
    if effects
        .iter()
        .any(|declared| declared.transition == transition)
    {
        return Err(GrammarRefusal::at(
            GrammarIssue::DuplicateEffect(transition),
            from,
        ));
    }
    if effects.iter().any(|declared| declared.seat == seat_name) {
        return Err(GrammarRefusal::at(
            GrammarIssue::DuplicateEffectSeat(seat_name.to_owned()),
            seat,
        ));
    }
    Ok(EffectSpec {
        transition,
        seat: seat_name.to_owned(),
        added,
    })
}

fn read_effect_punctuation(
    plus: &CapturedTokenTree,
    dash: &CapturedTokenTree,
    arrow: &CapturedTokenTree,
    equals: &CapturedTokenTree,
    comma: &CapturedTokenTree,
) -> Result<(), GrammarRefusal> {
    if plus.punct() != Some('+') {
        return Err(GrammarRefusal::at(GrammarIssue::MalformedEffect, plus));
    }
    if dash.joint_punct() != Some('-') {
        return Err(GrammarRefusal::at(GrammarIssue::MalformedEffect, dash));
    }
    if arrow.punct() != Some('>') {
        return Err(GrammarRefusal::at(GrammarIssue::MalformedEffect, arrow));
    }
    if equals.punct() != Some('=') {
        return Err(GrammarRefusal::at(GrammarIssue::MalformedEffect, equals));
    }
    if comma.punct() != Some(',') {
        return Err(GrammarRefusal::at(GrammarIssue::MalformedEffect, comma));
    }
    Ok(())
}

fn read_associations(
    tokens: &[CapturedTokenTree],
    events: &Bounded<NamedSpec, ROSTER_LIMIT>,
    operations: &Bounded<NamedSpec, ROSTER_LIMIT>,
) -> Result<Bounded<AssociationSpec, ROW_LIMIT>, GrammarRefusal> {
    let (rows, remainder) = tokens.as_chunks::<5>();
    if let Some(token) = remainder.first() {
        return Err(GrammarRefusal::at(
            GrammarIssue::MalformedAssociation,
            token,
        ));
    }
    let mut associations = Vec::new();
    for [event, equals, arrow, operation, comma] in rows {
        let (Some(event_name), Some(operation_name)) = (event.word(), operation.word()) else {
            return Err(GrammarRefusal::at(
                GrammarIssue::MalformedAssociation,
                event,
            ));
        };
        if equals.joint_punct() != Some('=') {
            return Err(GrammarRefusal::at(
                GrammarIssue::MalformedAssociation,
                equals,
            ));
        }
        if arrow.punct() != Some('>') {
            return Err(GrammarRefusal::at(
                GrammarIssue::MalformedAssociation,
                arrow,
            ));
        }
        if comma.punct() != Some(',') {
            return Err(GrammarRefusal::at(
                GrammarIssue::MalformedAssociation,
                comma,
            ));
        }
        let association = AssociationSpec {
            event: event_name.to_owned(),
            operation: operation_name.to_owned(),
        };
        if !contains(events, event_name) {
            return Err(GrammarRefusal::at(
                GrammarIssue::ForeignAssociation(association.clone()),
                event,
            ));
        }
        if !contains(operations, operation_name) {
            return Err(GrammarRefusal::at(
                GrammarIssue::ForeignAssociation(association),
                operation,
            ));
        }
        if associations
            .iter()
            .any(|row: &AssociationSpec| row.event == event_name)
        {
            return Err(GrammarRefusal::at(
                GrammarIssue::DuplicateAssociation(event_name.to_owned()),
                event,
            ));
        }
        associations.push(association);
    }
    for event in events.iter() {
        if !associations.iter().any(|row| row.event == event.name) {
            return Err(GrammarRefusal::whole(GrammarIssue::MissingAssociation(
                event.name.clone(),
            )));
        }
    }
    Bounded::new(associations)
        .map_err(|_overflow| GrammarRefusal::whole(GrammarIssue::AssociationsUnbounded))
}

fn read_policies(
    tokens: &[CapturedTokenTree],
    capabilities: &Bounded<NamedSpec, ROSTER_LIMIT>,
    operations: &Bounded<NamedSpec, ROSTER_LIMIT>,
) -> Result<Bounded<PolicySpec, ROW_LIMIT>, GrammarRefusal> {
    if tokens.is_empty() {
        return Err(GrammarRefusal::whole(GrammarIssue::PoliciesAbsent));
    }
    let (rows, remainder) = tokens.as_chunks::<5>();
    if let Some(token) = remainder.first() {
        return Err(GrammarRefusal::at(GrammarIssue::MalformedPolicy, token));
    }
    let mut policies = Vec::new();
    for [capability, equals, arrow, operation, comma] in rows {
        let (Some(capability_name), Some(operation_name)) = (capability.word(), operation.word())
        else {
            return Err(GrammarRefusal::at(
                GrammarIssue::MalformedPolicy,
                capability,
            ));
        };
        if equals.joint_punct() != Some('=') {
            return Err(GrammarRefusal::at(GrammarIssue::MalformedPolicy, equals));
        }
        if arrow.punct() != Some('>') {
            return Err(GrammarRefusal::at(GrammarIssue::MalformedPolicy, arrow));
        }
        if comma.punct() != Some(',') {
            return Err(GrammarRefusal::at(GrammarIssue::MalformedPolicy, comma));
        }
        let policy = PolicySpec {
            capability: capability_name.to_owned(),
            operation: operation_name.to_owned(),
        };
        if !contains(capabilities, capability_name) {
            return Err(GrammarRefusal::at(
                GrammarIssue::ForeignPolicy(policy.clone()),
                capability,
            ));
        }
        if !contains(operations, operation_name) {
            return Err(GrammarRefusal::at(
                GrammarIssue::ForeignPolicy(policy),
                operation,
            ));
        }
        if policies.iter().any(|declared| declared == &policy) {
            return Err(GrammarRefusal::at(
                GrammarIssue::DuplicatePolicy(policy),
                capability,
            ));
        }
        policies.push(policy);
    }
    Bounded::new(policies)
        .map_err(|_overflow| GrammarRefusal::whole(GrammarIssue::PoliciesUnbounded))
}

fn read_projections(
    tokens: &[CapturedTokenTree],
) -> Result<Bounded<NamedSpec, ROSTER_LIMIT>, GrammarRefusal> {
    let observed = read_roster(tokens, "projections")?;
    if observed.len() != EXPECTED_PROJECTIONS.len() {
        return Err(GrammarRefusal::whole(GrammarIssue::ProjectionMismatch {
            expected: "six declared projection seats",
            observed: format!("{} seats", observed.len()),
        }));
    }
    for (row, expected) in observed.iter().zip(EXPECTED_PROJECTIONS) {
        if row.name != expected {
            return Err(GrammarRefusal::whole(GrammarIssue::ProjectionMismatch {
                expected,
                observed: row.name.clone(),
            }));
        }
    }
    Ok(observed)
}

fn path(segments: &[&str]) -> Vec<GeneratedToken> {
    let mut tokens = vec![GeneratedToken::word(
        segments.first().copied().unwrap_or("crate"),
    )];
    for segment in segments.iter().skip(1) {
        tokens.push(GeneratedToken::joint(':'));
        tokens.push(GeneratedToken::alone(':'));
        tokens.push(GeneratedToken::word(segment));
    }
    tokens
}

fn subject_variant(kind: &str, variant: &str) -> Vec<GeneratedToken> {
    path(&["crate", kind, variant])
}

fn comma_parts(parts: impl IntoIterator<Item = Vec<GeneratedToken>>) -> Vec<GeneratedToken> {
    bakery::compiler::comma_many(parts.into_iter().collect())
}

fn slice_type(
    element: Vec<GeneratedToken>,
) -> Result<Vec<GeneratedToken>, bakery::compiler::Overflow> {
    Ok(vec![
        GeneratedToken::alone('&'),
        bakery::compiler::group(GeneratedDelimiter::Bracket, element)?,
    ])
}

fn slice_value(
    values: impl IntoIterator<Item = Vec<GeneratedToken>>,
) -> Result<Vec<GeneratedToken>, bakery::compiler::Overflow> {
    Ok(vec![
        GeneratedToken::alone('&'),
        bakery::compiler::group(GeneratedDelimiter::Bracket, comma_parts(values))?,
    ])
}

fn public_const(
    name: &str,
    kind: Vec<GeneratedToken>,
    value: Vec<GeneratedToken>,
) -> Vec<GeneratedToken> {
    let mut tokens = vec![GeneratedToken::word("pub")];
    tokens.extend(bakery::compiler::constant(name, kind, value));
    tokens
}

fn call_subject(
    kind: &str,
    method: &str,
    arguments: Vec<Vec<GeneratedToken>>,
) -> Result<Vec<GeneratedToken>, bakery::compiler::Overflow> {
    bakery::compiler::call(path(&["crate", kind, method]), comma_parts(arguments))
}

fn named_roster(
    constant: &str,
    kind: &str,
    rows: &Bounded<NamedSpec, ROSTER_LIMIT>,
) -> Result<Vec<GeneratedToken>, bakery::compiler::Overflow> {
    let values = rows
        .iter()
        .map(|row| subject_variant(kind, &row.name))
        .collect::<Vec<_>>();
    Ok(public_const(
        constant,
        slice_type(path(&["crate", kind]))?,
        slice_value(values)?,
    ))
}

fn transition_roster(
    declaration: &GuardedDeclaration,
) -> Result<Vec<GeneratedToken>, bakery::compiler::Overflow> {
    let mut effects: Vec<&EffectSpec> = declaration.effects.iter().collect();
    effects.sort_unstable();
    let mut values = Vec::new();
    for effect in effects {
        values.push(call_subject(
            "TransitionRow",
            "declared",
            vec![
                subject_variant("Standing", &effect.transition.from),
                subject_variant("Event", &effect.transition.event),
                subject_variant("Standing", &effect.transition.to),
                subject_variant("EffectSeat", &effect.seat),
                vec![GeneratedToken::number(effect.added)],
            ],
        )?);
    }
    Ok(public_const(
        "GENERATED_TRANSITIONS",
        slice_type(path(&["crate", "TransitionRow"]))?,
        slice_value(values)?,
    ))
}

fn effect_roster(
    declaration: &GuardedDeclaration,
) -> Result<Vec<GeneratedToken>, bakery::compiler::Overflow> {
    let mut effects: Vec<&EffectSpec> = declaration.effects.iter().collect();
    effects.sort_unstable();
    let values = effects
        .into_iter()
        .map(|effect| subject_variant("EffectSeat", &effect.seat))
        .collect::<Vec<_>>();
    Ok(public_const(
        "GENERATED_EFFECTS",
        slice_type(path(&["crate", "EffectSeat"]))?,
        slice_value(values)?,
    ))
}

fn association_roster(
    declaration: &GuardedDeclaration,
) -> Result<Vec<GeneratedToken>, bakery::compiler::Overflow> {
    let mut rows: Vec<&AssociationSpec> = declaration.associations.iter().collect();
    rows.sort_unstable();
    let mut values = Vec::new();
    for row in rows {
        values.push(call_subject(
            "Association",
            "declared",
            vec![
                subject_variant("Event", &row.event),
                subject_variant("Operation", &row.operation),
            ],
        )?);
    }
    Ok(public_const(
        "GENERATED_ASSOCIATIONS",
        slice_type(path(&["crate", "Association"]))?,
        slice_value(values)?,
    ))
}

fn policy_roster(
    declaration: &GuardedDeclaration,
) -> Result<Vec<GeneratedToken>, bakery::compiler::Overflow> {
    let mut rows: Vec<&PolicySpec> = declaration.policies.iter().collect();
    rows.sort_unstable();
    let mut values = Vec::new();
    for row in rows {
        values.push(call_subject(
            "PolicyEdge",
            "declared",
            vec![
                subject_variant("Capability", &row.capability),
                subject_variant("Operation", &row.operation),
            ],
        )?);
    }
    Ok(public_const(
        "GENERATED_POLICIES",
        slice_type(path(&["crate", "PolicyEdge"]))?,
        slice_value(values)?,
    ))
}

fn scalar_const(name: &str, kind: &str, variant: &str) -> Vec<GeneratedToken> {
    public_const(name, path(&["crate", kind]), subject_variant(kind, variant))
}

fn generated_road_impl() -> Result<Vec<GeneratedToken>, bakery::compiler::Overflow> {
    let parameters = comma_parts([
        {
            let mut tokens = vec![
                GeneratedToken::word("capability"),
                GeneratedToken::alone(':'),
            ];
            tokens.extend(path(&["crate", "Capability"]));
            tokens
        },
        {
            let mut tokens = vec![
                GeneratedToken::word("events"),
                GeneratedToken::alone(':'),
                GeneratedToken::alone('&'),
            ];
            tokens.push(bakery::compiler::group(
                GeneratedDelimiter::Bracket,
                path(&["crate", "Event"]),
            )?);
            tokens
        },
        vec![
            GeneratedToken::word("opening_value"),
            GeneratedToken::alone(':'),
            GeneratedToken::word("u64"),
        ],
    ]);
    let result = bakery::compiler::result_type(
        path(&["crate", "Reading"]),
        path(&["crate", "GuardRefusal"]),
    );
    let body = bakery::compiler::call(
        path(&["crate", "execute_declared"]),
        comma_parts([
            vec![GeneratedToken::word("capability")],
            vec![GeneratedToken::word("events")],
            vec![GeneratedToken::word("opening_value")],
            vec![GeneratedToken::word("GENERATED_TRANSITIONS")],
            vec![GeneratedToken::word("GENERATED_POLICIES")],
            vec![GeneratedToken::word("GENERATED_ASSOCIATIONS")],
            vec![GeneratedToken::word("GENERATED_INITIAL")],
        ]),
    )?;
    let execute = bakery::compiler::function("execute", parameters, result, body)?;
    let mut trait_path = path(&["crate", "GuardedContract"]);
    trait_path.push(GeneratedToken::word("for"));
    trait_path.push(GeneratedToken::word("GeneratedRoad"));
    trait_path.push(bakery::compiler::group(GeneratedDelimiter::Brace, execute)?);
    let mut tokens = vec![
        GeneratedToken::word("pub"),
        GeneratedToken::word("struct"),
        GeneratedToken::word("GeneratedRoad"),
        GeneratedToken::alone(';'),
        GeneratedToken::word("impl"),
    ];
    tokens.extend(trait_path);
    Ok(tokens)
}

fn production_tree(
    declaration: &GuardedDeclaration,
) -> Result<GeneratedTree, bakery::compiler::RenderError> {
    let mut tokens = Vec::new();
    tokens.extend(named_roster(
        "GENERATED_STATES",
        "Standing",
        &declaration.states,
    )?);
    tokens.extend(named_roster(
        "GENERATED_EVENTS",
        "Event",
        &declaration.events,
    )?);
    tokens.extend(scalar_const(
        "GENERATED_INITIAL",
        "Standing",
        &declaration.initial,
    ));
    tokens.extend(scalar_const(
        "GENERATED_TERMINAL",
        "Standing",
        &declaration.terminal,
    ));
    tokens.extend(transition_roster(declaration)?);
    tokens.extend(effect_roster(declaration)?);
    tokens.extend(named_roster(
        "GENERATED_CAPABILITIES",
        "Capability",
        &declaration.capabilities,
    )?);
    tokens.extend(named_roster(
        "GENERATED_OPERATIONS",
        "Operation",
        &declaration.operations,
    )?);
    tokens.extend(association_roster(declaration)?);
    tokens.extend(policy_roster(declaration)?);
    tokens.extend(generated_road_impl()?);
    GeneratedTree::assembled(tokens).map_err(bakery::compiler::RenderError::from)
}

fn text_projection(
    constant: &str,
    values: &[&str],
) -> Result<GeneratedTree, bakery::compiler::RenderError> {
    let type_tokens = slice_type(vec![
        GeneratedToken::alone('&'),
        GeneratedToken::word("str"),
    ])?;
    let value_tokens = slice_value(values.iter().map(|value| vec![GeneratedToken::text(value)]))?;
    GeneratedTree::assembled(public_const(constant, type_tokens, value_tokens))
        .map_err(bakery::compiler::RenderError::from)
}

fn receipt_projection_direct() -> Result<GeneratedTree, bakery::compiler::RenderError> {
    text_projection(
        "GENERATED_RECEIPT_FIELDS",
        &[
            "plan",
            "closure",
            "explanation",
            "expansion",
            "dispositions",
        ],
    )
}

fn receipt_projection_refactored() -> Result<GeneratedTree, bakery::compiler::RenderError> {
    let fields = [
        "plan",
        "closure",
        "explanation",
        "expansion",
        "dispositions",
    ];
    let material = fields
        .into_iter()
        .map(|field| vec![GeneratedToken::text(field)])
        .collect::<Vec<_>>();
    let kind = vec![
        GeneratedToken::alone('&'),
        bakery::compiler::group(
            GeneratedDelimiter::Bracket,
            vec![GeneratedToken::alone('&'), GeneratedToken::word("str")],
        )?,
    ];
    let value = vec![
        GeneratedToken::alone('&'),
        bakery::compiler::group(GeneratedDelimiter::Bracket, comma_parts(material))?,
    ];
    let mut tokens = vec![GeneratedToken::word("pub")];
    tokens.extend(bakery::compiler::constant(
        "GENERATED_RECEIPT_FIELDS",
        kind,
        value,
    ));
    GeneratedTree::assembled(tokens).map_err(bakery::compiler::RenderError::from)
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum RenderStyle {
    Direct,
    Refactored,
}

pub(crate) fn terminal_with(
    capture: CapturedInput,
    declaration: &GuardedDeclaration,
    style: RenderStyle,
) -> Result<Expansion<GuardedProjection>, Diagnostic> {
    Request::<GuardedProjection>::over(capture, declaration.clone(), &DOOR).render(
        |_plan, output| {
            output.unit(ProjectionRole::Production, production_tree(declaration)?)?;
            output.unit(
                ProjectionRole::Property,
                text_projection(
                    "GENERATED_PROPERTY_SEATS",
                    &[
                        "terminal-reached",
                        "value-bounded",
                        "default-deny",
                        "temporal-order",
                    ],
                )?,
            )?;
            output.unit(
                ProjectionRole::Mutation,
                text_projection(
                    "GENERATED_MUTATION_SEATS",
                    &[
                        "transition-omitted",
                        "effect-disconnected",
                        "policy-widened",
                        "policy-removed",
                        "projection-reordered",
                    ],
                )?,
            )?;
            output.unit(
                ProjectionRole::Benchmark,
                text_projection(
                    "GENERATED_BENCHMARK_AXES",
                    &["states", "transitions", "policies"],
                )?,
            )?;
            output.unit(
                ProjectionRole::Compile,
                text_projection(
                    "GENERATED_COMPILE_SEATS",
                    &[
                        "GeneratedRoad",
                        "GuardedContract",
                        "macro-removed",
                        "malformed-macro",
                        "foreign-rosters",
                    ],
                )?,
            )?;
            let receipt = match style {
                RenderStyle::Direct => receipt_projection_direct()?,
                RenderStyle::Refactored => receipt_projection_refactored()?,
            };
            output.unit(ProjectionRole::Receipt, receipt)
        },
    )
}

pub(crate) fn accounted(
    expansion: Expansion<GuardedProjection>,
) -> Result<Accounted<GuardedProjection, ProjectionKinds>, Diagnostic> {
    let unit = |role| {
        expansion
            .plan()
            .membership()
            .under(role)
            .map(|member| member.output.semantic_key)
            .ok_or_else(|| {
                Diagnostic::refused(&AccountingRefusal, &DOOR, &Placement::WholeDeclaration)
            })
    };
    let dispositions = DispositionSet::<ProjectionKinds>::complete(ProjectionDispositions {
        production: Disposition::Generated {
            unit: unit(ProjectionRole::Production)?,
        },
        property: Disposition::Generated {
            unit: unit(ProjectionRole::Property)?,
        },
        mutation: Disposition::Generated {
            unit: unit(ProjectionRole::Mutation)?,
        },
        benchmark: Disposition::Generated {
            unit: unit(ProjectionRole::Benchmark)?,
        },
        compile: Disposition::Generated {
            unit: unit(ProjectionRole::Compile)?,
        },
        receipt: Disposition::Generated {
            unit: unit(ProjectionRole::Receipt)?,
        },
    })
    .map_err(|_refusal| {
        Diagnostic::refused(&AccountingRefusal, &DOOR, &Placement::WholeDeclaration)
    })?;
    Ok(Accounted::seated(expansion, dispositions))
}

pub(crate) fn compile(
    capture: CapturedInput,
    style: RenderStyle,
) -> Result<Accounted<GuardedProjection, ProjectionKinds>, Diagnostic> {
    let declaration = read_declaration(&capture).map_err(|refusal| refusal.diagnostic())?;
    let expansion = terminal_with(capture, &declaration, style)?;
    accounted(expansion)
}
