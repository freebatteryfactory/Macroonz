//! External guarded-transition execution, property, compile-contract, and report crossings.

#![forbid(unsafe_code)]
#![deny(warnings)]

use bakery::harness::clock::{HarnessClock, MeasurementReading};
use bakery::harness::descriptor::{
    AuthoredTableName, Binding, CheckRef, ClaimRef, Classification, DerivedRevision,
    ExecutableAttachment, ExecutionSuite, Origin, PopulationRef, Provenance, RevisionBinding, Role,
    Row, SubjectRoute, Tag,
};
use bakery::harness::oracle::{
    CompilationDisagreement, CompilationVerdict, CompiledDisagreement, CompiledObservation,
    CompiledVerdict, DeclaredBehavior, DeclaredCompilation, DeclaredReadBack,
    DeclaredReadBackRoster, DiagnosticAnchor, ObservedCompilation, ObservedMember, ObservedValue,
    PrimarySourceSpan, RelativeSourcePath, RustcErrorCode, SourcePosition,
};
use bakery::harness::properties::{
    Agreement, Holding, ParitySuite, PoisonResponse, RoadPairing, SharedSubstrate, SubstrateRef,
    SubstrateRefusal, SubstrateRoster, TemporalClaim, TemporalDemand, TransitionContract,
    admits_lawful, fail_closed, holds_over_history, monotonicity, parity,
};
use bakery::harness::report::{
    ByteBudget, CaseBudget, CheckRevisionId, FindingCause, FindingLocation, HostTrialRecord,
    InvocationProfile, ReplayPosture, RunAttempt, SubjectRevisionId, TargetBinding, TargetTriple,
    TimeBudget, ToolchainIdentity, TrialConclusion, TrialReport, TrialSite,
};
use bakery::harness::runner::{
    Invocation, Selection, SelectionPlan, TrialBinding, TrialTable, record_all, record_one,
    trial_identity,
};
use guarded_transition_subject::{
    Association, Capability, EffectSeat, Event, GuardRefusal, GuardedContract, Operation,
    PolicyEdge, Reading, Standing, TransitionRow,
};
use std::cmp::Ordering;
use std::path::Path;
use std::process::{Command, ExitStatus, Output, Stdio};
use std::sync::mpsc::{self, RecvTimeoutError};
use std::time::Duration;

const OWNER: &str = "guarded-transition-challenges";
const TARGET: &str = "x86_64-pc-windows-msvc";
const TOOLCHAIN: &str = "rustc 1.98.0";
const HOST_CEILING: Duration = Duration::from_secs(60);
const READBACK: &str = "VALUE=5;STATE=Done;EFFECTS=2;STATES=3;EVENTS=2;TRANSITIONS=2;CAPABILITIES=2;OPERATIONS=2;POLICIES=3;ASSOCIATIONS=2;PROJECTIONS=6";

struct AdmissionCase {
    stem: &'static str,
    revision_material: &'static [u8],
    conclusion: TrialConclusion,
}

#[derive(Debug, Clone, PartialEq, Eq)]
struct JourneyInput {
    capability: Capability,
    events: Vec<Event>,
    opening_value: u64,
}

#[derive(Debug, Clone, PartialEq, Eq)]
enum TraceStanding {
    Admitted(Standing),
    Refused,
}

#[derive(Debug, Clone, PartialEq, Eq)]
struct TraceState {
    events: Vec<Event>,
    standing: TraceStanding,
    value: u64,
}

#[derive(Debug, Clone, PartialEq, Eq)]
struct TraceCommand {
    event: Event,
    ordinal: usize,
}

#[derive(Debug, Clone, PartialEq, Eq, PartialOrd, Ord)]
enum PolicyPosture {
    Removed,
    Baseline,
    Widened,
}

#[derive(Debug, Clone, PartialEq, Eq, PartialOrd, Ord)]
struct PolicyCount(usize);

struct SemanticClaims {
    generated_handwritten: TrialConclusion,
    generated_refactored: TrialConclusion,
    planted_wrong: TrialConclusion,
    generated_temporal: TrialConclusion,
    handwritten_temporal: TrialConclusion,
    policy_monotonicity: TrialConclusion,
    lawful: TrialConclusion,
    unauthorized: TrialConclusion,
    illegal: TrialConclusion,
}

struct ReadbackClaims {
    generated: CompiledVerdict,
    refactored: CompiledVerdict,
    handwritten: CompiledVerdict,
    wrong: CompiledVerdict,
}

struct DiagnosticClaims {
    removed: CompilationVerdict,
    malformed: TrialConclusion,
    wrong_code: CompilationVerdict,
    wrong_span: CompilationVerdict,
    foreign_state: TrialConclusion,
    foreign_event: TrialConclusion,
    foreign_capability: TrialConclusion,
    foreign_operation: TrialConclusion,
}

#[test]
fn guarded_transition_journey_executes_and_enters_report_standing() -> Result<(), String> {
    prove_host()?;
    assert_complete_readback_and_projection_carriers()?;
    assert_transition_and_policy_movement()?;
    admit(&admission_cases()?)
}

fn admission_cases() -> Result<Vec<AdmissionCase>, String> {
    let semantics = semantic_claims()?;
    let readback = readback_claims()?;
    let diagnostics = diagnostic_claims()?;
    let mut cases = readback_cases(&readback);
    cases.extend(semantic_cases(semantics));
    cases.extend(diagnostic_cases(diagnostics));
    Ok(cases)
}

fn readback_cases(readback: &ReadbackClaims) -> Vec<AdmissionCase> {
    vec![
        case(
            "generated-readback",
            include_bytes!("../src/bin/generated_readback.rs"),
            readback
                .generated
                .concluded(FindingLocation::at(file!(), line!())),
        ),
        case(
            "refactored-readback",
            include_bytes!("../src/bin/refactored_readback.rs"),
            readback
                .refactored
                .concluded(FindingLocation::at(file!(), line!())),
        ),
        case(
            "handwritten-readback",
            include_bytes!("../src/bin/handwritten_readback.rs"),
            readback
                .handwritten
                .concluded(FindingLocation::at(file!(), line!())),
        ),
        case(
            "wrong-readback-control",
            include_bytes!("../src/bin/generated_readback.rs"),
            readback
                .wrong
                .concluded(FindingLocation::at(file!(), line!())),
        ),
    ]
}

fn semantic_cases(semantics: SemanticClaims) -> Vec<AdmissionCase> {
    vec![
        case(
            "generated-handwritten-parity",
            include_bytes!("../../guarded-transition-subject/src/lib.rs"),
            semantics.generated_handwritten,
        ),
        case(
            "generated-refactored-parity",
            include_bytes!("../../guarded-transition-subject-macros/src/engine.rs"),
            semantics.generated_refactored,
        ),
        case(
            "planted-wrong-control",
            include_bytes!("../../guarded-transition-subject/src/lib.rs"),
            semantics.planted_wrong,
        ),
        case(
            "generated-temporal",
            include_bytes!("../../guarded-transition-subject/src/lib.rs"),
            semantics.generated_temporal,
        ),
        case(
            "handwritten-temporal",
            include_bytes!("../../guarded-transition-subject/src/lib.rs"),
            semantics.handwritten_temporal,
        ),
        case(
            "policy-monotonicity",
            include_bytes!("../../guarded-transition-subject/src/lib.rs"),
            semantics.policy_monotonicity,
        ),
        case(
            "lawful-admission",
            include_bytes!("../../guarded-transition-subject/src/lib.rs"),
            semantics.lawful,
        ),
        case(
            "unauthorized-default-deny",
            include_bytes!("../../guarded-transition-subject/src/lib.rs"),
            semantics.unauthorized,
        ),
        case(
            "illegal-transition",
            include_bytes!("../../guarded-transition-subject/src/lib.rs"),
            semantics.illegal,
        ),
    ]
}

fn diagnostic_cases(diagnostics: DiagnosticClaims) -> Vec<AdmissionCase> {
    vec![
        case(
            "macro-removed-refusal",
            include_bytes!("../src/bin/macro_removed.rs"),
            diagnostics
                .removed
                .concluded(FindingLocation::at(file!(), line!())),
        ),
        case(
            "malformed-macro-refusal",
            include_bytes!("../../guarded-transition-subject/src/bin/malformed_macro.rs"),
            diagnostics.malformed,
        ),
        case(
            "wrong-diagnostic-code-control",
            include_bytes!("../src/bin/macro_removed.rs"),
            diagnostics
                .wrong_code
                .concluded(FindingLocation::at(file!(), line!())),
        ),
        case(
            "wrong-diagnostic-span-control",
            include_bytes!("../src/bin/macro_removed.rs"),
            diagnostics
                .wrong_span
                .concluded(FindingLocation::at(file!(), line!())),
        ),
        case(
            "foreign-state-roster",
            include_bytes!("../../guarded-transition-subject/src/bin/foreign_roster.rs"),
            diagnostics.foreign_state,
        ),
        case(
            "foreign-event-roster",
            include_bytes!("../../guarded-transition-subject/src/bin/foreign_roster.rs"),
            diagnostics.foreign_event,
        ),
        case(
            "foreign-capability-roster",
            include_bytes!("../../guarded-transition-subject/src/bin/foreign_roster.rs"),
            diagnostics.foreign_capability,
        ),
        case(
            "foreign-operation-roster",
            include_bytes!("../../guarded-transition-subject/src/bin/foreign_roster.rs"),
            diagnostics.foreign_operation,
        ),
    ]
}

const fn case(
    stem: &'static str,
    revision_material: &'static [u8],
    conclusion: TrialConclusion,
) -> AdmissionCase {
    AdmissionCase {
        stem,
        revision_material,
        conclusion,
    }
}

fn assert_complete_readback_and_projection_carriers() -> Result<(), String> {
    assert_transition_family_readback();
    assert_policy_family_readback();
    assert_projection_carriers();
    assert_executed_readback()
}

fn assert_transition_family_readback() {
    let states = [Standing::Idle, Standing::Armed, Standing::Done];
    let events = [Event::Arm, Event::Finish];
    let transitions = [
        TransitionRow::declared(
            Standing::Idle,
            Event::Arm,
            Standing::Armed,
            EffectSeat::Arm,
            2,
        ),
        TransitionRow::declared(
            Standing::Armed,
            Event::Finish,
            Standing::Done,
            EffectSeat::Finish,
            3,
        ),
    ];
    let canonical_transitions = [transitions[1], transitions[0]];
    let effects = [EffectSeat::Arm, EffectSeat::Finish];
    let canonical_effects = [EffectSeat::Finish, EffectSeat::Arm];
    assert_eq!(
        guarded_transition_subject::generated::GENERATED_STATES,
        states
    );
    assert_eq!(
        guarded_transition_subject::generated::GENERATED_EVENTS,
        events
    );
    assert_eq!(
        guarded_transition_subject::generated::GENERATED_TRANSITIONS,
        canonical_transitions
    );
    assert_eq!(
        guarded_transition_subject::generated::GENERATED_EFFECTS,
        canonical_effects
    );
    assert_eq!(guarded_transition_subject::handwritten::STATES, states);
    assert_eq!(guarded_transition_subject::handwritten::EVENTS, events);
    assert_eq!(
        guarded_transition_subject::handwritten::TRANSITIONS,
        transitions
    );
    assert_eq!(guarded_transition_subject::handwritten::EFFECTS, effects);
    assert_eq!(
        guarded_transition_subject::generated::GENERATED_INITIAL,
        Standing::Idle
    );
    assert_eq!(
        guarded_transition_subject::generated::GENERATED_TERMINAL,
        Standing::Done
    );
    assert_eq!(
        guarded_transition_subject::handwritten::INITIAL,
        Standing::Idle
    );
    assert_eq!(
        guarded_transition_subject::handwritten::TERMINAL,
        Standing::Done
    );
}

fn assert_policy_family_readback() {
    let capabilities = [Capability::Basic, Capability::Elevated];
    let operations = [Operation::ArmOp, Operation::FinishOp];
    let policies = [
        PolicyEdge::declared(Capability::Basic, Operation::ArmOp),
        PolicyEdge::declared(Capability::Elevated, Operation::ArmOp),
        PolicyEdge::declared(Capability::Elevated, Operation::FinishOp),
    ];
    let associations = [
        Association::declared(Event::Arm, Operation::ArmOp),
        Association::declared(Event::Finish, Operation::FinishOp),
    ];
    assert_eq!(
        guarded_transition_subject::generated::GENERATED_CAPABILITIES,
        capabilities
    );
    assert_eq!(
        guarded_transition_subject::generated::GENERATED_OPERATIONS,
        operations
    );
    assert_eq!(
        guarded_transition_subject::generated::GENERATED_POLICIES,
        policies
    );
    assert_eq!(
        guarded_transition_subject::generated::GENERATED_ASSOCIATIONS,
        associations
    );
    assert_eq!(
        guarded_transition_subject::handwritten::CAPABILITIES,
        capabilities
    );
    assert_eq!(
        guarded_transition_subject::handwritten::OPERATIONS,
        operations
    );
    assert_eq!(guarded_transition_subject::handwritten::POLICIES, policies);
    assert_eq!(
        guarded_transition_subject::handwritten::ASSOCIATIONS,
        associations
    );
}

fn assert_projection_carriers() {
    assert_eq!(
        guarded_transition_subject::generated::GENERATED_PROPERTY_SEATS,
        [
            "terminal-reached",
            "value-bounded",
            "default-deny",
            "temporal-order"
        ]
    );
    assert_eq!(
        guarded_transition_subject::generated::GENERATED_MUTATION_SEATS,
        [
            "transition-omitted",
            "effect-disconnected",
            "policy-widened",
            "policy-removed",
            "projection-reordered",
        ]
    );
    assert_eq!(
        guarded_transition_subject::generated::GENERATED_BENCHMARK_AXES,
        ["states", "transitions", "policies"]
    );
    assert_eq!(
        guarded_transition_subject::generated::GENERATED_COMPILE_SEATS,
        [
            "GeneratedRoad",
            "GuardedContract",
            "macro-removed",
            "malformed-macro",
            "foreign-rosters",
        ]
    );
    assert_eq!(
        guarded_transition_subject::generated::GENERATED_RECEIPT_FIELDS,
        [
            "plan",
            "closure",
            "explanation",
            "expansion",
            "dispositions"
        ]
    );
}

fn assert_executed_readback() -> Result<(), String> {
    let generated = guarded_transition_challenges::generated_readback()
        .map_err(|refusal| format!("generated readback refused: {refusal}"))?;
    let refactored = guarded_transition_challenges::refactored_readback()
        .map_err(|refusal| format!("refactored readback refused: {refusal}"))?;
    let handwritten = guarded_transition_challenges::handwritten_readback()
        .map_err(|refusal| format!("handwritten readback refused: {refusal}"))?;
    assert_eq!(generated, refactored);
    assert_eq!(generated, handwritten);
    assert_eq!(generated.to_string(), READBACK);
    Ok(())
}

fn assert_transition_and_policy_movement() -> Result<(), String> {
    let fast = guarded_transition_subject::transition_added::GeneratedRoad::execute(
        Capability::Elevated,
        &[Event::Finish],
        0,
    )
    .map_err(|refusal| format!("added transition refused: {refusal}"))?;
    assert_eq!(fast.standing(), Standing::Done);
    assert_eq!(fast.value(), 5);
    assert_eq!(fast.effects(), &[EffectSeat::Fast]);
    assert_eq!(
        guarded_transition_subject::generated::GeneratedRoad::execute(
            Capability::Elevated,
            &[Event::Finish],
            0,
        ),
        Err(GuardRefusal::IllegalTransition {
            standing: Standing::Idle,
            event: Event::Finish,
        })
    );
    let widened = guarded_transition_subject::policy_widened::GeneratedRoad::execute(
        Capability::Basic,
        &[Event::Arm, Event::Finish],
        0,
    )
    .map_err(|refusal| format!("widened policy refused: {refusal}"))?;
    assert_eq!(widened.standing(), Standing::Done);
    assert_eq!(widened.value(), 5);
    assert_eq!(
        guarded_transition_subject::generated::GeneratedRoad::execute(
            Capability::Basic,
            &[Event::Arm, Event::Finish],
            0,
        ),
        Err(GuardRefusal::Unauthorized {
            capability: Capability::Basic,
            operation: Operation::FinishOp,
        })
    );
    assert_eq!(
        guarded_transition_subject::policy_removed::GeneratedRoad::execute(
            Capability::Elevated,
            &[Event::Arm, Event::Finish],
            0,
        ),
        Err(GuardRefusal::Unauthorized {
            capability: Capability::Elevated,
            operation: Operation::FinishOp,
        })
    );
    let baseline = guarded_transition_subject::generated::GENERATED_POLICIES;
    let widened = guarded_transition_subject::policy_widened::GENERATED_POLICIES;
    let removed = guarded_transition_subject::policy_removed::GENERATED_POLICIES;
    assert!(removed.iter().all(|edge| baseline.contains(edge)));
    assert!(baseline.iter().all(|edge| widened.contains(edge)));
    assert!(removed.len() < baseline.len());
    assert!(baseline.len() < widened.len());
    assert_eq!(
        guarded_transition_subject::generated::GENERATED_TRANSITIONS,
        guarded_transition_subject::policy_widened::GENERATED_TRANSITIONS
    );
    assert_eq!(
        guarded_transition_subject::generated::GENERATED_TRANSITIONS,
        guarded_transition_subject::policy_removed::GENERATED_TRANSITIONS
    );
    assert_eq!(
        guarded_transition_subject::generated::GENERATED_POLICIES,
        guarded_transition_subject::transition_added::GENERATED_POLICIES
    );
    Ok(())
}

fn execute_generated(input: &JourneyInput) -> Result<Reading, GuardRefusal> {
    guarded_transition_subject::generated::GeneratedRoad::execute(
        input.capability,
        &input.events,
        input.opening_value,
    )
}

fn execute_refactored(input: &JourneyInput) -> Result<Reading, GuardRefusal> {
    guarded_transition_subject::refactored::GeneratedRoad::execute(
        input.capability,
        &input.events,
        input.opening_value,
    )
}

fn execute_handwritten(input: &JourneyInput) -> Result<Reading, GuardRefusal> {
    guarded_transition_subject::handwritten::HandwrittenRoad::execute(
        input.capability,
        &input.events,
        input.opening_value,
    )
}

fn execute_planted(input: &JourneyInput) -> Result<Reading, GuardRefusal> {
    guarded_transition_subject::planted_wrong::GeneratedRoad::execute(
        input.capability,
        &input.events,
        input.opening_value,
    )
}

fn same_result(
    left: &Result<Reading, GuardRefusal>,
    right: &Result<Reading, GuardRefusal>,
) -> Agreement {
    if left == right {
        Agreement::Agrees
    } else {
        Agreement::Differs
    }
}

fn shared_substrate() -> Result<SharedSubstrate, String> {
    let standing = [
        SubstrateRef::named(OWNER, "subject-public-guarded-contract")
            .map_err(|refusal| format!("contract substrate refused: {refusal:?}"))?,
        SubstrateRef::named(OWNER, "subject-state-event-capability-operation-vocabulary")
            .map_err(|refusal| format!("vocabulary substrate refused: {refusal:?}"))?,
        SubstrateRef::named(
            OWNER,
            "subject-declared-transition-policy-and-effect-meaning",
        )
        .map_err(|refusal| format!("meaning substrate refused: {refusal:?}"))?,
        SubstrateRef::named(OWNER, "subject-source-package-and-stable-rust")
            .map_err(|refusal| format!("package substrate refused: {refusal:?}"))?,
    ];
    assert_eq!(
        SubstrateRoster::declared(&[]),
        Err(SubstrateRefusal::EmptyRoster)
    );
    assert_eq!(
        SubstrateRoster::declared(&[standing[0], standing[0]]),
        Err(SubstrateRefusal::DuplicateSubstrate(standing[0]))
    );
    SubstrateRoster::declared(&standing)
        .map(SharedSubstrate::Standing)
        .map_err(|refusal| format!("shared substrate roster refused: {refusal:?}"))
}

fn named_pair(stem: &'static str) -> Result<RoadPairing, String> {
    bakery::harness::descriptor::NamespacedName::named(OWNER, stem)
        .map(RoadPairing::Declared)
        .map_err(|refusal| format!("parity name refused: {refusal:?}"))
}

fn parity_conclusion(
    stem: &'static str,
    left: fn(&JourneyInput) -> Result<Reading, GuardRefusal>,
    right: fn(&JourneyInput) -> Result<Reading, GuardRefusal>,
) -> Result<TrialConclusion, String> {
    let suite = ParitySuite::over(
        named_pair(stem)?,
        left,
        right,
        same_result,
        shared_substrate()?,
    );
    let input = JourneyInput {
        capability: Capability::Elevated,
        events: vec![Event::Arm, Event::Finish],
        opening_value: 0,
    };
    let reading = parity(&suite, &input);
    Ok(reading.conclusion().clone())
}

fn trace_opening() -> TraceState {
    TraceState {
        events: Vec::new(),
        standing: TraceStanding::Admitted(Standing::Idle),
        value: 0,
    }
}

fn apply_trace<Road: GuardedContract>(state: &TraceState, command: &TraceCommand) -> TraceState {
    if command.ordinal != state.events.len() {
        return TraceState {
            events: state.events.clone(),
            standing: TraceStanding::Refused,
            value: state.value,
        };
    }
    let mut events = state.events.clone();
    events.push(command.event);
    match Road::execute(Capability::Elevated, &events, 0) {
        Ok(reading) => TraceState {
            events,
            standing: TraceStanding::Admitted(reading.standing()),
            value: reading.value(),
        },
        Err(_) => TraceState {
            events,
            standing: TraceStanding::Refused,
            value: state.value,
        },
    }
}

fn apply_generated_trace(state: &TraceState, command: &TraceCommand) -> TraceState {
    apply_trace::<guarded_transition_subject::generated::GeneratedRoad>(state, command)
}

fn apply_handwritten_trace(state: &TraceState, command: &TraceCommand) -> TraceState {
    apply_trace::<guarded_transition_subject::handwritten::HandwrittenRoad>(state, command)
}

const fn is_done(state: &TraceState) -> Holding {
    match state.standing {
        TraceStanding::Admitted(Standing::Done) => Holding::Holds,
        TraceStanding::Admitted(Standing::Idle | Standing::Armed) | TraceStanding::Refused => {
            Holding::Fails
        }
    }
}

const fn is_refused(state: &TraceState) -> Holding {
    match state.standing {
        TraceStanding::Refused => Holding::Holds,
        TraceStanding::Admitted(_) => Holding::Fails,
    }
}

const fn standing_rank(standing: &TraceStanding) -> u8 {
    match standing {
        TraceStanding::Admitted(Standing::Idle) => 0,
        TraceStanding::Admitted(Standing::Armed) => 1,
        TraceStanding::Admitted(Standing::Done) => 2,
        TraceStanding::Refused => 3,
    }
}

fn trace_order(left: &TraceState, right: &TraceState) -> Ordering {
    standing_rank(&left.standing).cmp(&standing_rank(&right.standing))
}

fn temporal_contract(
    apply: fn(&TraceState, &TraceCommand) -> TraceState,
) -> Result<TransitionContract<TraceState, TraceCommand>, String> {
    TransitionContract::declared(
        trace_opening,
        apply,
        vec![
            TemporalClaim::declared(
                FindingCause::named(OWNER, "terminal-eventually"),
                TemporalDemand::Eventually(is_done),
            ),
            TemporalClaim::declared(
                FindingCause::named(OWNER, "lawful-sequence-never-refuses"),
                TemporalDemand::Never(is_refused),
            ),
            TemporalClaim::declared(
                FindingCause::named(OWNER, "standing-never-decreases"),
                TemporalDemand::NeverDecreases(trace_order),
            ),
        ],
    )
    .map_err(|refusal| format!("temporal contract refused: {refusal:?}"))
}

fn policy_count(posture: &PolicyPosture) -> PolicyCount {
    PolicyCount(match posture {
        PolicyPosture::Removed => {
            guarded_transition_subject::policy_removed::GENERATED_POLICIES.len()
        }
        PolicyPosture::Baseline => guarded_transition_subject::generated::GENERATED_POLICIES.len(),
        PolicyPosture::Widened => {
            guarded_transition_subject::policy_widened::GENERATED_POLICIES.len()
        }
    })
}

fn posture_order(left: &PolicyPosture, right: &PolicyPosture) -> Ordering {
    left.cmp(right)
}

fn count_order(left: &PolicyCount, right: &PolicyCount) -> Ordering {
    left.cmp(right)
}

fn response(input: &JourneyInput) -> Result<Reading, GuardRefusal> {
    execute_generated(input)
}

const fn response_reading(answer: &Result<Reading, GuardRefusal>) -> PoisonResponse {
    match answer {
        Ok(_) => PoisonResponse::Answered,
        Err(_) => PoisonResponse::Refused,
    }
}

fn semantic_claims() -> Result<SemanticClaims, String> {
    let generated_handwritten = parity_conclusion(
        "generated-versus-handwritten",
        execute_generated,
        execute_handwritten,
    )?;
    let generated_refactored = parity_conclusion(
        "generated-versus-refactored",
        execute_generated,
        execute_refactored,
    )?;
    let planted_wrong = parity_conclusion(
        "generated-versus-planted-wrong",
        execute_generated,
        execute_planted,
    )?;
    let events = [Event::Arm, Event::Finish];
    let commands = [
        TraceCommand {
            event: Event::Arm,
            ordinal: 0,
        },
        TraceCommand {
            event: Event::Finish,
            ordinal: 1,
        },
    ];
    let generated_temporal =
        holds_over_history(&temporal_contract(apply_generated_trace)?, &commands);
    let handwritten_temporal =
        holds_over_history(&temporal_contract(apply_handwritten_trace)?, &commands);
    let removed_to_baseline = monotonicity(
        policy_count,
        posture_order,
        count_order,
        &PolicyPosture::Removed,
        &PolicyPosture::Baseline,
    );
    let policy_monotonicity = monotonicity(
        policy_count,
        posture_order,
        count_order,
        &PolicyPosture::Baseline,
        &PolicyPosture::Widened,
    );
    let lawful_input = JourneyInput {
        capability: Capability::Elevated,
        events: events.to_vec(),
        opening_value: 0,
    };
    let unauthorized_input = JourneyInput {
        capability: Capability::Basic,
        events: events.to_vec(),
        opening_value: 0,
    };
    let illegal_input = JourneyInput {
        capability: Capability::Elevated,
        events: vec![Event::Finish],
        opening_value: 0,
    };
    let lawful = admits_lawful(response, response_reading, &lawful_input);
    let unauthorized = fail_closed(response, response_reading, &unauthorized_input);
    let illegal = fail_closed(response, response_reading, &illegal_input);
    assert_eq!(generated_handwritten, TrialConclusion::Passed);
    assert_eq!(generated_refactored, TrialConclusion::Passed);
    assert!(matches!(planted_wrong, TrialConclusion::Refused(_)));
    assert_eq!(generated_temporal, TrialConclusion::Passed);
    assert_eq!(handwritten_temporal, TrialConclusion::Passed);
    assert_eq!(removed_to_baseline, TrialConclusion::Passed);
    assert_eq!(policy_monotonicity, TrialConclusion::Passed);
    assert_eq!(lawful, TrialConclusion::Passed);
    assert_eq!(unauthorized, TrialConclusion::Passed);
    assert_eq!(illegal, TrialConclusion::Passed);
    Ok(SemanticClaims {
        generated_handwritten,
        generated_refactored,
        planted_wrong,
        generated_temporal,
        handwritten_temporal,
        policy_monotonicity,
        lawful,
        unauthorized,
        illegal,
    })
}

fn readback_members() -> Vec<ObservedMember> {
    [
        ("VALUE", ObservedValue::Count(5)),
        ("STATE", ObservedValue::Text("Done".to_owned())),
        ("EFFECTS", ObservedValue::Count(2)),
        ("STATES", ObservedValue::Count(3)),
        ("EVENTS", ObservedValue::Count(2)),
        ("TRANSITIONS", ObservedValue::Count(2)),
        ("CAPABILITIES", ObservedValue::Count(2)),
        ("OPERATIONS", ObservedValue::Count(2)),
        ("POLICIES", ObservedValue::Count(3)),
        ("ASSOCIATIONS", ObservedValue::Count(2)),
        ("PROJECTIONS", ObservedValue::Count(6)),
    ]
    .into_iter()
    .map(|(name, value)| ObservedMember {
        name: name.to_owned(),
        value,
    })
    .collect()
}

fn declared_readback(value: u64) -> Vec<DeclaredReadBack<'static>> {
    vec![
        DeclaredReadBack {
            name: "VALUE",
            value: ObservedValue::Count(value),
        },
        DeclaredReadBack {
            name: "STATE",
            value: ObservedValue::Text("Done".to_owned()),
        },
        DeclaredReadBack {
            name: "EFFECTS",
            value: ObservedValue::Count(2),
        },
        DeclaredReadBack {
            name: "STATES",
            value: ObservedValue::Count(3),
        },
        DeclaredReadBack {
            name: "EVENTS",
            value: ObservedValue::Count(2),
        },
        DeclaredReadBack {
            name: "TRANSITIONS",
            value: ObservedValue::Count(2),
        },
        DeclaredReadBack {
            name: "CAPABILITIES",
            value: ObservedValue::Count(2),
        },
        DeclaredReadBack {
            name: "OPERATIONS",
            value: ObservedValue::Count(2),
        },
        DeclaredReadBack {
            name: "POLICIES",
            value: ObservedValue::Count(3),
        },
        DeclaredReadBack {
            name: "ASSOCIATIONS",
            value: ObservedValue::Count(2),
        },
        DeclaredReadBack {
            name: "PROJECTIONS",
            value: ObservedValue::Count(6),
        },
    ]
}

fn execute_readback(executable: &str, stem: &str) -> Result<CompiledObservation, String> {
    let output = bounded_output(Command::new(executable), stem)?;
    if !output.status.success() {
        return Err(format!(
            "{stem} failed with status {:?}: {}",
            output.status.code(),
            String::from_utf8_lossy(&output.stderr)
        ));
    }
    let stdout = String::from_utf8(output.stdout)
        .map_err(|error| format!("{stem} stdout was not UTF-8: {error}"))?;
    if stdout.trim() != READBACK {
        return Err(format!(
            "{stem} readback differed: expected {READBACK:?}, observed {stdout:?}"
        ));
    }
    Ok(CompiledObservation::ReadBack(readback_members()))
}

fn readback_claims() -> Result<ReadbackClaims, String> {
    let generated = execute_readback(
        env!("CARGO_BIN_EXE_generated-readback"),
        "generated-readback",
    )?;
    let refactored = execute_readback(
        env!("CARGO_BIN_EXE_refactored-readback"),
        "refactored-readback",
    )?;
    let handwritten = execute_readback(
        env!("CARGO_BIN_EXE_handwritten-readback"),
        "handwritten-readback",
    )?;
    let declared = declared_readback(5);
    let roster = DeclaredReadBackRoster::declared(&declared)
        .map_err(|refusal| format!("readback roster refused: {refusal:?}"))?;
    let generated_verdict = bakery::harness::oracle::compiled::compared(
        &generated,
        &DeclaredBehavior::ReadsBack(roster),
    );
    let refactored_verdict = bakery::harness::oracle::compiled::compared(
        &refactored,
        &DeclaredBehavior::ReadsBack(roster),
    );
    let handwritten_verdict = bakery::harness::oracle::compiled::compared(
        &handwritten,
        &DeclaredBehavior::ReadsBack(roster),
    );
    assert_eq!(generated_verdict, CompiledVerdict::Conforms);
    assert_eq!(refactored_verdict, CompiledVerdict::Conforms);
    assert_eq!(handwritten_verdict, CompiledVerdict::Conforms);
    let wrong_declared = declared_readback(6);
    let wrong_roster = DeclaredReadBackRoster::declared(&wrong_declared)
        .map_err(|refusal| format!("wrong readback roster refused: {refusal:?}"))?;
    let wrong = bakery::harness::oracle::compiled::compared(
        &generated,
        &DeclaredBehavior::ReadsBack(wrong_roster),
    );
    assert_eq!(
        wrong,
        CompiledVerdict::Deviates(CompiledDisagreement::MemberValue {
            member: "VALUE".to_owned(),
        })
    );
    Ok(ReadbackClaims {
        generated: generated_verdict,
        refactored: refactored_verdict,
        handwritten: handwritten_verdict,
        wrong,
    })
}

fn diagnostic_claims() -> Result<DiagnosticClaims, String> {
    let removed_anchor = anchor(
        "E0425",
        "guarded-transition-challenges/src/bin/macro_removed.rs",
        5,
        20,
        31,
    )?;
    let removed_observation = observed_refusal(
        "guarded-transition-challenges",
        "macro-removed",
        "macro-removed",
        "macro_removed.rs",
        &removed_anchor,
        None,
    )?;
    let removed = bakery::harness::oracle::compiled::compared_compilation(
        &removed_observation,
        &DeclaredCompilation::refuses(removed_anchor.clone()),
    );
    assert_eq!(removed, CompilationVerdict::Conforms);

    let malformed = observed_uncoded_refusal(&UncodedRefusal {
        package: "guarded-transition-subject",
        binary: "malformed-macro",
        feature: "malformed-macro",
        file_name: "malformed_macro.rs",
        message: "the guarded-transition declaration was refused as MalformedPolicy",
        line: 21,
        column_start: 22,
        column_end: 23,
    });
    let malformed = malformed?;
    assert_eq!(malformed, TrialConclusion::Passed);

    let wrong_code_anchor = anchor(
        "E0433",
        "guarded-transition-challenges/src/bin/macro_removed.rs",
        5,
        20,
        31,
    )?;
    let wrong_code = bakery::harness::oracle::compiled::compared_compilation(
        &removed_observation,
        &DeclaredCompilation::refuses(wrong_code_anchor.clone()),
    );
    assert_eq!(
        wrong_code,
        CompilationVerdict::Deviates(CompilationDisagreement::ErrorCode {
            expected: wrong_code_anchor.code().clone(),
            observed: removed_anchor.code().clone(),
        })
    );
    let wrong_span_anchor = anchor(
        "E0425",
        "guarded-transition-challenges/src/bin/macro_removed.rs",
        5,
        21,
        31,
    )?;
    let wrong_span = bakery::harness::oracle::compiled::compared_compilation(
        &removed_observation,
        &DeclaredCompilation::refuses(wrong_span_anchor.clone()),
    );
    assert_eq!(
        wrong_span,
        CompilationVerdict::Deviates(CompilationDisagreement::PrimarySpan {
            expected: wrong_span_anchor.primary().clone(),
            observed: removed_anchor.primary().clone(),
        })
    );
    let foreign_state = observed_foreign_roster("foreign-state", "Standing")?;
    let foreign_event = observed_foreign_roster("foreign-event", "Event")?;
    let foreign_capability = observed_foreign_roster("foreign-capability", "Capability")?;
    let foreign_operation = observed_foreign_roster("foreign-operation", "Operation")?;
    Ok(DiagnosticClaims {
        removed,
        malformed,
        wrong_code,
        wrong_span,
        foreign_state,
        foreign_event,
        foreign_capability,
        foreign_operation,
    })
}

fn observed_foreign_roster(feature: &str, owner: &str) -> Result<TrialConclusion, String> {
    let output = cargo_refusal("guarded-transition-subject", "foreign-roster", feature)?;
    let stdout = String::from_utf8(output.stdout)
        .map_err(|error| format!("foreign-roster Cargo JSON was not UTF-8: {error}"))?;
    let path_marker =
        "\"file_name\":\"guarded-transition-subject\\\\src\\\\bin\\\\foreign_roster.rs\"";
    let diagnostic = stdout
        .lines()
        .find(|entry| {
            entry.contains(path_marker)
                && entry.contains("\"code\":\"E0599\"")
                && entry.contains("Foreign")
                && entry.contains(owner)
        })
        .ok_or_else(|| {
            format!("foreign-roster {feature} did not produce its exact {owner} E0599 refusal")
        })?;
    if !diagnostic.contains("\"is_primary\":true") {
        return Err(format!(
            "foreign-roster {feature} did not carry a primary source span"
        ));
    }
    Ok(TrialConclusion::Passed)
}

struct UncodedRefusal<'a> {
    package: &'a str,
    binary: &'a str,
    feature: &'a str,
    file_name: &'a str,
    message: &'a str,
    line: u64,
    column_start: u64,
    column_end: u64,
}

fn observed_uncoded_refusal(expected: &UncodedRefusal<'_>) -> Result<TrialConclusion, String> {
    let output = cargo_refusal(expected.package, expected.binary, expected.feature)?;
    let stdout = String::from_utf8(output.stdout)
        .map_err(|error| format!("{} Cargo JSON was not UTF-8: {error}", expected.binary))?;
    let package = expected.package;
    let file_name = expected.file_name;
    let path_marker = format!("\"file_name\":\"{package}\\\\src\\\\bin\\\\{file_name}\"");
    let diagnostic = stdout
        .lines()
        .find(|entry| entry.contains(&path_marker) && entry.contains(expected.message))
        .ok_or_else(|| {
            format!(
                "{} exact typed macro diagnostic was absent",
                expected.binary
            )
        })?;
    for marker in [
        "\"code\":null".to_owned(),
        "\"is_primary\":true".to_owned(),
        format!("\"line_start\":{}", expected.line),
        format!("\"line_end\":{}", expected.line),
        format!("\"column_start\":{}", expected.column_start),
        format!("\"column_end\":{}", expected.column_end),
    ] {
        if !diagnostic.contains(&marker) {
            return Err(format!(
                "{} typed macro diagnostic omitted {marker}",
                expected.binary
            ));
        }
    }
    Ok(TrialConclusion::Passed)
}

fn anchor(
    code: &str,
    source: &str,
    line: u64,
    column_start: u64,
    column_end: u64,
) -> Result<DiagnosticAnchor, String> {
    let source = RelativeSourcePath::informed(source)
        .map_err(|refusal| format!("diagnostic source refused: {refusal:?}"))?;
    let start = SourcePosition::informed(line, column_start)
        .map_err(|refusal| format!("diagnostic start refused: {refusal:?}"))?;
    let end = SourcePosition::informed(line, column_end)
        .map_err(|refusal| format!("diagnostic end refused: {refusal:?}"))?;
    let primary = PrimarySourceSpan::informed(source, start, end)
        .map_err(|refusal| format!("diagnostic span refused: {refusal:?}"))?;
    let code = RustcErrorCode::informed(code)
        .map_err(|refusal| format!("diagnostic code refused: {refusal:?}"))?;
    Ok(DiagnosticAnchor::at(code, primary))
}

fn observed_refusal(
    package: &str,
    binary: &str,
    feature: &str,
    file_name: &str,
    expected: &DiagnosticAnchor,
    message: Option<&str>,
) -> Result<ObservedCompilation, String> {
    let output = cargo_refusal(package, binary, feature)?;
    let stdout = String::from_utf8(output.stdout)
        .map_err(|error| format!("{binary} Cargo JSON was not UTF-8: {error}"))?;
    let path_marker = format!("\"file_name\":\"{package}\\\\src\\\\bin\\\\{file_name}\"");
    let diagnostic = stdout
        .lines()
        .find(|line| {
            line.contains(&path_marker)
                && (expected.code().spelling().is_empty()
                    || line.contains(&format!("\"code\":\"{}\"", expected.code().spelling())))
                && message.is_none_or(|needle| line.contains(needle))
        })
        .ok_or_else(|| format!("{binary} exact stable diagnostic was absent"))?;
    for marker in [
        "\"is_primary\":true".to_owned(),
        format!("\"line_start\":{}", expected.primary().start().line()),
        format!("\"line_end\":{}", expected.primary().end().line()),
        format!("\"column_start\":{}", expected.primary().start().column()),
        format!("\"column_end\":{}", expected.primary().end().column()),
    ] {
        if !diagnostic.contains(&marker) {
            return Err(format!("{binary} diagnostic omitted {marker}"));
        }
    }
    Ok(ObservedCompilation::refused(expected.clone()))
}

fn cargo_refusal(package: &str, binary: &str, feature: &str) -> Result<Output, String> {
    let target = workspace()?.join("runtime-targets").join(binary);
    let target_spelling = target.to_string_lossy();
    let mut command = Command::new(env!("CARGO"));
    command.current_dir(workspace()?).args([
        "check",
        "--manifest-path",
        "Cargo.toml",
        "-p",
        package,
        "--bin",
        binary,
        "--features",
        feature,
        "--locked",
        "--offline",
        "--target",
        TARGET,
        "--target-dir",
        target_spelling.as_ref(),
        "--jobs",
        "1",
        "--message-format=json",
    ]);
    let output = bounded_output(command, binary)?;
    if output.status.success() {
        return Err(format!(
            "{binary} compiler challenge unexpectedly succeeded"
        ));
    }
    Ok(output)
}

fn prove_host() -> Result<(), String> {
    let rustc_path = Path::new(env!("CARGO")).with_file_name("rustc.exe");
    let mut rustc = Command::new(rustc_path);
    rustc.arg("-vV");
    let rustc = bounded_output(rustc, "rustc-host")?;
    if !rustc.status.success() {
        return Err("rustc host preflight failed".to_owned());
    }
    let facts = String::from_utf8(rustc.stdout)
        .map_err(|error| format!("rustc host preflight was not UTF-8: {error}"))?;
    if !(facts.contains("release: 1.98.0") && facts.contains(&format!("host: {TARGET}"))) {
        return Err(format!("unexpected rustc host facts: {facts}"));
    }
    let mut cargo = Command::new(env!("CARGO"));
    cargo.args(["--version", "--verbose"]);
    let cargo = bounded_output(cargo, "cargo-host")?;
    if !cargo.status.success() {
        return Err("cargo host preflight failed".to_owned());
    }
    let facts = String::from_utf8(cargo.stdout)
        .map_err(|error| format!("cargo host preflight was not UTF-8: {error}"))?;
    if !facts.starts_with("cargo 1.98.0 ") {
        return Err(format!("unexpected cargo host facts: {facts}"));
    }
    Ok(())
}

fn workspace() -> Result<&'static Path, String> {
    Path::new(env!("CARGO_MANIFEST_DIR"))
        .parent()
        .ok_or_else(|| "challenge package had no workspace parent".to_owned())
}

fn bounded_output(mut command: Command, stem: &str) -> Result<Output, String> {
    let evidence = workspace()?.join("evidence").join("runtime");
    std::fs::create_dir_all(&evidence)
        .map_err(|error| format!("runtime evidence directory was not writable: {error}"))?;
    let stdout_path = evidence.join(format!("{stem}-stdout.bin"));
    let stderr_path = evidence.join(format!("{stem}-stderr.bin"));
    let stdout = std::fs::File::create(&stdout_path)
        .map_err(|error| format!("{stem} stdout evidence was not writable: {error}"))?;
    let stderr = std::fs::File::create(&stderr_path)
        .map_err(|error| format!("{stem} stderr evidence was not writable: {error}"))?;
    let child = command
        .stdout(Stdio::from(stdout))
        .stderr(Stdio::from(stderr))
        .spawn()
        .map_err(|error| format!("{stem} was not runnable: {error}"))?;
    let status = wait_under_ceiling(child, stem)?;
    output_from_files(status, &stdout_path, &stderr_path, stem)
}

fn wait_under_ceiling(mut child: std::process::Child, stem: &str) -> Result<ExitStatus, String> {
    let process_id = child.id();
    let (sender, receiver) = mpsc::sync_channel(1);
    let waiter = std::thread::spawn(move || {
        let result = child.wait();
        let _sent = sender.send(result);
    });
    let status = match receiver.recv_timeout(HOST_CEILING) {
        Ok(result) => result.map_err(|error| format!("{stem} status was not readable: {error}"))?,
        Err(RecvTimeoutError::Timeout) => {
            terminate_process_tree(process_id, stem)?;
            let _after_kill = receiver.recv().map_err(|error| {
                format!("{stem} waiter disconnected after termination: {error}")
            })?;
            return Err(format!(
                "{stem} exceeded the exact {} second host ceiling",
                HOST_CEILING.as_secs()
            ));
        }
        Err(RecvTimeoutError::Disconnected) => {
            return Err(format!(
                "{stem} waiter disconnected before reporting status"
            ));
        }
    };
    if waiter.join().is_err() {
        return Err(format!("{stem} waiter unwound"));
    }
    Ok(status)
}

fn terminate_process_tree(process_id: u32, stem: &str) -> Result<(), String> {
    let system_root = option_env!("SystemRoot")
        .ok_or_else(|| format!("{stem} exceeded its ceiling but SystemRoot was unavailable"))?;
    let taskkill = Path::new(system_root).join("System32").join("taskkill.exe");
    let status = Command::new(taskkill)
        .args(["/PID", &process_id.to_string(), "/T", "/F"])
        .status()
        .map_err(|error| {
            format!("{stem} exceeded its ceiling and taskkill was not runnable: {error}")
        })?;
    if status.success() {
        Ok(())
    } else {
        Err(format!(
            "{stem} exceeded its ceiling and taskkill returned {:?}",
            status.code()
        ))
    }
}

fn output_from_files(
    status: ExitStatus,
    stdout_path: &Path,
    stderr_path: &Path,
    stem: &str,
) -> Result<Output, String> {
    let stdout = std::fs::read(stdout_path)
        .map_err(|error| format!("{stem} stdout evidence was not readable: {error}"))?;
    let stderr = std::fs::read(stderr_path)
        .map_err(|error| format!("{stem} stderr evidence was not readable: {error}"))?;
    Ok(Output {
        status,
        stdout,
        stderr,
    })
}

fn retained_check(_: &Invocation) -> TrialConclusion {
    TrialConclusion::Passed
}

fn admit(cases: &[AdmissionCase]) -> Result<(), String> {
    let check_revision =
        RevisionBinding::derived(DerivedRevision::from_material(include_bytes!("journey.rs")));
    let invocation = invocation();
    let mut bindings = Vec::with_capacity(cases.len());
    let mut records = Vec::with_capacity(cases.len());
    for case in cases {
        let subject_revision =
            RevisionBinding::derived(DerivedRevision::from_material(case.revision_material));
        let binding = binding(case.stem, subject_revision, check_revision)?;
        let record = HostTrialRecord::recorded(
            trial_identity(binding.row()),
            RunAttempt::Executed(case.conclusion.clone()),
            MeasurementReading::Unavailable,
        );
        let report = record_one(&binding, &invocation, record.clone())
            .map_err(|refusal| format!("record_one refused {}: {refusal:?}", case.stem))?;
        assert_report(&report, case, subject_revision, check_revision)?;
        bindings.push(binding);
        records.push(record);
    }
    let table = TrialTable::authored(
        AuthoredTableName::named(OWNER, "guarded-transition-journey")
            .map_err(|refusal| format!("table name refused: {refusal:?}"))?,
        Provenance::Unproduced,
        bindings,
    )
    .map_err(|refusal| format!("trial table refused: {refusal:?}"))?;
    let report = record_all(
        &table.view(),
        &SelectionPlan::of(Selection::All),
        &invocation,
        records,
    )
    .map_err(|refusal| format!("record_all refused: {refusal:?}"))?;
    assert_eq!(report.denominator(), cases.len());
    for (case, accounting) in cases.iter().zip(report.census()) {
        let admitted = accounting
            .disposition()
            .report()
            .ok_or_else(|| format!("{} was not selected", case.stem))?;
        let subject_revision =
            RevisionBinding::derived(DerivedRevision::from_material(case.revision_material));
        assert_report(admitted, case, subject_revision, check_revision)?;
    }
    Ok(())
}

fn binding(
    stem: &'static str,
    subject_revision: RevisionBinding,
    check_revision: RevisionBinding,
) -> Result<TrialBinding, String> {
    let subject = SubjectRoute::named(OWNER, stem)
        .map_err(|refusal| format!("subject route refused: {refusal:?}"))?;
    let check = CheckRef::named(OWNER, "guarded-transition-judge")
        .map_err(|refusal| format!("check reference refused: {refusal:?}"))?;
    let row = Row::declared(
        ClaimRef::named(OWNER, "subject-owned-guarded-transition")
            .map_err(|refusal| format!("claim reference refused: {refusal:?}"))?,
        ExecutionSuite::named(OWNER, "external-guarded-transition-challenges")
            .map_err(|refusal| format!("execution suite refused: {refusal:?}"))?,
        Classification::authored(
            vec![
                Role::named(OWNER, "guarded-transition")
                    .map_err(|refusal| format!("role refused: {refusal:?}"))?,
            ],
            vec![Tag::named(OWNER, stem).map_err(|refusal| format!("tag refused: {refusal:?}"))?],
        )
        .map_err(|refusal| format!("classification refused: {refusal:?}"))?,
        subject,
        check,
        PopulationRef::named(OWNER, "fixed-external-challenges")
            .map_err(|refusal| format!("population refused: {refusal:?}"))?,
        Origin::HandWritten,
    )
    .map_err(|refusal| format!("row refused: {refusal:?}"))?;
    Binding::bound(
        row,
        ExecutableAttachment::attached(
            subject,
            check,
            subject_revision,
            check_revision,
            retained_check,
        ),
        Provenance::Unproduced,
    )
    .map_err(|refusal| format!("binding refused: {refusal:?}"))
}

fn invocation() -> Invocation {
    Invocation::declared(
        InvocationProfile::declared(
            CaseBudget::declared(1),
            ByteBudget::declared(4_096),
            TimeBudget::declared(60_000_000_000),
        ),
        TargetBinding::bound(
            TargetTriple::declared(TARGET),
            ToolchainIdentity::declared(TOOLCHAIN),
        ),
        TrialSite::located(
            module_path!(),
            file!(),
            line!(),
            "guarded-transition-journey",
        ),
        HarnessClock::unavailable(),
    )
}

fn assert_report(
    report: &TrialReport,
    case: &AdmissionCase,
    subject_revision: RevisionBinding,
    check_revision: RevisionBinding,
) -> Result<(), String> {
    let standing = report.standing();
    let key = standing.key();
    assert_eq!(key.target().target().spelling(), TARGET);
    assert_eq!(key.target().toolchain().spelling(), TOOLCHAIN);
    assert_eq!(
        key.subject(),
        SubjectRevisionId::of_binding(subject_revision)
    );
    assert_eq!(key.check(), CheckRevisionId::of_binding(check_revision));
    assert_eq!(standing.replay(), ReplayPosture::ExactDerived);
    let expected = RunAttempt::Executed(case.conclusion.clone());
    if report.attempt() != &expected {
        return Err(format!(
            "{} carried an unexpected report attempt: {:?}",
            case.stem,
            report.attempt()
        ));
    }
    Ok(())
}
