//! Rust-required proc carrier for the bounded guarded-transition subject.

#![forbid(unsafe_code)]
#![deny(warnings)]

extern crate proc_macro;

mod engine;

use bakery::compiler::host::{self, Spans};
use proc_macro::TokenStream;

#[proc_macro]
pub fn guarded_transition(input: TokenStream) -> TokenStream {
    carried(input, engine::RenderStyle::Direct)
}

#[proc_macro]
pub fn guarded_transition_refactored(input: TokenStream) -> TokenStream {
    carried(input, engine::RenderStyle::Refactored)
}

fn carried(input: TokenStream, style: engine::RenderStyle) -> TokenStream {
    let mut spans = Spans::empty();
    match host::capture(input, &mut spans) {
        Ok(capture) => engine::compile(capture, style).map_or_else(
            |diagnostic| host::place(&diagnostic, &spans),
            |accounted| host::emit(accounted.expansion()),
        ),
        Err(refusal) => refusal.placed(&spans),
    }
}
