#![forbid(unsafe_code)]
#![deny(warnings)]

use bakery::compiler::{
    Accounted, Bounded, CanonicalContent, CapturedDelimiter, CapturedInput, CapturedTokenTree,
    CrateBinding, Destination, Diagnostic, Disposition, DispositionSet, Door, Expansion, Family,
    GeneratedDelimiter, GeneratedToken, GeneratedTree, KeyedRoster, KeyedRosterAssignment,
    KeyedRosterAssignmentError, KeyedRosterError, Kind, LineBody, NoQuestions, Observed, Phase,
    Placement, Producer, RefusalClass, Refused, Repair, Request, Role, SpanHandle, SpanTable,
};

const DOOR: Door = Door::declared(
    "guarded-transition-subject",
    "guarded-transition-subject.declaration",
    "guarded_transition_subject_macros::guarded_transition",
    CrateBinding::declared("bakery"),
    Producer {
        namespace: "guarded-transition-subject",
        name: "guarded-transition-subject-macros",
    },
);

const GRAMMAR_FAMILY: Family = Family::declared("guarded-transition-subject/grammar");
const ACCOUNTING_FAMILY: Family = Family::declared("guarded-transition-subject/accounting");
const ROSTER_LIMIT: usize = 8;
const ROW_LIMIT: usize = 16;
const EXPECTED_PROJECTIONS: [&str; 6] = [
    "production",
    "property",
    "mutation",
    "benchmark",
    "compile",
    "receipt",
];

#[derive(Debug, Clone, PartialEq, Eq, PartialOrd, Ord)]
pub(crate) struct NamedSpec {
    pub(crate) name: String,
}

#[derive(Debug, Clone, PartialEq, Eq, PartialOrd, Ord)]
pub(crate) struct TransitionSpec {
    pub(crate) from: String,
    pub(crate) event: String,
    pub(crate) to: String,
}

#[derive(Debug, Clone, PartialEq, Eq, PartialOrd, Ord)]
pub(crate) struct EffectSpec {
    pub(crate) transition: TransitionSpec,
    pub(crate) seat: String,
    pub(crate) added: u64,
}

#[derive(Debug, Clone, PartialEq, Eq, PartialOrd, Ord)]
pub(crate) struct AssociationSpec {
    pub(crate) event: String,
    pub(crate) operation: String,
}

#[derive(Debug, Clone, PartialEq, Eq, PartialOrd, Ord)]
pub(crate) struct PolicySpec {
    pub(crate) capability: String,
    pub(crate) operation: String,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) struct GuardedDeclaration {
    pub(crate) states: KeyedRoster<NamedSpec, String, ROSTER_LIMIT>,
    pub(crate) initial: String,
    pub(crate) terminal: String,
    pub(crate) effects:
        KeyedRosterAssignment<TransitionSpec, TransitionSpec, EffectSpec, String, ROW_LIMIT>,
    pub(crate) capabilities: KeyedRoster<NamedSpec, String, ROSTER_LIMIT>,
    pub(crate) operations: KeyedRoster<NamedSpec, String, ROSTER_LIMIT>,
    pub(crate) associations:
        KeyedRosterAssignment<NamedSpec, String, AssociationSpec, AssociationSpec, ROSTER_LIMIT>,
    pub(crate) policies: KeyedRoster<PolicySpec, PolicySpec, ROW_LIMIT>,
    pub(crate) projections: KeyedRoster<NamedSpec, String, ROSTER_LIMIT>,
}

impl GuardedDeclaration {
    pub(crate) fn transition_family_bytes(&self) -> Vec<u8> {
        let mut bytes = Vec::new();
        encode_named(&self.states, &mut bytes);
        encode_named(self.associations.denominator(), &mut bytes);
        bakery::compiler::encode_bytes(self.initial.as_bytes(), &mut bytes);
        bakery::compiler::encode_bytes(self.terminal.as_bytes(), &mut bytes);
        encode_count(self.effects.denominator().count(), &mut bytes);
        for row in self.effects.denominator().members() {
            bakery::compiler::encode_bytes(row.from.as_bytes(), &mut bytes);
            bakery::compiler::encode_bytes(row.event.as_bytes(), &mut bytes);
            bakery::compiler::encode_bytes(row.to.as_bytes(), &mut bytes);
        }
        encode_count(self.effects.count(), &mut bytes);
        for (_index, _transition_key, _transition, _seat, row) in self.effects.indexed() {
            bakery::compiler::encode_bytes(row.transition.from.as_bytes(), &mut bytes);
            bakery::compiler::encode_bytes(row.transition.event.as_bytes(), &mut bytes);
            bakery::compiler::encode_bytes(row.transition.to.as_bytes(), &mut bytes);
            bakery::compiler::encode_bytes(row.seat.as_bytes(), &mut bytes);
            bytes.extend_from_slice(&row.added.to_be_bytes());
        }
        bytes
    }

    pub(crate) fn policy_family_bytes(&self) -> Vec<u8> {
        let mut bytes = Vec::new();
        encode_named(&self.capabilities, &mut bytes);
        encode_named(&self.operations, &mut bytes);
        encode_count(self.policies.count(), &mut bytes);
        for row in self.policies.members() {
            bakery::compiler::encode_bytes(row.capability.as_bytes(), &mut bytes);
            bakery::compiler::encode_bytes(row.operation.as_bytes(), &mut bytes);
        }
        bytes
    }

    pub(crate) fn association_bytes(&self) -> Vec<u8> {
        let mut bytes = Vec::new();
        let mut rows = self.associations.payloads().members().collect::<Vec<_>>();
        rows.sort_unstable();
        encode_count(rows.len(), &mut bytes);
        for row in rows {
            bakery::compiler::encode_bytes(row.event.as_bytes(), &mut bytes);
            bakery::compiler::encode_bytes(row.operation.as_bytes(), &mut bytes);
        }
        bytes
    }
}

impl CanonicalContent for GuardedDeclaration {
    fn encode_content_into(&self, into: &mut Vec<u8>) {
        bakery::compiler::encode_bytes(&self.transition_family_bytes(), into);
        bakery::compiler::encode_bytes(&self.policy_family_bytes(), into);
        bakery::compiler::encode_bytes(&self.association_bytes(), into);
        encode_named(&self.projections, into);
    }
}

fn encode_named<const LIMIT: usize>(
    rows: &KeyedRoster<NamedSpec, String, LIMIT>,
    into: &mut Vec<u8>,
) {
    encode_count(rows.count(), into);
    for row in rows.members() {
        bakery::compiler::encode_bytes(row.name.as_bytes(), into);
    }
}

fn encode_count(count: usize, into: &mut Vec<u8>) {
    into.extend_from_slice(&u64::try_from(count).unwrap_or(u64::MAX).to_be_bytes());
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) struct GuardedProjection;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum ProjectionRole {
    Production,
    Property,
    Mutation,
    Benchmark,
    Compile,
    Receipt,
    HostileForeign,
}

impl Role for ProjectionRole {
    const ALL: &'static [Self] = &[
        Self::Production,
        Self::Property,
        Self::Mutation,
        Self::Benchmark,
        Self::Compile,
        Self::Receipt,
    ];

    fn name(self) -> &'static str {
        match self {
            Self::Production => "production",
            Self::Property => "property",
            Self::Mutation => "mutation",
            Self::Benchmark => "benchmark",
            Self::Compile => "compile",
            Self::Receipt => "receipt",
            Self::HostileForeign => "hostile-foreign",
        }
    }

    fn destination(self) -> Destination {
        Destination::DeclarationSite
    }
}

const _: ProjectionRole = ProjectionRole::HostileForeign;

impl Kind for GuardedProjection {
    const NAME: &'static str = "guarded-transition-subject.declaration";
    type Content = GuardedDeclaration;
    type Role = ProjectionRole;
    type Question = NoQuestions;
}

bakery::compiler::kinds! {
    set = ProjectionKinds;
    dispositions = ProjectionDispositions;

    Production = "guarded-transition.production", production => (), bakery::compiler::SoleRole, NoQuestions;
    PropertyEvidence = "guarded-transition.property", property => (), bakery::compiler::SoleRole, NoQuestions;
    MutationSurface = "guarded-transition.mutation", mutation => (), bakery::compiler::SoleRole, NoQuestions;
    BenchmarkAxis = "guarded-transition.benchmark", benchmark => (), bakery::compiler::SoleRole, NoQuestions;
    CompileContract = "guarded-transition.compile", compile => (), bakery::compiler::SoleRole, NoQuestions;
    ReceiptReading = "guarded-transition.receipt", receipt => (), bakery::compiler::SoleRole, NoQuestions;
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) enum GrammarIssue {
    MalformedDeclaration,
    RosterAbsent(&'static str),
    RosterUnbounded(&'static str),
    DuplicateMember {
        roster: &'static str,
        member: String,
    },
    ForeignStanding(String),
    InitialEqualsTerminal,
    TransitionsAbsent,
    TransitionsUnbounded,
    ForeignTransition(TransitionSpec),
    DuplicateTransition(TransitionSpec),
    SelfTransition(TransitionSpec),
    BackwardTransition(TransitionSpec),
    EffectsUnbounded,
    MissingEffect(TransitionSpec),
    DuplicateEffect(TransitionSpec),
    ForeignEffect(TransitionSpec),
    DuplicateEffectSeat(String),
    AssociationsUnbounded,
    MissingAssociation(String),
    DuplicateAssociation(String),
    ForeignAssociation(AssociationSpec),
    PoliciesAbsent,
    PoliciesUnbounded,
    ForeignPolicy(PolicySpec),
    DuplicatePolicy(PolicySpec),
    ProjectionMismatch {
        expected: &'static str,
        observed: String,
    },
    MalformedRoster(&'static str),
    MalformedTransition,
    MalformedEffect,
    MalformedAssociation,
    MalformedPolicy,
    UnsupportedEffectOperation(String),
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) struct GrammarRefusal {
    issue: GrammarIssue,
    at: Option<SpanHandle>,
}

impl GrammarRefusal {
    pub(crate) const fn issue(&self) -> &GrammarIssue {
        &self.issue
    }

    pub(crate) const fn token(&self) -> Option<SpanHandle> {
        self.at
    }

    fn at(issue: GrammarIssue, token: &CapturedTokenTree) -> Self {
        Self {
            issue,
            at: Some(token.span()),
        }
    }

    fn whole(issue: GrammarIssue) -> Self {
        Self { issue, at: None }
    }

    fn diagnostic(&self) -> Diagnostic {
        match self.token() {
            Some(token) => Diagnostic::refused(
                self,
                &DOOR,
                &Placement::AtToken {
                    token,
                    spans: &SpanTable::ProducerHeld,
                },
            ),
            None => Diagnostic::refused(self, &DOOR, &Placement::WholeDeclaration),
        }
    }
}

impl Refused for GrammarRefusal {
    const PHASE: Phase = Phase::Capture;
    const FAMILY: Family = GRAMMAR_FAMILY;

    fn class(&self) -> RefusalClass {
        RefusalClass::DeclarationNotRead
    }

    fn first(&self) -> String {
        format!(
            "the guarded-transition declaration was refused as {:?}",
            self.issue()
        )
    }

    fn observed(&self) -> Observed {
        Observed::ContractDisagreement
    }

    fn body(&self) -> LineBody {
        LineBody::SingleCause
    }

    fn related(&self) -> Vec<Vec<u8>> {
        Vec::new()
    }

    fn repairs(&self) -> Bounded<Repair, 8> {
        Bounded::empty()
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct AccountingRefusal;

impl Refused for AccountingRefusal {
    const PHASE: Phase = Phase::Binding;
    const FAMILY: Family = ACCOUNTING_FAMILY;

    fn class(&self) -> RefusalClass {
        RefusalClass::DeclarationNotRead
    }

    fn first(&self) -> String {
        "the generated projection roster could not be completely dispositioned".to_owned()
    }

    fn observed(&self) -> Observed {
        Observed::ContractDisagreement
    }

    fn body(&self) -> LineBody {
        LineBody::SingleCause
    }

    fn related(&self) -> Vec<Vec<u8>> {
        Vec::new()
    }

    fn repairs(&self) -> Bounded<Repair, 8> {
        Bounded::empty()
    }
}

fn group(token: &CapturedTokenTree) -> Result<&[CapturedTokenTree], GrammarRefusal> {
    let Some((CapturedDelimiter::Brace, members)) = token.group() else {
        return Err(GrammarRefusal::at(
            GrammarIssue::MalformedDeclaration,
            token,
        ));
    };
    Ok(members)
}

pub(crate) fn read_declaration(
    capture: &CapturedInput,
) -> Result<GuardedDeclaration, GrammarRefusal> {
    let [
        states_word,
        states_group,
        events_word,
        events_group,
        initial_word,
        initial_group,
        terminal_word,
        terminal_group,
        transitions_word,
        transitions_group,
        effects_word,
        effects_group,
        capabilities_word,
        capabilities_group,
        operations_word,
        operations_group,
        associations_word,
        associations_group,
        policies_word,
        policies_group,
        projections_word,
        projections_group,
    ] = capture.trees()
    else {
        return Err(capture.trees().first().map_or_else(
            || GrammarRefusal::whole(GrammarIssue::MalformedDeclaration),
            |token| GrammarRefusal::at(GrammarIssue::MalformedDeclaration, token),
        ));
    };
    for (token, expected) in [
        (states_word, "states"),
        (events_word, "events"),
        (initial_word, "initial"),
        (terminal_word, "terminal"),
        (transitions_word, "transitions"),
        (effects_word, "effects"),
        (capabilities_word, "capabilities"),
        (operations_word, "operations"),
        (associations_word, "associations"),
        (policies_word, "policies"),
        (projections_word, "projections"),
    ] {
        if token.word() != Some(expected) {
            return Err(GrammarRefusal::at(
                GrammarIssue::MalformedDeclaration,
                token,
            ));
        }
    }
    informed(&RawDeclaration {
        states: group(states_group)?,
        events: group(events_group)?,
        initial: group(initial_group)?,
        terminal: group(terminal_group)?,
        transitions: group(transitions_group)?,
        effects: group(effects_group)?,
        capabilities: group(capabilities_group)?,
        operations: group(operations_group)?,
        associations: group(associations_group)?,
        policies: group(policies_group)?,
        projections: group(projections_group)?,
    })
}

struct RawDeclaration<'a> {
    states: &'a [CapturedTokenTree],
    events: &'a [CapturedTokenTree],
    initial: &'a [CapturedTokenTree],
    terminal: &'a [CapturedTokenTree],
    transitions: &'a [CapturedTokenTree],
    effects: &'a [CapturedTokenTree],
    capabilities: &'a [CapturedTokenTree],
    operations: &'a [CapturedTokenTree],
    associations: &'a [CapturedTokenTree],
    policies: &'a [CapturedTokenTree],
    projections: &'a [CapturedTokenTree],
}

fn informed(raw: &RawDeclaration<'_>) -> Result<GuardedDeclaration, GrammarRefusal> {
    let states = read_roster(raw.states, "states")?;
    let events = read_roster(raw.events, "events")?;
    let initial = read_single(raw.initial, "initial")?;
    let terminal = read_single(raw.terminal, "terminal")?;
    if !contains(&states, &initial) {
        return Err(GrammarRefusal::whole(GrammarIssue::ForeignStanding(
            initial,
        )));
    }
    if !contains(&states, &terminal) {
        return Err(GrammarRefusal::whole(GrammarIssue::ForeignStanding(
            terminal,
        )));
    }
    if initial == terminal {
        return Err(GrammarRefusal::whole(GrammarIssue::InitialEqualsTerminal));
    }
    let (transitions, authored_transitions) = read_transitions(raw.transitions, &states, &events)?;
    let effects = read_effects(
        raw.effects,
        &states,
        &events,
        transitions,
        &authored_transitions,
    )?;
    let capabilities = read_roster(raw.capabilities, "capabilities")?;
    let operations = read_roster(raw.operations, "operations")?;
    let associations = read_associations(raw.associations, events, &operations)?;
    let policies = read_policies(raw.policies, &capabilities, &operations)?;
    let projections = read_projections(raw.projections)?;
    Ok(GuardedDeclaration {
        states,
        initial,
        terminal,
        effects,
        capabilities,
        operations,
        associations,
        policies,
        projections,
    })
}

fn read_single(
    tokens: &[CapturedTokenTree],
    roster: &'static str,
) -> Result<String, GrammarRefusal> {
    let [token] = tokens else {
        return Err(GrammarRefusal::whole(GrammarIssue::MalformedRoster(roster)));
    };
    token
        .word()
        .filter(|name| bakery::compiler::rendered_name(name))
        .map(str::to_owned)
        .ok_or_else(|| GrammarRefusal::at(GrammarIssue::MalformedRoster(roster), token))
}

fn read_roster(
    tokens: &[CapturedTokenTree],
    roster: &'static str,
) -> Result<KeyedRoster<NamedSpec, String, ROSTER_LIMIT>, GrammarRefusal> {
    if tokens.is_empty() {
        return Err(GrammarRefusal::whole(GrammarIssue::RosterAbsent(roster)));
    }
    let (rows, remainder) = tokens.as_chunks::<2>();
    if let Some(token) = remainder.first() {
        return Err(GrammarRefusal::at(
            GrammarIssue::MalformedRoster(roster),
            token,
        ));
    }
    let mut names = Vec::new();
    for [name, comma] in rows {
        let Some(spelling) = name
            .word()
            .filter(|candidate| bakery::compiler::rendered_name(candidate))
        else {
            return Err(GrammarRefusal::at(
                GrammarIssue::MalformedRoster(roster),
                name,
            ));
        };
        if comma.punct() != Some(',') {
            return Err(GrammarRefusal::at(
                GrammarIssue::MalformedRoster(roster),
                comma,
            ));
        }
        // This scan preserves the subject's authored diagnostic priority and token placement; the keyed constructor remains the lawful-value boundary.
        if names.iter().any(|named: &NamedSpec| named.name == spelling) {
            return Err(GrammarRefusal::at(
                GrammarIssue::DuplicateMember {
                    roster,
                    member: spelling.to_owned(),
                },
                name,
            ));
        }
        names.push(NamedSpec {
            name: spelling.to_owned(),
        });
    }
    KeyedRoster::new(names, |member| member.name.clone()).map_err(|error| match error {
        KeyedRosterError::Empty(_empty) => {
            GrammarRefusal::whole(GrammarIssue::RosterAbsent(roster))
        }
        KeyedRosterError::Overflow(_overflow) => {
            GrammarRefusal::whole(GrammarIssue::RosterUnbounded(roster))
        }
        KeyedRosterError::DuplicateKeys(duplicates) => {
            let duplicate = duplicates.first();
            let token = duplicate
                .repeated_positions()
                .first()
                .checked_mul(2)
                .and_then(|index| tokens.get(index));
            token.map_or_else(
                || {
                    GrammarRefusal::whole(GrammarIssue::DuplicateMember {
                        roster,
                        member: duplicate.key().clone(),
                    })
                },
                |name| {
                    GrammarRefusal::at(
                        GrammarIssue::DuplicateMember {
                            roster,
                            member: duplicate.key().clone(),
                        },
                        name,
                    )
                },
            )
        }
    })
}

fn contains<const LIMIT: usize>(
    roster: &KeyedRoster<NamedSpec, String, LIMIT>,
    name: &str,
) -> bool {
    roster.get(name).is_some()
}

fn rank<const LIMIT: usize>(
    roster: &KeyedRoster<NamedSpec, String, LIMIT>,
    name: &str,
) -> Option<usize> {
    roster.index_of(name)
}

fn read_transitions(
    tokens: &[CapturedTokenTree],
    states: &KeyedRoster<NamedSpec, String, ROSTER_LIMIT>,
    events: &KeyedRoster<NamedSpec, String, ROSTER_LIMIT>,
) -> Result<
    (
        KeyedRoster<TransitionSpec, TransitionSpec, ROW_LIMIT>,
        Vec<TransitionSpec>,
    ),
    GrammarRefusal,
> {
    if tokens.is_empty() {
        return Err(GrammarRefusal::whole(GrammarIssue::TransitionsAbsent));
    }
    let (rows, remainder) = tokens.as_chunks::<7>();
    if let Some(token) = remainder.first() {
        return Err(GrammarRefusal::at(GrammarIssue::MalformedTransition, token));
    }
    let mut transitions = Vec::new();
    for [from, plus, event, dash, arrow, to, comma] in rows {
        let (Some(from_name), Some(event_name), Some(to_name)) =
            (from.word(), event.word(), to.word())
        else {
            return Err(GrammarRefusal::at(GrammarIssue::MalformedTransition, from));
        };
        if plus.punct() != Some('+') {
            return Err(GrammarRefusal::at(GrammarIssue::MalformedTransition, plus));
        }
        if dash.joint_punct() != Some('-') {
            return Err(GrammarRefusal::at(GrammarIssue::MalformedTransition, dash));
        }
        if arrow.punct() != Some('>') {
            return Err(GrammarRefusal::at(GrammarIssue::MalformedTransition, arrow));
        }
        if comma.punct() != Some(',') {
            return Err(GrammarRefusal::at(GrammarIssue::MalformedTransition, comma));
        }
        let transition = TransitionSpec {
            from: from_name.to_owned(),
            event: event_name.to_owned(),
            to: to_name.to_owned(),
        };
        let Some(from_rank) = rank(states, from_name) else {
            return Err(GrammarRefusal::at(
                GrammarIssue::ForeignTransition(transition.clone()),
                from,
            ));
        };
        if !contains(events, event_name) {
            return Err(GrammarRefusal::at(
                GrammarIssue::ForeignTransition(transition.clone()),
                event,
            ));
        }
        let Some(to_rank) = rank(states, to_name) else {
            return Err(GrammarRefusal::at(
                GrammarIssue::ForeignTransition(transition),
                to,
            ));
        };
        match from_rank.cmp(&to_rank) {
            core::cmp::Ordering::Equal => {
                return Err(GrammarRefusal::at(
                    GrammarIssue::SelfTransition(transition),
                    arrow,
                ));
            }
            core::cmp::Ordering::Greater => {
                return Err(GrammarRefusal::at(
                    GrammarIssue::BackwardTransition(transition),
                    arrow,
                ));
            }
            core::cmp::Ordering::Less => {}
        }
        // This scan preserves the subject's authored diagnostic priority and token placement; the keyed constructor remains the lawful-value boundary.
        if transitions.iter().any(|row| row == &transition) {
            return Err(GrammarRefusal::at(
                GrammarIssue::DuplicateTransition(transition),
                from,
            ));
        }
        transitions.push(transition);
    }
    let authored = transitions.clone();
    transitions.sort_unstable();
    KeyedRoster::new(transitions, Clone::clone)
        .map(|canonical| (canonical, authored))
        .map_err(|error| match error {
            KeyedRosterError::Empty(_empty) => {
                GrammarRefusal::whole(GrammarIssue::TransitionsAbsent)
            }
            KeyedRosterError::Overflow(_overflow) => {
                GrammarRefusal::whole(GrammarIssue::TransitionsUnbounded)
            }
            KeyedRosterError::DuplicateKeys(duplicates) => GrammarRefusal::whole(
                GrammarIssue::DuplicateTransition(duplicates.first().key().clone()),
            ),
        })
}

fn read_effects(
    tokens: &[CapturedTokenTree],
    states: &KeyedRoster<NamedSpec, String, ROSTER_LIMIT>,
    events: &KeyedRoster<NamedSpec, String, ROSTER_LIMIT>,
    transitions: KeyedRoster<TransitionSpec, TransitionSpec, ROW_LIMIT>,
    authored_transitions: &[TransitionSpec],
) -> Result<
    KeyedRosterAssignment<TransitionSpec, TransitionSpec, EffectSpec, String, ROW_LIMIT>,
    GrammarRefusal,
> {
    let (rows, remainder) = tokens.as_chunks::<11>();
    if let Some(token) = remainder.first() {
        return Err(GrammarRefusal::at(GrammarIssue::MalformedEffect, token));
    }
    let mut effects = Vec::new();
    for row in rows {
        effects.push(read_effect(row, states, events, &transitions, &effects)?);
    }
    for transition in authored_transitions {
        if !effects
            .iter()
            .any(|effect: &EffectSpec| &effect.transition == transition)
        {
            return Err(GrammarRefusal::whole(GrammarIssue::MissingEffect(
                transition.clone(),
            )));
        }
    }
    KeyedRosterAssignment::complete(
        transitions,
        effects,
        |effect| effect.transition.clone(),
        |effect| effect.seat.clone(),
    )
    .map_err(|error| effect_refusal(error, rows, authored_transitions))
}

fn read_effect(
    row: &[CapturedTokenTree; 11],
    states: &KeyedRoster<NamedSpec, String, ROSTER_LIMIT>,
    events: &KeyedRoster<NamedSpec, String, ROSTER_LIMIT>,
    transitions: &KeyedRoster<TransitionSpec, TransitionSpec, ROW_LIMIT>,
    effects: &[EffectSpec],
) -> Result<EffectSpec, GrammarRefusal> {
    let [
        from,
        plus,
        event,
        dash,
        arrow,
        to,
        equals,
        seat,
        operation,
        arguments,
        comma,
    ] = row;
    let (Some(from_name), Some(event_name), Some(to_name), Some(seat_name)) = (
        from.word(),
        event.word(),
        to.word(),
        seat.word()
            .filter(|candidate| bakery::compiler::rendered_name(candidate)),
    ) else {
        return Err(GrammarRefusal::at(GrammarIssue::MalformedEffect, from));
    };
    read_effect_punctuation(plus, dash, arrow, equals, comma)?;
    let Some(operation_name) = operation.word() else {
        return Err(GrammarRefusal::at(GrammarIssue::MalformedEffect, operation));
    };
    if operation_name != "add" {
        return Err(GrammarRefusal::at(
            GrammarIssue::UnsupportedEffectOperation(operation_name.to_owned()),
            operation,
        ));
    }
    let Some((CapturedDelimiter::Parenthesis, [amount])) = arguments.group() else {
        return Err(GrammarRefusal::at(GrammarIssue::MalformedEffect, arguments));
    };
    let Some(added) = amount
        .number()
        .and_then(|number| number.parse::<u64>().ok())
    else {
        return Err(GrammarRefusal::at(GrammarIssue::MalformedEffect, amount));
    };
    let transition = TransitionSpec {
        from: from_name.to_owned(),
        event: event_name.to_owned(),
        to: to_name.to_owned(),
    };
    if !contains(states, from_name) {
        return Err(GrammarRefusal::at(
            GrammarIssue::ForeignEffect(transition.clone()),
            from,
        ));
    }
    if !contains(events, event_name) {
        return Err(GrammarRefusal::at(
            GrammarIssue::ForeignEffect(transition.clone()),
            event,
        ));
    }
    if !contains(states, to_name) {
        return Err(GrammarRefusal::at(
            GrammarIssue::ForeignEffect(transition),
            to,
        ));
    }
    if transitions.get(&transition).is_none() {
        return Err(GrammarRefusal::at(
            GrammarIssue::ForeignEffect(transition),
            from,
        ));
    }
    if effects
        .iter()
        .any(|declared| declared.transition == transition)
    {
        return Err(GrammarRefusal::at(
            GrammarIssue::DuplicateEffect(transition),
            from,
        ));
    }
    if effects.iter().any(|declared| declared.seat == seat_name) {
        return Err(GrammarRefusal::at(
            GrammarIssue::DuplicateEffectSeat(seat_name.to_owned()),
            seat,
        ));
    }
    Ok(EffectSpec {
        transition,
        seat: seat_name.to_owned(),
        added,
    })
}

fn effect_refusal(
    error: KeyedRosterAssignmentError<TransitionSpec, String, ROW_LIMIT>,
    rows: &[[CapturedTokenTree; 11]],
    authored_transitions: &[TransitionSpec],
) -> GrammarRefusal {
    match error {
        KeyedRosterAssignmentError::Empty(_empty) => authored_transitions.first().map_or_else(
            || GrammarRefusal::whole(GrammarIssue::EffectsUnbounded),
            |transition| GrammarRefusal::whole(GrammarIssue::MissingEffect(transition.clone())),
        ),
        KeyedRosterAssignmentError::Overflow(_overflow) => {
            GrammarRefusal::whole(GrammarIssue::EffectsUnbounded)
        }
        KeyedRosterAssignmentError::ForeignReferences(foreign) => {
            let foreign = foreign.first();
            effect_from_at(rows, foreign.offered_position()).map_or_else(
                || GrammarRefusal::whole(GrammarIssue::ForeignEffect(foreign.key().clone())),
                |token| {
                    GrammarRefusal::at(GrammarIssue::ForeignEffect(foreign.key().clone()), token)
                },
            )
        }
        KeyedRosterAssignmentError::DuplicateReferences(duplicates) => {
            let duplicate = duplicates.first();
            effect_from_at(rows, *duplicate.repeated_positions().first()).map_or_else(
                || GrammarRefusal::whole(GrammarIssue::DuplicateEffect(duplicate.key().clone())),
                |token| {
                    GrammarRefusal::at(
                        GrammarIssue::DuplicateEffect(duplicate.key().clone()),
                        token,
                    )
                },
            )
        }
        KeyedRosterAssignmentError::ReusedPayloadSeats(duplicates) => {
            let duplicate = duplicates.first();
            effect_seat_at(rows, *duplicate.repeated_positions().first()).map_or_else(
                || {
                    GrammarRefusal::whole(GrammarIssue::DuplicateEffectSeat(
                        duplicate.key().clone(),
                    ))
                },
                |token| {
                    GrammarRefusal::at(
                        GrammarIssue::DuplicateEffectSeat(duplicate.key().clone()),
                        token,
                    )
                },
            )
        }
        KeyedRosterAssignmentError::MissingMembers(missing) => {
            let first_missing = authored_transitions
                .iter()
                .find(|transition| missing.iter().any(|member| member.key() == *transition));
            first_missing.map_or_else(
                || {
                    GrammarRefusal::whole(GrammarIssue::MissingEffect(
                        missing.first().key().clone(),
                    ))
                },
                |transition| GrammarRefusal::whole(GrammarIssue::MissingEffect(transition.clone())),
            )
        }
    }
}

fn effect_from_at(rows: &[[CapturedTokenTree; 11]], position: usize) -> Option<&CapturedTokenTree> {
    rows.get(position).map(
        |[
            from,
            _plus,
            _event,
            _dash,
            _arrow,
            _to,
            _equals,
            _seat,
            _operation,
            _arguments,
            _comma,
        ]| from,
    )
}

fn effect_seat_at(rows: &[[CapturedTokenTree; 11]], position: usize) -> Option<&CapturedTokenTree> {
    rows.get(position).map(
        |[
            _from,
            _plus,
            _event,
            _dash,
            _arrow,
            _to,
            _equals,
            seat,
            _operation,
            _arguments,
            _comma,
        ]| seat,
    )
}

fn read_effect_punctuation(
    plus: &CapturedTokenTree,
    dash: &CapturedTokenTree,
    arrow: &CapturedTokenTree,
    equals: &CapturedTokenTree,
    comma: &CapturedTokenTree,
) -> Result<(), GrammarRefusal> {
    if plus.punct() != Some('+') {
        return Err(GrammarRefusal::at(GrammarIssue::MalformedEffect, plus));
    }
    if dash.joint_punct() != Some('-') {
        return Err(GrammarRefusal::at(GrammarIssue::MalformedEffect, dash));
    }
    if arrow.punct() != Some('>') {
        return Err(GrammarRefusal::at(GrammarIssue::MalformedEffect, arrow));
    }
    if equals.punct() != Some('=') {
        return Err(GrammarRefusal::at(GrammarIssue::MalformedEffect, equals));
    }
    if comma.punct() != Some(',') {
        return Err(GrammarRefusal::at(GrammarIssue::MalformedEffect, comma));
    }
    Ok(())
}

fn read_associations(
    tokens: &[CapturedTokenTree],
    events: KeyedRoster<NamedSpec, String, ROSTER_LIMIT>,
    operations: &KeyedRoster<NamedSpec, String, ROSTER_LIMIT>,
) -> Result<
    KeyedRosterAssignment<NamedSpec, String, AssociationSpec, AssociationSpec, ROSTER_LIMIT>,
    GrammarRefusal,
> {
    let (rows, remainder) = tokens.as_chunks::<5>();
    if let Some(token) = remainder.first() {
        return Err(GrammarRefusal::at(
            GrammarIssue::MalformedAssociation,
            token,
        ));
    }
    let mut associations = Vec::new();
    for [event, equals, arrow, operation, comma] in rows {
        let (Some(event_name), Some(operation_name)) = (event.word(), operation.word()) else {
            return Err(GrammarRefusal::at(
                GrammarIssue::MalformedAssociation,
                event,
            ));
        };
        if equals.joint_punct() != Some('=') {
            return Err(GrammarRefusal::at(
                GrammarIssue::MalformedAssociation,
                equals,
            ));
        }
        if arrow.punct() != Some('>') {
            return Err(GrammarRefusal::at(
                GrammarIssue::MalformedAssociation,
                arrow,
            ));
        }
        if comma.punct() != Some(',') {
            return Err(GrammarRefusal::at(
                GrammarIssue::MalformedAssociation,
                comma,
            ));
        }
        let association = AssociationSpec {
            event: event_name.to_owned(),
            operation: operation_name.to_owned(),
        };
        if !contains(&events, event_name) {
            return Err(GrammarRefusal::at(
                GrammarIssue::ForeignAssociation(association.clone()),
                event,
            ));
        }
        if !contains(operations, operation_name) {
            return Err(GrammarRefusal::at(
                GrammarIssue::ForeignAssociation(association),
                operation,
            ));
        }
        // This scan preserves the subject's authored diagnostic priority and token placement; the keyed assignment remains the lawful-value boundary.
        if associations
            .iter()
            .any(|row: &AssociationSpec| row.event == event_name)
        {
            return Err(GrammarRefusal::at(
                GrammarIssue::DuplicateAssociation(event_name.to_owned()),
                event,
            ));
        }
        associations.push(association);
    }
    let authored_events = events.keys().cloned().collect::<Vec<_>>();
    for event in events.members() {
        if !associations.iter().any(|row| row.event == event.name) {
            return Err(GrammarRefusal::whole(GrammarIssue::MissingAssociation(
                event.name.clone(),
            )));
        }
    }
    KeyedRosterAssignment::complete(
        events,
        associations,
        |association| association.event.clone(),
        Clone::clone,
    )
    .map_err(|error| association_refusal(error, rows, &authored_events))
}

fn association_refusal(
    error: KeyedRosterAssignmentError<String, AssociationSpec, ROSTER_LIMIT>,
    rows: &[[CapturedTokenTree; 5]],
    authored_events: &[String],
) -> GrammarRefusal {
    match error {
        KeyedRosterAssignmentError::Empty(_empty) => authored_events.first().map_or_else(
            || GrammarRefusal::whole(GrammarIssue::AssociationsUnbounded),
            |event| GrammarRefusal::whole(GrammarIssue::MissingAssociation(event.clone())),
        ),
        KeyedRosterAssignmentError::Overflow(_overflow) => {
            GrammarRefusal::whole(GrammarIssue::AssociationsUnbounded)
        }
        KeyedRosterAssignmentError::ForeignReferences(foreign) => {
            let foreign = foreign.first();
            association_at(rows, foreign.offered_position()).map_or_else(
                || {
                    GrammarRefusal::whole(GrammarIssue::ForeignAssociation(AssociationSpec {
                        event: foreign.key().clone(),
                        operation: String::new(),
                    }))
                },
                |(event, operation)| {
                    GrammarRefusal::at(
                        GrammarIssue::ForeignAssociation(AssociationSpec {
                            event: foreign.key().clone(),
                            operation: operation.word().unwrap_or_default().to_owned(),
                        }),
                        event,
                    )
                },
            )
        }
        KeyedRosterAssignmentError::DuplicateReferences(duplicates) => {
            let duplicate = duplicates.first();
            association_at(rows, *duplicate.repeated_positions().first()).map_or_else(
                || {
                    GrammarRefusal::whole(GrammarIssue::DuplicateAssociation(
                        duplicate.key().clone(),
                    ))
                },
                |(event, _operation)| {
                    GrammarRefusal::at(
                        GrammarIssue::DuplicateAssociation(duplicate.key().clone()),
                        event,
                    )
                },
            )
        }
        KeyedRosterAssignmentError::ReusedPayloadSeats(duplicates) => {
            let duplicate = duplicates.first();
            GrammarRefusal::whole(GrammarIssue::DuplicateAssociation(
                duplicate.key().event.clone(),
            ))
        }
        KeyedRosterAssignmentError::MissingMembers(missing) => {
            let first_missing = authored_events
                .iter()
                .find(|event| missing.iter().any(|member| member.key() == *event));
            first_missing.map_or_else(
                || {
                    GrammarRefusal::whole(GrammarIssue::MissingAssociation(
                        missing.first().key().clone(),
                    ))
                },
                |event| GrammarRefusal::whole(GrammarIssue::MissingAssociation(event.clone())),
            )
        }
    }
}

fn association_at(
    rows: &[[CapturedTokenTree; 5]],
    position: usize,
) -> Option<(&CapturedTokenTree, &CapturedTokenTree)> {
    rows.get(position)
        .map(|[event, _equals, _arrow, operation, _comma]| (event, operation))
}

fn read_policies(
    tokens: &[CapturedTokenTree],
    capabilities: &KeyedRoster<NamedSpec, String, ROSTER_LIMIT>,
    operations: &KeyedRoster<NamedSpec, String, ROSTER_LIMIT>,
) -> Result<KeyedRoster<PolicySpec, PolicySpec, ROW_LIMIT>, GrammarRefusal> {
    if tokens.is_empty() {
        return Err(GrammarRefusal::whole(GrammarIssue::PoliciesAbsent));
    }
    let (rows, remainder) = tokens.as_chunks::<5>();
    if let Some(token) = remainder.first() {
        return Err(GrammarRefusal::at(GrammarIssue::MalformedPolicy, token));
    }
    let mut policies = Vec::new();
    for [capability, equals, arrow, operation, comma] in rows {
        let (Some(capability_name), Some(operation_name)) = (capability.word(), operation.word())
        else {
            return Err(GrammarRefusal::at(
                GrammarIssue::MalformedPolicy,
                capability,
            ));
        };
        if equals.joint_punct() != Some('=') {
            return Err(GrammarRefusal::at(GrammarIssue::MalformedPolicy, equals));
        }
        if arrow.punct() != Some('>') {
            return Err(GrammarRefusal::at(GrammarIssue::MalformedPolicy, arrow));
        }
        if comma.punct() != Some(',') {
            return Err(GrammarRefusal::at(GrammarIssue::MalformedPolicy, comma));
        }
        let policy = PolicySpec {
            capability: capability_name.to_owned(),
            operation: operation_name.to_owned(),
        };
        if !contains(capabilities, capability_name) {
            return Err(GrammarRefusal::at(
                GrammarIssue::ForeignPolicy(policy.clone()),
                capability,
            ));
        }
        if !contains(operations, operation_name) {
            return Err(GrammarRefusal::at(
                GrammarIssue::ForeignPolicy(policy),
                operation,
            ));
        }
        // This scan preserves the subject's authored diagnostic priority and token placement; the keyed constructor remains the lawful-value boundary.
        if policies.iter().any(|declared| declared == &policy) {
            return Err(GrammarRefusal::at(
                GrammarIssue::DuplicatePolicy(policy),
                capability,
            ));
        }
        policies.push(policy);
    }
    policies.sort_unstable();
    KeyedRoster::new(policies, Clone::clone).map_err(|error| match error {
        KeyedRosterError::Empty(_empty) => GrammarRefusal::whole(GrammarIssue::PoliciesAbsent),
        KeyedRosterError::Overflow(_overflow) => {
            GrammarRefusal::whole(GrammarIssue::PoliciesUnbounded)
        }
        KeyedRosterError::DuplicateKeys(duplicates) => GrammarRefusal::whole(
            GrammarIssue::DuplicatePolicy(duplicates.first().key().clone()),
        ),
    })
}

fn read_projections(
    tokens: &[CapturedTokenTree],
) -> Result<KeyedRoster<NamedSpec, String, ROSTER_LIMIT>, GrammarRefusal> {
    let observed = read_roster(tokens, "projections")?;
    if observed.count() != EXPECTED_PROJECTIONS.len() {
        return Err(GrammarRefusal::whole(GrammarIssue::ProjectionMismatch {
            expected: "six declared projection seats",
            observed: format!("{} seats", observed.count()),
        }));
    }
    for (row, expected) in observed.members().zip(EXPECTED_PROJECTIONS) {
        if row.name != expected {
            return Err(GrammarRefusal::whole(GrammarIssue::ProjectionMismatch {
                expected,
                observed: row.name.clone(),
            }));
        }
    }
    Ok(observed)
}

fn path(segments: &[&str]) -> Vec<GeneratedToken> {
    let mut tokens = vec![GeneratedToken::word(
        segments.first().copied().unwrap_or("crate"),
    )];
    for segment in segments.iter().skip(1) {
        tokens.push(GeneratedToken::joint(':'));
        tokens.push(GeneratedToken::alone(':'));
        tokens.push(GeneratedToken::word(segment));
    }
    tokens
}

fn subject_variant(kind: &str, variant: &str) -> Vec<GeneratedToken> {
    path(&["crate", kind, variant])
}

fn comma_parts(parts: impl IntoIterator<Item = Vec<GeneratedToken>>) -> Vec<GeneratedToken> {
    bakery::compiler::comma_many(parts.into_iter().collect())
}

fn slice_type(
    element: Vec<GeneratedToken>,
) -> Result<Vec<GeneratedToken>, bakery::compiler::Overflow> {
    Ok(vec![
        GeneratedToken::alone('&'),
        bakery::compiler::group(GeneratedDelimiter::Bracket, element)?,
    ])
}

fn slice_value(
    values: impl IntoIterator<Item = Vec<GeneratedToken>>,
) -> Result<Vec<GeneratedToken>, bakery::compiler::Overflow> {
    Ok(vec![
        GeneratedToken::alone('&'),
        bakery::compiler::group(GeneratedDelimiter::Bracket, comma_parts(values))?,
    ])
}

fn public_const(
    name: &str,
    kind: Vec<GeneratedToken>,
    value: Vec<GeneratedToken>,
) -> Vec<GeneratedToken> {
    let mut tokens = vec![GeneratedToken::word("pub")];
    tokens.extend(bakery::compiler::constant(name, kind, value));
    tokens
}

fn call_subject(
    kind: &str,
    method: &str,
    arguments: Vec<Vec<GeneratedToken>>,
) -> Result<Vec<GeneratedToken>, bakery::compiler::Overflow> {
    bakery::compiler::call(path(&["crate", kind, method]), comma_parts(arguments))
}

fn named_roster(
    constant: &str,
    kind: &str,
    rows: &KeyedRoster<NamedSpec, String, ROSTER_LIMIT>,
) -> Result<Vec<GeneratedToken>, bakery::compiler::Overflow> {
    let values = bakery::compiler::keyed_roster_slice(rows, |_index, _key, row| {
        Ok(subject_variant(kind, &row.name))
    })?;
    Ok(public_const(
        constant,
        slice_type(path(&["crate", kind]))?,
        values,
    ))
}

fn transition_roster(
    declaration: &GuardedDeclaration,
) -> Result<Vec<GeneratedToken>, bakery::compiler::Overflow> {
    let values = bakery::compiler::keyed_assignment_slice(
        &declaration.effects,
        |_index, _transition_key, _transition, _seat, effect| {
            call_subject(
                "TransitionRow",
                "declared",
                vec![
                    subject_variant("Standing", &effect.transition.from),
                    subject_variant("Event", &effect.transition.event),
                    subject_variant("Standing", &effect.transition.to),
                    subject_variant("EffectSeat", &effect.seat),
                    vec![GeneratedToken::number(effect.added)],
                ],
            )
        },
    )?;
    Ok(public_const(
        "GENERATED_TRANSITIONS",
        slice_type(path(&["crate", "TransitionRow"]))?,
        values,
    ))
}

fn effect_roster(
    declaration: &GuardedDeclaration,
) -> Result<Vec<GeneratedToken>, bakery::compiler::Overflow> {
    let values = bakery::compiler::keyed_assignment_slice(
        &declaration.effects,
        |_index, _transition_key, _transition, _seat, effect| {
            Ok(subject_variant("EffectSeat", &effect.seat))
        },
    )?;
    Ok(public_const(
        "GENERATED_EFFECTS",
        slice_type(path(&["crate", "EffectSeat"]))?,
        values,
    ))
}

fn association_roster(
    declaration: &GuardedDeclaration,
) -> Result<Vec<GeneratedToken>, bakery::compiler::Overflow> {
    let mut rows = declaration
        .associations
        .payloads()
        .members()
        .collect::<Vec<_>>();
    rows.sort_unstable();
    let mut values = Vec::new();
    for row in rows {
        values.push(call_subject(
            "Association",
            "declared",
            vec![
                subject_variant("Event", &row.event),
                subject_variant("Operation", &row.operation),
            ],
        )?);
    }
    Ok(public_const(
        "GENERATED_ASSOCIATIONS",
        slice_type(path(&["crate", "Association"]))?,
        slice_value(values)?,
    ))
}

fn policy_roster(
    declaration: &GuardedDeclaration,
) -> Result<Vec<GeneratedToken>, bakery::compiler::Overflow> {
    let values =
        bakery::compiler::keyed_roster_slice(&declaration.policies, |_index, _key, row| {
            call_subject(
                "PolicyEdge",
                "declared",
                vec![
                    subject_variant("Capability", &row.capability),
                    subject_variant("Operation", &row.operation),
                ],
            )
        })?;
    Ok(public_const(
        "GENERATED_POLICIES",
        slice_type(path(&["crate", "PolicyEdge"]))?,
        values,
    ))
}

fn scalar_const(name: &str, kind: &str, variant: &str) -> Vec<GeneratedToken> {
    public_const(name, path(&["crate", kind]), subject_variant(kind, variant))
}

fn generated_road_impl() -> Result<Vec<GeneratedToken>, bakery::compiler::Overflow> {
    let parameters = comma_parts([
        {
            let mut tokens = vec![
                GeneratedToken::word("capability"),
                GeneratedToken::alone(':'),
            ];
            tokens.extend(path(&["crate", "Capability"]));
            tokens
        },
        {
            let mut tokens = vec![
                GeneratedToken::word("events"),
                GeneratedToken::alone(':'),
                GeneratedToken::alone('&'),
            ];
            tokens.push(bakery::compiler::group(
                GeneratedDelimiter::Bracket,
                path(&["crate", "Event"]),
            )?);
            tokens
        },
        vec![
            GeneratedToken::word("opening_value"),
            GeneratedToken::alone(':'),
            GeneratedToken::word("u64"),
        ],
    ]);
    let result = bakery::compiler::result_type(
        path(&["crate", "Reading"]),
        path(&["crate", "GuardRefusal"]),
    );
    let body = bakery::compiler::call(
        path(&["crate", "execute_declared"]),
        comma_parts([
            vec![GeneratedToken::word("capability")],
            vec![GeneratedToken::word("events")],
            vec![GeneratedToken::word("opening_value")],
            vec![GeneratedToken::word("GENERATED_TRANSITIONS")],
            vec![GeneratedToken::word("GENERATED_POLICIES")],
            vec![GeneratedToken::word("GENERATED_ASSOCIATIONS")],
            vec![GeneratedToken::word("GENERATED_INITIAL")],
        ]),
    )?;
    let execute = bakery::compiler::function("execute", parameters, result, body)?;
    let mut trait_path = path(&["crate", "GuardedContract"]);
    trait_path.push(GeneratedToken::word("for"));
    trait_path.push(GeneratedToken::word("GeneratedRoad"));
    trait_path.push(bakery::compiler::group(GeneratedDelimiter::Brace, execute)?);
    let mut tokens = vec![
        GeneratedToken::word("pub"),
        GeneratedToken::word("struct"),
        GeneratedToken::word("GeneratedRoad"),
        GeneratedToken::alone(';'),
        GeneratedToken::word("impl"),
    ];
    tokens.extend(trait_path);
    Ok(tokens)
}

pub(crate) fn production_material_tokens(
    declaration: &GuardedDeclaration,
) -> Result<Vec<GeneratedToken>, bakery::compiler::Overflow> {
    let mut tokens = Vec::new();
    tokens.extend(named_roster(
        "GENERATED_STATES",
        "Standing",
        &declaration.states,
    )?);
    tokens.extend(named_roster(
        "GENERATED_EVENTS",
        "Event",
        declaration.associations.denominator(),
    )?);
    tokens.extend(scalar_const(
        "GENERATED_INITIAL",
        "Standing",
        &declaration.initial,
    ));
    tokens.extend(scalar_const(
        "GENERATED_TERMINAL",
        "Standing",
        &declaration.terminal,
    ));
    tokens.extend(transition_roster(declaration)?);
    tokens.extend(effect_roster(declaration)?);
    tokens.extend(named_roster(
        "GENERATED_CAPABILITIES",
        "Capability",
        &declaration.capabilities,
    )?);
    tokens.extend(named_roster(
        "GENERATED_OPERATIONS",
        "Operation",
        &declaration.operations,
    )?);
    tokens.extend(association_roster(declaration)?);
    tokens.extend(policy_roster(declaration)?);
    Ok(tokens)
}

fn production_tree(
    declaration: &GuardedDeclaration,
) -> Result<GeneratedTree, bakery::compiler::RenderError> {
    let mut tokens = production_material_tokens(declaration)?;
    tokens.extend(generated_road_impl()?);
    GeneratedTree::assembled(tokens).map_err(bakery::compiler::RenderError::from)
}

fn text_projection(
    constant: &str,
    values: &[&str],
) -> Result<GeneratedTree, bakery::compiler::RenderError> {
    let type_tokens = slice_type(vec![
        GeneratedToken::alone('&'),
        GeneratedToken::word("str"),
    ])?;
    let value_tokens = slice_value(values.iter().map(|value| vec![GeneratedToken::text(value)]))?;
    GeneratedTree::assembled(public_const(constant, type_tokens, value_tokens))
        .map_err(bakery::compiler::RenderError::from)
}

fn receipt_projection_direct() -> Result<GeneratedTree, bakery::compiler::RenderError> {
    text_projection(
        "GENERATED_RECEIPT_FIELDS",
        &[
            "plan",
            "closure",
            "explanation",
            "expansion",
            "dispositions",
        ],
    )
}

fn receipt_projection_refactored() -> Result<GeneratedTree, bakery::compiler::RenderError> {
    let fields = [
        "plan",
        "closure",
        "explanation",
        "expansion",
        "dispositions",
    ];
    let material = fields
        .into_iter()
        .map(|field| vec![GeneratedToken::text(field)])
        .collect::<Vec<_>>();
    let kind = vec![
        GeneratedToken::alone('&'),
        bakery::compiler::group(
            GeneratedDelimiter::Bracket,
            vec![GeneratedToken::alone('&'), GeneratedToken::word("str")],
        )?,
    ];
    let value = vec![
        GeneratedToken::alone('&'),
        bakery::compiler::group(GeneratedDelimiter::Bracket, comma_parts(material))?,
    ];
    let mut tokens = vec![GeneratedToken::word("pub")];
    tokens.extend(bakery::compiler::constant(
        "GENERATED_RECEIPT_FIELDS",
        kind,
        value,
    ));
    GeneratedTree::assembled(tokens).map_err(bakery::compiler::RenderError::from)
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum RenderStyle {
    Direct,
    Refactored,
}

pub(crate) fn terminal_with(
    capture: CapturedInput,
    declaration: &GuardedDeclaration,
    style: RenderStyle,
) -> Result<Expansion<GuardedProjection>, Diagnostic> {
    Request::<GuardedProjection>::over(capture, declaration.clone(), &DOOR).render(
        |_plan, output| {
            output.unit(ProjectionRole::Production, production_tree(declaration)?)?;
            output.unit(
                ProjectionRole::Property,
                text_projection(
                    "GENERATED_PROPERTY_SEATS",
                    &[
                        "terminal-reached",
                        "value-bounded",
                        "default-deny",
                        "temporal-order",
                    ],
                )?,
            )?;
            output.unit(
                ProjectionRole::Mutation,
                text_projection(
                    "GENERATED_MUTATION_SEATS",
                    &[
                        "transition-omitted",
                        "effect-disconnected",
                        "policy-widened",
                        "policy-removed",
                        "projection-reordered",
                    ],
                )?,
            )?;
            output.unit(
                ProjectionRole::Benchmark,
                text_projection(
                    "GENERATED_BENCHMARK_AXES",
                    &["states", "transitions", "policies"],
                )?,
            )?;
            output.unit(
                ProjectionRole::Compile,
                text_projection(
                    "GENERATED_COMPILE_SEATS",
                    &[
                        "GeneratedRoad",
                        "GuardedContract",
                        "macro-removed",
                        "malformed-macro",
                        "foreign-rosters",
                    ],
                )?,
            )?;
            let receipt = match style {
                RenderStyle::Direct => receipt_projection_direct()?,
                RenderStyle::Refactored => receipt_projection_refactored()?,
            };
            output.unit(ProjectionRole::Receipt, receipt)
        },
    )
}

pub(crate) fn accounted(
    expansion: Expansion<GuardedProjection>,
) -> Result<Accounted<GuardedProjection, ProjectionKinds>, Diagnostic> {
    let unit = |role| {
        expansion
            .plan()
            .membership()
            .under(role)
            .map(|member| member.output.semantic_key)
            .ok_or_else(|| {
                Diagnostic::refused(&AccountingRefusal, &DOOR, &Placement::WholeDeclaration)
            })
    };
    let dispositions = DispositionSet::<ProjectionKinds>::complete(ProjectionDispositions {
        production: Disposition::Generated {
            unit: unit(ProjectionRole::Production)?,
        },
        property: Disposition::Generated {
            unit: unit(ProjectionRole::Property)?,
        },
        mutation: Disposition::Generated {
            unit: unit(ProjectionRole::Mutation)?,
        },
        benchmark: Disposition::Generated {
            unit: unit(ProjectionRole::Benchmark)?,
        },
        compile: Disposition::Generated {
            unit: unit(ProjectionRole::Compile)?,
        },
        receipt: Disposition::Generated {
            unit: unit(ProjectionRole::Receipt)?,
        },
    })
    .map_err(|_refusal| {
        Diagnostic::refused(&AccountingRefusal, &DOOR, &Placement::WholeDeclaration)
    })?;
    Ok(Accounted::seated(expansion, dispositions))
}

pub(crate) fn compile(
    capture: CapturedInput,
    style: RenderStyle,
) -> Result<Accounted<GuardedProjection, ProjectionKinds>, Diagnostic> {
    let declaration = read_declaration(&capture).map_err(|refusal| refusal.diagnostic())?;
    let expansion = terminal_with(capture, &declaration, style)?;
    accounted(expansion)
}
