//! External claims over the private subject compiler engine.

#![forbid(unsafe_code)]
#![deny(warnings)]

#[path = "../src/engine.rs"]
mod engine;

use bakery::compiler::request::committed;
use bakery::compiler::{
    CanonicalContent, Closure, ClosureIssue, CoordinateRole, Disposition, DispositionRecord,
    DispositionSet, DispositionSetError, GeneratedDelimiter, GeneratedToken, GeneratedTree,
    KindSet, OwnerFact, PlannedMember, RenderedProjection, RenderedUnit, Role, TextCapture,
};
use engine::{
    GrammarIssue, GuardedDeclaration, ProjectionKinds, ProjectionRole, RenderStyle, TransitionSpec,
};

const BASELINE: &str = r"
states { Idle, Armed, Done, }
events { Arm, Finish, }
initial { Idle }
terminal { Done }
transitions { Idle + Arm -> Armed, Armed + Finish -> Done, }
effects {
    Idle + Arm -> Armed = Arm add(2),
    Armed + Finish -> Done = Finish add(3),
}
capabilities { Basic, Elevated, }
operations { ArmOp, FinishOp, }
associations { Arm => ArmOp, Finish => FinishOp, }
policies { Basic => ArmOp, Elevated => ArmOp, Elevated => FinishOp, }
projections { production, property, mutation, benchmark, compile, receipt, }
";

const PERMUTED: &str = r"
states { Idle, Armed, Done, }
events { Arm, Finish, }
initial { Idle }
terminal { Done }
transitions { Armed + Finish -> Done, Idle + Arm -> Armed, }
effects {
    Armed + Finish -> Done = Finish add(3),
    Idle + Arm -> Armed = Arm add(2),
}
capabilities { Basic, Elevated, }
operations { ArmOp, FinishOp, }
associations { Finish => FinishOp, Arm => ArmOp, }
policies { Elevated => FinishOp, Elevated => ArmOp, Basic => ArmOp, }
projections { production, property, mutation, benchmark, compile, receipt, }
";

const TRANSITION_ADDED: &str = r"
states { Idle, Armed, Done, }
events { Arm, Finish, }
initial { Idle }
terminal { Done }
transitions { Idle + Arm -> Armed, Armed + Finish -> Done, Idle + Finish -> Done, }
effects {
    Idle + Arm -> Armed = Arm add(2),
    Armed + Finish -> Done = Finish add(3),
    Idle + Finish -> Done = Fast add(5),
}
capabilities { Basic, Elevated, }
operations { ArmOp, FinishOp, }
associations { Arm => ArmOp, Finish => FinishOp, }
policies { Basic => ArmOp, Elevated => ArmOp, Elevated => FinishOp, }
projections { production, property, mutation, benchmark, compile, receipt, }
";

const POLICY_WIDENED: &str = r"
states { Idle, Armed, Done, }
events { Arm, Finish, }
initial { Idle }
terminal { Done }
transitions { Idle + Arm -> Armed, Armed + Finish -> Done, }
effects {
    Idle + Arm -> Armed = Arm add(2),
    Armed + Finish -> Done = Finish add(3),
}
capabilities { Basic, Elevated, }
operations { ArmOp, FinishOp, }
associations { Arm => ArmOp, Finish => FinishOp, }
policies { Basic => ArmOp, Basic => FinishOp, Elevated => ArmOp, Elevated => FinishOp, }
projections { production, property, mutation, benchmark, compile, receipt, }
";

const POLICY_REMOVED: &str = r"
states { Idle, Armed, Done, }
events { Arm, Finish, }
initial { Idle }
terminal { Done }
transitions { Idle + Arm -> Armed, Armed + Finish -> Done, }
effects {
    Idle + Arm -> Armed = Arm add(2),
    Armed + Finish -> Done = Finish add(3),
}
capabilities { Basic, Elevated, }
operations { ArmOp, FinishOp, }
associations { Arm => ArmOp, Finish => FinishOp, }
policies { Basic => ArmOp, Elevated => ArmOp, }
projections { production, property, mutation, benchmark, compile, receipt, }
";

const HOSTILE_FACT: OwnerFact = OwnerFact {
    home: "guarded-transition-challenges",
    name: "hostile-projection-control",
};

fn read(source: &str) -> Result<bakery::compiler::CapturedInput, String> {
    TextCapture::read(source)
        .map(|capture| capture.input().clone())
        .map_err(|error| error.to_string())
}

fn parsed(source: &str) -> Result<GuardedDeclaration, String> {
    engine::read_declaration(&read(source)?)
        .map_err(|refusal| format!("declaration refused as {:?}", refusal.issue()))
}

fn refusal(source: &str) -> Result<engine::GrammarRefusal, String> {
    match engine::read_declaration(&read(source)?) {
        Ok(_) => Err("hostile declaration unexpectedly informed".to_owned()),
        Err(refusal) => Ok(refusal),
    }
}

fn expansion(
    source: &str,
    style: RenderStyle,
) -> Result<bakery::compiler::Expansion<engine::GuardedProjection>, String> {
    let capture = read(source)?;
    let declaration = engine::read_declaration(&capture)
        .map_err(|refusal| format!("declaration refused as {:?}", refusal.issue()))?;
    engine::terminal_with(capture, &declaration, style)
        .map_err(|diagnostic| diagnostic.summary().to_owned())
}

fn rendered_bytes(
    expansion: &bakery::compiler::Expansion<engine::GuardedProjection>,
    role: ProjectionRole,
) -> Result<Vec<u8>, String> {
    expansion
        .closure()
        .rendered()
        .under(role)
        .map(|unit| unit.bytes().clone())
        .ok_or_else(|| format!("rendered role absent: {role:?}"))
}

fn content_bytes(declaration: &GuardedDeclaration) -> Vec<u8> {
    declaration.canonical_content_bytes()
}

fn raw_path(segments: &[&str]) -> Vec<GeneratedToken> {
    let mut tokens = vec![GeneratedToken::word(
        segments.first().copied().unwrap_or("crate"),
    )];
    for segment in segments.iter().skip(1) {
        tokens.push(GeneratedToken::joint(':'));
        tokens.push(GeneratedToken::alone(':'));
        tokens.push(GeneratedToken::word(segment));
    }
    tokens
}

fn raw_subject_variant(kind: &str, variant: &str) -> Vec<GeneratedToken> {
    raw_path(&["crate", kind, variant])
}

fn raw_comma_parts(parts: impl IntoIterator<Item = Vec<GeneratedToken>>) -> Vec<GeneratedToken> {
    bakery::compiler::comma_many(parts.into_iter().collect())
}

fn raw_slice_type(element: Vec<GeneratedToken>) -> Result<Vec<GeneratedToken>, String> {
    Ok(vec![
        GeneratedToken::alone('&'),
        bakery::compiler::group(GeneratedDelimiter::Bracket, element)
            .map_err(|error| error.to_string())?,
    ])
}

fn raw_slice_value(
    values: impl IntoIterator<Item = Vec<GeneratedToken>>,
) -> Result<Vec<GeneratedToken>, String> {
    Ok(vec![
        GeneratedToken::alone('&'),
        bakery::compiler::group(GeneratedDelimiter::Bracket, raw_comma_parts(values))
            .map_err(|error| error.to_string())?,
    ])
}

fn raw_public_const(
    name: &str,
    kind: Vec<GeneratedToken>,
    value: Vec<GeneratedToken>,
) -> Vec<GeneratedToken> {
    let mut tokens = vec![GeneratedToken::word("pub")];
    tokens.extend(bakery::compiler::constant(name, kind, value));
    tokens
}

fn raw_call_subject(
    kind: &str,
    method: &str,
    arguments: Vec<Vec<GeneratedToken>>,
) -> Result<Vec<GeneratedToken>, String> {
    bakery::compiler::call(
        raw_path(&["crate", kind, method]),
        raw_comma_parts(arguments),
    )
    .map_err(|error| error.to_string())
}

fn raw_named_roster(
    constant: &str,
    kind: &str,
    rows: impl Iterator<Item = String>,
) -> Result<Vec<GeneratedToken>, String> {
    let values = rows
        .map(|name| raw_subject_variant(kind, &name))
        .collect::<Vec<_>>();
    Ok(raw_public_const(
        constant,
        raw_slice_type(raw_path(&["crate", kind]))?,
        raw_slice_value(values)?,
    ))
}

fn raw_transition_effect_tokens(
    declaration: &GuardedDeclaration,
) -> Result<Vec<GeneratedToken>, String> {
    let transitions = declaration
        .effects
        .indexed()
        .map(|(_index, _transition_key, _transition, _seat, effect)| {
            raw_call_subject(
                "TransitionRow",
                "declared",
                vec![
                    raw_subject_variant("Standing", &effect.transition.from),
                    raw_subject_variant("Event", &effect.transition.event),
                    raw_subject_variant("Standing", &effect.transition.to),
                    raw_subject_variant("EffectSeat", &effect.seat),
                    vec![GeneratedToken::number(effect.added)],
                ],
            )
        })
        .collect::<Result<Vec<_>, _>>()?;
    let mut tokens = raw_public_const(
        "GENERATED_TRANSITIONS",
        raw_slice_type(raw_path(&["crate", "TransitionRow"]))?,
        raw_slice_value(transitions)?,
    );
    let effects = declaration
        .effects
        .indexed()
        .map(|(_index, _transition_key, _transition, _seat, effect)| {
            raw_subject_variant("EffectSeat", &effect.seat)
        })
        .collect::<Vec<_>>();
    tokens.extend(raw_public_const(
        "GENERATED_EFFECTS",
        raw_slice_type(raw_path(&["crate", "EffectSeat"]))?,
        raw_slice_value(effects)?,
    ));
    Ok(tokens)
}

fn raw_production_material_tokens(
    declaration: &GuardedDeclaration,
) -> Result<Vec<GeneratedToken>, String> {
    let mut tokens = Vec::new();
    tokens.extend(raw_named_roster(
        "GENERATED_STATES",
        "Standing",
        declaration.states.keys().cloned(),
    )?);
    tokens.extend(raw_named_roster(
        "GENERATED_EVENTS",
        "Event",
        declaration.associations.denominator().keys().cloned(),
    )?);
    tokens.extend(raw_public_const(
        "GENERATED_INITIAL",
        raw_path(&["crate", "Standing"]),
        raw_subject_variant("Standing", &declaration.initial),
    ));
    tokens.extend(raw_public_const(
        "GENERATED_TERMINAL",
        raw_path(&["crate", "Standing"]),
        raw_subject_variant("Standing", &declaration.terminal),
    ));
    tokens.extend(raw_transition_effect_tokens(declaration)?);
    tokens.extend(raw_named_roster(
        "GENERATED_CAPABILITIES",
        "Capability",
        declaration.capabilities.keys().cloned(),
    )?);
    tokens.extend(raw_named_roster(
        "GENERATED_OPERATIONS",
        "Operation",
        declaration.operations.keys().cloned(),
    )?);
    let mut associations = declaration
        .associations
        .payloads()
        .members()
        .collect::<Vec<_>>();
    associations.sort_unstable();
    let associations = associations
        .into_iter()
        .map(|row| {
            raw_call_subject(
                "Association",
                "declared",
                vec![
                    raw_subject_variant("Event", &row.event),
                    raw_subject_variant("Operation", &row.operation),
                ],
            )
        })
        .collect::<Result<Vec<_>, _>>()?;
    tokens.extend(raw_public_const(
        "GENERATED_ASSOCIATIONS",
        raw_slice_type(raw_path(&["crate", "Association"]))?,
        raw_slice_value(associations)?,
    ));
    let policies = declaration
        .policies
        .members()
        .map(|row| {
            raw_call_subject(
                "PolicyEdge",
                "declared",
                vec![
                    raw_subject_variant("Capability", &row.capability),
                    raw_subject_variant("Operation", &row.operation),
                ],
            )
        })
        .collect::<Result<Vec<_>, _>>()?;
    tokens.extend(raw_public_const(
        "GENERATED_POLICIES",
        raw_slice_type(raw_path(&["crate", "PolicyEdge"]))?,
        raw_slice_value(policies)?,
    ));
    Ok(tokens)
}

fn generated_bytes(tokens: Vec<GeneratedToken>) -> Result<Vec<u8>, String> {
    GeneratedTree::assembled(tokens)
        .map(|tree| tree.canonical_bytes())
        .map_err(|error| error.to_string())
}

fn derived_receipt(
    accounted: &bakery::compiler::Accounted<engine::GuardedProjection, ProjectionKinds>,
) -> String {
    let expansion = accounted.expansion();
    format!(
        "schema=guarded-transition-expansion-v1\nplan={:?}\nclosure={:?}\nexplanation={:?}\nexpansion={:?}\nprojection-count={}\n",
        expansion.plan().identity(),
        expansion.closure().identity(),
        expansion.explain().identity(),
        expansion.identity(),
        accounted.dispositions().len(),
    )
}

fn require_refusal<Value, Refusal>(
    result: Result<Value, Refusal>,
    accepted: &str,
) -> Result<Refusal, String> {
    match result {
        Ok(_) => Err(accepted.to_owned()),
        Err(refusal) => Ok(refusal),
    }
}

fn assert_refusal_at(source: &str, issue: &GrammarIssue, needle: &str) -> Result<(), String> {
    let captured = TextCapture::read(source).map_err(|error| error.to_string())?;
    let refusal = require_refusal(
        engine::read_declaration(captured.input()),
        "a hostile declaration unexpectedly informed",
    )?;
    assert_eq!(refusal.issue(), issue);
    let token = refusal
        .token()
        .ok_or_else(|| "the hostile refusal had no token".to_owned())?;
    let coordinate = captured
        .spans()
        .coordinate_of(token)
        .map_err(|error| error.to_string())?;
    let expected = source
        .find(needle)
        .ok_or_else(|| format!("the hostile token {needle:?} was absent"))?;
    assert_eq!(coordinate.role, CoordinateRole::Byte);
    assert_eq!(
        coordinate.position,
        u64::try_from(expected).unwrap_or(u64::MAX)
    );
    Ok(())
}

#[test]
fn baseline_keeps_both_families_and_every_projection_explicit() -> Result<(), String> {
    let declaration = parsed(BASELINE)?;
    assert_eq!(
        declaration
            .states
            .members()
            .map(|row| row.name.as_str())
            .collect::<Vec<_>>(),
        ["Idle", "Armed", "Done"]
    );
    assert_eq!(
        declaration
            .associations
            .denominator()
            .members()
            .map(|row| row.name.as_str())
            .collect::<Vec<_>>(),
        ["Arm", "Finish"]
    );
    assert_eq!(declaration.initial, "Idle");
    assert_eq!(declaration.terminal, "Done");
    assert_eq!(declaration.effects.denominator().count(), 2);
    assert_eq!(declaration.effects.count(), 2);
    assert_eq!(declaration.capabilities.count(), 2);
    assert_eq!(declaration.operations.count(), 2);
    assert_eq!(declaration.associations.count(), 2);
    assert_eq!(declaration.policies.count(), 3);
    assert_eq!(
        declaration
            .projections
            .members()
            .map(|row| row.name.as_str())
            .collect::<Vec<_>>(),
        [
            "production",
            "property",
            "mutation",
            "benchmark",
            "compile",
            "receipt"
        ]
    );
    let accounted = engine::compile(read(BASELINE)?, RenderStyle::Direct)
        .map_err(|diagnostic| diagnostic.summary().to_owned())?;
    assert_eq!(accounted.dispositions().len(), 6);
    for role in ProjectionRole::ALL {
        assert!(
            accounted
                .expansion()
                .closure()
                .rendered()
                .under(*role)
                .is_some()
        );
    }
    Ok(())
}

#[test]
fn every_closed_roster_refuses_empty_duplicate_and_overbound_material() -> Result<(), String> {
    for (source, issue) in [
        (
            BASELINE.replace("states { Idle, Armed, Done, }", "states { }"),
            GrammarIssue::RosterAbsent("states"),
        ),
        (
            BASELINE.replace(
                "states { Idle, Armed, Done, }",
                "states { Idle, Idle, Done, }",
            ),
            GrammarIssue::DuplicateMember {
                roster: "states",
                member: "Idle".to_owned(),
            },
        ),
        (
            BASELINE.replace(
                "states { Idle, Armed, Done, }",
                "states { A, B, C, D, E, F, G, H, I, }",
            ),
            GrammarIssue::RosterUnbounded("states"),
        ),
        (
            BASELINE.replace("events { Arm, Finish, }", "events { }"),
            GrammarIssue::RosterAbsent("events"),
        ),
        (
            BASELINE.replace("events { Arm, Finish, }", "events { Arm, Arm, }"),
            GrammarIssue::DuplicateMember {
                roster: "events",
                member: "Arm".to_owned(),
            },
        ),
        (
            BASELINE.replace(
                "events { Arm, Finish, }",
                "events { A, B, C, D, E, F, G, H, I, }",
            ),
            GrammarIssue::RosterUnbounded("events"),
        ),
        (
            BASELINE.replace("capabilities { Basic, Elevated, }", "capabilities { }"),
            GrammarIssue::RosterAbsent("capabilities"),
        ),
        (
            BASELINE.replace(
                "capabilities { Basic, Elevated, }",
                "capabilities { Basic, Basic, }",
            ),
            GrammarIssue::DuplicateMember {
                roster: "capabilities",
                member: "Basic".to_owned(),
            },
        ),
        (
            BASELINE.replace(
                "capabilities { Basic, Elevated, }",
                "capabilities { A, B, C, D, E, F, G, H, I, }",
            ),
            GrammarIssue::RosterUnbounded("capabilities"),
        ),
        (
            BASELINE.replace("operations { ArmOp, FinishOp, }", "operations { }"),
            GrammarIssue::RosterAbsent("operations"),
        ),
        (
            BASELINE.replace(
                "operations { ArmOp, FinishOp, }",
                "operations { ArmOp, ArmOp, }",
            ),
            GrammarIssue::DuplicateMember {
                roster: "operations",
                member: "ArmOp".to_owned(),
            },
        ),
        (
            BASELINE.replace(
                "operations { ArmOp, FinishOp, }",
                "operations { A, B, C, D, E, F, G, H, I, }",
            ),
            GrammarIssue::RosterUnbounded("operations"),
        ),
    ] {
        assert_eq!(refusal(&source)?.issue(), &issue);
    }
    Ok(())
}

#[test]
fn transition_and_effect_structure_refuses_every_hostile_shape() -> Result<(), String> {
    let foreign = BASELINE.replace("Idle + Arm -> Armed,", "Idle + Foreign -> Armed,");
    assert!(matches!(
        refusal(&foreign)?.issue(),
        GrammarIssue::ForeignTransition(_)
    ));
    let duplicate = BASELINE.replace(
        "Idle + Arm -> Armed, Armed + Finish -> Done,",
        "Idle + Arm -> Armed, Idle + Arm -> Armed,",
    );
    assert!(matches!(
        refusal(&duplicate)?.issue(),
        GrammarIssue::DuplicateTransition(_)
    ));
    let self_edge = BASELINE.replace("Idle + Arm -> Armed,", "Idle + Arm -> Idle,");
    assert!(matches!(
        refusal(&self_edge)?.issue(),
        GrammarIssue::SelfTransition(_)
    ));
    let backward = BASELINE.replace("Idle + Arm -> Armed,", "Armed + Arm -> Idle,");
    assert!(matches!(
        refusal(&backward)?.issue(),
        GrammarIssue::BackwardTransition(_)
    ));
    let missing = BASELINE.replace("    Armed + Finish -> Done = Finish add(3),\n", "");
    assert_eq!(
        refusal(&missing)?.issue(),
        &GrammarIssue::MissingEffect(TransitionSpec {
            from: "Armed".to_owned(),
            event: "Finish".to_owned(),
            to: "Done".to_owned(),
        })
    );
    let doubled = BASELINE.replace(
        "    Armed + Finish -> Done = Finish add(3),",
        "    Armed + Finish -> Done = Finish add(3),\n    Armed + Finish -> Done = SecondFinish add(3),",
    );
    assert!(matches!(
        refusal(&doubled)?.issue(),
        GrammarIssue::DuplicateEffect(_)
    ));
    let foreign_effect = BASELINE.replace(
        "Armed + Finish -> Done = Finish add(3),",
        "Idle + Finish -> Done = Finish add(3),",
    );
    assert!(matches!(
        refusal(&foreign_effect)?.issue(),
        GrammarIssue::ForeignEffect(_)
    ));
    let reused_seat = BASELINE.replace("Finish add(3)", "Arm add(3)");
    assert_eq!(
        refusal(&reused_seat)?.issue(),
        &GrammarIssue::DuplicateEffectSeat("Arm".to_owned())
    );
    Ok(())
}

#[test]
fn transition_refusals_name_every_foreign_member_and_punctuation_seat() -> Result<(), String> {
    for (source, issue, needle) in [
        (
            BASELINE.replacen("Idle + Arm -> Armed,", "Foreign + Arm -> Armed,", 1),
            GrammarIssue::ForeignTransition(TransitionSpec {
                from: "Foreign".to_owned(),
                event: "Arm".to_owned(),
                to: "Armed".to_owned(),
            }),
            "Foreign",
        ),
        (
            BASELINE.replacen("Idle + Arm -> Armed,", "Idle + Foreign -> Armed,", 1),
            GrammarIssue::ForeignTransition(TransitionSpec {
                from: "Idle".to_owned(),
                event: "Foreign".to_owned(),
                to: "Armed".to_owned(),
            }),
            "Foreign",
        ),
        (
            BASELINE.replacen("Idle + Arm -> Armed,", "Idle + Arm -> Foreign,", 1),
            GrammarIssue::ForeignTransition(TransitionSpec {
                from: "Idle".to_owned(),
                event: "Arm".to_owned(),
                to: "Foreign".to_owned(),
            }),
            "Foreign",
        ),
        (
            BASELINE.replacen("Idle + Arm -> Armed,", "Idle ? Arm -> Armed,", 1),
            GrammarIssue::MalformedTransition,
            "? Arm -> Armed",
        ),
        (
            BASELINE.replacen("Idle + Arm -> Armed,", "Idle + Arm => Armed,", 1),
            GrammarIssue::MalformedTransition,
            "=> Armed",
        ),
        (
            BASELINE.replacen("Idle + Arm -> Armed,", "Idle + Arm -- Armed,", 1),
            GrammarIssue::MalformedTransition,
            "- Armed",
        ),
        (
            BASELINE.replacen("Idle + Arm -> Armed,", "Idle + Arm -> Armed;", 1),
            GrammarIssue::MalformedTransition,
            ";",
        ),
    ] {
        assert_refusal_at(&source, &issue, needle)?;
    }
    Ok(())
}

#[test]
fn effect_refusals_name_every_foreign_member_and_punctuation_seat() -> Result<(), String> {
    let row = "    Idle + Arm -> Armed = Arm add(2),";
    for (source, issue, needle) in [
        (
            BASELINE.replacen(row, "    Foreign + Arm -> Armed = Arm add(2),", 1),
            GrammarIssue::ForeignEffect(TransitionSpec {
                from: "Foreign".to_owned(),
                event: "Arm".to_owned(),
                to: "Armed".to_owned(),
            }),
            "Foreign",
        ),
        (
            BASELINE.replacen(row, "    Idle + Foreign -> Armed = Arm add(2),", 1),
            GrammarIssue::ForeignEffect(TransitionSpec {
                from: "Idle".to_owned(),
                event: "Foreign".to_owned(),
                to: "Armed".to_owned(),
            }),
            "Foreign",
        ),
        (
            BASELINE.replacen(row, "    Idle + Arm -> Foreign = Arm add(2),", 1),
            GrammarIssue::ForeignEffect(TransitionSpec {
                from: "Idle".to_owned(),
                event: "Arm".to_owned(),
                to: "Foreign".to_owned(),
            }),
            "Foreign",
        ),
        (
            BASELINE.replacen(row, "    Idle ? Arm -> Armed = Arm add(2),", 1),
            GrammarIssue::MalformedEffect,
            "? Arm -> Armed =",
        ),
        (
            BASELINE.replacen(row, "    Idle + Arm => Armed = Arm add(2),", 1),
            GrammarIssue::MalformedEffect,
            "=> Armed =",
        ),
        (
            BASELINE.replacen(row, "    Idle + Arm -- Armed = Arm add(2),", 1),
            GrammarIssue::MalformedEffect,
            "- Armed =",
        ),
        (
            BASELINE.replacen(row, "    Idle + Arm -> Armed : Arm add(2),", 1),
            GrammarIssue::MalformedEffect,
            ": Arm add(2)",
        ),
        (
            BASELINE.replacen(row, "    Idle + Arm -> Armed = Arm add(2);", 1),
            GrammarIssue::MalformedEffect,
            ";",
        ),
    ] {
        assert_refusal_at(&source, &issue, needle)?;
    }
    Ok(())
}

#[test]
fn association_and_policy_punctuation_refusals_name_every_seat() -> Result<(), String> {
    for (source, issue, needle) in [
        (
            BASELINE.replacen("Arm => ArmOp,", "Arm -> ArmOp,", 1),
            GrammarIssue::MalformedAssociation,
            "-> ArmOp",
        ),
        (
            BASELINE.replacen("Arm => ArmOp,", "Arm == ArmOp,", 1),
            GrammarIssue::MalformedAssociation,
            "= ArmOp",
        ),
        (
            BASELINE.replacen("Arm => ArmOp,", "Arm => ArmOp;", 1),
            GrammarIssue::MalformedAssociation,
            ";",
        ),
        (
            BASELINE.replacen("Basic => ArmOp", "Basic -> ArmOp", 1),
            GrammarIssue::MalformedPolicy,
            "-> ArmOp",
        ),
        (
            BASELINE.replacen("Basic => ArmOp", "Basic == ArmOp", 1),
            GrammarIssue::MalformedPolicy,
            "= ArmOp",
        ),
        (
            BASELINE.replacen("Basic => ArmOp,", "Basic => ArmOp;", 1),
            GrammarIssue::MalformedPolicy,
            ";",
        ),
    ] {
        assert_refusal_at(&source, &issue, needle)?;
    }
    Ok(())
}

#[test]
fn association_and_policy_structure_refuses_disconnected_widened_and_foreign_rows()
-> Result<(), String> {
    let missing_association = BASELINE.replace(", Finish => FinishOp", "");
    assert_eq!(
        refusal(&missing_association)?.issue(),
        &GrammarIssue::MissingAssociation("Finish".to_owned())
    );
    let doubled_association = BASELINE.replace(
        "Arm => ArmOp, Finish => FinishOp,",
        "Arm => ArmOp, Arm => FinishOp,",
    );
    assert_eq!(
        refusal(&doubled_association)?.issue(),
        &GrammarIssue::DuplicateAssociation("Arm".to_owned())
    );
    let foreign_association = BASELINE.replace("Finish => FinishOp", "Finish => ForeignOp");
    assert!(matches!(
        refusal(&foreign_association)?.issue(),
        GrammarIssue::ForeignAssociation(_)
    ));
    let no_policy = BASELINE.replace(
        "policies { Basic => ArmOp, Elevated => ArmOp, Elevated => FinishOp, }",
        "policies { }",
    );
    assert_eq!(refusal(&no_policy)?.issue(), &GrammarIssue::PoliciesAbsent);
    let duplicated_policy = BASELINE.replace(
        "Basic => ArmOp, Elevated => ArmOp, Elevated => FinishOp,",
        "Basic => ArmOp, Basic => ArmOp, Elevated => FinishOp,",
    );
    assert!(matches!(
        refusal(&duplicated_policy)?.issue(),
        GrammarIssue::DuplicatePolicy(_)
    ));
    let foreign_policy = BASELINE.replace("Basic => ArmOp", "Foreign => ArmOp");
    assert!(matches!(
        refusal(&foreign_policy)?.issue(),
        GrammarIssue::ForeignPolicy(_)
    ));
    Ok(())
}

#[test]
fn projection_declaration_refuses_missing_doubled_foreign_and_reordered_seats() -> Result<(), String>
{
    let missing = BASELINE.replace(
        "projections { production, property, mutation, benchmark, compile, receipt, }",
        "projections { production, property, mutation, benchmark, compile, }",
    );
    assert!(matches!(
        refusal(&missing)?.issue(),
        GrammarIssue::ProjectionMismatch { .. }
    ));
    let doubled = BASELINE.replace(
        "projections { production, property, mutation, benchmark, compile, receipt, }",
        "projections { production, property, mutation, benchmark, compile, compile, }",
    );
    assert!(matches!(
        refusal(&doubled)?.issue(),
        GrammarIssue::DuplicateMember {
            roster: "projections",
            ..
        }
    ));
    let foreign = BASELINE.replace(
        "projections { production, property, mutation, benchmark, compile, receipt, }",
        "projections { production, property, mutation, benchmark, compile, foreign, }",
    );
    assert_eq!(
        refusal(&foreign)?.issue(),
        &GrammarIssue::ProjectionMismatch {
            expected: "receipt",
            observed: "foreign".to_owned(),
        }
    );
    let reordered = BASELINE.replace(
        "projections { production, property, mutation, benchmark, compile, receipt, }",
        "projections { property, production, mutation, benchmark, compile, receipt, }",
    );
    assert_eq!(
        refusal(&reordered)?.issue(),
        &GrammarIssue::ProjectionMismatch {
            expected: "production",
            observed: "property".to_owned(),
        }
    );
    Ok(())
}

#[test]
fn transition_changes_move_only_the_transition_family_and_its_product_material()
-> Result<(), String> {
    let baseline_declaration = parsed(BASELINE)?;
    let changed_declaration = parsed(TRANSITION_ADDED)?;
    assert_ne!(
        baseline_declaration.transition_family_bytes(),
        changed_declaration.transition_family_bytes()
    );
    assert_eq!(
        baseline_declaration.policy_family_bytes(),
        changed_declaration.policy_family_bytes()
    );
    assert_eq!(
        baseline_declaration.association_bytes(),
        changed_declaration.association_bytes()
    );
    assert_eq!(baseline_declaration.effects.denominator().count(), 2);
    assert_eq!(changed_declaration.effects.denominator().count(), 3);

    let baseline = expansion(BASELINE, RenderStyle::Direct)?;
    let changed = expansion(TRANSITION_ADDED, RenderStyle::Direct)?;
    assert_ne!(
        rendered_bytes(&baseline, ProjectionRole::Production)?,
        rendered_bytes(&changed, ProjectionRole::Production)?
    );
    for role in [
        ProjectionRole::Property,
        ProjectionRole::Mutation,
        ProjectionRole::Benchmark,
        ProjectionRole::Compile,
        ProjectionRole::Receipt,
    ] {
        assert_eq!(
            rendered_bytes(&baseline, role)?,
            rendered_bytes(&changed, role)?
        );
    }
    assert_ne!(baseline.plan().identity(), changed.plan().identity());
    assert_ne!(baseline.identity(), changed.identity());
    Ok(())
}

#[test]
fn policy_changes_move_only_the_policy_family_and_its_product_material() -> Result<(), String> {
    let baseline_declaration = parsed(BASELINE)?;
    let widened_declaration = parsed(POLICY_WIDENED)?;
    let removed_declaration = parsed(POLICY_REMOVED)?;
    for changed in [&widened_declaration, &removed_declaration] {
        assert_eq!(
            baseline_declaration.transition_family_bytes(),
            changed.transition_family_bytes()
        );
        assert_eq!(
            baseline_declaration.association_bytes(),
            changed.association_bytes()
        );
        assert_ne!(
            baseline_declaration.policy_family_bytes(),
            changed.policy_family_bytes()
        );
    }
    assert_eq!(baseline_declaration.policies.count(), 3);
    assert_eq!(widened_declaration.policies.count(), 4);
    assert_eq!(removed_declaration.policies.count(), 2);

    let baseline = expansion(BASELINE, RenderStyle::Direct)?;
    for source in [POLICY_WIDENED, POLICY_REMOVED] {
        let changed = expansion(source, RenderStyle::Direct)?;
        assert_ne!(
            rendered_bytes(&baseline, ProjectionRole::Production)?,
            rendered_bytes(&changed, ProjectionRole::Production)?
        );
        for role in [
            ProjectionRole::Property,
            ProjectionRole::Mutation,
            ProjectionRole::Benchmark,
            ProjectionRole::Compile,
            ProjectionRole::Receipt,
        ] {
            assert_eq!(
                rendered_bytes(&baseline, role)?,
                rendered_bytes(&changed, role)?
            );
        }
        assert_ne!(baseline.plan().identity(), changed.plan().identity());
        assert_ne!(baseline.identity(), changed.identity());
    }
    Ok(())
}

#[test]
fn set_permutation_preserves_semantic_material_while_raw_capture_moves() -> Result<(), String> {
    let baseline_capture = read(BASELINE)?;
    let permuted_capture = read(PERMUTED)?;
    assert_ne!(committed(&baseline_capture), committed(&permuted_capture));
    assert_eq!(
        content_bytes(&parsed(BASELINE)?),
        content_bytes(&parsed(PERMUTED)?)
    );
    let baseline = expansion(BASELINE, RenderStyle::Direct)?;
    let permuted = expansion(PERMUTED, RenderStyle::Direct)?;
    for role in ProjectionRole::ALL {
        assert_eq!(
            rendered_bytes(&baseline, *role)?,
            rendered_bytes(&permuted, *role)?
        );
    }
    assert_ne!(baseline.plan().identity(), permuted.plan().identity());
    assert_ne!(baseline.identity(), permuted.identity());
    Ok(())
}

#[test]
fn private_renderer_refactor_preserves_every_identity_and_exact_byte() -> Result<(), String> {
    let direct = expansion(BASELINE, RenderStyle::Direct)?;
    let refactored = expansion(BASELINE, RenderStyle::Refactored)?;
    assert_eq!(direct.plan().identity(), refactored.plan().identity());
    assert_eq!(direct.closure().identity(), refactored.closure().identity());
    assert_eq!(direct.explain().identity(), refactored.explain().identity());
    assert_eq!(direct.identity(), refactored.identity());
    assert_eq!(direct, refactored);
    let direct_accounted =
        engine::accounted(direct).map_err(|diagnostic| diagnostic.summary().to_owned())?;
    let refactored_accounted =
        engine::accounted(refactored).map_err(|diagnostic| diagnostic.summary().to_owned())?;
    assert_eq!(
        derived_receipt(&direct_accounted),
        derived_receipt(&refactored_accounted)
    );
    Ok(())
}

#[test]
fn paved_structural_projectors_preserve_independently_written_raw_bytes() -> Result<(), String> {
    for source in [
        BASELINE,
        PERMUTED,
        TRANSITION_ADDED,
        POLICY_WIDENED,
        POLICY_REMOVED,
    ] {
        let declaration = parsed(source)?;
        let paved =
            engine::production_material_tokens(&declaration).map_err(|error| error.to_string())?;
        let raw = raw_production_material_tokens(&declaration)?;
        assert_eq!(generated_bytes(paved)?, generated_bytes(raw)?);
    }
    Ok(())
}

#[test]
fn informed_structures_retain_lawful_canonical_and_denominator_order() -> Result<(), String> {
    let declaration = parsed(PERMUTED)?;
    let transitions = declaration
        .effects
        .denominator()
        .members()
        .map(|transition| {
            (
                transition.from.as_str(),
                transition.event.as_str(),
                transition.to.as_str(),
            )
        })
        .collect::<Vec<_>>();
    assert_eq!(
        transitions,
        [("Armed", "Finish", "Done"), ("Idle", "Arm", "Armed")]
    );
    assert_eq!(
        declaration
            .effects
            .payloads()
            .keys()
            .map(String::as_str)
            .collect::<Vec<_>>(),
        ["Finish", "Arm"]
    );
    assert_eq!(
        declaration
            .associations
            .indexed()
            .map(|(_index, event, _member, _seat, association)| {
                (event.as_str(), association.operation.as_str())
            })
            .collect::<Vec<_>>(),
        [("Arm", "ArmOp"), ("Finish", "FinishOp")]
    );
    assert_eq!(
        declaration
            .policies
            .members()
            .map(|policy| (policy.capability.as_str(), policy.operation.as_str()))
            .collect::<Vec<_>>(),
        [
            ("Basic", "ArmOp"),
            ("Elevated", "ArmOp"),
            ("Elevated", "FinishOp")
        ]
    );
    Ok(())
}

#[test]
fn mixed_hostile_rows_keep_authored_diagnostic_priority_and_token_seats() -> Result<(), String> {
    let duplicate_roster = BASELINE
        .replace(
            "states { Idle, Armed, Done, }",
            "states { Idle, Idle, Done, }",
        )
        .replacen("Idle + Arm -> Armed,", "Idle ? Arm -> Armed,", 1);
    assert_refusal_at(
        &duplicate_roster,
        &GrammarIssue::DuplicateMember {
            roster: "states",
            member: "Idle".to_owned(),
        },
        "Idle, Done",
    )?;

    let duplicate_effect = BASELINE
        .replacen(
            "Armed + Finish -> Done = Finish add(3),",
            "Idle + Arm -> Armed = Finish add(3),",
            1,
        )
        .replace("Finish => FinishOp", "Finish => ForeignOp");
    assert_refusal_at(
        &duplicate_effect,
        &GrammarIssue::DuplicateEffect(TransitionSpec {
            from: "Idle".to_owned(),
            event: "Arm".to_owned(),
            to: "Armed".to_owned(),
        }),
        "Idle + Arm -> Armed = Finish",
    )?;

    let duplicate_association = BASELINE
        .replace("Finish => FinishOp", "Arm => FinishOp")
        .replace("Elevated => FinishOp", "Foreign => FinishOp");
    assert_refusal_at(
        &duplicate_association,
        &GrammarIssue::DuplicateAssociation("Arm".to_owned()),
        "Arm => FinishOp",
    )?;

    let effects_absent = BASELINE
        .replace("    Idle + Arm -> Armed = Arm add(2),\n", "")
        .replace("    Armed + Finish -> Done = Finish add(3),\n", "");
    assert_eq!(
        refusal(&effects_absent)?.issue(),
        &GrammarIssue::MissingEffect(TransitionSpec {
            from: "Idle".to_owned(),
            event: "Arm".to_owned(),
            to: "Armed".to_owned(),
        })
    );
    Ok(())
}

#[test]
fn paved_material_crosses_request_plan_and_closed_production_expansion() -> Result<(), String> {
    let declaration = parsed(BASELINE)?;
    let material = generated_bytes(
        engine::production_material_tokens(&declaration).map_err(|error| error.to_string())?,
    )?;
    let expansion = expansion(BASELINE, RenderStyle::Direct)?;
    let production = rendered_bytes(&expansion, ProjectionRole::Production)?;
    assert!(production.starts_with(&material));
    assert!(
        expansion
            .plan()
            .membership()
            .under(ProjectionRole::Production)
            .is_some()
    );
    assert!(
        expansion
            .closure()
            .rendered()
            .under(ProjectionRole::Production)
            .is_some()
    );
    Ok(())
}

#[test]
fn closure_refuses_missing_doubled_and_misdelivered_projection_units() -> Result<(), String> {
    let baseline = expansion(BASELINE, RenderStyle::Direct)?;
    let production = baseline
        .closure()
        .rendered()
        .under(ProjectionRole::Production)
        .ok_or_else(|| "production unit absent".to_owned())?
        .clone();
    let omitted = require_refusal(
        Closure::proved(
            baseline.plan(),
            RenderedProjection::materialized(
                baseline
                    .closure()
                    .rendered()
                    .units()
                    .iter()
                    .filter(|unit| unit.role() != ProjectionRole::Receipt)
                    .cloned()
                    .collect(),
            )
            .map_err(|error| error.to_string())?,
        ),
        "a rendering with missing declared projections unexpectedly closed",
    )?;
    assert!(omitted.issues().iter().any(|issue| {
        issue
            == &ClosureIssue::MemberMissing {
                role: ProjectionRole::Receipt,
            }
    }));
    let mut doubled_units = baseline
        .closure()
        .rendered()
        .units()
        .iter()
        .cloned()
        .collect::<Vec<_>>();
    doubled_units.push(production);
    let doubled = require_refusal(
        Closure::proved(
            baseline.plan(),
            RenderedProjection::materialized(doubled_units).map_err(|error| error.to_string())?,
        ),
        "a doubled production projection unexpectedly closed",
    )?;
    assert!(doubled.issues().iter().any(|issue| {
        issue
            == &ClosureIssue::MemberDuplicated {
                role: ProjectionRole::Production,
                observed: 2,
            }
    }));

    let compile_member = baseline
        .plan()
        .membership()
        .under(ProjectionRole::Compile)
        .ok_or_else(|| "compile member absent".to_owned())?;
    let misdelivered_member = PlannedMember {
        role: ProjectionRole::Receipt,
        output: compile_member.output.clone(),
    };
    let receipt_tree = baseline
        .closure()
        .rendered()
        .under(ProjectionRole::Receipt)
        .ok_or_else(|| "receipt unit absent".to_owned())?
        .tree()
        .clone();
    let misdelivered_unit = RenderedUnit::materialized(&misdelivered_member, receipt_tree)
        .map_err(|error| error.to_string())?;
    let misdelivered = require_refusal(
        Closure::proved(
            baseline.plan(),
            RenderedProjection::materialized(
                baseline
                    .closure()
                    .rendered()
                    .units()
                    .iter()
                    .filter(|unit| unit.role() != ProjectionRole::Receipt)
                    .cloned()
                    .chain([misdelivered_unit])
                    .collect(),
            )
            .map_err(|error| error.to_string())?,
        ),
        "a compile semantic key delivered under receipt unexpectedly closed",
    )?;
    assert!(misdelivered.issues().iter().any(|issue| {
        issue
            == &ClosureIssue::SemanticKeyMismatch {
                role: ProjectionRole::Receipt,
            }
    }));
    Ok(())
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct AdversarialRecord<const MODE: u8>;

impl<const MODE: u8> DispositionRecord for AdversarialRecord<MODE> {
    fn into_dispositions(self) -> impl Iterator<Item = (&'static str, Disposition)> {
        let declared = <ProjectionKinds as KindSet>::NAMES;
        let mut rows = declared
            .iter()
            .copied()
            .map(|name| {
                (
                    name,
                    Disposition::NotApplicable {
                        because: HOSTILE_FACT,
                    },
                )
            })
            .collect::<Vec<_>>();
        match MODE {
            0 => {
                let _removed = rows.pop();
            }
            1 => rows.push((
                declared[5],
                Disposition::NotRequested {
                    because: HOSTILE_FACT,
                },
            )),
            2 => rows[2].0 = "guarded-transition.foreign",
            3 => rows.swap(1, 2),
            _ => {}
        }
        rows.into_iter()
    }
}

struct AdversarialKinds<const MODE: u8>;

impl<const MODE: u8> KindSet for AdversarialKinds<MODE> {
    type Dispositions = AdversarialRecord<MODE>;
    const NAMES: &'static [&'static str] = <ProjectionKinds as KindSet>::NAMES;
}

#[test]
fn disposition_completion_refuses_omitted_doubled_foreign_and_reordered_rows() -> Result<(), String>
{
    assert_eq!(
        require_refusal(
            DispositionSet::<AdversarialKinds<0>>::complete(AdversarialRecord),
            "an omitted disposition row unexpectedly completed",
        )?,
        DispositionSetError::CountMismatch {
            expected: 6,
            observed: 5,
        }
    );
    assert_eq!(
        require_refusal(
            DispositionSet::<AdversarialKinds<1>>::complete(AdversarialRecord),
            "a doubled disposition row unexpectedly completed",
        )?,
        DispositionSetError::CountMismatch {
            expected: 6,
            observed: 7,
        }
    );
    assert_eq!(
        require_refusal(
            DispositionSet::<AdversarialKinds<2>>::complete(AdversarialRecord),
            "a foreign disposition row unexpectedly completed",
        )?,
        DispositionSetError::KindMismatch {
            expected: "guarded-transition.mutation",
            observed: "guarded-transition.foreign",
        }
    );
    assert_eq!(
        require_refusal(
            DispositionSet::<AdversarialKinds<3>>::complete(AdversarialRecord),
            "a reordered disposition row unexpectedly completed",
        )?,
        DispositionSetError::KindMismatch {
            expected: "guarded-transition.property",
            observed: "guarded-transition.mutation",
        }
    );
    Ok(())
}

#[test]
fn malformed_policy_places_the_typed_refusal_at_the_exact_wrong_token() -> Result<(), String> {
    let source = BASELINE.replace("Basic => ArmOp", "Basic = > ArmOp");
    let captured = TextCapture::read(&source).map_err(|refusal| refusal.to_string())?;
    let refusal = require_refusal(
        engine::read_declaration(captured.input()),
        "a spaced policy arrow unexpectedly informed",
    )?;
    assert_eq!(refusal.issue(), &GrammarIssue::MalformedPolicy);
    let token = refusal
        .token()
        .ok_or_else(|| "malformed policy refusal had no token".to_owned())?;
    let coordinate = captured
        .spans()
        .coordinate_of(token)
        .map_err(|refusal| refusal.to_string())?;
    let expected = source
        .find("= > ArmOp")
        .ok_or_else(|| "hostile equals token was absent".to_owned())?;
    assert_eq!(coordinate.role, CoordinateRole::Byte);
    assert_eq!(
        coordinate.position,
        u64::try_from(expected).unwrap_or(u64::MAX)
    );
    Ok(())
}

#[test]
fn expansion_readings_derive_one_bounded_host_neutral_receipt() -> Result<(), String> {
    let accounted = engine::compile(read(BASELINE)?, RenderStyle::Direct)
        .map_err(|diagnostic| diagnostic.summary().to_owned())?;
    let receipt = derived_receipt(&accounted);
    assert!(receipt.len() <= 1_024);
    for field in [
        "schema=guarded-transition-expansion-v1\n",
        "plan=",
        "closure=",
        "explanation=",
        "expansion=",
        "projection-count=6\n",
    ] {
        assert!(receipt.contains(field));
    }
    assert!(!receipt.contains("C:\\"));
    let workspace = std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
        .parent()
        .ok_or_else(|| "macro package had no workspace parent".to_owned())?;
    let evidence = workspace.join("evidence");
    std::fs::create_dir_all(&evidence)
        .map_err(|error| format!("receipt directory was not writable: {error}"))?;
    std::fs::write(evidence.join("derived-expansion-reading.txt"), receipt)
        .map_err(|error| format!("derived receipt was not writable: {error}"))
}
