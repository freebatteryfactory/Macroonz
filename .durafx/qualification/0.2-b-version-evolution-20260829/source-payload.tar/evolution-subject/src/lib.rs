//! Ordinary subject contracts plus independent generated and handwritten evolution roads.

#![forbid(unsafe_code)]
#![deny(warnings)]

use evolution_subject_macros::{evolution_graph, evolution_graph_refactored};

/// The complete subject-owned version vocabulary.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Version {
    /// The opening representation.
    V1,
    /// The first evolved representation.
    V2,
    /// The terminal representation in the baseline graph.
    V3,
}

impl Version {
    /// The complete version roster in subject-declared order.
    pub const ALL: &'static [Self] = &[Self::V1, Self::V2, Self::V3];
}

/// The adapter seats this subject may name.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum AdapterSeat {
    /// The adapter from V1 to V2.
    V1ToV2,
    /// The adapter from V2 to V3.
    V2ToV3,
    /// The planted direct adapter from V1 to V3.
    V1ToV3,
}

/// One admitted directed evolution edge and its exact adapter seat.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Edge {
    from: Version,
    to: Version,
    adapter: AdapterSeat,
}

impl Edge {
    /// Declares one edge and the adapter seat that realizes it.
    #[must_use]
    pub const fn declared(from: Version, to: Version, adapter: AdapterSeat) -> Self {
        Self { from, to, adapter }
    }

    /// The version the edge begins at.
    #[must_use]
    pub const fn from(self) -> Version {
        self.from
    }

    /// The version the edge reaches.
    #[must_use]
    pub const fn to(self) -> Version {
        self.to
    }

    /// The exact adapter seat assigned to this edge.
    #[must_use]
    pub const fn adapter(self) -> AdapterSeat {
        self.adapter
    }
}

/// Why an admitted subject transformation could not produce its next version.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum EvolutionError {
    /// The declared checked arithmetic crossed the value representation.
    Overflow,
}

impl core::fmt::Display for EvolutionError {
    fn fmt(&self, formatter: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        match self {
            Self::Overflow => formatter.write_str("the declared evolution value overflowed"),
        }
    }
}

impl core::error::Error for EvolutionError {}

/// One subject-owned adapter from `From` into `To`.
pub trait Adapter<From, To> {
    /// Applies the declared transformation.
    ///
    /// # Errors
    ///
    /// Returns [`EvolutionError`] when the transformation cannot represent its result.
    fn adapt(from: From) -> Result<To, EvolutionError>;
}

/// The ordinary public evolution contract shared by generated and handwritten versions.
pub trait EvolveTo<Next>: Sized {
    /// Evolves this value through its admitted direct edge.
    ///
    /// # Errors
    ///
    /// Returns [`EvolutionError`] when the edge's subject-owned adapter cannot represent its result.
    fn evolve(self) -> Result<Next, EvolutionError>;
}

/// The generated baseline graph.
pub mod generated {
    use super::{Adapter, evolution_graph};

    evolution_graph! {
        versions { V1, V2, V3, }
        edges { V1 -> V2, V2 -> V3, }
        adapters {
            V1 -> V2 = V1ToV2 add(5),
            V2 -> V3 = V2ToV3 add(7),
        }
    }
}

/// The baseline graph emitted through the alternate private adapter renderer.
pub mod refactored {
    use super::{Adapter, evolution_graph_refactored};

    evolution_graph_refactored! {
        versions { V1, V2, V3, }
        edges { V1 -> V2, V2 -> V3, }
        adapters {
            V1 -> V2 = V1ToV2 add(5),
            V2 -> V3 = V2ToV3 add(7),
        }
    }
}

/// The planted generated graph with one additional direct edge and adapter.
pub mod planted {
    use super::{Adapter, evolution_graph};

    evolution_graph! {
        versions { V1, V2, V3, }
        edges { V1 -> V2, V2 -> V3, V1 -> V3, }
        adapters {
            V1 -> V2 = V1ToV2 add(5),
            V2 -> V3 = V2ToV3 add(7),
            V1 -> V3 = V1ToV3 add(12),
        }
    }
}

/// The independently authored handwritten baseline graph.
pub mod handwritten {
    use super::{Adapter, AdapterSeat, Edge, EvolutionError, EvolveTo, Version};

    /// The handwritten opening representation.
    #[derive(Debug, Clone, Copy, PartialEq, Eq)]
    pub struct V1(u64);

    impl V1 {
        /// Builds the handwritten V1 value.
        #[must_use]
        pub const fn new(value: u64) -> Self {
            Self(value)
        }

        /// Reads the represented value.
        #[must_use]
        pub const fn value(self) -> u64 {
            self.0
        }
    }

    /// The handwritten second representation.
    #[derive(Debug, Clone, Copy, PartialEq, Eq)]
    pub struct V2(u64);

    impl V2 {
        /// Reads the represented value.
        #[must_use]
        pub const fn value(self) -> u64 {
            self.0
        }
    }

    /// The handwritten terminal representation.
    #[derive(Debug, Clone, Copy, PartialEq, Eq)]
    pub struct V3(u64);

    impl V3 {
        /// Reads the represented value.
        #[must_use]
        pub const fn value(self) -> u64 {
            self.0
        }
    }

    /// The handwritten V1-to-V2 adapter seat.
    pub struct V1ToV2Adapter;

    impl Adapter<V1, V2> for V1ToV2Adapter {
        fn adapt(from: V1) -> Result<V2, EvolutionError> {
            from.0
                .checked_add(5)
                .map(V2)
                .ok_or(EvolutionError::Overflow)
        }
    }

    impl EvolveTo<V2> for V1 {
        fn evolve(self) -> Result<V2, EvolutionError> {
            V1ToV2Adapter::adapt(self)
        }
    }

    /// The handwritten V2-to-V3 adapter seat.
    pub struct V2ToV3Adapter;

    impl Adapter<V2, V3> for V2ToV3Adapter {
        fn adapt(from: V2) -> Result<V3, EvolutionError> {
            from.0
                .checked_add(7)
                .map(V3)
                .ok_or(EvolutionError::Overflow)
        }
    }

    impl EvolveTo<V3> for V2 {
        fn evolve(self) -> Result<V3, EvolutionError> {
            V2ToV3Adapter::adapt(self)
        }
    }

    /// The complete handwritten version roster.
    pub const VERSIONS: &[Version] = &[Version::V1, Version::V2, Version::V3];

    /// The complete handwritten baseline edge and adapter roster.
    pub const EDGES: &[Edge] = &[
        Edge::declared(Version::V1, Version::V2, AdapterSeat::V1ToV2),
        Edge::declared(Version::V2, Version::V3, AdapterSeat::V2ToV3),
    ];
}
