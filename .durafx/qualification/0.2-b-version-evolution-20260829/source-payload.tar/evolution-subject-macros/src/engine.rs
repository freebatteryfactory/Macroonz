#![forbid(unsafe_code)]
#![deny(warnings)]

use bakery::compiler::{
    Bounded, CanonicalContent, CapturedDelimiter, CapturedInput, CapturedTokenTree, CrateBinding,
    Destination, Diagnostic, Door, Expansion, Family, GeneratedDelimiter, GeneratedToken,
    GeneratedTree, Kind, LineBody, NoQuestions, Observed, Phase, Placement, Producer, RefusalClass,
    Refused, Repair, Request, Role, SpanHandle, SpanTable,
};

const DOOR: Door = Door::declared(
    "evolution-subject",
    "evolution-subject.version-graph",
    "evolution_subject_macros::evolution_graph",
    CrateBinding::declared("bakery"),
    Producer {
        namespace: "evolution-subject",
        name: "evolution-subject-macros",
    },
);

const GRAMMAR_FAMILY: Family = Family::declared("evolution-subject/version-graph-grammar");
const VERSION_LIMIT: usize = 8;
const EDGE_LIMIT: usize = 16;

#[derive(Debug, Clone, PartialEq, Eq, PartialOrd, Ord)]
pub(crate) struct VersionSpec {
    pub(crate) name: String,
}

#[derive(Debug, Clone, PartialEq, Eq, PartialOrd, Ord)]
pub(crate) struct EdgeSpec {
    pub(crate) from: String,
    pub(crate) to: String,
}

#[derive(Debug, Clone, PartialEq, Eq, PartialOrd, Ord)]
pub(crate) struct AdapterSpec {
    pub(crate) edge: EdgeSpec,
    pub(crate) seat: String,
    pub(crate) added: u64,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) struct EvolutionDeclaration {
    pub(crate) versions: Bounded<VersionSpec, VERSION_LIMIT>,
    pub(crate) edges: Bounded<EdgeSpec, EDGE_LIMIT>,
    pub(crate) adapters: Bounded<AdapterSpec, EDGE_LIMIT>,
}

impl CanonicalContent for EvolutionDeclaration {
    fn encode_content_into(&self, into: &mut Vec<u8>) {
        into.extend_from_slice(
            &u64::try_from(self.versions.len())
                .unwrap_or(u64::MAX)
                .to_be_bytes(),
        );
        for version in self.versions.iter() {
            bakery::compiler::encode_bytes(version.name.as_bytes(), into);
        }
        let mut adapters: Vec<&AdapterSpec> = self.adapters.iter().collect();
        adapters.sort_unstable();
        into.extend_from_slice(
            &u64::try_from(adapters.len())
                .unwrap_or(u64::MAX)
                .to_be_bytes(),
        );
        for adapter in adapters {
            bakery::compiler::encode_bytes(adapter.edge.from.as_bytes(), into);
            bakery::compiler::encode_bytes(adapter.edge.to.as_bytes(), into);
            bakery::compiler::encode_bytes(adapter.seat.as_bytes(), into);
            into.extend_from_slice(&adapter.added.to_be_bytes());
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) struct EvolutionProjection;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum EvolutionRole {
    Graph,
    HostileForeign,
}

impl Role for EvolutionRole {
    const ALL: &'static [Self] = &[Self::Graph];

    fn name(self) -> &'static str {
        match self {
            Self::Graph => "version-graph",
            Self::HostileForeign => "hostile-foreign",
        }
    }

    fn destination(self) -> Destination {
        Destination::DeclarationSite
    }
}

const _: EvolutionRole = EvolutionRole::HostileForeign;

impl Kind for EvolutionProjection {
    const NAME: &'static str = "evolution-subject.version-graph";
    type Content = EvolutionDeclaration;
    type Role = EvolutionRole;
    type Question = NoQuestions;
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) enum GrammarIssue {
    MalformedDeclaration,
    VersionsAbsent,
    VersionsUnbounded,
    DuplicateVersion(String),
    EdgesAbsent,
    EdgesUnbounded,
    ForeignEdge(EdgeSpec),
    DuplicateEdge(EdgeSpec),
    SelfEdge(EdgeSpec),
    BackwardEdge(EdgeSpec),
    AdaptersUnbounded,
    MissingAdapter(EdgeSpec),
    DuplicateAdapter(EdgeSpec),
    ForeignAdapter(EdgeSpec),
    DuplicateAdapterSeat(String),
    MalformedVersion,
    MalformedEdge,
    MalformedAdapter,
    UnsupportedAdapterOperation(String),
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) struct GrammarRefusal {
    issue: GrammarIssue,
    at: Option<SpanHandle>,
}

impl GrammarRefusal {
    pub(crate) const fn issue(&self) -> &GrammarIssue {
        &self.issue
    }

    pub(crate) const fn token(&self) -> Option<SpanHandle> {
        self.at
    }

    fn at(issue: GrammarIssue, token: &CapturedTokenTree) -> Self {
        Self {
            issue,
            at: Some(token.span()),
        }
    }

    fn whole(issue: GrammarIssue) -> Self {
        Self { issue, at: None }
    }

    fn diagnostic(&self) -> Diagnostic {
        match self.token() {
            Some(token) => Diagnostic::refused(
                self,
                &DOOR,
                &Placement::AtToken {
                    token,
                    spans: &SpanTable::ProducerHeld,
                },
            ),
            None => Diagnostic::refused(self, &DOOR, &Placement::WholeDeclaration),
        }
    }
}

impl Refused for GrammarRefusal {
    const PHASE: Phase = Phase::Capture;
    const FAMILY: Family = GRAMMAR_FAMILY;

    fn class(&self) -> RefusalClass {
        RefusalClass::DeclarationNotRead
    }

    fn first(&self) -> String {
        match self.issue() {
            GrammarIssue::MalformedDeclaration => {
                "the declaration must state versions, edges, and adapters in that order".to_owned()
            }
            GrammarIssue::VersionsAbsent => "the version roster must not be empty".to_owned(),
            GrammarIssue::VersionsUnbounded => {
                "the version roster exceeds this subject's declared ceiling".to_owned()
            }
            GrammarIssue::DuplicateVersion(version) => {
                format!("the version `{version}` is declared more than once")
            }
            GrammarIssue::EdgesAbsent => "the evolution edge roster must not be empty".to_owned(),
            GrammarIssue::EdgesUnbounded => {
                "the evolution edge roster exceeds this subject's declared ceiling".to_owned()
            }
            GrammarIssue::ForeignEdge(edge) => format!(
                "the edge `{} -> {}` names a version outside the declared roster",
                edge.from, edge.to
            ),
            GrammarIssue::DuplicateEdge(edge) => format!(
                "the edge `{} -> {}` is declared more than once",
                edge.from, edge.to
            ),
            GrammarIssue::SelfEdge(edge) => {
                format!(
                    "the edge `{} -> {}` is a forbidden self edge",
                    edge.from, edge.to
                )
            }
            GrammarIssue::BackwardEdge(edge) => format!(
                "the edge `{} -> {}` violates this subject's forward-only law",
                edge.from, edge.to
            ),
            GrammarIssue::AdaptersUnbounded => {
                "the adapter roster exceeds this subject's declared ceiling".to_owned()
            }
            GrammarIssue::MissingAdapter(edge) => format!(
                "the admitted edge `{} -> {}` has no adapter seat",
                edge.from, edge.to
            ),
            GrammarIssue::DuplicateAdapter(edge) => format!(
                "the admitted edge `{} -> {}` has more than one adapter seat",
                edge.from, edge.to
            ),
            GrammarIssue::ForeignAdapter(edge) => format!(
                "the adapter for `{} -> {}` has no admitted edge",
                edge.from, edge.to
            ),
            GrammarIssue::DuplicateAdapterSeat(seat) => {
                format!("the adapter seat `{seat}` is used more than once")
            }
            GrammarIssue::MalformedVersion => {
                "a version row must be one ordinary Rust identifier followed by a comma".to_owned()
            }
            GrammarIssue::MalformedEdge => "an edge row must be `From -> To,`".to_owned(),
            GrammarIssue::MalformedAdapter => {
                "an adapter row must be `From -> To = Seat add(amount),`".to_owned()
            }
            GrammarIssue::UnsupportedAdapterOperation(operation) => {
                format!("the adapter operation `{operation}` is not in this subject grammar")
            }
        }
    }

    fn observed(&self) -> Observed {
        Observed::ContractDisagreement
    }

    fn body(&self) -> LineBody {
        LineBody::SingleCause
    }

    fn related(&self) -> Vec<Vec<u8>> {
        Vec::new()
    }

    fn repairs(&self) -> Bounded<Repair, 8> {
        Bounded::empty()
    }
}

pub(crate) fn read_declaration(
    capture: &CapturedInput,
) -> Result<EvolutionDeclaration, GrammarRefusal> {
    let [
        versions_word,
        versions_group,
        edges_word,
        edges_group,
        adapters_word,
        adapters_group,
    ] = capture.trees()
    else {
        return Err(capture.trees().first().map_or_else(
            || GrammarRefusal::whole(GrammarIssue::MalformedDeclaration),
            |token| GrammarRefusal::at(GrammarIssue::MalformedDeclaration, token),
        ));
    };
    if versions_word.word() != Some("versions") {
        return Err(GrammarRefusal::at(
            GrammarIssue::MalformedDeclaration,
            versions_word,
        ));
    }
    if edges_word.word() != Some("edges") {
        return Err(GrammarRefusal::at(
            GrammarIssue::MalformedDeclaration,
            edges_word,
        ));
    }
    if adapters_word.word() != Some("adapters") {
        return Err(GrammarRefusal::at(
            GrammarIssue::MalformedDeclaration,
            adapters_word,
        ));
    }
    let versions = group(versions_group)?;
    let edges = group(edges_group)?;
    let adapters = group(adapters_group)?;
    informed(versions, edges, adapters)
}

fn group(token: &CapturedTokenTree) -> Result<&[CapturedTokenTree], GrammarRefusal> {
    let Some((CapturedDelimiter::Brace, members)) = token.group() else {
        return Err(GrammarRefusal::at(
            GrammarIssue::MalformedDeclaration,
            token,
        ));
    };
    Ok(members)
}

fn informed(
    version_tokens: &[CapturedTokenTree],
    edge_tokens: &[CapturedTokenTree],
    adapter_tokens: &[CapturedTokenTree],
) -> Result<EvolutionDeclaration, GrammarRefusal> {
    let versions = read_versions(version_tokens)?;
    let edges = read_edges(edge_tokens, &versions)?;
    let adapters = read_adapters(adapter_tokens, &versions, &edges)?;
    Ok(EvolutionDeclaration {
        versions,
        edges,
        adapters,
    })
}

fn read_versions(
    tokens: &[CapturedTokenTree],
) -> Result<Bounded<VersionSpec, VERSION_LIMIT>, GrammarRefusal> {
    if tokens.is_empty() {
        return Err(GrammarRefusal::whole(GrammarIssue::VersionsAbsent));
    }
    let (rows, remainder) = tokens.as_chunks::<2>();
    if let Some(token) = remainder.first() {
        return Err(GrammarRefusal::at(GrammarIssue::MalformedVersion, token));
    }
    let mut versions = Vec::new();
    for [name, comma] in rows {
        let Some(name_spelling) = name
            .word()
            .filter(|spelling| bakery::compiler::rendered_name(spelling))
        else {
            return Err(GrammarRefusal::at(GrammarIssue::MalformedVersion, name));
        };
        if comma.punct() != Some(',') {
            return Err(GrammarRefusal::at(GrammarIssue::MalformedVersion, comma));
        }
        if versions
            .iter()
            .any(|version: &VersionSpec| version.name == name_spelling)
        {
            return Err(GrammarRefusal::at(
                GrammarIssue::DuplicateVersion(name_spelling.to_owned()),
                name,
            ));
        }
        versions.push(VersionSpec {
            name: name_spelling.to_owned(),
        });
    }
    Bounded::new(versions)
        .map_err(|_overflow| GrammarRefusal::whole(GrammarIssue::VersionsUnbounded))
}

fn read_edges(
    tokens: &[CapturedTokenTree],
    versions: &Bounded<VersionSpec, VERSION_LIMIT>,
) -> Result<Bounded<EdgeSpec, EDGE_LIMIT>, GrammarRefusal> {
    if tokens.is_empty() {
        return Err(GrammarRefusal::whole(GrammarIssue::EdgesAbsent));
    }
    let (rows, remainder) = tokens.as_chunks::<5>();
    if let Some(token) = remainder.first() {
        return Err(GrammarRefusal::at(GrammarIssue::MalformedEdge, token));
    }
    let mut edges = Vec::new();
    for [from, dash, arrow, to, comma] in rows {
        let Some(from_name) = from.word() else {
            return Err(GrammarRefusal::at(GrammarIssue::MalformedEdge, from));
        };
        let Some(to_name) = to.word() else {
            return Err(GrammarRefusal::at(GrammarIssue::MalformedEdge, to));
        };
        if dash.joint_punct() != Some('-') {
            return Err(GrammarRefusal::at(GrammarIssue::MalformedEdge, dash));
        }
        if arrow.punct() != Some('>') {
            return Err(GrammarRefusal::at(GrammarIssue::MalformedEdge, arrow));
        }
        if comma.punct() != Some(',') {
            return Err(GrammarRefusal::at(GrammarIssue::MalformedEdge, comma));
        }
        let edge = EdgeSpec {
            from: from_name.to_owned(),
            to: to_name.to_owned(),
        };
        let Some(from_rank) = rank(versions, from_name) else {
            return Err(GrammarRefusal::at(GrammarIssue::ForeignEdge(edge), from));
        };
        let Some(to_rank) = rank(versions, to_name) else {
            return Err(GrammarRefusal::at(GrammarIssue::ForeignEdge(edge), to));
        };
        if from_rank == to_rank {
            return Err(GrammarRefusal::at(GrammarIssue::SelfEdge(edge), arrow));
        }
        if from_rank > to_rank {
            return Err(GrammarRefusal::at(GrammarIssue::BackwardEdge(edge), arrow));
        }
        if edges.iter().any(|declared| declared == &edge) {
            return Err(GrammarRefusal::at(GrammarIssue::DuplicateEdge(edge), from));
        }
        edges.push(edge);
    }
    Bounded::new(edges).map_err(|_overflow| GrammarRefusal::whole(GrammarIssue::EdgesUnbounded))
}

fn read_adapters(
    tokens: &[CapturedTokenTree],
    versions: &Bounded<VersionSpec, VERSION_LIMIT>,
    edges: &Bounded<EdgeSpec, EDGE_LIMIT>,
) -> Result<Bounded<AdapterSpec, EDGE_LIMIT>, GrammarRefusal> {
    let (rows, remainder) = tokens.as_chunks::<9>();
    if let Some(token) = remainder.first() {
        return Err(GrammarRefusal::at(GrammarIssue::MalformedAdapter, token));
    }
    let mut adapters = Vec::new();
    for row in rows {
        adapters.push(read_adapter(row, versions, edges, &adapters)?);
    }
    for edge in edges.iter() {
        if !adapters.iter().any(|adapter| &adapter.edge == edge) {
            return Err(GrammarRefusal::whole(GrammarIssue::MissingAdapter(
                edge.clone(),
            )));
        }
    }
    Bounded::new(adapters)
        .map_err(|_overflow| GrammarRefusal::whole(GrammarIssue::AdaptersUnbounded))
}

fn read_adapter(
    row: &[CapturedTokenTree; 9],
    versions: &Bounded<VersionSpec, VERSION_LIMIT>,
    edges: &Bounded<EdgeSpec, EDGE_LIMIT>,
    adapters: &[AdapterSpec],
) -> Result<AdapterSpec, GrammarRefusal> {
    let [
        from,
        dash,
        arrow,
        to,
        equals,
        seat,
        operation,
        arguments,
        comma,
    ] = row;
    let Some(from_name) = from.word() else {
        return Err(GrammarRefusal::at(GrammarIssue::MalformedAdapter, from));
    };
    let Some(to_name) = to.word() else {
        return Err(GrammarRefusal::at(GrammarIssue::MalformedAdapter, to));
    };
    let Some(seat_name) = seat
        .word()
        .filter(|spelling| bakery::compiler::rendered_name(spelling))
    else {
        return Err(GrammarRefusal::at(GrammarIssue::MalformedAdapter, seat));
    };
    for (token, expected) in [(dash, '-'), (arrow, '>'), (equals, '='), (comma, ',')] {
        let found = if expected == '-' {
            token.joint_punct()
        } else {
            token.punct()
        };
        if found != Some(expected) {
            return Err(GrammarRefusal::at(GrammarIssue::MalformedAdapter, token));
        }
    }
    let Some(operation_name) = operation.word() else {
        return Err(GrammarRefusal::at(
            GrammarIssue::MalformedAdapter,
            operation,
        ));
    };
    if operation_name != "add" {
        return Err(GrammarRefusal::at(
            GrammarIssue::UnsupportedAdapterOperation(operation_name.to_owned()),
            operation,
        ));
    }
    let Some((CapturedDelimiter::Parenthesis, [amount])) = arguments.group() else {
        return Err(GrammarRefusal::at(
            GrammarIssue::MalformedAdapter,
            arguments,
        ));
    };
    let Some(added) = amount.number().and_then(|value| value.parse::<u64>().ok()) else {
        return Err(GrammarRefusal::at(GrammarIssue::MalformedAdapter, amount));
    };
    let edge = EdgeSpec {
        from: from_name.to_owned(),
        to: to_name.to_owned(),
    };
    if rank(versions, from_name).is_none() || rank(versions, to_name).is_none() {
        return Err(GrammarRefusal::at(GrammarIssue::ForeignAdapter(edge), from));
    }
    if !edges.iter().any(|declared| declared == &edge) {
        return Err(GrammarRefusal::at(GrammarIssue::ForeignAdapter(edge), from));
    }
    if adapters.iter().any(|declared| declared.edge == edge) {
        return Err(GrammarRefusal::at(
            GrammarIssue::DuplicateAdapter(edge),
            from,
        ));
    }
    if adapters.iter().any(|declared| declared.seat == seat_name) {
        return Err(GrammarRefusal::at(
            GrammarIssue::DuplicateAdapterSeat(seat_name.to_owned()),
            seat,
        ));
    }
    Ok(AdapterSpec {
        edge,
        seat: seat_name.to_owned(),
        added,
    })
}

fn rank(versions: &Bounded<VersionSpec, VERSION_LIMIT>, name: &str) -> Option<usize> {
    versions.iter().position(|version| version.name == name)
}

fn path(root: &str, member: &str) -> Vec<GeneratedToken> {
    vec![
        GeneratedToken::word(root),
        GeneratedToken::joint(':'),
        GeneratedToken::alone(':'),
        GeneratedToken::word(member),
    ]
}

fn derived() -> Result<Vec<GeneratedToken>, bakery::compiler::Overflow> {
    let traits = vec![
        GeneratedToken::word("Debug"),
        GeneratedToken::alone(','),
        GeneratedToken::word("Clone"),
        GeneratedToken::alone(','),
        GeneratedToken::word("Copy"),
        GeneratedToken::alone(','),
        GeneratedToken::word("PartialEq"),
        GeneratedToken::alone(','),
        GeneratedToken::word("Eq"),
    ];
    bakery::compiler::attribute(vec![
        GeneratedToken::word("derive"),
        bakery::compiler::group(GeneratedDelimiter::Parenthesis, traits)?,
    ])
}

fn generated_struct(
    version: &VersionSpec,
) -> Result<Vec<GeneratedToken>, bakery::compiler::Overflow> {
    let mut tokens = bakery::compiler::documentation("One generated subject version value.")?;
    tokens.extend(derived()?);
    tokens.extend([
        GeneratedToken::word("pub"),
        GeneratedToken::word("struct"),
        GeneratedToken::word(&version.name),
        bakery::compiler::group(
            GeneratedDelimiter::Parenthesis,
            vec![GeneratedToken::word("pub"), GeneratedToken::word("u64")],
        )?,
        GeneratedToken::alone(';'),
    ]);
    Ok(tokens)
}

fn generic_trait(name: &str, argument: &str) -> Vec<GeneratedToken> {
    let mut tokens = path("crate", name);
    tokens.extend([
        GeneratedToken::alone('<'),
        GeneratedToken::word(argument),
        GeneratedToken::alone('>'),
    ]);
    tokens
}

fn adapter_impl(adapter: &AdapterSpec) -> Result<Vec<GeneratedToken>, bakery::compiler::Overflow> {
    let marker = format!("{}Adapter", adapter.seat);
    let mut tokens = bakery::compiler::documentation("One generated subject adapter seat.")?;
    tokens.extend([
        GeneratedToken::word("pub"),
        GeneratedToken::word("struct"),
        GeneratedToken::word(&marker),
        GeneratedToken::alone(';'),
        GeneratedToken::word("impl"),
    ]);
    tokens.extend(adapter_trait(adapter));
    tokens.extend([GeneratedToken::word("for"), GeneratedToken::word(&marker)]);
    tokens.push(bakery::compiler::group(
        GeneratedDelimiter::Brace,
        adapt_method(adapter)?,
    )?);
    tokens.push(GeneratedToken::word("impl"));
    tokens.extend(generic_trait("EvolveTo", &adapter.edge.to));
    tokens.extend([
        GeneratedToken::word("for"),
        GeneratedToken::word(&adapter.edge.from),
    ]);
    tokens.push(bakery::compiler::group(
        GeneratedDelimiter::Brace,
        evolve_method(adapter, &marker)?,
    )?);
    Ok(tokens)
}

fn adapter_trait(adapter: &AdapterSpec) -> Vec<GeneratedToken> {
    let mut tokens = path("crate", "Adapter");
    tokens.extend([
        GeneratedToken::alone('<'),
        GeneratedToken::word(&adapter.edge.from),
        GeneratedToken::alone(','),
        GeneratedToken::word(&adapter.edge.to),
        GeneratedToken::alone('>'),
    ]);
    tokens
}

fn evolution_result(to: &str) -> Vec<GeneratedToken> {
    let mut tokens = path("core", "result");
    tokens.extend([
        GeneratedToken::joint(':'),
        GeneratedToken::alone(':'),
        GeneratedToken::word("Result"),
        GeneratedToken::alone('<'),
        GeneratedToken::word(to),
        GeneratedToken::alone(','),
    ]);
    tokens.extend(path("crate", "EvolutionError"));
    tokens.push(GeneratedToken::alone('>'));
    tokens
}

fn adapt_method(adapter: &AdapterSpec) -> Result<Vec<GeneratedToken>, bakery::compiler::Overflow> {
    let result = vec![
        GeneratedToken::word(&adapter.edge.from.to_lowercase()),
        GeneratedToken::alone('.'),
        GeneratedToken::number(0_u64),
        GeneratedToken::alone('.'),
        GeneratedToken::word("checked_add"),
        bakery::compiler::group(
            GeneratedDelimiter::Parenthesis,
            vec![GeneratedToken::number(adapter.added)],
        )?,
        GeneratedToken::alone('.'),
        GeneratedToken::word("map"),
        bakery::compiler::group(
            GeneratedDelimiter::Parenthesis,
            vec![GeneratedToken::word(&adapter.edge.to)],
        )?,
        GeneratedToken::alone('.'),
        GeneratedToken::word("ok_or"),
        bakery::compiler::group(
            GeneratedDelimiter::Parenthesis,
            path("crate", "EvolutionError")
                .into_iter()
                .chain([
                    GeneratedToken::joint(':'),
                    GeneratedToken::alone(':'),
                    GeneratedToken::word("Overflow"),
                ])
                .collect(),
        )?,
    ];
    let mut method = vec![
        GeneratedToken::word("fn"),
        GeneratedToken::word("adapt"),
        bakery::compiler::group(
            GeneratedDelimiter::Parenthesis,
            vec![
                GeneratedToken::word(&adapter.edge.from.to_lowercase()),
                GeneratedToken::alone(':'),
                GeneratedToken::word(&adapter.edge.from),
            ],
        )?,
        GeneratedToken::joint('-'),
        GeneratedToken::alone('>'),
    ];
    method.extend(evolution_result(&adapter.edge.to));
    method.push(bakery::compiler::group(GeneratedDelimiter::Brace, result)?);
    Ok(method)
}

fn evolve_method(
    adapter: &AdapterSpec,
    marker: &str,
) -> Result<Vec<GeneratedToken>, bakery::compiler::Overflow> {
    let call = vec![
        GeneratedToken::word(marker),
        GeneratedToken::joint(':'),
        GeneratedToken::alone(':'),
        GeneratedToken::word("adapt"),
        bakery::compiler::group(
            GeneratedDelimiter::Parenthesis,
            vec![GeneratedToken::word("self")],
        )?,
    ];
    let mut method = vec![
        GeneratedToken::word("fn"),
        GeneratedToken::word("evolve"),
        bakery::compiler::group(
            GeneratedDelimiter::Parenthesis,
            vec![GeneratedToken::word("self")],
        )?,
        GeneratedToken::joint('-'),
        GeneratedToken::alone('>'),
    ];
    method.extend(evolution_result(&adapter.edge.to));
    method.push(bakery::compiler::group(GeneratedDelimiter::Brace, call)?);
    Ok(method)
}

fn refactored_adapter_impl(
    adapter: &AdapterSpec,
) -> Result<Vec<GeneratedToken>, bakery::compiler::Overflow> {
    let marker = format!("{}Adapter", adapter.seat);
    let declaration = [
        GeneratedToken::word("pub"),
        GeneratedToken::word("struct"),
        GeneratedToken::word(&marker),
        GeneratedToken::alone(';'),
    ];
    let mut adapter_implementation = vec![GeneratedToken::word("impl")];
    adapter_implementation.extend(refactored_adapter_trait(adapter));
    adapter_implementation.extend([
        GeneratedToken::word("for"),
        GeneratedToken::word(&marker),
        bakery::compiler::group(GeneratedDelimiter::Brace, refactored_adapt_method(adapter)?)?,
    ]);
    let mut evolution_implementation = vec![GeneratedToken::word("impl")];
    evolution_implementation.extend(refactored_evolution_trait(&adapter.edge.to));
    evolution_implementation.extend([
        GeneratedToken::word("for"),
        GeneratedToken::word(&adapter.edge.from),
        bakery::compiler::group(
            GeneratedDelimiter::Brace,
            refactored_evolve_method(adapter, &marker)?,
        )?,
    ]);
    Ok(
        bakery::compiler::documentation("One generated subject adapter seat.")?
            .into_iter()
            .chain(declaration)
            .chain(adapter_implementation)
            .chain(evolution_implementation)
            .collect(),
    )
}

fn refactored_adapter_trait(adapter: &AdapterSpec) -> Vec<GeneratedToken> {
    path("crate", "Adapter")
        .into_iter()
        .chain([
            GeneratedToken::alone('<'),
            GeneratedToken::word(&adapter.edge.from),
            GeneratedToken::alone(','),
            GeneratedToken::word(&adapter.edge.to),
            GeneratedToken::alone('>'),
        ])
        .collect()
}

fn refactored_evolution_trait(to: &str) -> Vec<GeneratedToken> {
    path("crate", "EvolveTo")
        .into_iter()
        .chain([
            GeneratedToken::alone('<'),
            GeneratedToken::word(to),
            GeneratedToken::alone('>'),
        ])
        .collect()
}

fn refactored_result(to: &str) -> Vec<GeneratedToken> {
    path("core", "result")
        .into_iter()
        .chain([
            GeneratedToken::joint(':'),
            GeneratedToken::alone(':'),
            GeneratedToken::word("Result"),
            GeneratedToken::alone('<'),
            GeneratedToken::word(to),
            GeneratedToken::alone(','),
        ])
        .chain(path("crate", "EvolutionError"))
        .chain([GeneratedToken::alone('>')])
        .collect()
}

fn refactored_adapt_method(
    adapter: &AdapterSpec,
) -> Result<Vec<GeneratedToken>, bakery::compiler::Overflow> {
    let argument = adapter.edge.from.to_lowercase();
    let parameters = vec![
        GeneratedToken::word(&argument),
        GeneratedToken::alone(':'),
        GeneratedToken::word(&adapter.edge.from),
    ];
    let overflow = path("crate", "EvolutionError")
        .into_iter()
        .chain([
            GeneratedToken::joint(':'),
            GeneratedToken::alone(':'),
            GeneratedToken::word("Overflow"),
        ])
        .collect();
    let body = vec![
        GeneratedToken::word(&argument),
        GeneratedToken::alone('.'),
        GeneratedToken::number(0_u64),
        GeneratedToken::alone('.'),
        GeneratedToken::word("checked_add"),
        bakery::compiler::group(
            GeneratedDelimiter::Parenthesis,
            vec![GeneratedToken::number(adapter.added)],
        )?,
        GeneratedToken::alone('.'),
        GeneratedToken::word("map"),
        bakery::compiler::group(
            GeneratedDelimiter::Parenthesis,
            vec![GeneratedToken::word(&adapter.edge.to)],
        )?,
        GeneratedToken::alone('.'),
        GeneratedToken::word("ok_or"),
        bakery::compiler::group(GeneratedDelimiter::Parenthesis, overflow)?,
    ];
    let mut method = vec![
        GeneratedToken::word("fn"),
        GeneratedToken::word("adapt"),
        bakery::compiler::group(GeneratedDelimiter::Parenthesis, parameters)?,
        GeneratedToken::joint('-'),
        GeneratedToken::alone('>'),
    ];
    method.extend(refactored_result(&adapter.edge.to));
    method.push(bakery::compiler::group(GeneratedDelimiter::Brace, body)?);
    Ok(method)
}

fn refactored_evolve_method(
    adapter: &AdapterSpec,
    marker: &str,
) -> Result<Vec<GeneratedToken>, bakery::compiler::Overflow> {
    let invocation = vec![
        GeneratedToken::word(marker),
        GeneratedToken::joint(':'),
        GeneratedToken::alone(':'),
        GeneratedToken::word("adapt"),
        bakery::compiler::group(
            GeneratedDelimiter::Parenthesis,
            vec![GeneratedToken::word("self")],
        )?,
    ];
    let mut method = vec![
        GeneratedToken::word("fn"),
        GeneratedToken::word("evolve"),
        bakery::compiler::group(
            GeneratedDelimiter::Parenthesis,
            vec![GeneratedToken::word("self")],
        )?,
        GeneratedToken::joint('-'),
        GeneratedToken::alone('>'),
    ];
    method.extend(refactored_result(&adapter.edge.to));
    method.push(bakery::compiler::group(
        GeneratedDelimiter::Brace,
        invocation,
    )?);
    Ok(method)
}

fn roster_tokens(
    declaration: &EvolutionDeclaration,
) -> Result<Vec<GeneratedToken>, bakery::compiler::Overflow> {
    let mut versions = Vec::new();
    for version in declaration.versions.iter() {
        versions.extend(path("crate", "Version"));
        versions.extend([
            GeneratedToken::joint(':'),
            GeneratedToken::alone(':'),
            GeneratedToken::word(&version.name),
            GeneratedToken::alone(','),
        ]);
    }
    let mut edges = Vec::new();
    let mut adapters: Vec<&AdapterSpec> = declaration.adapters.iter().collect();
    adapters.sort_unstable();
    for adapter in adapters {
        let mut row = path("crate", "Edge");
        row.extend([
            GeneratedToken::joint(':'),
            GeneratedToken::alone(':'),
            GeneratedToken::word("declared"),
        ]);
        let mut arguments = path("crate", "Version");
        arguments.extend([
            GeneratedToken::joint(':'),
            GeneratedToken::alone(':'),
            GeneratedToken::word(&adapter.edge.from),
            GeneratedToken::alone(','),
        ]);
        arguments.extend(path("crate", "Version"));
        arguments.extend([
            GeneratedToken::joint(':'),
            GeneratedToken::alone(':'),
            GeneratedToken::word(&adapter.edge.to),
            GeneratedToken::alone(','),
        ]);
        arguments.extend(path("crate", "AdapterSeat"));
        arguments.extend([
            GeneratedToken::joint(':'),
            GeneratedToken::alone(':'),
            GeneratedToken::word(&adapter.seat),
        ]);
        row.push(bakery::compiler::group(
            GeneratedDelimiter::Parenthesis,
            arguments,
        )?);
        row.push(GeneratedToken::alone(','));
        edges.extend(row);
    }
    let mut tokens = bakery::compiler::documentation("The complete generated version roster.")?;
    tokens.extend([
        GeneratedToken::word("pub"),
        GeneratedToken::word("const"),
        GeneratedToken::word("VERSIONS"),
        GeneratedToken::alone(':'),
        GeneratedToken::alone('&'),
    ]);
    tokens.push(bakery::compiler::group(
        GeneratedDelimiter::Bracket,
        path("crate", "Version"),
    )?);
    tokens.extend([
        GeneratedToken::alone('='),
        GeneratedToken::alone('&'),
        bakery::compiler::group(GeneratedDelimiter::Bracket, versions)?,
        GeneratedToken::alone(';'),
    ]);
    tokens.extend(bakery::compiler::documentation(
        "The complete generated edge and adapter roster.",
    )?);
    tokens.extend([
        GeneratedToken::word("pub"),
        GeneratedToken::word("const"),
        GeneratedToken::word("EDGES"),
        GeneratedToken::alone(':'),
        GeneratedToken::alone('&'),
    ]);
    tokens.push(bakery::compiler::group(
        GeneratedDelimiter::Bracket,
        path("crate", "Edge"),
    )?);
    tokens.extend([
        GeneratedToken::alone('='),
        GeneratedToken::alone('&'),
        bakery::compiler::group(GeneratedDelimiter::Bracket, edges)?,
        GeneratedToken::alone(';'),
    ]);
    Ok(tokens)
}

fn generated_tree(
    declaration: &EvolutionDeclaration,
) -> Result<GeneratedTree, bakery::compiler::RenderError> {
    assembled_tree(declaration, adapter_impl)
}

type AdapterRenderer = fn(&AdapterSpec) -> Result<Vec<GeneratedToken>, bakery::compiler::Overflow>;

fn assembled_tree(
    declaration: &EvolutionDeclaration,
    render_adapter: AdapterRenderer,
) -> Result<GeneratedTree, bakery::compiler::RenderError> {
    let mut tokens = Vec::new();
    for version in declaration.versions.iter() {
        tokens.extend(generated_struct(version)?);
    }
    let mut adapters: Vec<&AdapterSpec> = declaration.adapters.iter().collect();
    adapters.sort_unstable();
    for adapter in adapters {
        tokens.extend(render_adapter(adapter)?);
    }
    tokens.extend(roster_tokens(declaration)?);
    GeneratedTree::assembled(tokens).map_err(bakery::compiler::RenderError::from)
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum RenderStyle {
    Direct,
    Refactored,
}

const _: RenderStyle = RenderStyle::Refactored;

fn refactored_tree(
    declaration: &EvolutionDeclaration,
) -> Result<GeneratedTree, bakery::compiler::RenderError> {
    assembled_tree(declaration, refactored_adapter_impl)
}

pub(crate) fn terminal_with(
    capture: CapturedInput,
    style: RenderStyle,
) -> Result<Expansion<EvolutionProjection>, Diagnostic> {
    let declaration = read_declaration(&capture).map_err(|refusal| refusal.diagnostic())?;
    Request::<EvolutionProjection>::over(capture, declaration, &DOOR).render(|plan, output| {
        match style {
            RenderStyle::Direct => {
                output.unit(EvolutionRole::Graph, generated_tree(plan.content())?)?;
            }
            RenderStyle::Refactored => {
                output.unit(EvolutionRole::Graph, refactored_tree(plan.content())?)?;
            }
        }
        Ok(())
    })
}

pub(crate) fn compile(
    capture: CapturedInput,
) -> Result<Expansion<EvolutionProjection>, Diagnostic> {
    terminal_with(capture, RenderStyle::Direct)
}

pub(crate) fn compile_refactored(
    capture: CapturedInput,
) -> Result<Expansion<EvolutionProjection>, Diagnostic> {
    terminal_with(capture, RenderStyle::Refactored)
}
