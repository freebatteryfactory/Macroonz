//! Subject-owned procedural carrier for the bounded version/evolution pilot.

#![forbid(unsafe_code)]
#![deny(warnings)]

extern crate proc_macro;

mod engine;

use bakery::compiler::host::{self, Spans};
use proc_macro::TokenStream;

/// Emits one subject-owned closed version graph and its exact adapter seats.
#[proc_macro]
pub fn evolution_graph(input: TokenStream) -> TokenStream {
    carried(input, engine::RenderStyle::Direct)
}

/// Emits the same subject-owned graph through the alternate private adapter renderer.
#[proc_macro]
pub fn evolution_graph_refactored(input: TokenStream) -> TokenStream {
    carried(input, engine::RenderStyle::Refactored)
}

fn carried(input: TokenStream, style: engine::RenderStyle) -> TokenStream {
    let mut spans = Spans::empty();
    match host::capture(input, &mut spans) {
        Ok(capture) => match style {
            engine::RenderStyle::Direct => engine::compile(capture),
            engine::RenderStyle::Refactored => engine::compile_refactored(capture),
        }
        .map_or_else(
            |diagnostic| host::place(&diagnostic, &spans),
            |expansion| host::emit(&expansion),
        ),
        Err(refusal) => refusal.placed(&spans),
    }
}
