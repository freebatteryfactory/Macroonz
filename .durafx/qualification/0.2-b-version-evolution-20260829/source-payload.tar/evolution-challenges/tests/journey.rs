//! External version/evolution execution, compile-contract, property, and report crossings.

#![forbid(unsafe_code)]
#![deny(warnings)]

use bakery::harness::clock::{HarnessClock, MeasurementReading};
use bakery::harness::descriptor::{
    AuthoredTableName, Binding, CheckRef, ClaimRef, Classification, DerivedRevision,
    ExecutableAttachment, ExecutionSuite, Origin, PopulationRef, Provenance, RevisionBinding, Role,
    Row, SubjectRoute, Tag,
};
use bakery::harness::oracle::{
    CompilationDisagreement, CompilationVerdict, CompiledDisagreement, CompiledObservation,
    CompiledVerdict, DeclaredBehavior, DeclaredCompilation, DeclaredReadBack,
    DeclaredReadBackRoster, DiagnosticAnchor, ObservedCompilation, ObservedMember, ObservedValue,
    PrimarySourceSpan, RelativeSourcePath, RustcErrorCode, SourcePosition,
};
use bakery::harness::properties::{
    Agreement, ParitySuite, PoisonResponse, RoadPairing, SharedSubstrate, SubstrateRef,
    SubstrateRoster, admits_lawful, fail_closed, parity,
};
use bakery::harness::report::{
    ByteBudget, CaseBudget, CheckRevisionId, FindingLocation, HostTrialRecord, InvocationProfile,
    ReplayPosture, RunAttempt, SubjectRevisionId, TargetBinding, TargetTriple, TimeBudget,
    ToolchainIdentity, TrialConclusion, TrialReport, TrialSite,
};
use bakery::harness::runner::{
    Invocation, Selection, SelectionPlan, TrialBinding, TrialTable, record_all, record_one,
    trial_identity,
};
use evolution_subject::{AdapterSeat, Edge, EvolutionError, Version};
use std::path::Path;
use std::process::{Command, ExitStatus, Output, Stdio};
use std::sync::mpsc::{self, RecvTimeoutError};
use std::time::Duration;

const OWNER: &str = "evolution-challenges";
const TARGET: &str = "x86_64-pc-windows-msvc";
const TOOLCHAIN: &str = "rustc 1.98.0";
const HOST_CEILING: Duration = Duration::from_secs(60);
const BASELINE_VERSIONS: &str = "[V1, V2, V3]";
const BASELINE_EDGES: &str =
    "[Edge { from: V1, to: V2, adapter: V1ToV2 }, Edge { from: V2, to: V3, adapter: V2ToV3 }]";
const PLANTED_EDGES: &str = "[Edge { from: V1, to: V2, adapter: V1ToV2 }, Edge { from: V1, to: V3, adapter: V1ToV3 }, Edge { from: V2, to: V3, adapter: V2ToV3 }]";

struct AdmissionCase {
    stem: &'static str,
    revision_material: &'static [u8],
    conclusion: TrialConclusion,
}

#[derive(Debug, Clone, PartialEq, Eq)]
struct EdgeQuestion {
    from: Version,
    to: Version,
}

#[derive(Debug, Clone, PartialEq, Eq)]
enum EdgeAnswer {
    Admitted,
    Refused,
}

struct EvolutionInput(u64);

struct ReadbackClaims {
    generated: CompiledVerdict,
    refactored: CompiledVerdict,
    handwritten: CompiledVerdict,
    planted: CompiledVerdict,
    wrong: CompiledVerdict,
}

struct PropertyClaims {
    generated_refactored: TrialConclusion,
    generated_handwritten: TrialConclusion,
    planted_composition: TrialConclusion,
    lawful: TrialConclusion,
    undeclared: TrialConclusion,
    wrong_adapter: TrialConclusion,
}

struct DiagnosticClaims {
    direct: CompilationVerdict,
    removed: CompilationVerdict,
    wrong_code: CompilationVerdict,
    wrong_span: CompilationVerdict,
}

#[test]
fn version_evolution_journey_executes_and_enters_report_standing() -> Result<(), String> {
    prove_host()?;
    assert_complete_public_rosters();
    admit(&admission_cases()?)
}

fn admission_cases() -> Result<Vec<AdmissionCase>, String> {
    let readback = readback_claims()?;
    let properties = property_claims()?;
    let diagnostics = diagnostic_claims()?;
    Ok(vec![
        case(
            "generated-readback",
            include_bytes!("../src/bin/generated_readback.rs"),
            readback
                .generated
                .concluded(FindingLocation::at(file!(), line!())),
        ),
        case(
            "refactored-readback",
            include_bytes!("../src/bin/refactored_readback.rs"),
            readback
                .refactored
                .concluded(FindingLocation::at(file!(), line!())),
        ),
        case(
            "handwritten-readback",
            include_bytes!("../src/bin/handwritten_readback.rs"),
            readback
                .handwritten
                .concluded(FindingLocation::at(file!(), line!())),
        ),
        case(
            "planted-readback",
            include_bytes!("../src/bin/planted_readback.rs"),
            readback
                .planted
                .concluded(FindingLocation::at(file!(), line!())),
        ),
        case(
            "generated-refactored-parity",
            include_bytes!("../../evolution-subject/src/lib.rs"),
            properties.generated_refactored,
        ),
        case(
            "generated-handwritten-parity",
            include_bytes!("../../evolution-subject/src/lib.rs"),
            properties.generated_handwritten,
        ),
        case(
            "planted-direct-composed-parity",
            include_bytes!("../../evolution-subject/src/lib.rs"),
            properties.planted_composition,
        ),
        case(
            "lawful-edge-admission",
            include_bytes!("../../evolution-subject/src/lib.rs"),
            properties.lawful,
        ),
        case(
            "undeclared-edge-fail-closed",
            include_bytes!("../../evolution-subject/src/lib.rs"),
            properties.undeclared,
        ),
        case(
            "wrong-adapter-control",
            include_bytes!("journey.rs"),
            properties.wrong_adapter,
        ),
        case(
            "wrong-readback-control",
            include_bytes!("../src/bin/generated_readback.rs"),
            readback
                .wrong
                .concluded(FindingLocation::at(file!(), line!())),
        ),
        case(
            "direct-edge-refusal",
            include_bytes!("../src/bin/direct_edge.rs"),
            diagnostics
                .direct
                .concluded(FindingLocation::at(file!(), line!())),
        ),
        case(
            "macro-removed-refusal",
            include_bytes!("../src/bin/macro_removed.rs"),
            diagnostics
                .removed
                .concluded(FindingLocation::at(file!(), line!())),
        ),
        case(
            "wrong-diagnostic-code-control",
            include_bytes!("../src/bin/macro_removed.rs"),
            diagnostics
                .wrong_code
                .concluded(FindingLocation::at(file!(), line!())),
        ),
        case(
            "wrong-diagnostic-span-control",
            include_bytes!("../src/bin/macro_removed.rs"),
            diagnostics
                .wrong_span
                .concluded(FindingLocation::at(file!(), line!())),
        ),
    ])
}

fn readback_claims() -> Result<ReadbackClaims, String> {
    let generated = baseline_readback(
        env!("CARGO_BIN_EXE_generated_readback"),
        "generated-readback",
    )?;
    let handwritten = baseline_readback(
        env!("CARGO_BIN_EXE_handwritten_readback"),
        "handwritten-readback",
    )?;
    let refactored = baseline_readback(
        env!("CARGO_BIN_EXE_refactored_readback"),
        "refactored-readback",
    )?;
    let planted = planted_readback()?;
    let baseline_contract = baseline_contract()?;
    let generated_verdict = bakery::harness::oracle::compiled::compared(
        &generated,
        &DeclaredBehavior::ReadsBack(baseline_contract),
    );
    let handwritten_verdict = bakery::harness::oracle::compiled::compared(
        &handwritten,
        &DeclaredBehavior::ReadsBack(baseline_contract),
    );
    let refactored_verdict = bakery::harness::oracle::compiled::compared(
        &refactored,
        &DeclaredBehavior::ReadsBack(baseline_contract),
    );
    assert_eq!(generated_verdict, CompiledVerdict::Conforms);
    assert_eq!(handwritten_verdict, CompiledVerdict::Conforms);
    assert_eq!(refactored_verdict, CompiledVerdict::Conforms);

    let planted_members = [
        DeclaredReadBack {
            name: "DIRECT",
            value: ObservedValue::Count(19),
        },
        DeclaredReadBack {
            name: "COMPOSED",
            value: ObservedValue::Count(19),
        },
        DeclaredReadBack {
            name: "VERSIONS",
            value: ObservedValue::Text(BASELINE_VERSIONS.to_owned()),
        },
        DeclaredReadBack {
            name: "EDGES",
            value: ObservedValue::Text(PLANTED_EDGES.to_owned()),
        },
    ];
    let planted_contract = DeclaredReadBackRoster::declared(&planted_members)
        .map_err(|refusal| format!("planted read-back roster refused: {refusal:?}"))?;
    let planted_verdict = bakery::harness::oracle::compiled::compared(
        &planted,
        &DeclaredBehavior::ReadsBack(planted_contract),
    );
    assert_eq!(planted_verdict, CompiledVerdict::Conforms);

    let wrong_members = [
        DeclaredReadBack {
            name: "VALUE",
            value: ObservedValue::Count(20),
        },
        DeclaredReadBack {
            name: "VERSIONS",
            value: ObservedValue::Text(BASELINE_VERSIONS.to_owned()),
        },
        DeclaredReadBack {
            name: "EDGES",
            value: ObservedValue::Text(BASELINE_EDGES.to_owned()),
        },
    ];
    let wrong_contract = DeclaredReadBackRoster::declared(&wrong_members)
        .map_err(|refusal| format!("wrong read-back roster refused: {refusal:?}"))?;
    let wrong_readback = bakery::harness::oracle::compiled::compared(
        &generated,
        &DeclaredBehavior::ReadsBack(wrong_contract),
    );
    assert_eq!(
        wrong_readback,
        CompiledVerdict::Deviates(CompiledDisagreement::MemberValue {
            member: "VALUE".to_owned(),
        })
    );
    Ok(ReadbackClaims {
        generated: generated_verdict,
        refactored: refactored_verdict,
        handwritten: handwritten_verdict,
        planted: planted_verdict,
        wrong: wrong_readback,
    })
}

fn property_claims() -> Result<PropertyClaims, String> {
    let refactored_conclusion = generated_refactored_parity()?;
    let parity_conclusion = generated_handwritten_parity()?;
    let planted_parity_conclusion = planted_direct_composed_parity()?;
    let wrong_adapter_conclusion = wrong_adapter_control()?;
    let lawful = admits_lawful(
        baseline_edge_answer,
        edge_answer_reading,
        &EdgeQuestion {
            from: Version::V1,
            to: Version::V2,
        },
    );
    let undeclared = fail_closed(
        baseline_edge_answer,
        edge_answer_reading,
        &EdgeQuestion {
            from: Version::V1,
            to: Version::V3,
        },
    );
    assert_eq!(lawful, TrialConclusion::Passed);
    assert_eq!(undeclared, TrialConclusion::Passed);
    Ok(PropertyClaims {
        generated_refactored: refactored_conclusion,
        generated_handwritten: parity_conclusion,
        planted_composition: planted_parity_conclusion,
        lawful,
        undeclared,
        wrong_adapter: wrong_adapter_conclusion,
    })
}

fn diagnostic_claims() -> Result<DiagnosticClaims, String> {
    let direct_anchor = anchor(
        "E0277",
        "evolution-challenges/src/bin/direct_edge.rs",
        11,
        10,
        42,
    )?;
    let observed_direct = observed_refusal(
        "direct-edge",
        "direct-edge",
        "direct_edge.rs",
        &direct_anchor,
    )?;
    let direct_verdict = bakery::harness::oracle::compiled::compared_compilation(
        &observed_direct,
        &DeclaredCompilation::refuses(direct_anchor),
    );
    assert_eq!(direct_verdict, CompilationVerdict::Conforms);

    let removed_anchor = anchor(
        "E0425",
        "evolution-challenges/src/bin/macro_removed.rs",
        7,
        17,
        28,
    )?;
    let observed_removed = observed_refusal(
        "macro-removed",
        "macro-removed",
        "macro_removed.rs",
        &removed_anchor,
    )?;
    let removed_verdict = bakery::harness::oracle::compiled::compared_compilation(
        &observed_removed,
        &DeclaredCompilation::refuses(removed_anchor.clone()),
    );
    assert_eq!(removed_verdict, CompilationVerdict::Conforms);

    let wrong_code_anchor = anchor(
        "E0433",
        "evolution-challenges/src/bin/macro_removed.rs",
        7,
        17,
        28,
    )?;
    let wrong_code = bakery::harness::oracle::compiled::compared_compilation(
        &observed_removed,
        &DeclaredCompilation::refuses(wrong_code_anchor.clone()),
    );
    assert_eq!(
        wrong_code,
        CompilationVerdict::Deviates(CompilationDisagreement::ErrorCode {
            expected: wrong_code_anchor.code().clone(),
            observed: removed_anchor.code().clone(),
        })
    );
    let wrong_span_anchor = anchor(
        "E0425",
        "evolution-challenges/src/bin/macro_removed.rs",
        7,
        18,
        28,
    )?;
    let wrong_span = bakery::harness::oracle::compiled::compared_compilation(
        &observed_removed,
        &DeclaredCompilation::refuses(wrong_span_anchor.clone()),
    );
    assert_eq!(
        wrong_span,
        CompilationVerdict::Deviates(CompilationDisagreement::PrimarySpan {
            expected: wrong_span_anchor.primary().clone(),
            observed: removed_anchor.primary().clone(),
        })
    );
    Ok(DiagnosticClaims {
        direct: direct_verdict,
        removed: removed_verdict,
        wrong_code,
        wrong_span,
    })
}

const fn case(
    stem: &'static str,
    revision_material: &'static [u8],
    conclusion: TrialConclusion,
) -> AdmissionCase {
    AdmissionCase {
        stem,
        revision_material,
        conclusion,
    }
}

fn baseline_contract() -> Result<DeclaredReadBackRoster<'static>, String> {
    static MEMBERS: std::sync::LazyLock<[DeclaredReadBack<'static>; 3]> =
        std::sync::LazyLock::new(|| {
            [
                DeclaredReadBack {
                    name: "VALUE",
                    value: ObservedValue::Count(19),
                },
                DeclaredReadBack {
                    name: "VERSIONS",
                    value: ObservedValue::Text(BASELINE_VERSIONS.to_owned()),
                },
                DeclaredReadBack {
                    name: "EDGES",
                    value: ObservedValue::Text(BASELINE_EDGES.to_owned()),
                },
            ]
        });
    DeclaredReadBackRoster::declared(&*MEMBERS)
        .map_err(|refusal| format!("baseline read-back roster refused: {refusal:?}"))
}

fn assert_complete_public_rosters() {
    let versions = [Version::V1, Version::V2, Version::V3];
    let baseline_edges = [
        Edge::declared(Version::V1, Version::V2, AdapterSeat::V1ToV2),
        Edge::declared(Version::V2, Version::V3, AdapterSeat::V2ToV3),
    ];
    let planted_edges = [
        Edge::declared(Version::V1, Version::V2, AdapterSeat::V1ToV2),
        Edge::declared(Version::V1, Version::V3, AdapterSeat::V1ToV3),
        Edge::declared(Version::V2, Version::V3, AdapterSeat::V2ToV3),
    ];
    assert_eq!(Version::ALL, versions);
    assert_eq!(evolution_subject::generated::VERSIONS, versions);
    assert_eq!(evolution_subject::refactored::VERSIONS, versions);
    assert_eq!(evolution_subject::handwritten::VERSIONS, versions);
    assert_eq!(evolution_subject::planted::VERSIONS, versions);
    assert_eq!(evolution_subject::generated::EDGES, baseline_edges);
    assert_eq!(evolution_subject::refactored::EDGES, baseline_edges);
    assert_eq!(evolution_subject::handwritten::EDGES, baseline_edges);
    assert_eq!(evolution_subject::planted::EDGES, planted_edges);
}

fn generated_road(value: &EvolutionInput) -> Result<u64, EvolutionError> {
    evolution_challenges::generated_path(value.0)
}

fn refactored_road(value: &EvolutionInput) -> Result<u64, EvolutionError> {
    evolution_challenges::refactored_path(value.0)
}

fn handwritten_road(value: &EvolutionInput) -> Result<u64, EvolutionError> {
    evolution_challenges::handwritten_path(value.0)
}

fn planted_direct_road(value: &EvolutionInput) -> Result<u64, EvolutionError> {
    evolution_challenges::planted_direct_path(value.0)
}

fn planted_composed_road(value: &EvolutionInput) -> Result<u64, EvolutionError> {
    evolution_challenges::planted_composed_path(value.0)
}

fn wrong_adapter_road(value: &EvolutionInput) -> Result<u64, EvolutionError> {
    value.0.checked_add(13).ok_or(EvolutionError::Overflow)
}

fn same_result(
    left: &Result<u64, EvolutionError>,
    right: &Result<u64, EvolutionError>,
) -> Agreement {
    if left == right {
        Agreement::Agrees
    } else {
        Agreement::Differs
    }
}

fn shared_substrate() -> Result<SharedSubstrate, String> {
    let standing = [
        SubstrateRef::named(OWNER, "subject-public-evolve-contract")
            .map_err(|refusal| format!("contract substrate refused: {refusal:?}"))?,
        SubstrateRef::named(OWNER, "subject-version-edge-vocabulary")
            .map_err(|refusal| format!("vocabulary substrate refused: {refusal:?}"))?,
        SubstrateRef::named(OWNER, "subject-adapter-arithmetic-declaration")
            .map_err(|refusal| format!("arithmetic substrate refused: {refusal:?}"))?,
        SubstrateRef::named(OWNER, "subject-source-package-revision")
            .map_err(|refusal| format!("source substrate refused: {refusal:?}"))?,
    ];
    SubstrateRoster::declared(&standing)
        .map(SharedSubstrate::Standing)
        .map_err(|refusal| format!("shared substrate roster refused: {refusal:?}"))
}

fn generated_handwritten_parity() -> Result<TrialConclusion, String> {
    let pairing = RoadPairing::Declared(
        bakery::harness::descriptor::NamespacedName::named(
            OWNER,
            "generated-versus-handwritten-evolution",
        )
        .map_err(|refusal| format!("parity name refused: {refusal:?}"))?,
    );
    let suite = ParitySuite::over(
        pairing,
        generated_road,
        handwritten_road,
        same_result,
        shared_substrate()?,
    );
    let reading = parity(&suite, &EvolutionInput(7));
    assert_eq!(reading.left(), &Ok(19));
    assert_eq!(reading.right(), &Ok(19));
    Ok(reading.conclusion().clone())
}

fn generated_refactored_parity() -> Result<TrialConclusion, String> {
    let pairing = RoadPairing::Declared(
        bakery::harness::descriptor::NamespacedName::named(
            OWNER,
            "generated-versus-refactored-renderer",
        )
        .map_err(|refusal| format!("refactored parity name refused: {refusal:?}"))?,
    );
    let suite = ParitySuite::over(
        pairing,
        generated_road,
        refactored_road,
        same_result,
        shared_substrate()?,
    );
    let reading = parity(&suite, &EvolutionInput(7));
    assert_eq!(reading.left(), &Ok(19));
    assert_eq!(reading.right(), &Ok(19));
    Ok(reading.conclusion().clone())
}

fn planted_direct_composed_parity() -> Result<TrialConclusion, String> {
    let suite = ParitySuite::fused_versus_separate(
        planted_direct_road,
        planted_composed_road,
        same_result,
        shared_substrate()?,
    );
    let reading = parity(&suite, &EvolutionInput(7));
    assert_eq!(reading.left(), &Ok(19));
    assert_eq!(reading.right(), &Ok(19));
    Ok(reading.conclusion().clone())
}

fn wrong_adapter_control() -> Result<TrialConclusion, String> {
    let pairing = RoadPairing::Declared(
        bakery::harness::descriptor::NamespacedName::named(OWNER, "wrong-adapter-control")
            .map_err(|refusal| format!("wrong-adapter pairing refused: {refusal:?}"))?,
    );
    let suite = ParitySuite::over(
        pairing,
        planted_direct_road,
        wrong_adapter_road,
        same_result,
        shared_substrate()?,
    );
    let reading = parity(&suite, &EvolutionInput(7));
    assert_eq!(reading.left(), &Ok(19));
    assert_eq!(reading.right(), &Ok(20));
    assert!(matches!(reading.conclusion(), TrialConclusion::Refused(_)));
    Ok(reading.conclusion().clone())
}

fn baseline_edge_answer(question: &EdgeQuestion) -> EdgeAnswer {
    let admitted = evolution_subject::generated::EDGES
        .iter()
        .any(|edge| edge.from() == question.from && edge.to() == question.to);
    if admitted {
        EdgeAnswer::Admitted
    } else {
        EdgeAnswer::Refused
    }
}

const fn edge_answer_reading(answer: &EdgeAnswer) -> PoisonResponse {
    match answer {
        EdgeAnswer::Admitted => PoisonResponse::Answered,
        EdgeAnswer::Refused => PoisonResponse::Refused,
    }
}

fn baseline_readback(executable: &str, stem: &str) -> Result<CompiledObservation, String> {
    let expected = format!("VALUE=19;VERSIONS={BASELINE_VERSIONS};EDGES={BASELINE_EDGES}");
    execute_readback(
        executable,
        stem,
        &expected,
        vec![
            ObservedMember {
                name: "VALUE".to_owned(),
                value: ObservedValue::Count(19),
            },
            ObservedMember {
                name: "VERSIONS".to_owned(),
                value: ObservedValue::Text(BASELINE_VERSIONS.to_owned()),
            },
            ObservedMember {
                name: "EDGES".to_owned(),
                value: ObservedValue::Text(BASELINE_EDGES.to_owned()),
            },
        ],
    )
}

fn planted_readback() -> Result<CompiledObservation, String> {
    let expected =
        format!("DIRECT=19;COMPOSED=19;VERSIONS={BASELINE_VERSIONS};EDGES={PLANTED_EDGES}");
    execute_readback(
        env!("CARGO_BIN_EXE_planted_readback"),
        "planted-readback",
        &expected,
        vec![
            ObservedMember {
                name: "DIRECT".to_owned(),
                value: ObservedValue::Count(19),
            },
            ObservedMember {
                name: "COMPOSED".to_owned(),
                value: ObservedValue::Count(19),
            },
            ObservedMember {
                name: "VERSIONS".to_owned(),
                value: ObservedValue::Text(BASELINE_VERSIONS.to_owned()),
            },
            ObservedMember {
                name: "EDGES".to_owned(),
                value: ObservedValue::Text(PLANTED_EDGES.to_owned()),
            },
        ],
    )
}

fn execute_readback(
    executable: &str,
    stem: &str,
    expected: &str,
    members: Vec<ObservedMember>,
) -> Result<CompiledObservation, String> {
    let mut command = Command::new(executable);
    let output = bounded_output(&mut command, stem)?;
    if !output.status.success() {
        return Err(format!(
            "{stem} failed with status {:?}: {}",
            output.status.code(),
            String::from_utf8_lossy(&output.stderr)
        ));
    }
    let stdout = String::from_utf8(output.stdout)
        .map_err(|error| format!("{stem} stdout was not UTF-8: {error}"))?;
    if stdout.trim() != expected {
        return Err(format!(
            "{stem} read-back differed: expected {expected:?}, observed {stdout:?}"
        ));
    }
    Ok(CompiledObservation::ReadBack(members))
}

fn observed_refusal(
    feature: &str,
    binary: &str,
    file_name: &str,
    expected: &DiagnosticAnchor,
) -> Result<ObservedCompilation, String> {
    let workspace = workspace()?;
    let mut command = Command::new(env!("CARGO"));
    command.current_dir(workspace).args([
        "check",
        "--manifest-path",
        "Cargo.toml",
        "-p",
        "evolution-challenges",
        "--bin",
        binary,
        "--features",
        feature,
        "--locked",
        "--offline",
        "--target",
        TARGET,
        "--target-dir",
        &format!("{binary}-runtime-target"),
        "--jobs",
        "1",
        "--message-format=json",
    ]);
    let output = bounded_output(&mut command, binary)?;
    if output.status.success() {
        return Err(format!(
            "{binary} compiler challenge unexpectedly succeeded"
        ));
    }
    let stdout = String::from_utf8(output.stdout)
        .map_err(|error| format!("{binary} Cargo JSON was not UTF-8: {error}"))?;
    let path_marker =
        format!("\"file_name\":\"evolution-challenges\\\\src\\\\bin\\\\{file_name}\"");
    let code_marker = format!("\"code\":\"{}\"", expected.code().spelling());
    let line = stdout
        .lines()
        .find(|line| line.contains(&path_marker) && line.contains(&code_marker))
        .ok_or_else(|| format!("{binary} exact stable diagnostic was absent"))?;
    for marker in [
        "\"is_primary\":true".to_owned(),
        format!("\"line_start\":{}", expected.primary().start().line()),
        format!("\"line_end\":{}", expected.primary().end().line()),
        format!("\"column_start\":{}", expected.primary().start().column()),
        format!("\"column_end\":{}", expected.primary().end().column()),
    ] {
        if !line.contains(&marker) {
            return Err(format!("{binary} diagnostic omitted {marker}"));
        }
    }
    Ok(ObservedCompilation::refused(expected.clone()))
}

fn anchor(
    code: &str,
    source: &str,
    line: u64,
    column_start: u64,
    column_end: u64,
) -> Result<DiagnosticAnchor, String> {
    let source = RelativeSourcePath::informed(source)
        .map_err(|refusal| format!("diagnostic source refused: {refusal:?}"))?;
    let start = SourcePosition::informed(line, column_start)
        .map_err(|refusal| format!("diagnostic start refused: {refusal:?}"))?;
    let end = SourcePosition::informed(line, column_end)
        .map_err(|refusal| format!("diagnostic end refused: {refusal:?}"))?;
    let primary = PrimarySourceSpan::informed(source, start, end)
        .map_err(|refusal| format!("diagnostic span refused: {refusal:?}"))?;
    let code = RustcErrorCode::informed(code)
        .map_err(|refusal| format!("diagnostic code refused: {refusal:?}"))?;
    Ok(DiagnosticAnchor::at(code, primary))
}

fn prove_host() -> Result<(), String> {
    let rustc_path = Path::new(env!("CARGO")).with_file_name("rustc.exe");
    let mut rustc_command = Command::new(rustc_path);
    rustc_command.arg("-vV");
    let rustc = bounded_output(&mut rustc_command, "rustc-host")?;
    if !rustc.status.success() {
        return Err("rustc host preflight failed".to_owned());
    }
    let facts = String::from_utf8(rustc.stdout)
        .map_err(|error| format!("rustc host preflight was not UTF-8: {error}"))?;
    if !(facts.contains("release: 1.98.0") && facts.contains(&format!("host: {TARGET}"))) {
        return Err(format!("unexpected rustc host facts: {facts}"));
    }
    let mut cargo_command = Command::new(env!("CARGO"));
    cargo_command.args(["--version", "--verbose"]);
    let cargo = bounded_output(&mut cargo_command, "cargo-host")?;
    if !cargo.status.success() {
        return Err("cargo host preflight failed".to_owned());
    }
    let cargo_facts = String::from_utf8(cargo.stdout)
        .map_err(|error| format!("cargo host preflight was not UTF-8: {error}"))?;
    if !cargo_facts.starts_with("cargo 1.98.0 ") {
        return Err(format!("unexpected cargo host facts: {cargo_facts}"));
    }
    Ok(())
}

fn workspace() -> Result<&'static Path, String> {
    Path::new(env!("CARGO_MANIFEST_DIR"))
        .parent()
        .ok_or_else(|| "challenge package had no workspace parent".to_owned())
}

fn bounded_output(command: &mut Command, stem: &str) -> Result<Output, String> {
    let evidence = workspace()?.join("evidence").join("runtime");
    std::fs::create_dir_all(&evidence)
        .map_err(|error| format!("runtime evidence directory was not writable: {error}"))?;
    let stdout_path = evidence.join(format!("{stem}-stdout.bin"));
    let stderr_path = evidence.join(format!("{stem}-stderr.bin"));
    let stdout = std::fs::File::create(&stdout_path)
        .map_err(|error| format!("{stem} stdout evidence was not writable: {error}"))?;
    let stderr = std::fs::File::create(&stderr_path)
        .map_err(|error| format!("{stem} stderr evidence was not writable: {error}"))?;
    let child = command
        .stdout(Stdio::from(stdout))
        .stderr(Stdio::from(stderr))
        .spawn()
        .map_err(|error| format!("{stem} was not runnable: {error}"))?;
    let status = wait_under_ceiling(child, stem)?;
    output_from_files(status, &stdout_path, &stderr_path, stem)
}

fn wait_under_ceiling(mut child: std::process::Child, stem: &str) -> Result<ExitStatus, String> {
    let process_id = child.id();
    let (sender, receiver) = mpsc::sync_channel(1);
    let waiter = std::thread::spawn(move || {
        let result = child.wait();
        let _sent = sender.send(result);
    });
    let status = match receiver.recv_timeout(HOST_CEILING) {
        Ok(result) => result.map_err(|error| format!("{stem} status was not readable: {error}"))?,
        Err(RecvTimeoutError::Timeout) => {
            terminate_process_tree(process_id, stem)?;
            let _after_kill = receiver.recv().map_err(|error| {
                format!("{stem} waiter disconnected after termination: {error}")
            })?;
            return Err(format!(
                "{stem} exceeded the exact {} second host ceiling",
                HOST_CEILING.as_secs()
            ));
        }
        Err(RecvTimeoutError::Disconnected) => {
            return Err(format!(
                "{stem} waiter disconnected before reporting status"
            ));
        }
    };
    if waiter.join().is_err() {
        return Err(format!("{stem} waiter unwound"));
    }
    Ok(status)
}

fn terminate_process_tree(process_id: u32, stem: &str) -> Result<(), String> {
    let system_root = option_env!("SystemRoot")
        .ok_or_else(|| format!("{stem} exceeded its ceiling but SystemRoot was unavailable"))?;
    let taskkill = Path::new(system_root).join("System32").join("taskkill.exe");
    let status = Command::new(taskkill)
        .args(["/PID", &process_id.to_string(), "/T", "/F"])
        .status()
        .map_err(|error| {
            format!("{stem} exceeded its ceiling and taskkill was not runnable: {error}")
        })?;
    if status.success() {
        Ok(())
    } else {
        Err(format!(
            "{stem} exceeded its ceiling and taskkill returned {:?}",
            status.code()
        ))
    }
}

fn output_from_files(
    status: ExitStatus,
    stdout_path: &Path,
    stderr_path: &Path,
    stem: &str,
) -> Result<Output, String> {
    let stdout = std::fs::read(stdout_path)
        .map_err(|error| format!("{stem} stdout evidence was not readable: {error}"))?;
    let stderr = std::fs::read(stderr_path)
        .map_err(|error| format!("{stem} stderr evidence was not readable: {error}"))?;
    Ok(Output {
        status,
        stdout,
        stderr,
    })
}

fn retained_check(_: &Invocation) -> TrialConclusion {
    TrialConclusion::Passed
}

fn admit(cases: &[AdmissionCase]) -> Result<(), String> {
    let check_revision =
        RevisionBinding::derived(DerivedRevision::from_material(include_bytes!("journey.rs")));
    let invocation = invocation();
    let mut bindings = Vec::with_capacity(cases.len());
    let mut records = Vec::with_capacity(cases.len());
    for case in cases {
        let subject_revision =
            RevisionBinding::derived(DerivedRevision::from_material(case.revision_material));
        let binding = binding(case.stem, subject_revision, check_revision)?;
        let record = HostTrialRecord::recorded(
            trial_identity(binding.row()),
            RunAttempt::Executed(case.conclusion.clone()),
            MeasurementReading::Unavailable,
        );
        let report = record_one(&binding, &invocation, record.clone())
            .map_err(|refusal| format!("record_one refused {}: {refusal:?}", case.stem))?;
        assert_report(&report, case, subject_revision, check_revision)?;
        bindings.push(binding);
        records.push(record);
    }
    let table = TrialTable::authored(
        AuthoredTableName::named(OWNER, "version-evolution-journey")
            .map_err(|refusal| format!("table name refused: {refusal:?}"))?,
        Provenance::Unproduced,
        bindings,
    )
    .map_err(|refusal| format!("trial table refused: {refusal:?}"))?;
    let report = record_all(
        &table.view(),
        &SelectionPlan::of(Selection::All),
        &invocation,
        records,
    )
    .map_err(|refusal| format!("record_all refused: {refusal:?}"))?;
    assert_eq!(report.denominator(), cases.len());
    for (case, accounting) in cases.iter().zip(report.census()) {
        let admitted = accounting
            .disposition()
            .report()
            .ok_or_else(|| format!("{} was not selected", case.stem))?;
        let subject_revision =
            RevisionBinding::derived(DerivedRevision::from_material(case.revision_material));
        assert_report(admitted, case, subject_revision, check_revision)?;
    }
    Ok(())
}

fn binding(
    stem: &'static str,
    subject_revision: RevisionBinding,
    check_revision: RevisionBinding,
) -> Result<TrialBinding, String> {
    let subject = SubjectRoute::named(OWNER, stem)
        .map_err(|refusal| format!("subject route refused: {refusal:?}"))?;
    let check = CheckRef::named(OWNER, "version-evolution-judge")
        .map_err(|refusal| format!("check reference refused: {refusal:?}"))?;
    let row = Row::declared(
        ClaimRef::named(OWNER, "subject-owned-version-evolution")
            .map_err(|refusal| format!("claim reference refused: {refusal:?}"))?,
        ExecutionSuite::named(OWNER, "external-evolution-challenges")
            .map_err(|refusal| format!("execution suite refused: {refusal:?}"))?,
        Classification::authored(
            vec![
                Role::named(OWNER, "version-evolution")
                    .map_err(|refusal| format!("role refused: {refusal:?}"))?,
            ],
            vec![Tag::named(OWNER, stem).map_err(|refusal| format!("tag refused: {refusal:?}"))?],
        )
        .map_err(|refusal| format!("classification refused: {refusal:?}"))?,
        subject,
        check,
        PopulationRef::named(OWNER, "fixed-external-challenges")
            .map_err(|refusal| format!("population refused: {refusal:?}"))?,
        Origin::HandWritten,
    )
    .map_err(|refusal| format!("row refused: {refusal:?}"))?;
    Binding::bound(
        row,
        ExecutableAttachment::attached(
            subject,
            check,
            subject_revision,
            check_revision,
            retained_check,
        ),
        Provenance::Unproduced,
    )
    .map_err(|refusal| format!("binding refused: {refusal:?}"))
}

fn invocation() -> Invocation {
    Invocation::declared(
        InvocationProfile::declared(
            CaseBudget::declared(1),
            ByteBudget::declared(4_096),
            TimeBudget::declared(60_000_000_000),
        ),
        TargetBinding::bound(
            TargetTriple::declared(TARGET),
            ToolchainIdentity::declared(TOOLCHAIN),
        ),
        TrialSite::located(
            module_path!(),
            file!(),
            line!(),
            "version-evolution-journey",
        ),
        HarnessClock::unavailable(),
    )
}

fn assert_report(
    report: &TrialReport,
    case: &AdmissionCase,
    subject_revision: RevisionBinding,
    check_revision: RevisionBinding,
) -> Result<(), String> {
    let standing = report.standing();
    let key = standing.key();
    assert_eq!(key.target().target().spelling(), TARGET);
    assert_eq!(key.target().toolchain().spelling(), TOOLCHAIN);
    assert_eq!(
        key.subject(),
        SubjectRevisionId::of_binding(subject_revision)
    );
    assert_eq!(key.check(), CheckRevisionId::of_binding(check_revision));
    assert_eq!(standing.replay(), ReplayPosture::ExactDerived);
    let expected = RunAttempt::Executed(case.conclusion.clone());
    if report.attempt() != &expected {
        return Err(format!(
            "{} carried an unexpected report attempt: {:?}",
            case.stem,
            report.attempt()
        ));
    }
    Ok(())
}
