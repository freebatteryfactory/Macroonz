//! External challenge operations for the subject-owned version/evolution pilot.

#![forbid(unsafe_code)]
#![deny(warnings)]

use evolution_subject::EvolveTo;

/// Executes the generated baseline graph from V1 through V3.
///
/// # Errors
///
/// Returns the subject's typed evolution refusal when either admitted adapter cannot represent its output.
pub fn generated_path(value: u64) -> Result<u64, evolution_subject::EvolutionError> {
    let v1 = evolution_subject::generated::V1(value);
    let v2: evolution_subject::generated::V2 = v1.evolve()?;
    let v3: evolution_subject::generated::V3 = v2.evolve()?;
    Ok(v3.0)
}

/// Executes the refactored-renderer baseline graph from V1 through V3.
///
/// # Errors
///
/// Returns the subject's typed evolution refusal when either admitted adapter cannot represent its output.
pub fn refactored_path(value: u64) -> Result<u64, evolution_subject::EvolutionError> {
    let v1 = evolution_subject::refactored::V1(value);
    let v2: evolution_subject::refactored::V2 = v1.evolve()?;
    let v3: evolution_subject::refactored::V3 = v2.evolve()?;
    Ok(v3.0)
}

/// Executes the handwritten baseline graph from V1 through V3.
///
/// # Errors
///
/// Returns the subject's typed evolution refusal when either admitted adapter cannot represent its output.
pub fn handwritten_path(value: u64) -> Result<u64, evolution_subject::EvolutionError> {
    let v1 = evolution_subject::handwritten::V1::new(value);
    let v2: evolution_subject::handwritten::V2 = v1.evolve()?;
    let v3: evolution_subject::handwritten::V3 = v2.evolve()?;
    Ok(v3.value())
}

/// Executes the planted direct V1-to-V3 generated edge.
///
/// # Errors
///
/// Returns the subject's typed evolution refusal when the planted adapter cannot represent its output.
pub fn planted_direct_path(value: u64) -> Result<u64, evolution_subject::EvolutionError> {
    let v1 = evolution_subject::planted::V1(value);
    let v3: evolution_subject::planted::V3 = v1.evolve()?;
    Ok(v3.0)
}

/// Executes the planted graph through its unchanged baseline edge sequence.
///
/// # Errors
///
/// Returns the subject's typed evolution refusal when either unchanged adapter cannot represent its output.
pub fn planted_composed_path(value: u64) -> Result<u64, evolution_subject::EvolutionError> {
    let v1 = evolution_subject::planted::V1(value);
    let v2: evolution_subject::planted::V2 = v1.evolve()?;
    let v3: evolution_subject::planted::V3 = v2.evolve()?;
    Ok(v3.0)
}
